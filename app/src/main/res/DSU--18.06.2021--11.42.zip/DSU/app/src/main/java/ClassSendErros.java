import android.content.Context;

public class ClassSendErros {
    public ClassSendErros(Context context) {
    }
}
