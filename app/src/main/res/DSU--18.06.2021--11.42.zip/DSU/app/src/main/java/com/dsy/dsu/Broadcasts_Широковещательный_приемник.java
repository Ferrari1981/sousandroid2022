package com.dsy.dsu;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.loader.content.AsyncTaskLoader;
import androidx.loader.content.Loader;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ListenableWorker;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Broadcasts_Широковещательный_приемник extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        try {

            Log.i(this.getClass().getName(), " Внутри Broadcatrecever (intent.getAction()   СЛУЖБА" +(intent.getAction().toString())+" время запуска  " +new Date());

            // TODO: 18.04.2021 запувскает широковещатель
            if (intent.getAction().equals(Intent.ACTION_SCREEN_ON) || intent.getAction().equals(Intent.ACTION_SYNC) ||
                    intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED) ||
                    intent.getAction().equals(Intent.ACTION_LOCKED_BOOT_COMPLETED) ||
                intent.getAction().equals(Intent.ACTION_SCREEN_OFF)
                    || intent.getAction().equals(Intent. ACTION_REBOOT)) {
                ///
                Log.i(this.getClass().getName(), " Внутри Broadcatrecever (intent.getAction()   СЛУЖБА" +(intent.getAction().toString()));





               PendingResult pendingResult=goAsync();






                        ////TODO ЗАПУСК СЛЛУЖБЫ . Notifications и UpdateПО
                        Log.i(this.getClass().getName(), " Внутри Broadcatrecever (intent.getAction()   СЛУЖБА   new ExecutorService " +(intent.getAction().toString())+
                                " Название ПОтока внутри синхрониазции  и Уведомдения" +Thread.currentThread().getName().toString());


                        МетодЗапускаСинхоронизацииИзШироковещательногоПриёмника(context);
                        /////


                        МетодЗапускаСлужбВШировоВещятелеУведомления(context);


 

                        pendingResult.finish();
                        ///



///////////////////

                /////





                // TODO: 22.04.2021  srart JOBschedele
            Log.d(this.getClass().getName(), "ВЫХОД ПОСЛЕ ОТРАБОТКИ СЛУЖБА ВНУТРИ startService   Вещятеля BroadcastReceiver" +
                    "  Synchronizasiy_Data pendingIntent ExecutorService ");

          /*  МетодЗапускаJOBВШироковещательном_Применике(context);


             ///   Toast.makeText(context, " Запуск  startForegroundService  BroadcastReceiver" +new Date()  , Toast.LENGTH_LONG).show();


            Log.d(this.getClass().getName(), "ВЫХОД ПОСЛЕ ОТРАБОТКИ СЛУЖБА ВНУТРИ startService   Вещятеля BroadcastReceiver" +
                    "  Service_Уведомления  JOBS ");
*/


            }



        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(context.getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.e(context.getClass().getName(), " Стоп СЛУЖБА  onReceive onDestroy() Exception "+" ::"+e.toString());


        }


    }

    private void МетодЗапускаСинхоронизацииИзШироковещательногоПриёмника(Context context) {
        try{
        Log.i(context.getClass().getName(), "ЗАПУСК из BroadcastReceiver СЛУЖБА СЛУЖБА  Synchronizasiy_Data  doWork WorkManager Synchronizasiy_Data время "
                +new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data"));


        Constraints constraintsСинхронизация= new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresCharging(false)
                .setRequiresBatteryNotLow(false)
                .setRequiresStorageNotLow(false)
                .build();
        ///



            PeriodicWorkRequest periodicWorkRequestСинхронизация=new PeriodicWorkRequest.Builder(MyWork_Синхронизация.class,17,  TimeUnit.MINUTES)//MIN_PERIODIC_FLEX_MILLIS
                .setConstraints(constraintsСинхронизация)
                //    .setInputData(new Data.Builder().putString("КтоЗапустилWorkmanager","BroadCastRecieve").build())
                .addTag("WorkManager Synchronizasiy_Data")
                .build();


// Queue the work
        WorkManager.getInstance(context.getApplicationContext()).enqueueUniquePeriodicWork("WorkManager Synchronizasiy_Data", ExistingPeriodicWorkPolicy.KEEP, periodicWorkRequestСинхронизация);
        // WorkManager.getInstance().enqueue(periodicWorkRequest);// workmanager.enqueueUniquePeriodicWork(TAG, ExistingPeriodicWorkPolicy.KEEP, photoCheckWork)




            Log.i(context.getClass().getName(), "После Запуска из  BroadcastReceiver  СЛУЖБА Synchronizasiy_Datas ПОСЛЕ doWork  Synchronizasiy_Dataя время "
                    +new Date() + " СТАТУС WORKMANAGER-----------" +WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data")+
                    "\n"+
                    WorkManager.getInstance(context.getApplicationContext()).getWorkInfoByIdLiveData(periodicWorkRequestСинхронизация.getId())+" \n"+
                    " periodicWorkRequestСинхронизация.getId()" +periodicWorkRequestСинхронизация.getId());





// TODO: 23.04.2021  запуск синхронизации
        //////////
    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(context.getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

        Log.e(context.getClass().getName(), " Стоп из BroadcastReceiver  СЛУЖБА Service_Уведомления в BroadCasrReciver onDestroy() Exception "+e.toString());


    }

}


    // TODO: 02.04.2021 метод запуска службы из BroadCastas


    private void МетодЗапускаСлужбВШировоВещятелеУведомления(Context context ) {




        try{


            Log.i(context.getClass().getName(), "ЗАПУСК из BroadcastReceiver СЛУЖБА СЛУЖБАService_Notifications doWork  MyWorkУведомления время "
                    +new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation"));


            Constraints constraintsУведомления= new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                    .setRequiresCharging(false)
                    .setRequiresBatteryNotLow(false)
                    .setRequiresStorageNotLow(false)
                    .build();
///
            ///


            PeriodicWorkRequest periodicWorkRequestУведомления=new PeriodicWorkRequest.Builder(MyWorkУведомления.class,15,  TimeUnit.MINUTES)//MIN_PERIODIC_FLEX_MILLIS
                    .setConstraints(constraintsУведомления)
                    .addTag("WorkManager NOtofocation")
                    //.setInputData(new Data.Builder().putString("КтоЗапустилWorkmanager","BroadCastRecieve").build())
                    .build();



// Queue the work
            WorkManager.getInstance(context.getApplicationContext()).enqueueUniquePeriodicWork("WorkManager NOtofocation", ExistingPeriodicWorkPolicy.KEEP, periodicWorkRequestУведомления);


            // WorkManager.getInstance().enqueue(periodicWorkRequest);// workmanager.enqueueUniquePeriodicWork(TAG, ExistingPeriodicWorkPolicy.KEEP, photoCheckWork);



            Log.i(context.getClass().getName(), "После Запуска из  BroadcastReceiver  СЛУЖБА СЛУЖБАService_Notifications ПОСЛЕ doWork  MyWorkУведомления время "
                    +new Date() + " СТАТУС WORKMANAGER-----------" +WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation")+"\n"+
                    WorkManager.getInstance(context.getApplicationContext()).getWorkInfoByIdLiveData(periodicWorkRequestУведомления.getId())+" \n"+
                    "periodicWorkRequestУведомления.getId()" +periodicWorkRequestУведомления.getId());


            // TODO: 23.04.2021 jobs



            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(context.getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.e(context.getClass().getName(), " Стоп из BroadcastReceiver  СЛУЖБА Service_Уведомления в BroadCasrReciver onDestroy() Exception "+e.toString());


        }







    }

/*    private void МетодЗапускаJOBВШироковещательном_Применике(Context context) {
        try{
        ComponentName componentName = new ComponentName(context, JobMyService.class);
        JobInfo info = new JobInfo.Builder(1,componentName)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED) // change this later to wifi
                .setPersisted(true)
                .setPeriodic(900000)
                .build();

        JobScheduler scheduler = (JobScheduler)context.getSystemService(JOB_SCHEDULER_SERVICE);
        int resultCode = scheduler.schedule(info);
        if (resultCode==JobScheduler.RESULT_SUCCESS) {
            Log.d(this.getClass().getName()," СЛУЖБА JOb JOb Scheduled");
        } else {
            Log.d(this.getClass().getName()," СЛУЖБА JOb Job Scheduling fail");
        }



/////////

    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }*/


}