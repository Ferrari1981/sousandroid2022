package com.dsy.dsu;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.icu.text.SimpleDateFormat;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.util.Log;
import android.view.Gravity;
import android.widget.Toast;

import androidx.annotation.NonNull;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.channels.CompletionHandler;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionService;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.ToDoubleBiFunction;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;


//////-------TODO  ЭТО ПЕРВЫЙ КОНТРОЛЛЕР КОТОРЫЙ ВИЗУАЛИЗИРУЕТ СИНХРОНИЗАЦИЮ С ПРОГРАССБАРОМ---------------------------------------------------------------




public class CONTROLLER_synchronized extends MODEL_synchronized {

    String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;

   private static Context КонтекстСинхроДляКонтроллера;



    public CONTROLLER_synchronized( @NotNull Context context) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
        super(context);
        try{

        ////////todo ОБНУЛЯЕМ КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ ОБНОВЛЕНИЙ
        КонтекстСинхроДляКонтроллера=context;

        ////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
        // ССылкаНаСозданнуюБазу = this.getWritableDatabase(); //ссылка на схему базы данных;//ссылка на схему базы данных ГЛАВНАЯ ВСТАВКА НА БАЗУ ДСУ-1
        ////// TODO созданеи шифрование
        if ( PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки==null) {
            //TODO ключ для шифрование и расщифровки
            byte[] CipherKey= "[C@3841f624[B@6415a86b[B@143c678".getBytes();
            PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки =
                    new SecretKeySpec(CipherKey,
                            "AES");
            PUBLIC_CONTENT. ПолитикаШифрование= Cipher.getInstance("AES");
            PUBLIC_CONTENT.ПолитикаШифрование.init(Cipher.ENCRYPT_MODE, PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки);
            ///////
            PUBLIC_CONTENT.ПолитикаРасшифровки= Cipher.getInstance("AES");
            PUBLIC_CONTENT. ПолитикаРасшифровки.init(Cipher.DECRYPT_MODE, PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки);
            ///// конец шифрование
        }
        ////// конец  TODO созданеи шифрование

        ///////
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }

    public int УспешноеКоличествоВставокДанныхсСервера;
    ///////
    public int УспешноеКоличествоОбновлениеДанныхсСервера;
    ////


    /////////////
    ContentValues  АдаптерПриОбновленияДанныхсСервера;
    //////
    ContentValues   АдаптерДляВставкиДанныхсСервер;




    Cursor Курсор_УзнатьЕслиНаАндройдеТакойUUID = null;/// ТУТ ОН ЗАПОНИМАЕНТ ПОСЛЕНИЙ UUID НА СТРОЙКИ

    Cursor Курсор_УзнатьЕслиНаАндройдеТакойID = null;/// ТУТ ОН ЗАПОНИМАЕНТ ПОСЛЕНИЙ UUID НА СТРОЙКИ



    int ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON;




//////ПЕРВЫЙ МЕТОД ОБМЕНА ДАННЫМИ С СЕРВЕРОМ МЕТОД GET

    protected void  МетодНачалоСихронизацииДляАктивити( @NotNull Context  context) throws InterruptedException, ExecutionException, TimeoutException, JSONException {
        try{
            ////////todo ОБНУЛЯЕМ КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ ОБНОВЛЕНИЙ
            КонтекстСинхроДляКонтроллера=context;
            ///
            StringBuffer РезультатотБуфераПолученияЗначений=new StringBuffer();

            CountDownLatch countDownLatchLДляПолученияIDПубличногоОтСесвераaвФОНЕ=new CountDownLatch(2);
            ///
            ExecutorService cachedThreadPoolФоноваяПолучениеПубличногоID = Executors.newSingleThreadScheduledExecutor(); //newSingleThreadExecutor()
               //////////
            CompletionService<StringBuffer> КомплитФоноваяСинхронизация=new ExecutorCompletionService<StringBuffer>(cachedThreadPoolФоноваяПолучениеПубличногоID);

             ////
         ;
            final StringBuffer[] РезультатотБуфераПолученияЗначенийВнутри = {new StringBuffer()};

            ///TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными

            КомплитФоноваяСинхронизация.submit(new Callable<StringBuffer>() {
                @Override
                public StringBuffer call() throws Exception {
            ///

//////////
                    countDownLatchLДляПолученияIDПубличногоОтСесвераaвФОНЕ.countDown();




                    // TODO: 31.05.2021 вместо удаленого метода


                    final StringBuffer[] БуферПолучениеДанных = {new StringBuffer()};
                    ///


                    CyclicBarrier cyclicBarrierметодполучениеidотсерверадлябуфергеренированиеuuid=new CyclicBarrier(1);
                    /////
                    //PUBLIC_CONTENT.ПУбличныйДанныеПришёлЛиIDДЛяГенерацииUUID=ДанныеПришёлЛиIDДЛяГенерацииUUID;
                    try {


                        // TODO: 26.04.2021 определения
                        try{


                            /////


                            ////
                            БуферПолучениеДанных[0] = new StringBuffer(УниверсальныйБуферПолучениеДанныхсСервера("", "", "", "application/text", "Хотим Получить ID для Генерации  UUID", "", "")); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position

                            ////////

                            Log.d(this.getClass().getName(), "  БуферПолучениеДанных[0]  " + БуферПолучениеДанных[0].toString());

                        } catch (Exception e) {
                            //  Block of code to handle errors
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                    Thread.currentThread().getStackTrace()[2].getLineNumber());
                        }



                        /////
                        if (cyclicBarrierметодполучениеidотсерверадлябуфергеренированиеuuid.getParties() > 0) {
                            /////////
                            cyclicBarrierметодполучениеidотсерверадлябуфергеренированиеuuid.await();
                        }


                        if (cyclicBarrierметодполучениеidотсерверадлябуфергеренированиеuuid.getNumberWaiting() == 0) {
                            ///////
                            cyclicBarrierметодполучениеidотсерверадлябуфергеренированиеuuid.reset();



                            // TODO: 24.05.2021  коод после подлучения

                            if (БуферПолучениеДанных[0] != null) {
                                ////
                                if (БуферПолучениеДанных[0].length() > 0 ) {


                                    String ДанныеПришёлЛиIDДЛяГенерацииUUID = new String();


                                    ///
                                    Log.d(this.getClass().getName(), "БуферПолучениеДанных  " + БуферПолучениеДанных.toString());

                                    // TODO: 26.05.2021 ЦИКЛ

                                    do {
                                        ДанныеПришёлЛиIDДЛяГенерацииUUID = БуферПолучениеДанных.toString();
                                        /////
                                        Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID  " + ДанныеПришёлЛиIDДЛяГенерацииUUID);


                                        ///
                                        ///todo если мы прошли один раз и нет данных выходим
                                        if (ДанныеПришёлЛиIDДЛяГенерацииUUID == null) {
                                            //
                                            if (ДанныеПришёлЛиIDДЛяГенерацииUUID.length() == 0) {
                                                break;
                                            }
                                            break;

                                        }

                                    } while (ДанныеПришёлЛиIDДЛяГенерацииUUID == null);/////конец for # количество респонсев


                                    // TODO: 26.04.2021 ПУЛУЧИЛИ ПУБЛИЧНЫЙ ID // TODO: 26.04.2021 ПУЛУЧИЛИ ПУБЛИЧНЫЙ ID // TODO: 26.04.2021 ПУЛУЧИЛИ ПУБЛИЧНЫЙ ID // TODO: 26.04.2021 ПУЛУЧИЛИ ПУБЛИЧНЫЙ ID // TODO: 26.04.2021 ПУЛУЧИЛИ ПУБЛИЧНЫЙ IDS


                                    if (ДанныеПришёлЛиIDДЛяГенерацииUUID.length() > 0 ) {

                                        //////TODO присванием ПОЛУЧЕННЫЙ ПУБЛИЧНЫЙ ID  ДЛЯ РАБОТЫ ПРИЛОЖЕНИЯ
                                        PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID = БуферПолучениеДанных.toString();

                                        РезультатотБуфераПолученияЗначенийВнутри[0].append(ДанныеПришёлЛиIDДЛяГенерацииUUID);


                                        /////////
                                        Log.d(this.getClass().getName(), "  ПубличноеIDПолученныйИзСервлетаДляUUID  " + PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID +
                                                "  РезультатотБуфераПолученияЗначенийВнутри[0] " + РезультатотБуфераПолученияЗначенийВнутри[0]);


// TODO: 15.04.2021 определяем ЗАБЛОКИРОВАН ПОЛЬЗОВАТЕЛЬ ИЛИ НЕТ


                                        //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
                                        StringBuffer БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя = new StringBuffer();

                                        БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя = УниверсальныйБуферПолучениеДанныхсСервера("", "", "", "application/text",
                                                "Хотим Получить Статус Блокировки Пользователя по ID", "", PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID);


                                        if (БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя != null) {
                                            ////
                                            if (БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя.length() > 0) {

                                                Log.d(this.getClass().getName(), "  БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя  "
                                                        + БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя.toString());
                                            }

                                        }


                                        // TODO: 29.03.2021 записываем в базу полученный публичный ID от сервреа
// TODO: 15.04.2021 добускаються пользователи только с статусом false не заблокированы на сервере

                                        if (БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя.toString().equalsIgnoreCase("false")) {
                                            //////
                                            if (ДанныеПришёлЛиIDДЛяГенерацииUUID != null) {

                                                if (ДанныеПришёлЛиIDДЛяГенерацииUUID.length() > 0) {//ЕСЛИ МЫ ПОЛУЧИЛИ ID  и СОЗДАЛИ НА ЕГО БАЗЕ UUID ТО ПРОХОДИИМ К СЛЕДУЮЩЕМУ КОДУ ПОЛУЧАЕМ ВЕРСИЮ ДАННЫХ СЕРВВЕРА


                                                    //////TODO  данный код срабатывает когда произошда ошивка в базе разблокировка

                                                    PUBLIC_CONTENT.ФлагЧтоЗаблокированТекущийПользователь = false;


                                                    // TODO: 29.03.2021 записываем в базу полученный ID пубичный предший от сервера
                                                    Log.d(this.getClass().getName(), "  БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя.toString()" +
                                                            "  " + БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя.toString());

                                                    ////
                                                    Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID  " + ДанныеПришёлЛиIDДЛяГенерацииUUID.length());


                                                    ////запускаем слуд.ющий метод получение версии базы данных
                                                    МетодПолучениеСпискаТаблицДляОбменаДанными(ДанныеПришёлЛиIDДЛяГенерацииUUID);//получаем ID для генерирования UUID


                                                }
                                            }


                                            // TODO: 15.04.2021 ПОЛЬЗОВАТЕЛИ ЗАБЛОКИРОВАН И НЕ ДОСПУКАЕТЬСЯ С РАБОТЕ ПРОГРЫММ И СИНХРОНИЗАЦММ ВЫХОД И РАБОТЫ СИСТЕМЫ

                                        } else if (БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя.toString().equalsIgnoreCase("true")) {


                                            //////TODO  данный код срабатывает когда произошда ошивка в базе

                                            PUBLIC_CONTENT.ФлагЧтоЗаблокированТекущийПользователь = true;


                                            // TODO: 15.04.2021 пользователя времени заблокировали
                                            Log.d(this.getClass().getName(), "  БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя.toString()" +
                                                    "  " + БуферПолучениеДанныхДляПолучениеСтатусаБлокировкиПользователя.toString() +
                                                    "   PUBLIC_CONTENT.  ФлагЧтоЗаблокированТекущийПользователь " + PUBLIC_CONTENT.ФлагЧтоЗаблокированТекущийПользователь);


                                            try {


                                                // TODO: 26.05.2021 очистчка таблиц


                                                new CREATE_DATABASE(КонтекстСинхроДляКонтроллера).ОчисткаТаблицДляПользователя();

                                                /////


                                                // TODO: 26.05.2021 по результата показыаем пользователю


                                                Intent finalИнтент_Меню = new Intent();
                                                ((Activity) КонтекстСинхроДляКонтроллера).runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {

                                                        /////TODO ЗАПУСКАМ ОБНОЛВЕНИЕ ДАННЫХ С СЕРВЕРА ПЕРЕРД ЗАПУСКОМ ПРИЛОЖЕНИЯ ВСЕ ПРИЛОЖЕНИЯ ДСУ-1
                                                        finalИнтент_Меню.setClass(КонтекстСинхроДляКонтроллера, MainActivity_Tabels_Users_And_Passwords.class); //MainActivity_Sinfrozisaziy_Prograssbar //MainActivity_FACE_APP
                                                        finalИнтент_Меню.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);//////FLAG_ACTIVITY_SINGLE_TOP
                                                        КонтекстСинхроДляКонтроллера.startActivity(finalИнтент_Меню);

                                                        ////TODO ДАННАЯ КОМАНДА ПЕРЕКРЫВАЕТ НЕ ЗАПУСКАЕМОЕ АКТИВТИ А АКТИВТИ КОТОРЕ ЕГО ЗАПУСТИЛО

                                                        Toast.makeText(КонтекстСинхроДляКонтроллера, " Текущий пользователь Заблокирован !!!" + "\n" + "Или нет прав !!!!", Toast.LENGTH_LONG).show();

                                                    }
                                                });


                                            } catch (Exception e) {
                                                //  Block of code to handle errors
                                                e.printStackTrace();
                                                ///метод запись ошибок в таблицу
                                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                                new КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                                            }


                                        }


                                    }


                                    // TODO: 26.04.2021


                                    ////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                                    /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                                } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                                    Log.e(this.getClass().getName(), " Ошибка Данных нет c сервера Поток Пришел Нулевой 0 ");
                                }


                                /////////
                            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                                Log.e(this.getClass().getName(), "Ошибка Ошибка НЕТ ДАННЫХ ОТ СЕВРВЕРА ОШИБКА Данных нет c сервера  ");
                            }


                            // TODO: 28.05.2021  end cyclicBarrierметодполучениеidотсерверадлябуфергеренированиеuuid.getNumberWaiting()
                        }   // TODO: 28.05.2021  end cyclicBarrierметодполучениеidотсерверадлябуфергеренированиеuuid.getNumberWaiting()



                    } catch (Exception e) {
                        //  Block of code to handle errors
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }
























                    /////////////////////////////////////////////////////////////////




                    ///todo конец финал обрабоатываем обновлениея
                    if (  РезультатотБуфераПолученияЗначенийВнутри[0] !=null &&   РезультатотБуфераПолученияЗначенийВнутри[0].length()>0) {
                        Log.d(this.getClass().getName(), "РезультатотБуфераПолученияЗначений.toString()   ПУБЛИЧНЫЙ ID ПОЛЬЗОВАТЕЛЯ ПОЛУЧЕНО С СЕРВЕРА "
                                + РезультатотБуфераПолученияЗначений.toString());
                    }


                    return РезультатотБуфераПолученияЗначенийВнутри[0];
                }
            });
//////////
            countDownLatchLДляПолученияIDПубличногоОтСесвераaвФОНЕ.countDown();
            // TODO: 23.05.2021
            Future<StringBuffer> ФинальныйРезультатПолученияПубличногоID=         КомплитФоноваяСинхронизация.take();
            ////
            countDownLatchLДляПолученияIDПубличногоОтСесвераaвФОНЕ.await();

            if(ФинальныйРезультатПолученияПубличногоID.isDone()){


StringBuffer stringBufferПолученинныйID=ФинальныйРезультатПолученияПубличногоID.get();

                // TODO: 25.05.2021  резульата потока

                Log.d(this.getClass().getName(), " ФОНОВАЯ СИНХОРОНИЗАЦИИИ  получение публичного ID СЛУЖБА " +cachedThreadPoolФоноваяПолучениеПубличногоID.isTerminated()+ "\n"+
                        " ФИНАЛ ФОНОВАЯ СЛУЖБА публичного ID (сам): " +stringBufferПолученинныйID.toString());


                ФинальныйРезультатПолученияПубличногоID.cancel(false);

                cachedThreadPoolФоноваяПолучениеПубличногоID.shutdown();


            }



            ///todo конец финал обрабоатываем обновлениея
            ///TODO

            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();

            if(!e.toString().trim().equals("java.lang.nullpointerexception: field == null")){

                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }




    }












































    ///////////////////метод получение ОТ СЕРВЕРА КОНКРЕТНЫЙ СПИСОК ТАДОИЦЦ ДЛЯ ОБМЕНА


    ////////////МЕТОД ПОЛУЧЕНИЕ  ВЕРСИИ ДАННЫХ
    void МетодПолучениеСпискаТаблицДляОбменаДанными ( @NonNull  String  ДанныеПришёлЛиIDДЛяГенерацииUUID) throws JSONException, InterruptedException, ExecutionException, TimeoutException {///второй метод получаем версию данных на СЕРВЕР ЧТОБЫ СОПОЧТАВИТЬ ДАТЫ
//////

        Log.d(this.getClass().getName(), " ДанныеПришёлЛиIDДЛяГенерацииUUID" + ДанныеПришёлЛиIDДЛяГенерацииUUID);
        String    ДанныеПришлаСпискаТаблицДляОбмена = "";
        StringBuffer БуферПолученияСпискаТАблицДляОбмена = new   StringBuffer();


        ////TODO ПОСЛЕ ОБРАБОТКИ ТАБЛИЦ ОБНУЛЯЕМ
        PUBLIC_CONTENT.ИменаТаблицыОтАндройда.clear();
        // PUBLIC_CONTENT. ДатыТаблицыВерсииДанныхОтСервера.clear();
        //  PUBLIC_CONTENT.   ИменаПроектовОтСервера.clear();


        try {
            //////TODO СПИСОК ТАБЛИЦ ДЛЯ ОБМЕНА
            БуферПолученияСпискаТАблицДляОбмена = УниверсальныйБуферПолучениеДанныхсСервера("view_data_modification","", "","application/json",
                    "Хотим Получить Версию Данных Сервера","",ДанныеПришёлЛиIDДЛяГенерацииUUID); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position

            Log.d(this.getClass().getName(), " БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length " + БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length);




            if (БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length>3) {
                do {
                    ДанныеПришлаСпискаТаблицДляОбмена= БуферПолученияСпискаТАблицДляОбмена .toString();
                    //////
                    БуферПолученияСпискаТАблицДляОбмена.append(ДанныеПришлаСпискаТаблицДляОбмена).append("\n");
                    Log.d(this.getClass().getName(), " ДанныеПришлаЛиВерсияДанныхсСервера " +ДанныеПришлаСпискаТаблицДляОбмена);
                } while (ДанныеПришлаСпискаТаблицДляОбмена== null);/////конец for # количество респонсев
                /////
                Log.d(this.getClass().getName(), "  ПубличноеIDПолученныйИзСервлетаДляUUID  " + PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID +
                        " БуферПолученияСпискаТАблицДляОбмена " +БуферПолученияСпискаТАблицДляОбмена.toString());
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
                ///ПОЛУЧЕННЫЙ СПИСОК ЗАПИСЫВАЕМ В ТАБЛИЦУ НАШУ ПЕРЕРМЕННЦУЮ
                JSONObject  ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента= new JSONObject(БуферПолученияСпискаТАблицДляОбмена.toString());///упаковываем в j
                ///
                JSONArray МассивJSONТаблиц = ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.names();
                String  НазваниеИзПришедшихТаблицДляКлиента;
                String СодержимоеИзПришедшихТаблицДляКлиента;
                String JSONСтрочка ;
                String  JSONНазваниеСтолбика;
                String JSONСодержимоеСтолика;
                String JSONСодержимоеСтоликаДляХэша;
                /////ЦИКЛ КРУТИТЬ JSON
                PUBLIC_CONTENT.ИменаТаблицыОтАндройда.clear();

                //todo
                /////ЦИКЛ КОТРЫЙ БЕЖИТ ПО СТОРОКА ПРИГЕДШЕГО JSON ФАЙЛА И НАХОДИМ НАЩШИ ТАЮЛИЦЫ ДЛЯ УКАЗАННОГО ПОЛЬЗОВАТСЯ
                for ( int ИндексТаблицыДляДанногоКлиента= 0;ИндексТаблицыДляДанногоКлиента< ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.names().length(); ИндексТаблицыДляДанногоКлиента++) {
                    ////// распарсиваем  josn
                    НазваниеИзПришедшихТаблицДляКлиента = МассивJSONТаблиц .getString(ИндексТаблицыДляДанногоКлиента);
                    СодержимоеИзПришедшихТаблицДляКлиента = ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.getString(НазваниеИзПришедшихТаблицДляКлиента); // Here's
                    JSONObject  ОбьектJSON= new JSONObject(СодержимоеИзПришедшихТаблицДляКлиента);
                    JSONСтрочка = String.valueOf(ОбьектJSON.names());



                    ////todo
                    /////ЦИКЛ КОТРЫЙ БЕЖИТ ПО СТОЛБЦАМ  ПРИГЕДШЕГО JSON ФАЙЛА И НАХОДИМ НАЩШИ ТАЮЛИЦЫ ДЛЯ УКАЗАННОГО ПОЛЬЗОВАТСЯ
                    for ( int ИндексТаблицыДляДанногоКлиентаСтолбцы= 0;ИндексТаблицыДляДанногоКлиентаСтолбцы< ОбьектJSON.length(); ИндексТаблицыДляДанногоКлиентаСтолбцы++) {
                        JSONНазваниеСтолбика = String.valueOf(ОбьектJSON.names().get(ИндексТаблицыДляДанногоКлиентаСтолбцы));
                        JSONСодержимоеСтолика = ОбьектJSON.getString(JSONНазваниеСтолбика);
                        ///ЗАПОЛНЯЕМ ТОЛЬКО НАЗВАНИЯ ТАБЛИЦ  ПРЕДНАЗВАНЧЕН ТОЛЬКО ДЛЯ ДАННГО ПОЛЬЗОВАТЕЛЯ ТАБЛИЦЫ ПО КОТОРЫМ БУДЕТ ОБМЕН




                        ///todo вытаскмваем название таблиц для заполения таблицы модификейшен клеинта на андройде
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ИМЯ ИЗ МОДИФИКАЦИИ СЕРВЕР") ){


                            ///TODO ЕЩЕ ДО САМОЙ СИНХРОНИЗАЦИИ ОПЕРДЕЛЯЕМ КОЛИЧЕСТВО ТАБЛИЦ КОТОРЫЕ СОБСТВЕННО И БУДУТ ПРИНИМАТЬУЧАСТИЕ В СИНХРОНИАЗЗЦИИ ЗАПОЛНЯЕМ ИХХ С СЕРВЕРА

                            PUBLIC_CONTENT.ИменаТаблицыОтАндройда.add(JSONСодержимоеСтолика); //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ
                            ////////
                            Log.d(this.getClass().getName(), " JSONСодержимоеСтолика " +JSONСодержимоеСтолика +
                                    "PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size() "+PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size());
                        }



                        /////А ТУТ МЫ ПРОСТО ЗАПОМИНАЕМ НАЗВАНИЕ ТАБЛИЦ С СЕРВЕРА  И ПЛЮС ИХ ДАТЫ ПОСЛЕДНЕГО ИЗМЕНЕНИЕ ДАННЫХ НА ДАННЫХ ТАБЛИЦАХ НА СЕРВЕРЕ
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ИМЯ ИЗ МОДИФИКАЦИИ СЕРВЕР") ) {

                            //////ОТДЕЛЬНО ДляХэшМап
                            JSONСодержимоеСтоликаДляХэша = ОбьектJSON.getString("ДАТА ВЕРСИИ СЕРВЕРА");/////ТОЛЬКО ДЛЯ HSMAP
                            PUBLIC_CONTENT.  ДатыТаблицыВерсииДанныхОтСервера.put(JSONСодержимоеСтолика, JSONСодержимоеСтоликаДляХэша); ///// ЗАПОЛНЯЕМ ХЭШМАП ДЛЯ КРНКРЕТНОГО ПОЛЬЗОВАТЕЛЯ ТАБЛИЦ ДЛЯ ТОЛЬКО СЕСИИ
                            Log.d(this.getClass().getName(), " JSONСодержимоеСтолика " +JSONСодержимоеСтолика+ "  JSONСодержимоеСтоликаДляХэша  "+ JSONСодержимоеСтоликаДляХэша );
                        }


                        //todo проект имена
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ПРОЕКТЫ") ){
                            PUBLIC_CONTENT.   ИменаПроектовОтСервера.add(JSONСодержимоеСтолика); //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ
                            Log.d(this.getClass().getName(), " ИменаПроектовОтСервера " +PUBLIC_CONTENT.ИменаПроектовОтСервера.toString());
                        }

                        //todo имя ПРАВ
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ID_ПРАВ") ){
                            /// PUBLIC_CONTENT.   ИменаПроектовОтСервера.add(JSONСодержимоеСтолика); //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ
                            Log.d(this.getClass().getName(), " ID_ПРАВ " +PUBLIC_CONTENT.ИменаПроектовОтСервера.toString());
                        }



                    }//TODO END FOR






                }//TODO END FOR main


                Log.d(this.getClass().getName(),  " PUBLIC_CONTENT.ИменаТаблицыОтАндройда.toArray().toString()) "+PUBLIC_CONTENT.ИменаТаблицыОтАндройда.toString());
                //////
                /////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера  " );





            }
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }finally {
            Log.i(this.getClass().getName(), " ИменаТаблицыОтАндройда " +PUBLIC_CONTENT.ИменаТаблицыОтАндройда.toString() +
                    " ДатыТаблицыВерсииДанныхОтСервера " +PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.toString());
            if (ДанныеПришлаСпискаТаблицДляОбмена.length()>2){//ЕСЛИ МЫ ПОЛУЧИЛИ ID  и СОЗДАЛИ НА ЕГО БАЗЕ UUID ТО ПРОХОДИИМ К СЛЕДУЮЩЕМУ КОДУ ПОЛУЧАЕМ ВЕРСИЮ ДАННЫХ СЕРВВЕРА
                ////запускаем слуд.ющий метод получение версии базы данных
                if (БуферПолученияСпискаТАблицДляОбмена!=null);
                //// TODO запускам если ОТ СЕРВЕРА ПРИШЛИ  ДАННЫЕ СПИСОК ТАБЛИЦ ДЛЯ СОЗДАНИЕ СПИСК ДЛЯ ПОЛЬЗОВАТЕЯД
                //   МетодЗапускаемЦиклПоТаблицамДляДанногоПользователя(  ДанныеПришёлЛиIDДЛяГенерацииUUID);

            }
        }
    }






    /////////////////////ИЩЕМ ДАТУ СЕРВЕРВА
    void МетодДляАнализаВерсийДанныхПолучаемДатыСервера(String ТекущаяТаблицаДляОБменаДанными, String ДанныеПришёлЛиIDДЛяГенерацииUUID ,
                                                        int ФиналОбщееКоличествоСколькоСтрочекJSON,Context КонтекстДляСинхронизацииОбмена)
            throws JSONException, InterruptedException, ExecutionException, TimeoutException {
        //
        final Date[] ДатаВерсииДанныхНаSqlServer = {null};
        ////
        ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON= ФиналОбщееКоличествоСколькоСтрочекJSON;

        //////
        КонтекстСинхроДляКонтроллера=КонтекстДляСинхронизацииОбмена;

        Log.d(this.getClass().getName(), " ДанныеПришёлЛиIDДЛяГенерацииUUID  "  +ДанныеПришёлЛиIDДЛяГенерацииUUID+ " ТекущаяТаблицаДляОБменаДанными "+ ТекущаяТаблицаДляОБменаДанными);

        final String[] ПолученнаяДатыSqlServer = new String[1];
        JSONObject ОбьектыJSONФайлJSONсСервераВерсияSQlserver = new JSONObject();
        final String[] ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных = {""};
        final String[] ИмитацияВремяДляПроверки = new String[1];
        final Date[] ИмитациДатыДляПроверки = {null};
        ///////
        String ТесктДатыSqlServer = null;




        try {
/////ТУТ -- КОД АНАЛИЗА ДАННЫХ SQL SERVER  ПРИШЕДШЕЙ ТЕКУЩЕЙ ТАБЛИЦЕ ПОЛУЧАЕМ НАЗВАНИЕ БАЗЫ И К НЕЙ ПОЛУЧАЕМ ДАТУ Е НЕЙ
//анализируем записи и ищем нашут текущаю таблицу и дату к ней
            for(Map.Entry<String, String> ХэшДляАнализаТекущейТаблицыВерсииДанных: PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.entrySet()){
                ////////////////
                System.out.println( ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey() + " - " +  ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue());
                if (ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey().equalsIgnoreCase(ТекущаяТаблицаДляОБменаДанными) ) {///ищем в текущей строчке текущуе название таблицы например CFO==CFO
                    ////записываем в json  получену.юю текущаю названеи табиуви к ней дата ВЕРСИЯ ДАННЫХ
                    /////
                    ОбьектыJSONФайлJSONсСервераВерсияSQlserver.put(ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey(), ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue());
                    /////
                    Log.d(this.getClass().getName()," ОбьектыJSONФайлJSONсСервераВерсияSQlserver " +ОбьектыJSONФайлJSONсСервераВерсияSQlserver.toString());
                    ////////
                    ////ПЕРЕРДАЕМ ИМЯ ТАБЛИЦЫ ОТ SQL SERVER
                    ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных[0] = ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey();
                    //// ПЕРЕДАЕМ ДАТУ ИЗ ТАБЛИЦЫ ОТ SQL SERVER
                    ПолученнаяДатыSqlServer[0] = ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue();
                    if (ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных[0] != null) {///ЕСЛИ НА SQL SERVER НЕ ПУСТЦЫЕ СТРОЧКИ В ТАБОИЦЕ ВЕРСИЙ СЕРВЕРА
                        ///////
                        // TODO: 13.05.2021 даты для aip 23


                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {


                            ДатаВерсииДанныхНаSqlServer[0] = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ПолученнаяДатыSqlServer[0]);// получена ДАТА ВЕРСИИ ДАННЫХ СЕРВЕРА


                        }else {


                            ДатаВерсииДанныхНаSqlServer[0] = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ПолученнаяДатыSqlServer[0]);// получена ДАТА ВЕРСИИ ДАННЫХ СЕРВЕРА
                        }
                        //// как все сделали выходим
                        break;
                    }
                }
            }



///// todo КОНЕЦ ТУТ -- КОД АНАЛИЗА ДАННЫХ SQL SERVER  ПРИШЕДШЕЙ ТЕКУЩЕЙ ТАБЛИЦЕ ПОЛУЧАЕМ НАЗВАНИЕ БАЗЫ И К НЕЙ ПОЛУЧАЕМ ДАТУ Е НЕЙ
            /////////////////////////////////имитация///////////////////////////////// TODO ИМИТАЦИЯ НУЖНА КОГДА ДАТА SQL SERVER НУЛЕВАЯ И МЫ ЕЕ ИМИТИРУЕМ
            Calendar calendar = new GregorianCalendar(1800, 02 , 01);////имитируем дату на андройде
            ИмитациДатыДляПроверки[0] = calendar.getTime();
            DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
            dateFormat.format(ИмитациДатыДляПроверки[0]);
            ИмитацияВремяДляПроверки[0] = dateFormat.format(ИмитациДатыДляПроверки[0]);
            Log.d(this.getClass().getName()," ИмитациДатыДляПроверки "+ ИмитациДатыДляПроверки[0].toString());
            //////////////

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл


        } finally {
            ////////
            Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаSqlServer  " + ДатаВерсииДанныхНаSqlServer[0].toString() + "  ИмитациДатыДляПроверки " + ИмитациДатыДляПроверки[0].toString());
            if ( ДатаВерсииДанныхНаSqlServer[0].after(ИмитациДатыДляПроверки[0])) {
/////////////
                try {
                    МетодДляВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером(ОбьектыJSONФайлJSONсСервераВерсияSQlserver, ДатаВерсииДанныхНаSqlServer[0], ТекущаяТаблицаДляОБменаДанными,
                            ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных[0],    ДанныеПришёлЛиIDДЛяГенерацииUUID );////метод получение даты версии данных из андройда
                    ///
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    ////// начало запись в файл


                }
            }
        }
        ///

    }


    /////////////////////TODO метод ВЫРАВНИВАНИЯ ТАБЛИЦ МЕЖДУ КЛИЕНТОМ И СЕРВЕРОМ КОЛИЧЕСТВО ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ
    void МетодДляВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером(   JSONObject ФайлJSONcВерсиейДанныхСервера,Date ДатаВерсииДанныхНаSqlServer,
                                                                             String ИмяТаблицыОтАндройда_Локальноая,
                                                                             String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных ,
                                                                             String    ДанныеПришёлЛиIDДЛяГенерацииUUID)
            throws InterruptedException, ExecutionException, TimeoutException {

        Log.d(this.getClass().getName(), " ФайлJSONcВерсиейДанныхСервера " +ФайлJSONcВерсиейДанныхСервера.toString());
        JSONObject ОбьектыJSONvalue;
        JSONArray КлючJSONПолей = null;
        Cursor КурсорДляАнализаВерсииДанныхАндройда;
        String ТекстВерсииБазыАндрод = "";
////////
        String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;
        Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновления = null;
        String ДатаВерсииДанныхНаАндройдеДляМетодаGET = null;
        Date ДатаВерсииДанныхНаАндройде = null;
        try {
            //// #1 РАСПАРСИВАЕМ ПРИШЕДШИЙ JSON С СЕРВРЕА ОТ SQL SERVER
            JSONArray КлючиJSONПолей = ФайлJSONcВерсиейДанныхСервера.names();
            for (int ИндексПолучениеВерсииДанныхАндройда = 0; ИндексПолучениеВерсииДанныхАндройда < ФайлJSONcВерсиейДанныхСервера.names().length(); ИндексПолучениеВерсииДанныхАндройда++) {
                String ИмяПоляДляВставкиВАндйрод = КлючиJSONПолей.getString(ИндексПолучениеВерсииДанныхАндройда); // Here's your key
                Log.d(this.getClass().getName()," ИмяПоляДляВставкиВАндйрод "+ИмяПоляДляВставкиВАндйрод);
                String СодержимоеПоляДляВставкиВАндйрод = ФайлJSONcВерсиейДанныхСервера.getString(ИмяПоляДляВставкиВАндйрод); // Here's your value
                Log.d(this.getClass().getName(), " ЗначениеСтолбикаНазваниеТаблицНаСервере " + ИмяПоляДляВставкиВАндйрод + " ЗначениеСтолбикаВерсииТаблицНаСервере   " +
                        СодержимоеПоляДляВставкиВАндйрод);
                ///// #2 ТЕПЕРЬ ПОЛУЧЕНЫЕ ДАННЫЕ А ТОЧНЕЕ НАЗВАНИЕ ТАБЛИЦ ЗАПИСЫВАЕМ В ВЕРСИЮ ДАННЫХ АНДРОЙД
                КурсорДляАнализаВерсииДанныхАндройда = КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[] { "name"}, "name=?",new String[] { ИмяПоляДляВставкиВАндйрод } ,
                        null, null, null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                //"SuccessLogin", "date_update","id=","1",null,null,null,null
                ////////вставляем ноое название талицы если ее нет на андройде в таблице модификаци данных
                if ( КурсорДляАнализаВерсииДанныхАндройда !=null){
                    КурсорДляАнализаВерсииДанныхАндройда.moveToFirst();
                    Log.d(this.getClass().getName(), " КурсорДляАнализаВерсииДанныхАндройда.getCount() " +КурсорДляАнализаВерсииДанныхАндройда.getCount());
                }
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
                //ОЧЕНЬ ВАЖНО ЕСЛИ ЭТОТ КУРСОР ВЕРНЕТЬ ПОЛОЖИТЕЛЬНО ЦИФРУ ЭТО ЗНАЧИИТ ЧТО ТАКАЯ ТАБЛИЦУ УЖЕ ЕСТЬ НА АНДРОЙДЕ И ВСТАВЛЯЕТЬ ЕЕ НЕ НАДО
                if (КурсорДляАнализаВерсииДанныхАндройда.getCount() < 1) {/////ЕСЛИ КУРСОР ВОЗВРЯЩАЕТ ЦИФРУ 1 ТО ТОГДА ДАННАЯ ТАБОИЦА УЖЕ ЕСТЬ В ТАБЛИЦЕ ВЕРСИЙ ДАНЫХ АНДРОЙДА
                    Log.d(this.getClass().getName(), " КурсорДляАнализаВерсииДанныхАндройда.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());
                    ContentValues КонтейнерВствкаНовыхИменТаблицМодифика = new ContentValues();
                    КонтейнерВствкаНовыхИменТаблицМодифика.put("name", ИмяПоляДляВставкиВАндйрод);////ЗАПОЛЯНЕМ КОНТЕРЙНЕР ИМЯ ТАБЛИЦЫ КОТОРОЙ НЕТ ИЗ  СЕРВЕРА
                    //КонтейнерВствкаНовыхИменТаблицМодифика.put("versionserveraandroid", "2001-11-01 00:00:00");////ЗАПОЛЯНЕМ КОНТЕРЙНЕР ДАТУ ГЕНЕРИРУЕМ В ТАБЛИЦУ КОТОРО НЕТ
                    /////записываем если такой таблицы нет  на андройде в таблице модификация данных
                    Long РезультатВставкиДанных = ВставкаДанныхЧерезКонтейнерУниверсальная("MODIFITATION_Client", КонтейнерВствкаНовыхИменТаблицМодифика,ИмяТаблицыОтАндройда_Локальноая,"",false,
                            ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON,false,КонтекстСинхроДляКонтроллера); ////false  не записывать изменениея в таблице модификавет версия
                    Log.d(this.getClass().getName(), " РезультатВставкиДанных " + РезультатВставкиДанных);
                    ////
                    /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                }
                Log.i(this.getClass().getName()," НазваниеТаблицНаСервере  "+ ИмяПоляДляВставкиВАндйрод+ " ФайлJSONcВерсиейДанныхСервера.names().length() "
                        +ФайлJSONcВерсиейДанныхСервера.names().length() + " КурсорДляАнализаВерсииДанныхАндройда.getCount()  " +КурсорДляАнализаВерсииДанныхАндройда.getCount() );
//внутри цикла
            }
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        } finally {
            //// ПОЛУЧИЛИ ДАТУ ОТ SQL SERVER  ДЛЯ ОПРЕЕЛЕННОЙ ТАБЛИЦЫ И ЗАПОЛНИЛИ ТАБЛИЦУ МОДИФИКАЦИЯ ДАНЫХ НА КЛИЕНТЕ  И ИДЕМ УЖЕ АНАЛИЗИРОВАТЬ ИХ НИЖЕ
            if (ДатаВерсииДанныхНаSqlServer.toString().length()>0) {
                Log.d(this.getClass().getName(), " ИмяТаблицыОтАндройда_Локальноая " + ИмяТаблицыОтАндройда_Локальноая + " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toString() + " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных "
                        + ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных);
                //////////метод анализа данных
                МетодАнализаВресииДАнныхКлиента(ИмяТаблицыОтАндройда_Локальноая, ДатаВерсииДанныхНаSqlServer, ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных ,   ДанныеПришёлЛиIDДЛяГенерацииUUID);
            }
        }
    }



    ////////////////////////////ДАННЫЙ МЕТОД ПОСЛЕ ВЫШЕ СТОЯШЕГО ВЫРАВНИЯНИЯ НАЗВАНИЙ ТАБЛИЦ ПРИСТУПАЕТ К САМОМУ АНАЛИЗУ ДАННЫХ ВЕРСИИ ДАННЫХ НАХОДЯЩИХСЯ НА АНДРОЙДЕ
    void МетодАнализаВресииДАнныхКлиента(String ИмяТаблицыОтАндройда_Локальноая,Date ДатаВерсииДанныхНаSqlServer,String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,String    ДанныеПришёлЛиIDДЛяГенерацииUUID)
            throws InterruptedException, ExecutionException, TimeoutException {

        Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаSqlServer " +ДатаВерсииДанныхНаSqlServer.toGMTString());
        Cursor КурсорДляАнализаВерсииДанныхАндройда;
        String ДатаВерсииДанныхНаАндройдеДляМетодаGET = null;
        Date ДатаВерсииДанныхНаАндройдеSERVER = null;
        // String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;
        Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = null;
        try {
            ////#3 ТРЕТИТЬ КОГДА ЕСИ ОТСУТТВУЕТ НАЗВАНИЕ ТАБЛИЦ НА АНДРОЙДЕ И МЫ ИХ ТУДА ВПИСАЛИ , ТО ПРИСТУПАЕМ  К ТРЕТЬЕМУ ШАГУ К АНАЛИЗУ ДАНННЫХ
            КурсорДляАнализаВерсииДанныхАндройда = КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[] { "name,localversionandroid, versionserveraandroid"},
                    "name=?",new String[] {ИмяТаблицыОтАндройда_Локальноая } , null, null, null, null);//"SELECT
            // * FROM MODIFITATION_Client WHERE name=?",ИмяТаблицыОтАндройда_Локальноая
            //  //"SuccessLogin", "date_update","id=","1",null,null,null,null
            ////
            /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
            /////////ВАЖНО ЕСЛИ БОЛЬШЕ НУЛ ЗНАЧИТ В АНДРОЙДЕ ТАБЛИЦА С ТАКИМ НАЗВАНИЕМ УЖЕ ЕСТЬ
            if (КурсорДляАнализаВерсииДанныхАндройда.getCount() > 0) {////ВЫЖНОЕ УСЛОВИЕ ЕСЛИ КУРСОР ВЕРНУЛ БОЛЬШЕ НУЛЯ  ДАННАЕ ТОЛЬКО ТОГДА НАЧИНАЕМ АНАЛИЗ ВЕРСИИ ДАННЫХ НА АНДРОЙДЕ
                КурсорДляАнализаВерсииДанныхАндройда.moveToFirst();
                Log.d(this.getClass().getName(), "  Курсор_УзнаемВерсиюБазыНаАдройде.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());
                //////////////
                //String id = КурсорДляАнализаВерсииДанныхАндройда.getString( КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("name") );
                try {
                    ДатаВерсииДанныхНаАндройдеДляМетодаGET = КурсорДляАнализаВерсииДанныхАндройда.getString(КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("versionserveraandroid"));
                } catch (Exception e) {
                    e.printStackTrace();
                }


                // TODO: 16.03.2021 если дата NULL  то тогда искустнвенноее созадем

                if (ДатаВерсииДанныхНаАндройдеДляМетодаGET == null){
                    ДатаВерсииДанныхНаАндройдеДляМетодаGET = "1900-01-10 00:00:00";// получена ДАТА ВЕРСИИ ДАННЫХ СЕРВЕРА

                }


                try {
                    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = КурсорДляАнализаВерсииДанныхАндройда.getString(КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("localversionandroid"));
                } catch (Exception e) {
                    e.printStackTrace();
                }


                // TODO: 16.03.2021 если дата NULL  то тогда искустнвенноее созадем
                if (ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET==null) {
                    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = "1900-01-10 00:00:00";// получена ДАТА ВЕРСИИ ДАННЫХ СЕРВЕРА

                }





                Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеДляМетодаGET " + ДатаВерсииДанныхНаАндройдеДляМетодаGET
                        + " ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET  " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);

                ///////////ОПРЕДЕЛЯЕМ ДАТУ АНДРОЙДА ДЛЯ СОСТЫКОВКИ С ДАТОЙ SQ; SERVER//// ПОЛУЧАЕМ ДАТУ НА АНДРОЙДЕ ПОЛСЕДНЕЕ ИЗМЕНЕНИЯ ПРИШЕДЩИЕ ДАННЫЕ С СЕРВЕРА
                ДатаВерсииДанныхНаАндройдеSERVER = null;
                if (ДатаВерсииДанныхНаАндройдеДляМетодаGET != null) {///ЕСЛИ НА АНДРОЙДЕ НЕ ПУСТЦЫЕ СТРОЧКИ В ТАБОИЦЕ ВЕРСИЙ КЛИЕНТА
                    try {


                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                            ДатаВерсииДанныхНаАндройдеSERVER = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеДляМетодаGET);

                        }else {

                            ДатаВерсииДанныхНаАндройдеSERVER = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеДляМетодаGET);

                        }

                        Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеSERVER " +ДатаВерсииДанныхНаАндройдеSERVER.toString());


                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    ////////
                    Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеДляМетодаGET  " + ДатаВерсииДанныхНаАндройдеДляМетодаGET +
                            "   ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);

                    ///////////ОПРЕДЕЛЯЕМ ДАТУ АНДРОЙДА ДЛЯ СОСТЫКОВКИ С ДАТОЙ SQ; SERVER //////ПОЛУЧЕНИЕ ДАННЫХ ОБ ИЗМЕННИЯХ ДАННЫХ ЛОКАЛЬНО САМИМ ПОЛЬЗОВАТЛЕМ
                    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = null;
                    if (ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET != null) {///ЕСЛИ НА АНДРОЙДЕ НЕ ПУСТЦЫЕ СТРОЧКИ В ТАБОИЦЕ ВЕРСИЙ КЛИЕНТА
                        try {



                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                                ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);

                            }else {

                                ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);



                            }






                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        ////////
                        Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеДляМетодаGET  " + ДатаВерсииДанныхНаАндройдеДляМетодаGET
                                + "   ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET   " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);
                    }
                }
            }else{
                Log.d(this.getClass().getName(), "  КурсорДляАнализаВерсииДанныхАндройда.getCount()" +КурсорДляАнализаВерсииДанныхАндройда.getCount());
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл

        } finally {
            Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройде " +ДатаВерсииДанныхНаАндройдеSERVER.toString()
                    + " ДатаВерсииДанныхНаSqlServer  " + ДатаВерсииДанныхНаSqlServer.toString() +
                    " ДатаВерсииДанныхНаАндройдеДляЛокальногоОбновления " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString() + " ДатаВерсииДанныхНаАндройдеДляМетодаGET " + ДатаВерсииДанныхНаАндройдеДляМетодаGET);
            if (ДатаВерсииДанныхНаАндройдеSERVER != null && ДатаВерсииДанныхНаSqlServer != null && ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL != null) {
                ///////////////
                //СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
                МетодПринятияРешенияПолучитьДанныесСервераИлиОтправитьДанныесКлиента(ДатаВерсииДанныхНаАндройдеSERVER,
                        ДатаВерсииДанныхНаSqlServer, ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL,
                        ИмяТаблицыОтАндройда_Локальноая, ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                        ДатаВерсииДанныхНаАндройдеДляМетодаGET,    ДанныеПришёлЛиIDДЛяГенерацииUUID);///СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
            }
        }
    }




    //TODO СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
    void МетодПринятияРешенияПолучитьДанныесСервераИлиОтправитьДанныесКлиента(Date ДатаВерсииДанныхНаАндройдеSERVER,Date ДатаВерсииДанныхНаSqlServer, Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL,
                                                                              String ИмяТаблицыОтАндройда_Локальноая ,String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных ,
                                                                              String ДатаВерсииДанныхНаАндройдеДляМетодаGET,String    ДанныеПришёлЛиIDДЛяГенерацииUUID) {
        //
        Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаАндройдеДляЛокальногоОбновления " +ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toGMTString()+
                " ИмяТаблицыОтАндройда_Локальноая " +ИмяТаблицыОтАндройда_Локальноая + " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных " +ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных);
        try {

/////ОБЯЗАТОЛЬНОЕ УСЛОВИЕ НАЗВАНИЕ ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ НАПРИМЕР  CFO==CFO
            if (ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных.equalsIgnoreCase(ИмяТаблицыОтАндройда_Локальноая)) {//////ОБЯЗАТОЛЬНОЕ УСЛОВИЕ НАЗВАНИЕ ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ НАПРИМЕР  CFO==CFO








////// todo ВНИМАНИЕ ТУТ КОД НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ БОЛЬШЕ И МЫ ДОЛЖНЫ С ТЕЛЕФОНА ОТОСЛАТЬ ДАННЫЕ НА СЕВРЕР SQL SEVER
////// ЛОКАЛЬНАЯ ПРОВЕРКА ВЕРСИИ ДАНННЫХ  #1 НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ ПОСЛЕДНАЯЯ НАДО С АНДРОЙДА ПОСЛАТЬ ДАННЫЕ НА СЕРВЕР
                if (ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.after(ДатаВерсииДанныхНаАндройдеSERVER)) {//ПРОВЕРЯЕМ ДАТЫ КАКАЯ БОЛЬШЕ МЕНЬШЕ тут больше что слева sql server
//////  НАЧАЛО  ЛОКАЛЬНАЯ ПРОВЕРКА ВНУТИРИ АНДРОЙДА ПО ДАТАМ МЕЖДУ СОБОЙ
                    Log.d(this.getClass().getName(),
                            "    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL   " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString()
                                    + " ДатаВерсииДанныхНаАндройдеSERVER   " + ДатаВерсииДанныхНаАндройдеSERVER.toString()
                                    + " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toString());
          /*  ////TODO ПЕРЕДАЕМ ДАТЫ МЕТОДУ ДЛЯ ОТПРАВКИ ДАННЫХ НА СЕРВЕР ДЛЯ ЭТОГО ЕГО НЕМНОГО ПРЕОБРАЗУЕМs
            DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));
            String ДатаВерсииДанныхНаSqlServerДляОтправкиНаСерверДанных =dateFormat.format(ДатаВерсииДанныхНаSqlServer );
                    ///////todo МЕТОД GET запускаем метод POST посылаем Данные на сервер
            /////МетодПосылаемДанныеНаСервер(ИмяТаблицыОтАндройда_Локальноая ,ДатаВерсииДанныхНаSqlServerДляОтправкиНаСерверДанных ); //////МЕТОД POST*/
                    ////// todo МЕТОД POST
                    МетодПосылаемДанныеНаСервер(ИмяТаблицыОтАндройда_Локальноая ); ////// todo МЕТОД POST














                    //////// TODO  В ДАННОМ СЛУЧАЕ НА СЕРВРЕР ВЕРСИЯ  ДАННЫХ СТАРШЕ ЧЕМ НА АНДЙРОДЕ , И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВЕРА
                } else if (ДатаВерсииДанныхНаSqlServer.after(ДатаВерсииДанныхНаАндройдеSERVER)) { // С СЕРВЕРА
                    //////
                    Log.d(this.getClass().getName(), " НА SQL SERVER  ДАТА больше версия" +
                            " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toString() +
                            " и  ДатаВерсииДанныхНаАндройдеSERVER " + ДатаВерсииДанныхНаАндройдеSERVER.toString()+
                            " и  ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString());

//////////TODO МЕТОД get
                    МетодПолучаемДаннныесСервера(ИмяТаблицыОтАндройда_Локальноая,ДатаВерсииДанныхНаАндройдеДляМетодаGET,   ДанныеПришёлЛиIDДЛяГенерацииUUID,
                            ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL);/// ЗАПУСКАМ МЕТОД ПОЛУЧЕНИЕ ДАННЫХ С СЕРВЕРА    МЕТОД GET
                    Log.d(this.getClass().getName(), " ПОСЛЕ УСПЕШНОЙ ОТПАРВКИ ДАННЫХ НА СЕРВЕР" +
                            " КоличествоУспешныхВставки " +PUBLIC_CONTENT.КоличествоУспешныхВставки + " КоличествоУспешныхОбновлений " +PUBLIC_CONTENT.КоличествоУспешныхОбновлений );






/////todo В ДАНОМ СЛУЧАЕ ДАННЫЕ СИНХРОНИЗИРОВАТЬ НЕ НАДО ВЕСРИЯ ДАННЫХ НА СЕРВРЕР И НА КЛИЕНТЕ ОДИНАКОВЫ






                }else{
                    Log.d(this.getClass().getName(), " Синхронизация не Нужна така ка версии Дат Равны");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }



    /////МЕТОД КОГДА НА СЕРВЕРЕ ВЕРСИЯ ДАННЫХ ВЫШЕ И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВРА
    void МетодПолучаемДаннныесСервера(String имяТаблицыОтАндройда_локальноая,String ДатаВерсииДанныхНаАндройдеДляМетодаGET,
                                      String    ДанныеПришёлЛиIDДЛяГенерацииUUID ,Date ДатаВерсииДанныхНаАндройдеДляЛокальногоОбновления) {
        ////
        Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID " + ДанныеПришёлЛиIDДЛяГенерацииUUID);
        //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ

        StringBuffer БуферПолучениеДанных=new StringBuffer();
        //
        StringBuffer БуферПолученныйJSON=null;


        try{
            Log.d(this.getClass().getName(), "  МетодПолучаемДаннныесСервера" + "  имяТаблицыОтАндройда_локальноая" +имяТаблицыОтАндройда_локальноая);


            // TODO: 10.06.2021  главный код получаем данные

            БуферПолучениеДанных= УниверсальныйБуферПолучениеДанныхсСервера(имяТаблицыОтАндройда_локальноая,"",
                    "","application/json","Хотим Получить  JSON",ДатаВерсииДанныхНаАндройдеДляМетодаGET,ДанныеПришёлЛиIDДЛяГенерацииUUID); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position

            Log.d(this.getClass().getName(), " БуферПолучениеДанных.toString() " + БуферПолучениеДанных.toString());


            // TODO: 10.06.2021 получили данные от сервереа
            
            if (БуферПолучениеДанных!=null  && БуферПолучениеДанных.length()>0) {
                ////
        БуферПолученныйJSON=new StringBuffer();
                
                /////ЦИКЛ ПЕРЕБОРА JSON КОТОРЫЙ ПРИШЁЛ
                do {
                    БуферПолученныйJSON.append(БуферПолучениеДанных.toString());
                    Log.d(this.getClass().getName()," БуферПолученныйJSON внутри цикла  " +  БуферПолученныйJSON.toString());

                } while(БуферПолучениеДанных == null);
                ////////Присылаем количестов строчек обработанных на сервлете
                Log.d(this.getClass().getName(), " БуферПолученныйJSON.length()  " +БуферПолученныйJSON.length());
                Log.d(this.getClass().getName(), " БуферПолученныйJSON  " +БуферПолученныйJSON.toString());
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера сам файл JSON  " );
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }finally {
            //////ЗАПУСКАЕМ МЕТОД РАСПАРСИВАНИЕ JSON  ПОЛУЧЕНЫЙ ИЗ СЕРВЛЕТА ОТ МЕТОДА  GET



            ////TODO если пришел JSON  то не пустой проверяем болле 3 символов
            if (БуферПолученныйJSON!=null && БуферПолученныйJSON.toString().toCharArray().length > 3){

                Log.d(this.getClass().getName(), "  БуферПолученныйJSON " + БуферПолученныйJSON.toString());
                ///как только получиили данные как первый запуска переключаем флаг что далее будет не первый запуск , ТО ТОГДА МЫ ФИЛЬТР ОБНОВЛЯНЕМ И ПЕРЕКОЛЮЧЕМ ЕГО НА НЕ ПЕРВЫЙ ЗАПУСК
                if (PUBLIC_CONTENT.ФильтрДляДанныхЯвляетьсяЛиНулевойЗапускКлиента.length()>0){
                    PUBLIC_CONTENT.ФильтрДляДанныхЯвляетьсяЛиНулевойЗапускКлиента="";
                }
                try{
                    //////TODO запускаем метод распарстивая JSON
                    МетодПарсингJSONФайлаОтСерврера(БуферПолученныйJSON,имяТаблицыОтАндройда_локальноая );/////ЗАПУСК МЕТОДА ПАСРИНГА JSON

                    //поймать ошибку всего классаIOException | MyException e    NumberFormatException
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }


            }else{
                Log.i(this.getClass().getName(), " Сервер пристал пустой файл Запрос по вашем параметрам не т данных в сервере (SQL Server)  БуферПолученныйJSON " + БуферПолученныйJSON.toString());
            }
        }}





    /////// TODO МЕТОД ПАСРИНГА ПРИШЕДШЕГО  С СЕРВЕРА  json для визаулиации для prograssbar
    void  МетодПарсингJSONФайлаОтСерврера(  StringBuffer БуферПолученныйJSON,String имяТаблицыОтАндройда_локальноая ) {
        ////
        ///
        try {
            Log.d(this.getClass().getName()," БуферПолученныйJSON " +БуферПолученныйJSON.toString());
            /////ПАРСИНГ JSON ПРИШЁЛ С СЕРВЕРА SQL SERVER
            final String[] JSON_ИмяСтолбца = {""};
            final String[] JSON_ИмяСтолбцаПосик = {""};
            final String[] JSON_ИмяСодержимое = {""};



            ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных

            //////
            //////
            ////TODO ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON
            JSONObject JSON_ПерваяЧасть = new JSONObject(БуферПолученныйJSON.toString());/////ВАЖНО ПОЛУЧЕНИЕ JSON ОБЬЕКТОВ ИЗ БУФЕРА , ЧТОБЫ ДАЛЛЕ РАЗНЕСТИ ЕГО ПО СТРОЧКАМ
            ////TODO ДВИЖОК ПАРСИНГ JSON
            JSONArray JSON_ВтораяЧасть = JSON_ПерваяЧасть.names();////КОЛИЧЕСТВВОсТРОЧЕК В JSON
            //////todoОбнуялем
            ///TODO
            boolean СработалПоворот=false;
            ///////TODO ОПРЕДЕЛЯЕМ ОБЩЕЕ КОЛИЧЕСТВО JSON ВСЕГО МЕТОД
            ///TODO симофор устанавлием
            Log.d(this.getClass().getName()," JSON_ПерваяЧасть " +JSON_ПерваяЧасть.toString());

            ///TODO SLEEP

            ReentrantLock reentrantLock=new ReentrantLock();
            ////
            ///
            АдаптерПриОбновленияДанныхсСервера=new ContentValues();

            АдаптерДляВставкиДанныхсСервер=new ContentValues();

// TODO: 27.05.2021  для удаление лишних строчек

            HashMap<String,Integer> ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек=new HashMap<>();
            
            


            //// todo парсинг данных которы е пришли с сервера JSON ОБРАБОТКАТ СТРОК
            for (Iterator<String> iterator = JSON_ПерваяЧасть.keys(); iterator.hasNext(); ) {
                try {

                    //TODO ЗАСЫПАЕТ ЦИКЛ ВАЖНО ДЛЯ ОТОБРАЖЕНИЯ КОЛИЧЕСТВРОСТРОК ПРИ РАСПАРСИВАНИИ JSON ПЕРВЫЙ  ---ПОЛУЧЕНИЕ ДАННЫХ
                 /*   try {
                        TimeUnit.MILLISECONDS.sleep(0);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }*/
//     .tryLock(5, TimeUnit.MILLISECONDS);




                    ////
                    reentrantLock.lock();
//////////
                /*    ///
                    АдаптерПриОбновленияДанныхсСервера=new ContentValues();
                    АдаптерДляВставкиДанныхсСервер=new ContentValues();
*/



                    // TODO: 16.03.2021  лОВИМ ИЗ ДАННЫХ ID И UUID ДЛЯ ЗАПИСИВ БАЗУ
                    String UUIDПолученныйИзПришедшегоJSON = null;

                    String IDИзПришедшегоJSON =null;




                    /// ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ


                    ///////  ----- TODO НЕПОСРЕДСТВЕННО САМ JSON
                    String JSON_ТретьяЧасть = null;

                    ////TODO СДВИГАЕМ ИТЕРАТОР ПРИ СИНХРОНИЗАЦИИИ НЕ СНАЧАЛА

                    ///TODO без сдвига
                    JSON_ТретьяЧасть = iterator.next();
                    /////
                    Log.d(this.getClass().getName(), " Текущая строка json которй пришел сервера " + iterator.toString() + " JSON_ТретьяЧасть " + JSON_ТретьяЧасть);

////todo передаем количество операций для визуализации обновлениея  вставки

                    ///

                    Log.d(this.getClass().getName(), " JSON_ТретьяЧасть  " + JSON_ТретьяЧасть + " JSON_ТретьяЧасть   " + JSON_ТретьяЧасть.length());
                    /////
                    JSONObject JSON_ЧетвертаяЧасть = null;

                    JSON_ЧетвертаяЧасть = JSON_ПерваяЧасть.getJSONObject(JSON_ТретьяЧасть);

                    Log.d(this.getClass().getName(), " JSON_ЧетвертаяЧасть " + JSON_ЧетвертаяЧасть.toString() + " JSON_ЧетвертаяЧасть " + JSON_ЧетвертаяЧасть.length());
                    //////
                    JSONObject JSON_ПятаяЧасть = null;



                    JSON_ПятаяЧасть = new JSONObject(String.valueOf(JSON_ЧетвертаяЧасть));

                    Log.d(this.getClass().getName(), " ОбьектыJSONvalue" + JSON_ПятаяЧасть.toString());


                    ////// TODO JSON ОБРАБОТКА СТОЛБЦОВ
                    for (int ИндексПеремещенияПоСтрокеJSON = 0; ИндексПеремещенияПоСтрокеJSON < JSON_ЧетвертаяЧасть.length(); ИндексПеремещенияПоСтрокеJSON++) {


                        //TODO сомо имя json
                        JSON_ИмяСтолбца[0] = ((String) JSON_ПятаяЧасть.names().get(ИндексПеремещенияПоСтрокеJSON));


                        System.out.println("  JSON_ИмяСтолбца[0]  " +JSON_ИмяСтолбца[0] );






                        ////TODO само значение json

                        JSON_ИмяСодержимое[0] = String.valueOf(JSON_ПятаяЧасть.get(String.valueOf(JSON_ИмяСтолбца[0])));








/////TODO если нет UUID


                        if (UUIDПолученныйИзПришедшегоJSON==null) {
                            for (int ИндексИмяИщемUUID = 0; ИндексИмяИщемUUID < JSON_ЧетвертаяЧасть.length(); ИндексИмяИщемUUID++) {
                                JSON_ИмяСтолбцаПосик [0] = ((String) JSON_ПятаяЧасть.names().get(ИндексИмяИщемUUID));

                                Log.d(this.getClass().getName(), "  JSON_ИмяСтолбца[0] " + JSON_ИмяСтолбцаПосик [0] );

                                if (JSON_ИмяСтолбцаПосик [0].equals("uuid")){

                                    UUIDПолученныйИзПришедшегоJSON =   String.valueOf(JSON_ПятаяЧасть.get("uuid"));
                                    ///////////

                                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON[0] " + UUIDПолученныйИзПришедшегоJSON);
                                    break;
                                    /////TODO когда нет uuid используетм ID
                                }
                            }
                        }

/////TODO если  ID

                        if (IDИзПришедшегоJSON==null) {
                            for (int ИндексИмяИщемUUID = 0; ИндексИмяИщемUUID < JSON_ЧетвертаяЧасть.length(); ИндексИмяИщемUUID++) {
                                JSON_ИмяСтолбцаПосик [0] = ((String) JSON_ПятаяЧасть.names().get(ИндексИмяИщемUUID));

                                Log.d(this.getClass().getName(), "  JSON_ИмяСтолбца[0] " + JSON_ИмяСтолбцаПосик [0] );

                                if (JSON_ИмяСтолбца[0].equals("id")) {

                                    IDИзПришедшегоJSON = String.valueOf(JSON_ПятаяЧасть.get("id"));
                                    ///
                                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON[0] " + IDИзПришедшегоJSON);
                                    break;
                                }
                            }
                        }


                        Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца[0] + " JSON_ИмяСодержимое  " + JSON_ИмяСодержимое[0] + " IDИзПришедшегоJSON "
                                + IDИзПришедшегоJSON + "  JSON_ИмяСодержимое.length() " + JSON_ИмяСодержимое[0].length());





                        // TODO: 27.05.2021 механиз удаление из таблицы Уведомлений Лишних Значений


                        if (имяТаблицыОтАндройда_локальноая.equalsIgnoreCase("notification") && JSON_ИмяСтолбцаПосик [0].equalsIgnoreCase("id")) {

                            // TODO: 27.05.2021  заполянем ХЭШ для только дтаблица Уведомления
                            ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек.put(JSON_ИмяСтолбцаПосик [0],Integer.parseInt(IDИзПришедшегоJSON));

                            ///////
                            Log.d(this.getClass().getName(), "   ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек "+
                                    ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек.values());
                        }


                       /*
                        МетодВнутриСинхронизацииКоторыйУдаляетЗначенияЛишниеИзТаблицыУведомления(JSON_ИмяСтолбцаПосик [0],
                                "notification",
                                ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек);*/
                        







                        ////// todo ЗАПОЛЯНЕМ КОНТЕРЙНЕР ЕСЛИ И СТОЛБИК И СОДЕРЖИМОЕ СТОЛБЬИКА ПРИСУТВУЕТ
                        if (JSON_ИмяСтолбца[0].length() > 0) {///ЕСЛИ НЕ ПУСТОЕ ИМЯ И СОДЕРЖИМОЕ JSON


                            /////todo метод заполенения получым json файлом В АДАПТЕР ВСТАВКИ И/ИЛИ ОБНОВЛЕНИЕ ПРОСТО ЗАПОЛЯНЕМ
                            МетодЗаполнениеПолученымJSONсСервераВКонтейнер(UUIDПолученныйИзПришедшегоJSON, JSON_ИмяСтолбца[0], JSON_ИмяСодержимое[0], имяТаблицыОтАндройда_локальноая,
                                    IDИзПришедшегоJSON);//////МЕТОД ЗАПОЛЕНЕНИЯ JSON ПОЛЕЙ ПОЛУЧЕННЫЙ С СЕРВЕРА В КОНТЕЙНЕР  ДЛЯ ОПРЕДЕЛЕНИЯ ВСТАВЛЯИ ИЛИ ОБНОВЛЯТЬ

//
                            Log.d(this.getClass().getName(), " Конец  Записали в Базу синхронизация "+ JSON_ИмяСтолбца[0]);

                        }///todo end for СТОЛБЦЫ




                    }///todo end for СТРОКИ


                    ////---СТРОГО КАК ТОЛЬКО МЫ ЗАПОЛНИЛИ В КОНТЕНЕР ДАННЫХ СТРОЧКУ JSON ИЗ СЕРВЕРА
                    // ExecutorService executorService=Executors.newSingleThreadExecutor();
                    ExecutorService  executorServiceЗаписываемJSONвБАзу=Executors.newSingleThreadExecutor();
                    //
                    String finalUUIDПолученныйИзПришедшегоJSON = UUIDПолученныйИзПришедшегоJSON;
                    String finalIDИзПришедшегоJSON = IDИзПришедшегоJSON;
                    ///
                    Future<StringBuffer> futureЗаписьВБазу= executorServiceЗаписываемJSONвБАзу.submit(new Callable<StringBuffer>() {
                        @Override
                        public StringBuffer call() {
                            StringBuffer stringBuffer=new StringBuffer();
;
                            //////// TODO МЕТОД ПЕРОСРЕДСТВЕНОЙ ЗАПИСЬ В  БАЗУ АНДРОЙДА ДАННЫМИС SQL SERVER метод конкретной записо заполеного контерйнра json в  базуу

                            МетодаЗаписиВБазуКонтейнераобновлениеИлиВставкиJSON(имяТаблицыОтАндройда_локальноая, finalUUIDПолученныйИзПришедшегоJSON, finalIDИзПришедшегоJSON);///////после того как

                            // TODO: 27.05.2021
                            stringBuffer.append("ЗаписьВбазуДАнныхОбновенеиИЛИВставкасСерврера");

   return stringBuffer ;

                        }
                    });
                    //////
                    StringBuffer БуферРезультатВставкиИЛИОбновдения=        futureЗаписьВБазу.get();
                    /////
                    if(futureЗаписьВБазу.isDone()) {
                        executorServiceЗаписываемJSONвБАзу.shutdown();
                        futureЗаписьВБазу.cancel(false);
                        Log.d(this.getClass().getName(), " Конец  имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);

                    }







/////TODO попытка заполнить Все Строки

                    //АдаптерДляВставкиДанныхсСерверБуфер.putAll(АдаптерДляВставкиДанныхсСервер);




/////TODO увеличиваем строку на 1

                    Log.d(this.getClass().getName(), " Конец  Записали в Базу синхронизация " );
                    /////
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    ////// начало запись в файл
                }finally {
                    /////TODO вставка строк меньше ста

                    reentrantLock.unlock();
                }



                /////
            }//todo end stroki for






            // TODO: 27.05.20 после обоаьртки ьалицы улалояем лишине цвдомления




            МетодВнутриСинхронизацииКоторыйУдаляетЗначенияЛишниеИзТаблицыУведомления(JSON_ИмяСтолбцаПосик [0],
                    "notification",
                    ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек);











            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }


    // TODO: 27.05.2021 метод удаляет лишние значения из таблицы уведомления

    protected void МетодВнутриСинхронизацииКоторыйУдаляетЗначенияЛишниеИзТаблицыУведомления(String IDТаблицыУведомления,
                                                                                            String НазваниеТаблицы,
                                                                                            HashMap<String,Integer> ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек) {

        try {

   if ( НазваниеТаблицы.equalsIgnoreCase("notification")  &&  ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек.size()>0){



       Log.d(this.getClass().getName(), " Метод Удаление Лишних уведомдения и з таблицы Уведомдеолия которых уже нет на сервере" +
               " ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек "+ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек.values());



       Log.d(this.getClass().getName(), "IDТаблицыУведомления"+IDТаблицыУведомления+ " НазваниеТаблицы "+ НазваниеТаблицы);

// TODO: 27.05.2021

       Cursor Курсор_ВычисляемВнутриКлиентаТАблицуУведомленийВсеИЗАполняемХэшДляАнализаНаУдаления=null;

    Курсор_ВычисляемВнутриКлиентаТАблицуУведомленийВсеИЗАполняемХэшДляАнализаНаУдаления = new MODEL_synchronized(КонтекстСинхроДляКонтроллера).
               КурсорУниверсальныйБазыДанных("SELECT id,message FROM notification");

       if (Курсор_ВычисляемВнутриКлиентаТАблицуУведомленийВсеИЗАполняемХэшДляАнализаНаУдаления.getCount()>0){
           ///
           ContentValues contentValuesЗаполяемIdДЛяПоледущегоУдаленияИзТаблицыУведомленияЛишнизаписей=new ContentValues();
           ///
           Курсор_ВычисляемВнутриКлиентаТАблицуУведомленийВсеИЗАполняемХэшДляАнализаНаУдаления.moveToLast();

           do {

               contentValuesЗаполяемIdДЛяПоледущегоУдаленияИзТаблицыУведомленияЛишнизаписей.put(Курсор_ВычисляемВнутриКлиентаТАблицуУведомленийВсеИЗАполняемХэшДляАнализаНаУдаления.getString(0),
                       Курсор_ВычисляемВнутриКлиентаТАблицуУведомленийВсеИЗАполняемХэшДляАнализаНаУдаления.getString(1));


           }while(Курсор_ВычисляемВнутриКлиентаТАблицуУведомленийВсеИЗАполняемХэшДляАнализаНаУдаления.moveToNext());

           Log.d(this.getClass().getName(), " contentValuesЗаполяемIdДЛяПоледущегоУдаленияИзТаблицыУведомленияЛишнизаписей "+
                   contentValuesЗаполяемIdДЛяПоледущегоУдаленияИзТаблицыУведомленияЛишнизаписей.valueSet());


           // TODO: 27.05.2021  после вычислени замо удалние лишних заисей

           for (String ХэшIDУведомленияДляПриняити: contentValuesЗаполяемIdДЛяПоледущегоУдаленияИзТаблицыУведомленияЛишнизаписей.keySet()) {



           boolean ВычисляемЕстьТакойIdВБАзеКлиентаИЛИнетЕслиНЕтУдаляем
               =ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек.containsValue(Integer.parseInt(ХэшIDУведомленияДляПриняити));



           Log.d(this.getClass().getName(), " ВычисляемЕстьТакойIdВБАзеКлиентаИЛИнетЕслиНЕтУдаляем "+
                   ВычисляемЕстьТакойIdВБАзеКлиентаИЛИнетЕслиНЕтУдаляем);

           // TODO: 27.05.2021  само удаление
           if (ВычисляемЕстьТакойIdВБАзеКлиентаИЛИнетЕслиНЕтУдаляем==false){


               long РезультатУдаленияIDКоторгоНЕтЛишниеУведолмления=    ССылкаНаСозданнуюБазу.delete("notification",
                       "id = ?", new String[]{String.valueOf(ХэшIDУведомленияДляПриняити)});

               ////

               Log.d(this.getClass().getName(), "  РезультатУдаленияIDКоторгоНЕтЛишниеУведолмления " +РезультатУдаленияIDКоторгоНЕтЛишниеУведолмления );



           }

           }



       }



   }


            /////////

        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(КонтекстСинхроДляКонтроллера).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 11.05.2021 запись ошибок

        }


    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


    //////МЕТОД ТОЛЬКО ЗАПОЛЕНИЕЯ КОНТЕЙНЕРА ВСТАВКИ И ОБНОВЛЕНИЕ ДАННЫХ КОТОРЫЕ ПРИШЛИ С СЕРВЕРА
    void МетодЗаполнениеПолученымJSONсСервераВКонтейнер(String UUIDПолученныйИзПришедшегоJSON,String JSON_ИмяСтолбца ,String JSON_ИмяСодержимое
            ,String имяТаблицыОтАндройда_локальноая , String IDИзПришедшегоJSON ) { /////МЕТОД ЗАПОЛЕНЕИЯ КОНТЕЙНЕРОМ JSON ПОЛЯМИы
        //

        ///
        try {





            ///TODO ДАННЫЙ КОД ОБРЕЗАЮТ ДАТУ А ТРИ НАЗАД ЕСЛИ ДЛИНА ДАТЫ РОВНЯЕТЬСЯ 22 СИМВОЛА
            if (JSON_ИмяСтолбца.equalsIgnoreCase("date_update")) {
                //Todo цикл обработаки лишних символом даты date_update
                while (true) {
                    if (JSON_ИмяСодержимое.length() > 19) {
                        ////TODO УДАЛЯЕМ СИЩГИЕ СИМВОЛЫ В  ДАТЕ
                        JSON_ИмяСодержимое = JSON_ИмяСодержимое.substring(0, JSON_ИмяСодержимое.length() - 1);

                    } else {
                        // code block to be executed
                        Log.d(this.getClass().getName(), " JSON_ИмяСодержимое " + JSON_ИмяСодержимое + " JSON_ИмяСодержимое.length()  " + JSON_ИмяСодержимое.length());
                        break;
                    }

                }
            }

            ////ДЛЯ НАЧАЛО ОЦЕНИВАЕМ ЕСЛИ UUID В ЭТОЙ ТЕКУЩЕЙ ЗАПИСИ ,, ЗАПОМИНАЕМ ЕГО И ДАЛЕЕ ОТ РЕЗУЛЬТАТО В НАЧИНАЕМ ЛИБО ВСТАКУ ЛИБО ОБНОВЛЕНИЕ АДАЕЫХ
            ////////ПРОВЕРЯЕМ UUID ЕСЛИ Т ЕКУЩЕЕ ПОЛЕ UUID
            Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца);


            String ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде = null;

            String ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде = null;


            //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ      //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ        //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ

            //////TODO вторым флагом запрещем при первом запуске заниматься обновдениям  только вставка  при синхронизации ==false значить обнолвение включено ,,,,, ЗНАЧАЕТ ЧТО ИДЕТ ТОЛЬКО ВСТАВКА ДАННЫХ TRUE
            // final boolean ДанныйФлагРазрешаетОбновлеениеТОлькоПослеПерсвойСинхронизации = PUBLIC_CONTENT.ФлагПриПервомЗапускеОграничитьОперациюТолькоВставка;




//final boolean СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации=PUBLIC_CONTENT.ФлагРазрешаетОбновлениеПриСинхронизации;
            //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID


            //////
            // TODO: 16.03.2021 выбираем как обнолять через uuid and id
            if (UUIDПолученныйИзПришедшегоJSON!=null) {
                //////
                if (  UUIDПолученныйИзПришедшегоJSON.length()    > 0 ) {
                    /////TODO запрет на обновление если Первая Синхронизация

                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON " + UUIDПолученныйИзПришедшегоJSON.length()+"JSON_ИмяСтолбца " +JSON_ИмяСтолбца );

                    //TODO UUID
                    МетодАнализаUUIDСинхрониазция(UUIDПолученныйИзПришедшегоJSON, JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая, IDИзПришедшегоJSON);



                    //////TODO анализиует СТОЛЮИК UUID
                } else   {


                    if (  IDИзПришедшегоJSON.length() > 0) {
                        ///
                        Log.d(this.getClass().getName(), "JSON_ИмяСтолбца " +JSON_ИмяСтолбца+ " IDИзПришедшегоJSON " +IDИзПришедшегоJSON);
                        ////TODO ID
                        МетодАнализаIDСинхрониазции(UUIDПолученныйИзПришедшегоJSON, JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая, IDИзПришедшегоJSON);
                    }


                }





                // TODO: 16.03.2021 когда нет UUID
            }else{

                if (  IDИзПришедшегоJSON.length() > 0) {
                    ///
                    Log.d(this.getClass().getName(), "JSON_ИмяСтолбца " +JSON_ИмяСтолбца+ " IDИзПришедшегоJSON " +IDИзПришедшегоJSON);
                    ////TODO ID
                    МетодАнализаIDСинхрониазции(UUIDПолученныйИзПришедшегоJSON, JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая, IDИзПришедшегоJSON);
                }

            }

            // Log.d(this.getClass().getName(), " СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации " + СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации);





            //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ


            ////TODO САМО ДЕЛЕНИЕ ДАННЫХ С СЕРВЕРА НА ВСТАВКУ ДАННЫХ ИЛИ ЕЕ ОБНОВЛЕНИЯ ЗАВИСМОСТИ ЕСЛИ  UUID ИЛИ ID



            ////
            /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }



    ///todo АНАЛИЗ UUID
    void МетодАнализаUUIDСинхрониазция(String UUIDПолученныйИзПришедшегоJSON, String JSON_ИмяСтолбца, String JSON_ИмяСодержимое,
                                       String имяТаблицыОтАндройда_локальноая, String IDИзПришедшегоJSON)
            throws ExecutionException, InterruptedException, TimeoutException {

        //////TODO анализиует СТОЛЮИК UUID


        try{

            ////// TODO ИЗ ПРАВИЛА ЧТО НЕЛЬЗЯ ОБНОЛВЛЯТЬ ПОЕЛ UUID ПРОПУСКАЕМ ЕГО ЭТО КОГДА СТОЛБИК ID ПРОПУСКАЕМ


            if (имяТаблицыОтАндройда_локальноая.equals("tabels") || имяТаблицыОтАндройда_локальноая.equals("fio")){
                /////////
                if( JSON_ИмяСтолбца.equals("id")) {
                    JSON_ИмяСтолбца = "_id";
                }
                System.out.println("  JSON_ИмяСтолбца[0]  " +JSON_ИмяСтолбца );

            }


            long ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде;


            ////todo  ПЫТАЕМСЯ ОРГАНИЗОВАТЬ ОБНОВЛЕНИЕ НО ТОЛЬКО ЕСЛИ ВЛАГ  TRUE





            if (Курсор_УзнатьЕслиНаАндройдеТакойUUID==null) {
                ////
                Курсор_УзнатьЕслиНаАндройдеТакойUUID = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,
                        new String[]{"uuid"}, "uuid=?", new String[]{UUIDПолученныйИзПришедшегоJSON}, null, null,
                        null, "1");//"SuccessLogin", "date_update","id=","1",null,null,null,null


                ////////
            }




            if (Курсор_УзнатьЕслиНаАндройдеТакойUUID!=null) {

                if (Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount() > 0) {
                    // Курсор_УзнатьЕслиНаАндройдеТакойUUID.moveToFirst();


                    ///
         /*   ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде = Курсор_УзнатьЕслиНаАндройдеТакойUUID.getLong(0);
            Log.d(this.getClass().getName(), " ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде " + ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде);


            ////////
            Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON " + UUIDПолученныйИзПришедшегоJSON.length() + " Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount()  "
                    + Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount() +
                    " IDИзПришедшегоJSON " + IDИзПришедшегоJSON);*/

                    Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца + " JSON_ИмяСодержимое " + JSON_ИмяСодержимое);
                    //////МЕТОДКОТРЫЙ ПРИ ОТСТВИИИ UUID ЕГО ГЕНЕРИРЕТ НА ПРИШЕЛДХИ ДАННЫХ

                    /////второе условие чтобы uuid не вставлем тоже



                    /// TODO ТУТ ПРОИЗВОДИТЬСЯ ОБНОВЛЕНИЕ ДАННЫХ
                    АдаптерПриОбновленияДанныхсСервера.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);////заполняем контрейнер обнолвеними

                    ////
                    Log.d(this.getClass().getName(), " Курсор_УзнатьЕслиНаАндройдеТакойUUID " + Курсор_УзнатьЕслиНаАндройдеТакойUUID + " АдаптерПриОбновленияДанныхсСервера.size() "
                            + АдаптерПриОбновленияДанныхсСервера.size());



                    ///TODO ВСТАВКА ЧЕРЕЗ UUID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID
                }  else {
                    ///TODO ВСТАВКА ЧЕРЕЗ UUID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID

                    АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                    Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер UUID " +АдаптерДляВставкиДанныхсСервер.size());

                }
            }else {
                ///TODO ВСТАВКА ЧЕРЕЗ UUID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID

                АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер UUID " +АдаптерДляВставкиДанныхсСервер.size());

            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }












    ///////todo АНАЛИХ ID
    void МетодАнализаIDСинхрониазции(String UUIDПолученныйИзПришедшегоJSON, String JSON_ИмяСтолбца, String JSON_ИмяСодержимое,
                                     String имяТаблицыОтАндройда_локальноая, String IDИзПришедшегоJSON) throws ExecutionException, InterruptedException, TimeoutException {

        //////TODO анализиует СТОЛЮИК UUID

        try{

            String ИндификаторДляIDВзависмостиОтТаблицы="id";
/////
            if (имяТаблицыОтАндройда_локальноая.equals("tabels") || имяТаблицыОтАндройда_локальноая.equals("fio")) {
                ////////////
                ИндификаторДляIDВзависмостиОтТаблицы = "_id";

                if( JSON_ИмяСтолбца.equals("id")) {
                    //TODO сам столбиц
                    JSON_ИмяСтолбца=ИндификаторДляIDВзависмостиОтТаблицы;
                }
                ///

                ///


                System.out.println("  JSON_ИмяСтолбца[0]  " + JSON_ИмяСтолбца + " ИндификаторДляIDВзависмостиОтТаблицы "+ИндификаторДляIDВзависмостиОтТаблицы);

            }


            /////
            int ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде;///////
            ////
            ////todo  ПЫТАЕМСЯ ОРГАНИЗОВАТЬ ОБНОВЛЕНИЕ НО ТОЛЬКО ЕСЛИ ВЛАГ  TRUE





            if (Курсор_УзнатьЕслиНаАндройдеТакойID==null) {
                ////
                Курсор_УзнатьЕслиНаАндройдеТакойID = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,
                        new String[]{ИндификаторДляIDВзависмостиОтТаблицы}, ИндификаторДляIDВзависмостиОтТаблицы + "=?", new String[]{IDИзПришедшегоJSON}, null, null,
                        null, "1");//"SuccessLogin", "date_update","id=","1",null,null,null,null

///////
            }

            if (Курсор_УзнатьЕслиНаАндройдеТакойID!=null) {
                if (Курсор_УзнатьЕслиНаАндройдеТакойID.getCount() > 0 ) {
                    // Курсор_УзнатьЕслиНаАндройдеТакойID.moveToFirst();




                    //ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде = Курсор_УзнатьЕслиНаАндройдеТакойID.getInt(0);
                    //  Log.d(this.getClass().getName(), "ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде" +
                    //  ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде);


              /*  ////////
                Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON " + UUIDПолученныйИзПришедшегоJSON.length() + " Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount()  "
                        + Курсор_УзнатьЕслиНаАндройдеТакойID.getCount() +
                        " IDИзПришедшегоJSON " + IDИзПришедшегоJSON);
*/
                    Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца + " JSON_ИмяСодержимое " + JSON_ИмяСодержимое);
                    //////МЕТОДКОТРЫЙ ПРИ ОТСТВИИИ UUID ЕГО ГЕНЕРИРЕТ НА ПРИШЕЛДХИ ДАННЫХ

                    /////второе условие чтобы uuid не вставлем тоже


                    ////// TODO ИЗ ПРАВИЛА ЧТО НЕЛЬЗЯ ОБНОЛВЛЯТЬ ПОЕЛ UUID ПРОПУСКАЕМ ЕГО ЭТО КОГДА СТОЛБИК ID ПРОПУСКАЕМ





                    ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID
                    АдаптерПриОбновленияДанныхсСервера.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);////заполняем контрейнер обнолвеними

                    ////
                    Log.d(this.getClass().getName(), " Курсор_УзнатьЕслиНаАндройдеТакойUUID " + Курсор_УзнатьЕслиНаАндройдеТакойID + " АдаптерПриОбновленияДанныхсСервера.size() "
                            + АдаптерПриОбновленияДанныхсСервера.size());




                    ///TODO ВСТАВКА ЧЕРЕЗ ID       ///TODO ВСТАВКА ЧЕРЕЗ ID
                } else {
                    ///TODO ВСТАВКА ЧЕРЕЗ ID

                    АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                    Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер ID " + АдаптерДляВставкиДанныхсСервер.size());


                    /////
                }//todo end     ///////TODO КОГДА ЕСТЬ ТОЛЬКО ID ШНИК ОБНОВЛЕНИЕ


            }else {
                ///TODO ВСТАВКА ЧЕРЕЗ ID

                АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер ID " + АдаптерДляВставкиДанныхсСервер.size());


                /////
            }//todo end     ///////TODO КОГДА ЕСТЬ ТОЛЬКО ID ШНИК ОБНОВЛЕНИЕ



        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }



    //////////////TODO метод непосредвственой запись в базу данных json КОТОРЫЙ ПРИШЁЛ С СЕРВЕРА
    void МетодаЗаписиВБазуКонтейнераобновлениеИлиВставкиJSON(String имяТаблицыОтАндройда_локальноая, String UUIDПолученныйИзПришедшегоJSON,String  IDИзПришедшегоJSON) {////запись полученого json   от сервера через контейнер

        Log.d(this.getClass().getName()," UUIDПолученныйИзПришедшегоJSON  " +UUIDПолученныйИзПришедшегоJSON);

        try {


            //////////todo ВСТАВКА JSON НА КЛИЕНТА ДАННЫЕ С СЕРВЕРА
            Log.i(this.getClass().getName(), "  АдаптерДляВставкиПриВставкиДанныхсСервера      "+  АдаптерДляВставкиДанныхсСервер.size());
            if (АдаптерДляВставкиДанныхсСервер.size()>0) {///если в контенер заполнилься то начинаем вставку
                ////////ВЫЗЫВАЕМ ВСТАВКУ ДАННЫХ
                long РезультатВставкиЧерезКонтрейнер=0;

                РезультатВставкиЧерезКонтрейнер = ВставкаДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая,  АдаптерДляВставкиДанныхсСервер,имяТаблицыОтАндройда_локальноая,
                        "",true,
                        ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON,true, КонтекстСинхроДляКонтроллера);

                /// после вствки в базу обнуляем контейнер данные от сервера
                if (РезультатВставкиЧерезКонтрейнер>0) {
                    //////
                    //// todo ПРИ УСПЕШНОЙ ВСТАВКИ ДАННЫХ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                    PUBLIC_CONTENT.КоличествоУспешныхВставки++;
                    /////
                    //// TODO ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице++;
                    /////TODO ВАЖНО ПОСЛЕ УСПЕШНОЙ ОБРАБОТКИ ПРИСВАИВАЕМ ЗНАЧЕНИЕ присваиваем наверх факсическое значение идущего цикла После Успешного прохода ТАБЛИЦЫ одной ИЗ
                    Log.d(this.getClass().getName()," КоличествоУспешныхВставки JSON " +PUBLIC_CONTENT.КоличествоУспешныхВставки);
                    ///TODO переводим ввобщим в универсальный индификатор



                    ///



                }
                ///
                //  АдаптерДляВставкиДанныхсСерверБуфер.clear();

                АдаптерДляВставкиДанныхсСервер.clear();


                //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON
                ///


            }
            //////////todo ВСТАВКА JSON НА КЛИЕНТА ДАННЫЕ С СЕРВЕРА










            ////////// TODO ОБНОВЛЕНИЕ JSON НА КЛИЕНТА
            Log.i(this.getClass().getName(), "  АдаптерДляОбновленияПриВставкиДанныхсСервера "+  АдаптерПриОбновленияДанныхсСервера.size());
            if ( АдаптерПриОбновленияДанныхсСервера.size()>0) {///если в контенер заполнилься то начинаем обновление
                ////////ВЫЗЫВАЕМ ОБНОВЛЕНИЕ
                long РезультатОбновлениеЧерезКонтрейнер=0;

                /////TODO делим обновление на два вида если есть UUID ИЛИ НЕТ А ЕСТЬ ID


                ///TODO когда есть только UUID
                if (UUIDПолученныйИзПришедшегоJSON!=null){

                    if(UUIDПолученныйИзПришедшегоJSON.length()>0){

                        //////todo UUID UPDATE
                        РезультатОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая, АдаптерПриОбновленияДанныхсСервера,
                                UUIDПолученныйИзПришедшегоJSON,
                                ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON,true, КонтекстСинхроДляКонтроллера,
                                "uuid");



                        ///TODO когда есть только ID

                    } else if (IDИзПришедшегоJSON!=null){
                        if (IDИзПришедшегоJSON.length()>0) {

                            String ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID;

                            if (имяТаблицыОтАндройда_локальноая.equals("tabels") || имяТаблицыОтАндройда_локальноая.equals("fio")){



                                ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID="_id";

                            }else{
                                ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID="id";
                            }


                            //////todo ID UPDATE
                            РезультатОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая, АдаптерПриОбновленияДанныхсСервера,
                                    IDИзПришедшегоJSON,
                                    ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON,
                                    true, КонтекстСинхроДляКонтроллера,ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID);

                        }
                    }


// TODO: 08.04.2021 НЕТ UUID И ОБНОВЛЕМ ПО ID
            } else if (IDИзПришедшегоJSON!=null){
                if (IDИзПришедшегоJSON.length()>0) {

                    String ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID;

                    if (имяТаблицыОтАндройда_локальноая.equals("tabels") || имяТаблицыОтАндройда_локальноая.equals("fio")){



                        ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID="_id";

                    }else{
                        ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID="id";
                    }


                    //////todo ID UPDATE
                    РезультатОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая, АдаптерПриОбновленияДанныхсСервера,
                            IDИзПришедшегоJSON,
                            ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON,
                            true, КонтекстСинхроДляКонтроллера,ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID);

                }
            }










                /// после обновление  в базу обнуляем контейнер  данные от сервера
                if (РезультатОбновлениеЧерезКонтрейнер>0) {
//////////////////
                    //// todo ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                    PUBLIC_CONTENT.КоличествоУспешныхОбновлений++;
                    ////
                    //// TODO ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице++;
                    /////TODO ВАЖНО ПОСЛЕ УСПЕШНОЙ ОБРАБОТКИ ПРИСВАИВАЕМ ЗНАЧЕНИЕ присваиваем наверх факсическое значение идущего цикла После Успешного прохода ТАБЛИЦЫ одной ИЗ
                    Log.d(this.getClass().getName()," КоличествоУспешныхОбновлений JSON " +PUBLIC_CONTENT.КоличествоУспешныхОбновлений);
                    ///TODO переводим ввобщим в универсальный индификатор

                    /////TODO ВАЖНО ПОСЛЕ УСПЕШНОЙ ОБРАБОТКИ ПРИСВАИВАЕМ ЗНАЧЕНИЕ присваиваем наверх факсическое значение идущего цикла После Успешного прохода ТАБЛИЦЫ одной ИЗ






                }

                АдаптерПриОбновленияДанныхсСервера.clear();
                ////


                ////TODO вставка
            }



            ///TODO если что -то открыта закрыть

            /////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }finally {

            //////Удаляем из памяти Асинтаск
            if (Курсор_УзнатьЕслиНаАндройдеТакойUUID!=null) {
                Курсор_УзнатьЕслиНаАндройдеТакойUUID.close();
                Курсор_УзнатьЕслиНаАндройдеТакойUUID=null;
            }

            ////
            if (Курсор_УзнатьЕслиНаАндройдеТакойID!=null) {
                Курсор_УзнатьЕслиНаАндройдеТакойID.close();
                Курсор_УзнатьЕслиНаАндройдеТакойID=null;

            }
        }

    }

    ////////// TODO  КОНЕЦ ОБНОВЛЕНИЕ JSON НА КЛИЕНТА

    ///----------- ТУТ КОД УЖЕ ПОСЫЛАНИЕ ДАННЫХ НА СЕРВЕР МЕТОДУ POST (данные андройда посылаються на сервер)


























    /////todo POST() МЕТОД КОГДА НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ ВЫШЕ ЧЕМ НА СЕРВРЕР И МЫ ПОСЫЛАЕМ JSON ФАЙЛ ТУДА МЕТОД POST
    void МетодПосылаемДанныеНаСервер(String имяТаблицыОтАндройда_локальноая) {
        ////
        Log.d(this.getClass().getName(), "  имяТаблицыОтАндройда_локальноая " +имяТаблицыОтАндройда_локальноая);
        Cursor КурсорДляОтправкиДанныхНаСервер = null;
        int    КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки=0;
        int   КоличествоКолоноквОтправвляемойТаблице=0;
        try{






            Log.d(this.getClass().getName(), "  МетодПосылаемДанныеНаСервер ");
            Cursor   КурсорДляАнализаДатыПоследнейОтпракиНаСервер=null;
            ///// еще не сделал
           КурсорДляАнализаДатыПоследнейОтпракиНаСервер = КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[] { "versionserveraandroid"}, "name=?", new String[]
                    {имяТаблицыОтАндройда_локальноая}  , null, null, null, null);
            //////ОЧИСТКА ПАМЯТИ ОТ ASYNSTASK
            /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
            Log.i(this.getClass().getName(), " КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount() " +КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount());


            if (КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount() >0) {///// КУРСОР ПО ПОИСКУ ДАТФ ПОСЛЕДНЕЙ ОТПРАВКИ НА СЕРВЕР
                КурсорДляАнализаДатыПоследнейОтпракиНаСервер.moveToFirst();
                String ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер = null;
                ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер = КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getString(0);



                ///TODO ЕСЛИ НЕТ ДАТЫ НЕЧЕГО ОТПРАВЛЯТЬ
                if (ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер!=null){
                    Log.d(this.getClass().getName(), " ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер "+ ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер +
                            "  имяТаблицыОтАндройда_локальноая " +имяТаблицыОтАндройда_локальноая);
                    int КоличествоСтрокПолученыеДляОтпарвкиПоДате =КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount();
                    Log.d(this.getClass().getName(), " ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер   " + ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер );

                    Log.d(this.getClass().getName()," ДатаВерсииДанныхНаSqlServer.toString() " + ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер

                            + " ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер андройд " +ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер);
                    ///todo
                    ///todo закрываем куроср
                    КурсорДляАнализаДатыПоследнейОтпракиНаСервер.close();
                    ////// todo ГЛАВНЫЙ КУРСОР ДЛЯ ОТПРАВКИ ДАННЫХ НА СЕРВЕР визцальаня синхронизация
                /* КурсорДляОтправкиДанныхНаСервер =КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,new String[] { "*"}, "date_update >?",
                         new String[] {ДатаВерсииДанныхНаSqlServer}  , null, null, null, null); ///ДатаВерсииДанныхНаSqlServer.toString() / ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер*/
//                    КурсорДляОтправкиДанныхНаСервер =КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,new String[] { "*"}, " date_update > ? ",
//                            new String[] {ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер}  , null, null, null, null);
//                    //////ОЧИСТКА ПАМЯТИ ОТ ASYNSTASK
//
//


// TODO: 28.04.2021  ГЛАВНЫЙ КУРСОР КОТОРЙ ВЫБИРАТЬ ЧТО НАМ ОТРРАВЛЯТЬ ИЛИ НЕТ

/* КурсорДляОтправкиДанныхНаСервер =КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,new String[] { "*"}, "date_update >?",
                         new String[] {ДатаВерсииДанныхНаSqlServer}  , null, null, null, null); ///ДатаВерсииДанныхНаSqlServer.toString() / ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер*/
                    if (имяТаблицыОтАндройда_локальноая.equalsIgnoreCase("tabels")) {
                        КурсорДляОтправкиДанныхНаСервер = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая, new String[]{"*"}, " date_update > ? AND fio IS NOT NULL",
                                new String[]{ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер}, null, null, null, null);
                    } else {
                        // TODO: 29.03.2021 все другие таблицы в фоне
                        КурсорДляОтправкиДанныхНаСервер = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая, new String[]{"*"}, " date_update > ? ",
                                new String[]{ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер}, null, null, null, null);
                    }







                    ///TODO курсор с данными для отправки на сервер

                    if (КурсорДляОтправкиДанныхНаСервер.getCount() >0) {/////работаем уже в сгенерированных даннных которые мы отправим на сервер
                        КурсорДляОтправкиДанныхНаСервер.moveToFirst();
                        КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки =КурсорДляОтправкиДанныхНаСервер.getCount();////КОЛИЧЕСТВО СТРОК В АНДРОЙДЕ ДАННЫЕ КОТОРЫЕ НУЖНО ПОСЛЛАТЬ
                        КоличествоКолоноквОтправвляемойТаблице=КурсорДляОтправкиДанныхНаСервер.getColumnCount();/////КОЛИЧЕСТВО СТОЛЮЦОВ НА АНДРОДЕ БАЗЕ КОТОРОЫЕ НУЖНО ОТОСЛАТЬ
                        ////
                        Log.d(this.getClass().getName(), " КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки  " + КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки+
                                "  КоличествоКолоноквОтправвляемойТаблице  "  +КоличествоКолоноквОтправвляемойТаблице);
                    }else {
                        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                        Log.d(this.getClass().getName(), " Нет данных для отправки на сервер не в фоне  КурсорДляОтправкиДанныхНаСервер.getCount() " + КурсорДляОтправкиДанныхНаСервер.getCount() );
                    }
                }}

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }finally {

            Log.d(this.getClass().getName(), "КурсорДляОтправкиДанныхНаСервер.getCount() " +КурсорДляОтправкиДанныхНаСервер.getCount()
                    + " имяТаблицыОтАндройда_локальноая " +имяТаблицыОтАндройда_локальноая);
            if (КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки>0) {
                //////// todo упаковываем в  json ПЕРЕХОДИМ НА СЛЕДУЩИМ МЕТОД

                МетодГенеррируемJSONИзНашыхДанных(КурсорДляОтправкиДанныхНаСервер,КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки,
                        КоличествоКолоноквОтправвляемойТаблице,имяТаблицыОтАндройда_локальноая);


                ///todo закрываем куроср
                КурсорДляОтправкиДанныхНаСервер.close();
            }
        }
    }


    ////////МЕТОД ГЕНЕРИРОУЕМ JSON ПОЛЯ НА ОСНОВАНИЕ НАШИХ ДАННЫХ ДЛЯ ПОСЛЕДЖУЮЩЕ ОТПРАВКИ
    void МетодГенеррируемJSONИзНашыхДанных(Cursor КурсорДляОтправкиДанныхНаСерверОтАндройда, int КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки,
                                                int КоличествоКолоноквОтправвляемойТаблице, String имяТаблицыОтАндройда_локальноая) {
        ///
        Log.d(this.getClass().getName(), " КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки " + КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки);

        int ЕслиUUIDПриЗабросеДанныхНаСервер = 0;
        int ЕслиIDПриЗабросеДанныхНаСервер=0;

        JSONObject ГенерацияJSONполейФинал = new JSONObject();///генериция финального поля дляJSON;  ////ПОЛЯ  ДЛЯ  JSON
        try {
///////метод создание josn из наших данных на отправку
            ////
            String ПерхнееПолеJSONПоследнаяОперация = null;////ПЕРЕРВОДИМ ИЗ INT TO STRING


            Log.d(this.getClass().getName(), " КурсорДляОтправкиДанныхНаСервер.getCount())   " + КурсорДляОтправкиДанныхНаСерверОтАндройда.getCount()+" имяТаблицыОтАндройда_локальноая " +имяТаблицыОтАндройда_локальноая);
            boolean СработалПоворот = false;
            ///// ДО DO WHILE ОБЯЗАТЕЛЬНО
            КурсорДляОтправкиДанныхНаСерверОтАндройда.moveToFirst();
            final int[] КакаяСтрочкаОбработкиТекущаяя = {1};/////ОСТЛЕЖИВАЕМ ТЕКУЩУЮ СТРОЧКУ ОБРАБОТКИ
            ///TODO ЗАПУСКАЕМ  ПуллПамяти
            ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных


            //todo бежим по строчкам json
            do {/////КРУТИТЬ ДАННЫЕ ЧЕРЕЗ ЦИКЛ ОТВЕТЫ ОТ МЕТОДА POST

                /// ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ
                ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных
                /// ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ


                /////////////////
                JSONObject ГенерацияJSONполей = new JSONObject();  ////ПОЛЯ  ДЛЯ  JSON ///ВАЖНО ГЕНЕРАЦИЯ НОВЫХ ОБЬЕКТОВ JSON НУЖНО СТАВИТЬ ВНУТРИ DO WHILE  НО ДО FOR ЦИКЛА МЕЖДУ НИМИ
                //todo бежим по столбцам
                for (int ИндексПоТАблицамДляОтправки = 0; ИндексПоТАблицамДляОтправки < КоличествоКолоноквОтправвляемойТаблице; ИндексПоТАблицамДляОтправки++) {
                    try {

                        //////////TODO ЭКСПЕРЕМЕНТ С JSON
                        //////ПОЛЯ ДЛЯ ВСТВКИ В JSON  ДЛЯ ОТПРАВКИ ЕГО НА СЕРВЕЛТ
                        String КлючJsonСтроки = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnName(ИндексПоТАблицамДляОтправки);


                        //TODO сомо имя json
                        System.out.println(" КлючJsonСтроки  " +КлючJsonСтроки );










                        /////////
                        Object ЗначниеJsonСтроки = КурсорДляОтправкиДанныхНаСерверОтАндройда.getString(ИндексПоТАблицамДляОтправки);

                        Log.d(this.getClass().getName(), " КлючJsonСтроки ::    "
                                + КлючJsonСтроки + "  ЗначниеJsonСтроки " + ЗначниеJsonСтроки);


                        //TODO НАЧИНАЕМ ОБРАБАТЫВАТЬ КОГДА ЗНАЧЕНИЕ ПО СТОЛБИКУ ОТРУСТУЕТ VALUE==BULL  #ПЕРВАЯ ЧАСТЬ
                        Log.d(this.getClass().getName(), " КлючJsonСтроки " + КлючJsonСтроки);
                        if (ЗначниеJsonСтроки == null) {
                  /*      ////todo если пустые значение по столбику имитируем его как текст но и как цифра для столиков fio and uuid
                        Log.d(this.getClass().getName(), " КлючJsonСтроки " +КлючJsonСтроки );
                        if (КлючJsonСтроки.equalsIgnoreCase("fio") || КлючJsonСтроки.equalsIgnoreCase("uuid") || КлючJsonСтроки.equalsIgnoreCase("id")){
                            //ЗначниеJsonСтроки=null;////чтобы небыло ошибки ПРИНУДИТЕЛЬНО В СОДРЕЖИСОА JSON ГЕНЕРИРУЕМОГО ДОБАВЛЯЕМ ПРОБЕЛЫ ЧТОБЫ JSON ПОД ДАНОМУ ПОЛЮ БЫЛ ЗОЗДАН
                            ////////// TODO КОНКРЕТАНАЯ ГЕНЕРАЦИЯ  JSON СТРОКИ
                                    ////разрешаем вставку с NULL
                                    if (КлючJsonСтроки!=null ) {
                                        ///todo генерация самой строки json ниже ключ к нему после for
                                        ГенерацияJSONполей.put(КлючJsonСтроки, ЗначниеJsonСтроки); ////заполение полей JSON
                                        ///
                                        Log.d(this.getClass().getName(), " КлючJsonСтроки  " + КлючJsonСтроки + "  ЗначниеJsonСтроки " +ЗначниеJsonСтроки );
                                        //todo обнуление после вставки
                                        КлючJsonСтроки=null;
                                        ЗначниеJsonСтроки=null;
                                    }
                        }
*/

                            //TODO НАЧИНАЕМ ОБРАБАТЫВАТЬ КОГДА ЗНАЧЕНИЕ ПО СТОЛБИКУ ЕСТЬ , ВСЕ  ХОРОШО И ИМЯ СТОБЛИКА ЕСТЬИ ЕГО ЗНАЧЕНИЕ ТОЖЕ ЕСТЬ #ВТОРАЯ ЧАСТЬ
                            Log.d(this.getClass().getName(), " КлючJsonСтроки " + КлючJsonСтроки);
                        } else if (ЗначниеJsonСтроки != null) {
                            ////////// TODO КОНКРЕТАНАЯ ГЕНЕРАЦИЯ  JSON СТРОКИ
                            if (КлючJsonСтроки != null && ЗначниеJsonСтроки != null) {//ПРОИЗВОДИМ ВСТАВКИ JSON ПОЛЕЙ ТОЛЬКО ЕСЛИ ОНИ НЕ NULL



                                ////TODO в обратную сторону обмена из _id в таблице tabels на id меняем ы фоне

                                if (имяТаблицыОтАндройда_локальноая.equals("tabels")
                                        && КлючJsonСтроки.equals("_id")){
                                    /////////
                                    КлючJsonСтроки="id";
                                    System.out.println("  КлючJsonСтроки  " +КлючJsonСтроки );



                                    //TODO для таблицы fio
                                }else if (имяТаблицыОтАндройда_локальноая.equals("fio")
                                        && КлючJsonСтроки.equals("_id")){
                                    /////////
                                    КлючJsonСтроки="id";
                                    System.out.println("  КлючJsonСтроки  " +КлючJsonСтроки );


                                }
                                //////

                                /////TODO вытаемся отслидить хотябы один заполненый день
                                Log.d(this.getClass().getName(), "КлючJsonСтроки " + "--" + КлючJsonСтроки +  " З начниеJsonСтроки " +ЗначниеJsonСтроки);/////


                                ///todo генерация самой строки json ниже ключ к нему после for///   && ЗначниеJsonСтроки.toString().matches("[1-9]"
                                if (КлючJsonСтроки.matches("[d].*") &&  КлючJsonСтроки.length()<=3) {
                                    ///////
                                    ГенерацияJSONполей.put(КлючJsonСтроки, ЗначниеJsonСтроки); ////заполение полей JSON

                                }else if (ЗначниеJsonСтроки!=null){
                                    ///////
                                    ГенерацияJSONполей.put(КлючJsonСтроки, ЗначниеJsonСтроки); ////заполение полей JSON
                                }




                                ///
                                Log.d(this.getClass().getName(), " КлючJsonСтроки  " + КлючJsonСтроки + "  ЗначниеJsonСтроки " + ЗначниеJsonСтроки);
                                //todo обнуление после вставки
                                КлючJsonСтроки = null;
                                ЗначниеJsonСтроки = null;
                            }
                            ///////////////ДОБАЛВЕНИЕ ВЕПХНЕГО ID ПО ВЕРХ JSON ПОЛЕЙ
                        }


                        //////////TODO  КОНЕЦ ЭКСПЕРЕМЕНТ С JSON
                        ///todo  только uuid
                        ЕслиUUIDПриЗабросеДанныхНаСервер = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("uuid");

                        if (ЕслиUUIDПриЗабросеДанныхНаСервер >= 0) {

                            Log.d(this.getClass().getName(), "ЕслиUUIDИлиIDПриЗабросеДанныхНаСервер " + ЕслиUUIDПриЗабросеДанныхНаСервер);
                            ///////////////ЕСЛИ ID ПОЛЕ ПУСТОЕ ТО ЗАПОЛНЕМЕМ ЕГО ВТОРЫМ ПОЛЕМ
                            int ИндексДвижениеПОПОлямДЛяФОрмированиеID = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("uuid");
                            ////todo
                            ПерхнееПолеJSONПоследнаяОперация = КурсорДляОтправкиДанныхНаСерверОтАндройда.getString(ИндексДвижениеПОПОлямДЛяФОрмированиеID);

                        }




                        ///todo  только id
                        ЕслиIDПриЗабросеДанныхНаСервер = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("id");

                        if (ЕслиIDПриЗабросеДанныхНаСервер >= 0 && ПерхнееПолеJSONПоследнаяОперация==null) {

                            Log.d(this.getClass().getName(), "ЕслиUUIDИлиIDПриЗабросеДанныхНаСервер " + ЕслиIDПриЗабросеДанныхНаСервер);
                            ///////////////ЕСЛИ ID ПОЛЕ ПУСТОЕ ТО ЗАПОЛНЕМЕМ ЕГО ВТОРЫМ ПОЛЕМ
                            int ИндексДвижениеПОПОлямДЛяФОрмированиеID = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("id");
                            ////todo
                            ПерхнееПолеJSONПоследнаяОперация = КурсорДляОтправкиДанныхНаСерверОтАндройда.getString(ИндексДвижениеПОПОлямДЛяФОрмированиеID);

                        }




                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ////// начало запись в файл
                    }
                }
                ///future



                ////TODO упаковываем jon если хоть какое поле есть   , ЕСЛИ ЕСТЬ ИЛИ ID ИЛИ UUID
                if (ПерхнееПолеJSONПоследнаяОперация!=null   &&  ГенерацияJSONполей!=null  && ГенерацияJSONполей.length()>0 )
                {


                    /// todo МЕЖДУ FOR И WHILE
                    Log.i(this.getClass().getName(), " ПерхнееПолеJSONПоследнаяОперация  :     " + ПерхнееПолеJSONПоследнаяОперация
                            + " ГенерацияJSONполей " + ГенерацияJSONполей.toString());


                    /////////
                    try {
                        //////////todo КОНКРЕТАНАЯ ГЕНЕРАЦИЯ  JSON ВЕРХНЕГО КЛЮЧА
                        ГенерацияJSONполейФинал.put(ПерхнееПолеJSONПоследнаяОперация, ГенерацияJSONполей);////ВСТАВЛЯЕМ ОДИН JSON в ДРУГОЙ JSON ПОЛУЧАЕМ ФИНАЛЬНЫЙ РЕЗУЛЬТАТ JSON"А

                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ////// начало запись в файл
                    }

                }


                КакаяСтрочкаОбработкиТекущаяя[0]++;////ЛОВИМ ТЕКУУЩЮ СТРОЧКУ ОБРАБОТКИ


                //todo ////


                //todo  ////

                ////// todo  КОНЕЦ МЕЖДУ FOR И WHILE
                ///todo идем по сторчкам  json
            } while (КурсорДляОтправкиДанныхНаСерверОтАндройда.moveToNext());////ДАННЫЕ КРУТИЯТЬСЯ ДО КОНЦА ДАННЫХ И ГЕНЕРИРУЮ JSON
            ///todo



            КурсорДляОтправкиДанныхНаСерверОтАндройда.close();

            /////

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл

        } finally {
            ////// TODO сгенировали JSON файл для отправки его на сервер


            /////////
            if (ГенерацияJSONполейФинал.toString().length() > 3) {

                ///////// TODO ФИНАЛ ПРОСМАТРИВАЕМ СГЕНЕРИРОВАНЫЙ JSON  ФАЙЛ ПОСЛЕ ЦИКЛА DO WHILE СОЗДАИНИЕ НА СТОРОНЕ АНДРОЙДА JSON ПОЛЕЙ
                Log.d(this.getClass().getName(), " ГенерацияJSONполейФинал  "+   ГенерацияJSONполейФинал+ " ГенерацияJSONполейФинал "+ ГенерацияJSONполейФинал.toString() + " ГенерацияJSONполейФинал.length() " + ГенерацияJSONполейФинал.length());
                //TODO ЗАКРЫВАЕМ КУРСОР
                ///todo МЫ СОЗДАЛИ ФАЙЛ JSON  И ПОСЫЛАЕМ ЕГО НА СЕРВЕР
                МетодПосылаетНаСерверСозданныйJSONФайл(ГенерацияJSONполейФинал, имяТаблицыОтАндройда_локальноая); ////СГЕНЕРИРОВАНЫЙ JSON ФАЙЛ ЕСЛИ БОЛЬШЕ 2 ССИМВОЛОМ В НЕМ ТО ОТПРАВЛЯЕМ
            }
        }

    }


    //////todo МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST
    void МетодПосылаетНаСерверСозданныйJSONФайл(JSONObject ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда, String имяТаблицыОтАндройда_локальноая) {
        /////
        Log.d(this.getClass().getName(), " ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString() "
                + ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString() +
                " ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString().toCharArray().length  "
                + ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString().toCharArray().length+
                " имяТаблицыОтАндройда_локальноая " +имяТаблицыОтАндройда_локальноая);




        String ДанныеПришёлВОтветОтМетодаPOST = new String();
        ///

        StringBuffer БуферОтправкаДанных=new StringBuffer();
        try {
            Log.d(this.getClass().getName(), "  МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST ");

            // TODO: 15.06.2021 проверяем если таблица табель то еси в нутри потока отпралеемого хоть один день d1,d2,d3 защита от пустого траыфика\





            if (имяТаблицыОтАндройда_локальноая.equalsIgnoreCase("tabels")) {

                boolean РезультатАнализа =   new MODEL_synchronized(КонтекстСинхроДляКонтроллера).
                        МетодКоторыйВычисляетЕслиДНИвПотоке (имяТаблицыОтАндройда_локальноая ,ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда );


                if (РезультатАнализа==true) {
                    ////
                    //////todo МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST
                    БуферОтправкаДанных = УниверсальныйБуферОтправкиДанныхНаСервера(ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда,
                            PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID, имяТаблицыОтАндройда_локальноая,
                            "Получение JSON файла от Андройда"); ///БУФЕР ОТПРАВКИ ДАННЫХ НА СЕРВЕР

                    Log.d(this.getClass().getName(), "БуферОтправкаДанных.toString() "+БуферОтправкаДанных.toString());
                }


                // TODO: 15.06.2021 ве сотадльные таблицы кроме табелей
            }else{


                //////todo МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST
                БуферОтправкаДанных = УниверсальныйБуферОтправкиДанныхНаСервера(ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда,
                        PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID, имяТаблицыОтАндройда_локальноая,
                        "Получение JSON файла от Андройда"); ///БУФЕР ОТПРАВКИ ДАННЫХ НА СЕРВЕР

                Log.d(this.getClass().getName(), "БуферОтправкаДанных.toString() "+БуферОтправкаДанных.toString());

            }










            ////TODO  ОТВЕТ ОТ СЕРВЕРА ПОСЛЕ ОТПРАВКИ ДАННЫХ НА СЕРВЕР
            if (БуферОтправкаДанных!=null && БуферОтправкаДанных.length()>0) {
                do {
                    ДанныеПришёлВОтветОтМетодаPOST = БуферОтправкаДанных.toString();
                    Log.d(this.getClass().getName(), "  ДанныеПришёлВОтветОтМетодаPOST  " + ДанныеПришёлВОтветОтМетодаPOST);
                } while (ДанныеПришёлВОтветОтМетодаPOST == null);/////конец for # количество респонсев
                ////
                Log.d(this.getClass().getName(), " ДанныеПришёлВОтветОтМетодаPOST " + ДанныеПришёлВОтветОтМетодаPOST);
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера БуферОтправкаДанных.length() " + БуферОтправкаДанных.length());
            }
            
            
            ///////////////////////////////////////////////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        } finally {
            ////TODO ОТВЕТ ОТ СЕРВЕРА
            Log.d(this.getClass().getName(), " ДанныеПришёлВОтветОтМетодаPOST " + ДанныеПришёлВОтветОтМетодаPOST);
            if (ДанныеПришёлВОтветОтМетодаPOST.length() > 0) {
                /////// данные код анализирует успешные и/ил обновление данных на серврер кторые ему присла пользователь
                МетодАнализаОтветаОтСервераУспешныеВставкиИлиОбновление(ДанныеПришёлВОтветОтМетодаPOST, имяТаблицыОтАндройда_локальноая);

            }
        }
    }





    /////// TODO не ФОНЕ
    // данные код анализирует успешные и/ил обновление данных на серврер кторые ему присла пользователь
    void МетодАнализаОтветаОтСервераУспешныеВставкиИлиОбновление( String    ДанныеПришёлВОтветОтМетодаPOST,String имяТаблицыОтАндройда_локальноая) {
        //////
        Log.d(this.getClass().getName(), "  ДанныеПришёлВОтветОтМетодаPOST " + ДанныеПришёлВОтветОтМетодаPOST);

        StringBuffer ОтветОтСервераДляВставки = new StringBuffer();
        try {
            Log.d(this.getClass().getName(), " ДанныеПришёлВОтветОтМетодаPOST             " + ДанныеПришёлВОтветОтМетодаPOST);
/////// данные код анализирует успешные и/ил обновление данных на серврер кторые ему присла пользователь

            ////todo обновление ответной от сервера
            int УспешноеОбновлениеНаСерверe=0;
            int УспешноеВставкаНаСервере=0;
            String ВытащилиUUIDИзPOST = "";
            //TODO ОБНОВЛНИЕ
            int УспешныеЛиОтветыОтСервераИлиНет = ДанныеПришёлВОтветОтМетодаPOST.indexOf("::");///TODO если в теле ответа от сервера POSt вообще ::
            if (УспешныеЛиОтветыОтСервераИлиНет>0){
                ///////
                for (String ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера :  ДанныеПришёлВОтветОтМетодаPOST.split("::")) {
                    /////
                    if (УспешноеОбновлениеНаСерверe==0) {
                        УспешноеОбновлениеНаСерверe = ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера.indexOf("Обновление");
                    }
                    if( УспешноеВставкаНаСервере==0) {
                        УспешноеВставкаНаСервере = ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера.indexOf("Вставка");
                    }
                    //////////
                    for ( String ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений :  ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера.split(" ")) {
                        Log.d(this.getClass().getName(), "  ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений " + ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений);
                        boolean РезультатЯвляетьсяЦифройВесьТекст = МетодОпределениеВселиЦифрыВстроке(ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений);
                        Log.d(this.getClass().getName(), " РезультатЯвляетьсяЦифройВесьТекст            " + РезультатЯвляетьсяЦифройВесьТекст);
                        if (РезультатЯвляетьсяЦифройВесьТекст == true) {
                            ВытащилиUUIDИзPOST=ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений;

                            ////todo при успешной обновления сервера и получение статуса обнолвения вернулось с СЕРВЕРА ЗАПУСКАМ ДАННЫЙ МЕТОД
                            long  РезультатПослеОбновлениеЧерезКонтрейнер=0;
                            РезультатПослеОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерВозвращениеРезультатаОтСервераУниверсальная(имяТаблицыОтАндройда_локальноая,
                                    Long.parseLong(ВытащилиUUIDИзPOST),
                                    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);
                            /// после обновление  в базу обнуляем контейнер  данные от сервера



/////TODO РЕЗУЛЬТАТА ВСТАВКИ ОТВЕТА ОТ СЕРВРЕ НА КЛИНЕТ ПРИ УСПЕШНОЙ ОБНОВЛЕНИИ ИЛИ ВСТАВКЕ
                            if (РезультатПослеОбновлениеЧерезКонтрейнер > 0) {
                                //todo обявлем успешное встаку
                                if (УспешноеОбновлениеНаСерверe>0){
                                    PUBLIC_CONTENT.КоличествоУспешныхОбновлений++;
                                    /////
                                    //// TODO ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице++;
                                    ////todo после успешной операции обнуяем
                                    УспешноеОбновлениеНаСерверe=0;
                                }else if (УспешноеВставкаНаСервере>0){
                                    PUBLIC_CONTENT. КоличествоУспешныхВставки++;
                                    //////
                                    //// TODO ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице++;
                                    ////todo после успешной операции обнуяем
                                    УспешноеВставкаНаСервере=0;
                                }
                                ////TODO метод POST ответ от сервера
                                //todo обявлем успешное обнолвнение
                                Log.d(this.getClass().getName(), " КоличествоУспешныхВставки " + PUBLIC_CONTENT.КоличествоУспешныхВставки + " КоличествоУспешныхОбновлений " + PUBLIC_CONTENT.КоличествоУспешныхОбновлений);
                            }
                        }}
                    ////// todo Удаляем из памяти Асинтаск

                }
            }




            //////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }
    ///todo являеться ли весь текст числом
    boolean МетодОпределениеВселиЦифрыВстроке(String ВселиЦифрыВтексе) {
        boolean Результат=false;
        try {
            Long.parseLong(ВселиЦифрыВтексе);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }

    }

    ///////TODO КОД КОТОРЫЙ ЗАПУСКАЕТ ЛЮБОЕ АКТИВТИ ИЗ ПРОСТОГО КЛАССА
    void МетодВызываетИПростогоКлассаАктивити() {
        //captureImage();
        Activity activity = new Activity();
        Intent i1 = new Intent ( activity, MainActivity_Single_Tabely.class);
        activity.startActivity(i1);
    }


    public  void МетодОчищаемИзБазыNULLЗначенияя(){


        try{


            // TODO: 26.03.2021 ДОПОЛНИТЕЛЬНО ОБНУЛЯЕМ ВСЕ ТАБЕЛЯ С NULL В ФИО ЧТО БЫ ОБМЕН НЕ РУГАЛЬСЯ

            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE fio IS NULL");
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE cfo IS NULL");
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE nametabel_typename IS NULL");
            ССылкаНаСозданнуюБазу.setTransactionSuccessful();
            ССылкаНаСозданнуюБазу.endTransaction();

            ///////todo\
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }

    //////ТУТ БУДЕТ ЗАПИСЫВАТЬСЯ УСПЕШНОЕ ОБНЛВДЕНИ И ВСТАВКИ ДАННЫХ НА СЕРВЕРЕ ДЛЯ КЛИЕНТА

}











































































































































///////////--------------------------TODO ЭТО ТРЕТИЙ  КОНТРОЛЛЕР ТОЛЬКО ДЛЯ ПОЛУЧЕНИЯ  ТОЛЬКО JSON ПОЛЕЙ  И СКОЛЬКО ТАБЛИЦ НУЖНО БЕЗ  СИНХРОНИЗАЦИИИ-----------------------------------------------------------



class CONTROLLER_synchronized_ROWS_JSON_AND_ALL_TABLES extends MODEL_synchronized {

    String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;
    /////
    Context КонтекстСинхроДляКонтроллераOnlyROWSAllTables;


    public CONTROLLER_synchronized_ROWS_JSON_AND_ALL_TABLES(Context context) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
        super(context);
        ////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК

        КонтекстСинхроДляКонтроллераOnlyROWSAllTables=context;

        // ССылкаНаСозданнуюБазу = this.getWritableDatabase(); //ссылка на схему базы данных;//ссылка на схему базы данных ГЛАВНАЯ ВСТАВКА НА БАЗУ ДСУ-1
        ////// TODO созданеи шифрование
        if ( PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки==null) {
            //TODO ключ для шифрование и расщифровки
            byte[] CipherKey= "[C@3841f624[B@6415a86b[B@143c678".getBytes();
            PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки =
                    new SecretKeySpec(CipherKey,
                            "AES");
            PUBLIC_CONTENT. ПолитикаШифрование= Cipher.getInstance("AES");
            PUBLIC_CONTENT.ПолитикаШифрование.init(Cipher.ENCRYPT_MODE, PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки);
            ///////
            PUBLIC_CONTENT.ПолитикаРасшифровки= Cipher.getInstance("AES");
            PUBLIC_CONTENT. ПолитикаРасшифровки.init(Cipher.DECRYPT_MODE, PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки);
            ///// конец шифрование
        }
        ////// конец  TODO созданеи шифрование
    }


    ////


    /////////////
    ContentValues  АдаптерПриОбновленияДанныхсСервера= new ContentValues();
    ContentValues   АдаптерДляВставкиДанныхсСервер= new ContentValues();

    Cursor Курсор_УзнатьЕслиНаАндройдеТакойUUID = null;/// ТУТ ОН ЗАПОНИМАЕНТ ПОСЛЕНИЙ UUID НА СТРОЙКИ







////// TODO ПЕРВЫЙ МЕТОД ОБМЕНА ДАННЫМИ С СЕРВЕРОМ МЕТОД GET JSON только когда иы хотим узнать все строки json  по всем строкам мы запускаем этот код И ВСЕ !!!!

    Integer  МетодНачалоСихронизациивПолучениеКоличествоJSON(Context  context) throws InterruptedException, ExecutionException, TimeoutException, JSONException {

        ////////todo ОБНУЛЯЕМ КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ ОБНОВЛЕНИЙ
        КонтекстСинхроДляКонтроллераOnlyROWSAllTables=context;
        /////
        try{


            try{
                ////TODO ДАННЫЙ ЦИКЛ НУЖЕН ПЕРВЫЙ ШАГОМ ВЫ ВСТАВЛЯЕМ ДАННЫЕ ЕСЛИ ОНИ ЕСТЬ , А ВТОРЫМ ШАГОМ И ИХ ДОГОНЯЕМ ОБНОВЛЕМ ДАННЫЕ ВОТ ТАК  ДЛЯ СИНХРОНИЗАЦИИ





                        ////САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ
                        Integer РезультатПолучениеПубличногоIDВВизуальнойсинхронизцииВнутри=
                                МетодПолучениеIDотСервераДляГеренированиеUUIDONLYROWS(); ////САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ///// TODO ГЛАВНЫЙ МЕТОД ОБМЕНА ДАНЫМИ  НА АКТИВИТИ FACE_APP




                      ///
                if (РезультатПолучениеПубличногоIDВВизуальнойсинхронизцииВнутри>0) {
                    ///////
                    PUBLIC_CONTENT.ПУбличныйДанныеПришёлЛиIDДЛяГенерацииUUID= String.valueOf(РезультатПолучениеПубличногоIDВВизуальнойсинхронизцииВнутри);
                }


                /////


                Log.d(this.getClass().getName(), "СЛУЖБА  ПОЛУЧЕНИЕ ПУБЛИЧНГО ID ВИЗУАЛЬНОЙ СИНХОРНИЗАЦИИ РезультатПолучениеПубличногоIDВВизуальнойсинхронизции  "
                        +РезультатПолучениеПубличногоIDВВизуальнойсинхронизцииВнутри);






                ///todo конец финал обрабоатываем обновлениея
                ///todo конец финал обрабоатываем обновлениея
                ///TOD

            } catch (Exception e) {
                //  Block of code to handle errors
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
             new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
            }



            //////////

        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return  PUBLIC_CONTENT.СколькоСтрочекJSON;
        ///////
    }








    Integer МетодПолучениеIDотСервераДляГеренированиеUUIDONLYROWS () throws JSONException, InterruptedException, ExecutionException, TimeoutException {
        ///
        Integer ДанныеПришёлЛиIDДЛяГенерацииUUID = 0;
        /////

        try {
            Log.d(this.getClass().getName(), " public   void МетодПолучениеIDОтСервераДляГеренированиеUUID ()" +
                    " ДанныеПришёлЛиIDДЛяГенерацииUUID " + ДанныеПришёлЛиIDДЛяГенерацииUUID);


                    Long результатЗаписиОргназации = 0l;

                    //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
                    StringBuffer  БуферПолучениеДанных=new StringBuffer();

            //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
            try {
                БуферПолучениеДанных= УниверсальныйБуферПолучениеДанныхсСервера("","","","application/text","Хотим Получить ID для Генерации  UUID","",""); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position
                //////////

            } catch (Exception e) {
                //  Block of code to handle errors
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
            }

            ///////

            if (БуферПолучениеДанных!=null && БуферПолучениеДанных.length()>0) {
                /////TODO ЦИКЛ ПОЛУЧЕНИЯ UUID
                do {
                    // TODO: 26.05.2021
                    ДанныеПришёлЛиIDДЛяГенерацииUUID = Integer.parseInt(БуферПолучениеДанных.toString());
                    ///
                    Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID  " + ДанныеПришёлЛиIDДЛяГенерацииUUID);
                    /////todo ПРИСВАВАЕМ ПОЛУЧЕННЫЙ ПУБЛИЧНЫЙ ID ВСЕЙ ПРОГРММЕ
                    PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID = БуферПолучениеДанных.toString(); ///ИЗ ОТВЕТА ПОЛУЧАЕМ ID ПОЛЬЗОВАТЕЛЯ ДЛЯ ГЕНЕРАЦИИ  UUID//

                    ///todo если мы прошли один раз и нет данных выходим
                    if ( ДанныеПришёлЛиIDДЛяГенерацииUUID>0){

                        break;
                    }
                    /////
                } while (ДанныеПришёлЛиIDДЛяГенерацииUUID==0);/////конец for # количество респонсев


                Log.d(this.getClass().getName(), "  ПубличноеIDПолученныйИзСервлетаДляUUID  " + PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID);


                // TODO: 29.03.2021 записываем полученный от сенрврера Пубдиный ID



                if (ДанныеПришёлЛиIDДЛяГенерацииUUID !=null) {
                    ////
                    if ( ДанныеПришёлЛиIDДЛяГенерацииUUID>0 ){//ЕСЛИ МЫ ПОЛУЧИЛИ ID  и СОЗДАЛИ НА ЕГО БАЗЕ UUID ТО ПРОХОДИИМ К СЛЕДУЮЩЕМУ КОДУ ПОЛУЧАЕМ ВЕРСИЮ ДАННЫХ СЕРВВЕРА

                        // TODO: 19.03.2021 метод записываем версию данных ID  от сервера в локальную базу

                        Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID  "+ ДанныеПришёлЛиIDДЛяГенерацииUUID);




                        // TODO: 07.05.2021 запись организации

            результатЗаписиОргназации=           МетодЗАписиПолученогоОтСервреаIDПубличного(String.valueOf(ДанныеПришёлЛиIDДЛяГенерацииUUID));





                        Log.d(this.getClass().getName(), "  результатЗаписиОргназации  "+результатЗаписиОргназации);


                        ////запускаем слуд.ющий метод получение версии базы данных
                        МетодПолучениеСпискаТаблицДляОбменаДанными (String.valueOf(ДанныеПришёлЛиIDДЛяГенерацииUUID));//получаем ID для генерирования UUID
                    }
                }

                ////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера  " );
            }



  /////


        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


        return ДанныеПришёлЛиIDДЛяГенерацииUUID;

    }
















    ///////////////////метод получение ОТ СЕРВЕРА КОНКРЕТНЫЙ СПИСОК ТАДОИЦЦ ДЛЯ ОБМЕНА


    ////////////МЕТОД ПОЛУЧЕНИЕ  ВЕРСИИ ДАННЫХ
  protected   StringBuffer МетодПолучениеСпискаТаблицДляОбменаДанными (@NonNull  String  ДанныеПришёлЛиIDДЛяГенерацииUUID) throws JSONException, InterruptedException, ExecutionException, TimeoutException {///второй метод получаем версию данных на СЕРВЕР ЧТОБЫ СОПОЧТАВИТЬ ДАТЫ
//////

        Log.d(this.getClass().getName(), " ДанныеПришёлЛиIDДЛяГенерацииUUID" + ДанныеПришёлЛиIDДЛяГенерацииUUID);
        String    ДанныеПришлаСпискаТаблицДляОбмена = new String();
        StringBuffer БуферПолученияСпискаТАблицДляОбмена = new   StringBuffer();


        ////TODO ПОСЛЕ ОБРАБОТКИ ТАБЛИЦ ОБНУЛЯЕМ
        PUBLIC_CONTENT.ИменаТаблицыОтАндройда.clear();

        try {
            //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
            БуферПолученияСпискаТАблицДляОбмена = УниверсальныйБуферПолучениеДанныхсСервера("view_data_modification","", "","application/json",
                    "Хотим Получить Версию Данных Сервера","",ДанныеПришёлЛиIDДЛяГенерацииUUID); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position


            //////


            Log.d(this.getClass().getName(), " БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length " + БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length);
            if (БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length>3) {
                do {
                    ДанныеПришлаСпискаТаблицДляОбмена= БуферПолученияСпискаТАблицДляОбмена .toString();
                    //////
                    БуферПолученияСпискаТАблицДляОбмена.append(ДанныеПришлаСпискаТаблицДляОбмена).append("\n");
                    Log.d(this.getClass().getName(), " ДанныеПришлаЛиВерсияДанныхсСервера " +ДанныеПришлаСпискаТаблицДляОбмена);
                } while (ДанныеПришлаСпискаТаблицДляОбмена== null);/////конец for # количество респонсев
                /////
                Log.d(this.getClass().getName(), "  ПубличноеIDПолученныйИзСервлетаДляUUID  " + PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID +
                        " БуферПолученияСпискаТАблицДляОбмена Для Обмена " +БуферПолученияСпискаТАблицДляОбмена.toString());
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
                ///ПОЛУЧЕННЫЙ СПИСОК ЗАПИСЫВАЕМ В ТАБЛИЦУ НАШУ ПЕРЕРМЕННЦУЮ
                JSONObject  ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента= new JSONObject(БуферПолученияСпискаТАблицДляОбмена.toString());///упаковываем в j
                ///
                JSONArray МассивJSONТаблиц = ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.names();
                String  НазваниеИзПришедшихТаблицДляКлиента;
                String СодержимоеИзПришедшихТаблицДляКлиента;
                String JSONСтрочка ;
                String  JSONНазваниеСтолбика;
                String JSONСодержимоеСтолика;
                String JSONСодержимоеСтоликаДляХэша;
                /////ЦИКЛ КРУТИТЬ JSON

                PUBLIC_CONTENT.ИменаТаблицыОтАндройда.clear();

                /////ЦИКЛ КОТРЫЙ БЕЖИТ ПО СТОРОКА ПРИГЕДШЕГО JSON ФАЙЛА И НАХОДИМ НАЩШИ ТАЮЛИЦЫ ДЛЯ УКАЗАННОГО ПОЛЬЗОВАТСЯ
                for ( int ИндексТаблицыДляДанногоКлиента= 0;ИндексТаблицыДляДанногоКлиента< ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.names().length(); ИндексТаблицыДляДанногоКлиента++) {
                    ////// распарсиваем  josn
                    НазваниеИзПришедшихТаблицДляКлиента = МассивJSONТаблиц .getString(ИндексТаблицыДляДанногоКлиента);
                    СодержимоеИзПришедшихТаблицДляКлиента = ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.getString(НазваниеИзПришедшихТаблицДляКлиента); // Here's
                    JSONObject  ОбьектJSON= new JSONObject(СодержимоеИзПришедшихТаблицДляКлиента);
                    JSONСтрочка = String.valueOf(ОбьектJSON.names());
                    /////ЦИКЛ КОТРЫЙ БЕЖИТ ПО СТОЛБЦАМ  ПРИГЕДШЕГО JSON ФАЙЛА И НАХОДИМ НАЩШИ ТАЮЛИЦЫ ДЛЯ УКАЗАННОГО ПОЛЬЗОВАТСЯ
                    for ( int ИндексТаблицыДляДанногоКлиентаСтолбцы= 0;ИндексТаблицыДляДанногоКлиентаСтолбцы< ОбьектJSON.length(); ИндексТаблицыДляДанногоКлиентаСтолбцы++) {
                        JSONНазваниеСтолбика = String.valueOf(ОбьектJSON.names().get(ИндексТаблицыДляДанногоКлиентаСтолбцы));
                        JSONСодержимоеСтолика = ОбьектJSON.getString(JSONНазваниеСтолбика);
                        ///ЗАПОЛНЯЕМ ТОЛЬКО НАЗВАНИЯ ТАБЛИЦ  ПРЕДНАЗВАНЧЕН ТОЛЬКО ДЛЯ ДАННГО ПОЛЬЗОВАТЕЛЯ ТАБЛИЦЫ ПО КОТОРЫМ БУДЕТ ОБМЕН
                        ///todo вытаскмваем название таблиц для заполения таблицы модификейшен клеинта на андройде
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ИМЯ ИЗ МОДИФИКАЦИИ СЕРВЕР") ){



                            //////TODO ЗАПОЛЯЕМ ИМЕНАМИ ТАБЛИЦ ДЛЯ ПОСЛУДУЮЩИЕ ОБРАБОТКИ КАКИЕ ТАБЛИЦЫ ЗАПОЛНЯТЬСЯ ТАКИЕ И БУДУТ ПРИНИМАТЬ УЧАСТИЕ В СИНХРОНИЗАЦИИ

                            PUBLIC_CONTENT.ИменаТаблицыОтАндройда.add(JSONСодержимоеСтолика); //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ

                            Log.d(this.getClass().getName(), " JSONСодержимоеСтолика " +JSONСодержимоеСтолика
                                    + "  UBLIC_CONTENT.ИменаТаблицыОтАндройда.size(  " +PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size());
                        }
                        /////А ТУТ МЫ ПРОСТО ЗАПОМИНАЕМ НАЗВАНИЕ ТАБЛИЦ С СЕРВЕРА  И ПЛЮС ИХ ДАТЫ ПОСЛЕДНЕГО ИЗМЕНЕНИЕ ДАННЫХ НА ДАННЫХ ТАБЛИЦАХ НА СЕРВЕРЕ
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ИМЯ ИЗ МОДИФИКАЦИИ СЕРВЕР") ) {
                            //////ОТДЕЛЬНО ДляХэшМап

                            JSONСодержимоеСтоликаДляХэша = ОбьектJSON.getString("ДАТА ВЕРСИИ СЕРВЕРА");/////ТОЛЬКО ДЛЯ HSMAP
                            PUBLIC_CONTENT. ДатыТаблицыВерсииДанныхОтСервера.put(JSONСодержимоеСтолика, JSONСодержимоеСтоликаДляХэша); ///// ЗАПОЛНЯЕМ ХЭШМАП ДЛЯ КРНКРЕТНОГО ПОЛЬЗОВАТЕЛЯ ТАБЛИЦ ДЛЯ ТОЛЬКО СЕСИИ

                            Log.d(this.getClass().getName(), " JSONСодержимоеСтолика " +JSONСодержимоеСтолика+ "  JSONСодержимоеСтоликаДляХэша  "+ JSONСодержимоеСтоликаДляХэша );
                        }
                        //todo проект имена
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ПРОЕКТЫ") ){
                            PUBLIC_CONTENT.  ИменаПроектовОтСервера.add(JSONСодержимоеСтолика);
                            //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ
                            Log.d(this.getClass().getName(), " ИменаПроектовОтСервера " +PUBLIC_CONTENT.ИменаПроектовОтСервера.toString());
                        }

                    }



                }


                Log.d(this.getClass().getName(), "  UBLIC_CONTENT.ИменаТаблицыОтАндройда.size(  " +PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size());




                //////
                /////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера  " );





            }
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }finally {
            Log.i(this.getClass().getName(), " ИменаТаблицыОтАндройда " +PUBLIC_CONTENT.ИменаТаблицыОтАндройда.toString() +
                    " ДатыТаблицыВерсииДанныхОтСервера " +PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.toString());
            if (ДанныеПришлаСпискаТаблицДляОбмена.length()>2){//ЕСЛИ МЫ ПОЛУЧИЛИ ID  и СОЗДАЛИ НА ЕГО БАЗЕ UUID ТО ПРОХОДИИМ К СЛЕДУЮЩЕМУ КОДУ ПОЛУЧАЕМ ВЕРСИЮ ДАННЫХ СЕРВВЕРА
                ////запускаем слуд.ющий метод получение версии базы данных
                if (БуферПолученияСпискаТАблицДляОбмена!=null  && БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length>0);
                //// TODO запускам если ОТ СЕРВЕРА ПРИШЛИ  ДАННЫЕ СПИСОК ТАБЛИЦ ДЛЯ СОЗДАНИЕ СПИСК ДЛЯ ПОЛЬЗОВАТЕЯД

                ////TODO ТОЛЬКО НЕ ДЛЯ АКТИВТИ АНОНИМНЫЙ ОБМЕН БЕЗ ВИЗУАЛИЗАЦИИ СИНХРОНИЗАЦИИ
                МетодЗапускаемЦиклПоТаблицамДляДанногоПользователя(  ДанныеПришёлЛиIDДЛяГенерацииUUID);

            }
        }
   return (StringBuffer)   БуферПолученияСпискаТАблицДляОбмена;
    }











    /////TODO МЕТОД ЗАПУСКА ЦИКЛА ПО ПОЛУЧЕННЫСМ ТАБЛИЦ С СЕРВЕРА ДАННЫХ ЦИКЛ FOR

/////

    void  МетодЗапускаемЦиклПоТаблицамДляДанногоПользователя(@NonNull String    ДанныеПришёлЛиIDДЛяГенерацииUUID){//КонтекстСинхроДляКонтроллера
        try{
/// ТУТ МЫ ЗАПУСКАЕМ ЦИКЛ С ПОЛУЧЕНЫМИ ДО  ЭТГО ТАБЛИЦАП КОНКРЕТНО ДЛЯ  ЭТОГО ПОДЛЬЗОВАТЛЯ
            Log.i(this.getClass().getName(), " ИменаТаблицыОтАндройда " +PUBLIC_CONTENT.ИменаТаблицыОтАндройда.toString() +
                    " ДатыТаблицыВерсииДанныхОтСервера " +PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.toString());
//          ////TODO настройки поо расширению количесво потоков в момент выполенния
            ////TODO текущая ТАБЛИЦА ПРИ ОБРАБОТКИ СИНХРОНИЗАЦИИ КОТОРАЯ УВЕЛИЧИВАЕТЬСЯ В ЦИКДЕ ПРИ ОБМЕНЕН
            ////////
            PUBLIC_CONTENT.  ОбщееКоличествоТаблиц=PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size();

            int ОбщееКоличествоТаблиц=PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size();






            //TODO ОБНУЛЯЕМ КОЛИЧЕСТВО СТРОЧКЕ КАЖДЫЙ РАЗ КОГДА ПРИХОДИТ НОВЫЙ ФАЙЛ С JSON только когда иы хотим узнать все строки json  по всем строкам мы запускаем этот код И ВСЕ !!!!

            ////// TODO ГЛАВНЫЙ ПЕРВЫЙ ЦИКЛ ОБМЕНА ДАННЫХ         //////ГЛАВНЫЙ ПЕРВЫЙ ЦИКЛ ОБМЕНА ДАННЫХ         //////ГЛАВНЫЙ ПЕРВЫЙ ЦИКЛ ОБМЕНА ДАННЫХ
            for(String ТекущаяТаблицаДляОБменаДанными: PUBLIC_CONTENT.ИменаТаблицыОтАндройда) {
                //////







                Log.d(this.getClass().getName(), " ТекущаяТаблицаДляОБменаДанными " + ТекущаяТаблицаДляОБменаДанными );
                /////
                try {
                    ///TODO сон
                    //////TODO метод обрабтки п таюлицам
                    МетодДляАнализаВерсийДанныхПолучаемДатыСервера(ТекущаяТаблицаДляОБменаДанными,   ДанныеПришёлЛиIDДЛяГенерацииUUID); ////Получение Версии Данных Сервера для дальнейшего анализа
                    ///todo публикум название таблицы или цифру его

                    // TODO: 23.05.2021




                    ////TODO
                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

                ////// todo  ПАРСИНГ ПРИШЕДЩЕГО JOSN ЗАПСКАЕМ МЕТОД ЕСЛИ РЕАЛЬНО ДАННЫЕ ПРИШЛИ ОТ СЕРВЕРА В ВИДЕ JSON
                /////TODO код которй запускаеть из класса Активти
                ///TODO засыпаем
                /////todo КОНЕЦ цикла фор



                //////


            }///end for

            // TODO: 23.05.2021


            // TODO: 05.04.2021 после цикла



        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }










    /////////////////////ИЩЕМ ДАТУ СЕРВЕРВА
    void МетодДляАнализаВерсийДанныхПолучаемДатыСервера(String ТекущаяТаблицаДляОБменаДанными, String ДанныеПришёлЛиIDДЛяГенерацииUUID)
            throws JSONException, InterruptedException, ExecutionException, TimeoutException {
        //
        Date ДатаВерсииДанныхНаSqlServer = null;
        try{

            Log.d(this.getClass().getName(), " ДанныеПришёлЛиIDДЛяГенерацииUUID  "  +ДанныеПришёлЛиIDДЛяГенерацииUUID+ " ТекущаяТаблицаДляОБменаДанными "+ ТекущаяТаблицаДляОБменаДанными);

            String  ПолученнаяДатыSqlServer;
            JSONObject ОбьектыJSONФайлJSONсСервераВерсияSQlserver = new JSONObject();
            String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных = "";
            String ИмитацияВремяДляПроверки;
            Date ИмитациДатыДляПроверки = null;
            ///////
            String ТесктДатыSqlServer = null;
            try {
/////ТУТ -- КОД АНАЛИЗА ДАННЫХ SQL SERVER  ПРИШЕДШЕЙ ТЕКУЩЕЙ ТАБЛИЦЕ ПОЛУЧАЕМ НАЗВАНИЕ БАЗЫ И К НЕЙ ПОЛУЧАЕМ ДАТУ Е НЕЙ
//анализируем записи и ищем нашут текущаю таблицу и дату к ней
                for(Map.Entry<String, String> ХэшДляАнализаТекущейТаблицыВерсииДанных: PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.entrySet()){

                    System.out.println( ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey() + " - " +  ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue());

                    if (ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey().equalsIgnoreCase(ТекущаяТаблицаДляОБменаДанными) ) {///ищем в текущей строчке текущуе название таблицы например CFO==CFO
                        ////записываем в json  получену.юю текущаю названеи табиуви к ней дата ВЕРСИЯ ДАННЫХ
                        /////
                        ОбьектыJSONФайлJSONсСервераВерсияSQlserver.put(ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey(), ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue());
                        /////
                        Log.d(this.getClass().getName()," ОбьектыJSONФайлJSONсСервераВерсияSQlserver " +ОбьектыJSONФайлJSONсСервераВерсияSQlserver.toString());
                        ////////
                        ////ПЕРЕРДАЕМ ИМЯ ТАБЛИЦЫ ОТ SQL SERVER
                        ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных= ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey();
                        //// ПЕРЕДАЕМ ДАТУ ИЗ ТАБЛИЦЫ ОТ SQL SERVER
                        ПолученнаяДатыSqlServer= ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue();
                        if (ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных != null) {///ЕСЛИ НА SQL SERVER НЕ ПУСТЦЫЕ СТРОЧКИ В ТАБОИЦЕ ВЕРСИЙ СЕРВЕРА


                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                                ДатаВерсииДанныхНаSqlServer = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ПолученнаяДатыSqlServer);// получена ДАТА ВЕРСИИ ДАННЫХ СЕРВЕРА

                            }else {

                                ДатаВерсииДанныхНаSqlServer = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ПолученнаяДатыSqlServer);// получена ДАТА ВЕРСИИ ДАННЫХ СЕРВЕРА


                            }

                            Log.d(this.getClass().getName()," ДатаВерсииДанныхНаSqlServer " +ДатаВерсииДанныхНаSqlServer.toString());








                            //// как все сделали выходим
                            break;
                        }
                    }
                }



///// todo КОНЕЦ ТУТ -- КОД АНАЛИЗА ДАННЫХ SQL SERVER  ПРИШЕДШЕЙ ТЕКУЩЕЙ ТАБЛИЦЕ ПОЛУЧАЕМ НАЗВАНИЕ БАЗЫ И К НЕЙ ПОЛУЧАЕМ ДАТУ Е НЕЙ
                /////////////////////////////////имитация///////////////////////////////// TODO ИМИТАЦИЯ НУЖНА КОГДА ДАТА SQL SERVER НУЛЕВАЯ И МЫ ЕЕ ИМИТИРУЕМ
                Calendar calendar = new GregorianCalendar(1800, 02 , 01);////имитируем дату на андройде
                ИмитациДатыДляПроверки  = calendar.getTime();
                DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
                dateFormat.format(ИмитациДатыДляПроверки );
                ИмитацияВремяДляПроверки= dateFormat.format(ИмитациДатыДляПроверки );
                Log.d(this.getClass().getName()," ИмитациДатыДляПроверки "+ИмитациДатыДляПроверки.toString());
                //////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ////// начало запись в файл
            } finally {
                ////////
                Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаSqlServer  " + ДатаВерсииДанныхНаSqlServer.toString() + "  ИмитациДатыДляПроверки " +ИмитациДатыДляПроверки.toString());





                /////todo начинаем обрабоатывать синхронизция когда дата на sql server больше имитационной для того чтобы при сравнеии даты небыло ошибки при null даты
                if ( ДатаВерсииДанныхНаSqlServer.after(ИмитациДатыДляПроверки )) {
/////////////
                    МетодДляВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером(ОбьектыJSONФайлJSONсСервераВерсияSQlserver,ДатаВерсииДанныхНаSqlServer, ТекущаяТаблицаДляОБменаДанными,
                            ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,    ДанныеПришёлЛиIDДЛяГенерацииUUID );////метод получение даты версии данных из андройда
                }
            }

        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }
















    /////////////////////TODO метод ВЫРАВНИВАНИЯ ТАБЛИЦ МЕЖДУ КЛИЕНТОМ И СЕРВЕРОМ КОЛИЧЕСТВО ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ
    void МетодДляВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером(   JSONObject ФайлJSONcВерсиейДанныхСервера,Date ДатаВерсииДанныхНаSqlServer,
                                                                             String ИмяТаблицыОтАндройда_Локальноая,
                                                                             String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных ,
                                                                             String    ДанныеПришёлЛиIDДЛяГенерацииUUID)
            throws InterruptedException, ExecutionException, TimeoutException {
        try{

            Log.d(this.getClass().getName(), " ФайлJSONcВерсиейДанныхСервера " +ФайлJSONcВерсиейДанныхСервера.toString());
            JSONObject ОбьектыJSONvalue;
            JSONArray КлючJSONПолей = null;
            Cursor КурсорДляАнализаВерсииДанныхАндройда;
            String ТекстВерсииБазыАндрод = "";
////////
            String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;
            Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновления = null;
            String ДатаВерсииДанныхНаАндройдеДляМетодаGET = null;
            Date ДатаВерсииДанныхНаАндройде = null;
            try {
                //// #1 РАСПАРСИВАЕМ ПРИШЕДШИЙ JSON С СЕРВРЕА ОТ SQL SERVER
                JSONArray КлючиJSONПолей = ФайлJSONcВерсиейДанныхСервера.names();
                for (int ИндексПолучениеВерсииДанныхАндройда = 0; ИндексПолучениеВерсииДанныхАндройда < ФайлJSONcВерсиейДанныхСервера.names().length(); ИндексПолучениеВерсииДанныхАндройда++) {
                    String ИмяПоляДляВставкиВАндйрод = КлючиJSONПолей.getString(ИндексПолучениеВерсииДанныхАндройда); // Here's your key
                    Log.d(this.getClass().getName()," ИмяПоляДляВставкиВАндйрод "+ИмяПоляДляВставкиВАндйрод);
                    String СодержимоеПоляДляВставкиВАндйрод = ФайлJSONcВерсиейДанныхСервера.getString(ИмяПоляДляВставкиВАндйрод); // Here's your value
                    Log.d(this.getClass().getName(), " ЗначениеСтолбикаНазваниеТаблицНаСервере " + ИмяПоляДляВставкиВАндйрод + " ЗначениеСтолбикаВерсииТаблицНаСервере   " +
                            СодержимоеПоляДляВставкиВАндйрод);
                    ///// #2 ТЕПЕРЬ ПОЛУЧЕНЫЕ ДАННЫЕ А ТОЧНЕЕ НАЗВАНИЕ ТАБЛИЦ ЗАПИСЫВАЕМ В ВЕРСИЮ ДАННЫХ АНДРОЙД
                    КурсорДляАнализаВерсииДанныхАндройда = КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[] { "name"}, "name=?",new String[] { ИмяПоляДляВставкиВАндйрод } ,
                            null, null, null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                    //"SuccessLogin", "date_update","id=","1",null,null,null,null
                    ////////вставляем ноое название талицы если ее нет на андройде в таблице модификаци данных
                    if ( КурсорДляАнализаВерсииДанныхАндройда !=null){
                        КурсорДляАнализаВерсииДанныхАндройда.moveToFirst();
                        Log.d(this.getClass().getName(), " КурсорДляАнализаВерсииДанныхАндройда.getCount() " +КурсорДляАнализаВерсииДанныхАндройда.getCount());
                    }
                    ////
                    /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                    /////////
                    //TODO  ОЧЕНЬ ВАЖНО ЕСЛИ ЭТОТ КУРСОР ВЕРНЕТЬ ПОЛОЖИТЕЛЬНО ЦИФРУ ЭТО ЗНАЧИИТ ЧТО ТАКАЯ ТАБЛИЦУ УЖЕ ЕСТЬ НА АНДРОЙДЕ И ВСТАВЛЯЕТЬ ЕЕ НЕ НАДО
                    int ЗаписываемНазваниеТаблицыЕслиОльИлиОтрицательноеЗначение=КурсорДляАнализаВерсииДанныхАндройда.getCount();
                    Log.d(this.getClass().getName(), " ЗаписываемНазваниеТаблицыЕслиОльИлиОтрицательноеЗначение " +ЗаписываемНазваниеТаблицыЕслиОльИлиОтрицательноеЗначение);
                    //
                    КурсорДляАнализаВерсииДанныхАндройда.close();
                    /////////
                    if (ЗаписываемНазваниеТаблицыЕслиОльИлиОтрицательноеЗначение < 1) {/////ЕСЛИ КУРСОР ВОЗВРЯЩАЕТ ЦИФРУ 1 ТО ТОГДА ДАННАЯ ТАБОИЦА УЖЕ ЕСТЬ В ТАБЛИЦЕ ВЕРСИЙ ДАНЫХ АНДРОЙДА
                        Log.d(this.getClass().getName(), " КурсорДляАнализаВерсииДанныхАндройда.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());
                        ContentValues КонтейнерВствкаНовыхИменТаблицМодифика = new ContentValues();
                        КонтейнерВствкаНовыхИменТаблицМодифика.put("name", ИмяПоляДляВставкиВАндйрод);////ЗАПОЛЯНЕМ КОНТЕРЙНЕР ИМЯ ТАБЛИЦЫ КОТОРОЙ НЕТ ИЗ  СЕРВЕРА
                        //КонтейнерВствкаНовыхИменТаблицМодифика.put("versionserveraandroid", "2001-11-01 00:00:00");////ЗАПОЛЯНЕМ КОНТЕРЙНЕР ДАТУ ГЕНЕРИРУЕМ В ТАБЛИЦУ КОТОРО НЕТ

                        /////TODO записываем если такой таблицы нет  на андройде в таблице модификация данных
                        Long РезультатВставкиДанных = ВставкаДанныхЧерезКонтейнерУниверсальная("MODIFITATION_Client", КонтейнерВствкаНовыхИменТаблицМодифика,ИмяТаблицыОтАндройда_Локальноая,"",false,
                                0,false,КонтекстСинхроДляКонтроллераOnlyROWSAllTables); ////false  не записывать изменениея в таблице модификавет версия
                        Log.d(this.getClass().getName(), " РезультатВставкиДанных " + РезультатВставкиДанных);
                        ////
                        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                    }
                    Log.i(this.getClass().getName()," НазваниеТаблицНаСервере  "+ ИмяПоляДляВставкиВАндйрод+ " ФайлJSONcВерсиейДанныхСервера.names().length() "
                            +ФайлJSONcВерсиейДанныхСервера.names().length() + " КурсорДляАнализаВерсииДанныхАндройда.getCount()  " +КурсорДляАнализаВерсииДанныхАндройда.getCount() );
//внутри цикла
                }
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ////// начало запись в файл
            } finally {
                //// ПОЛУЧИЛИ ДАТУ ОТ SQL SERVER  ДЛЯ ОПРЕЕЛЕННОЙ ТАБЛИЦЫ И ЗАПОЛНИЛИ ТАБЛИЦУ МОДИФИКАЦИЯ ДАНЫХ НА КЛИЕНТЕ  И ИДЕМ УЖЕ АНАЛИЗИРОВАТЬ ИХ НИЖЕ
                if (ДатаВерсииДанныхНаSqlServer.toString().length()>0) {
                    Log.d(this.getClass().getName(), " ИмяТаблицыОтАндройда_Локальноая " + ИмяТаблицыОтАндройда_Локальноая + " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toString() + " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных "
                            + ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных);
                    //////////метод анализа данных
                    МетодАнализаВресииДАнныхКлиента(ИмяТаблицыОтАндройда_Локальноая, ДатаВерсииДанныхНаSqlServer, ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных ,   ДанныеПришёлЛиIDДЛяГенерацииUUID);
                }
            }
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }






















    ////////////////////////////ДАННЫЙ МЕТОД ПОСЛЕ ВЫШЕ СТОЯШЕГО ВЫРАВНИЯНИЯ НАЗВАНИЙ ТАБЛИЦ ПРИСТУПАЕТ К САМОМУ АНАЛИЗУ ДАННЫХ ВЕРСИИ ДАННЫХ НАХОДЯЩИХСЯ НА АНДРОЙДЕ
    void МетодАнализаВресииДАнныхКлиента(String ИмяТаблицыОтАндройда_Локальноая,Date ДатаВерсииДанныхНаSqlServer,String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                                         String    ДанныеПришёлЛиIDДЛяГенерацииUUID) {

        try{

            Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаSqlServer " +ДатаВерсииДанныхНаSqlServer.toGMTString());
            Cursor КурсорДляАнализаВерсииДанныхАндройда;
            String ДатаВерсииДанныхНаАндройдеДляМетодаGET = null;
            Date ДатаВерсииДанныхНаАндройдеSERVER = null;
            // String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;
            Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = null;
            try {
                ////#3 ТРЕТИТЬ КОГДА ЕСИ ОТСУТТВУЕТ НАЗВАНИЕ ТАБЛИЦ НА АНДРОЙДЕ И МЫ ИХ ТУДА ВПИСАЛИ , ТО ПРИСТУПАЕМ  К ТРЕТЬЕМУ ШАГУ К АНАЛИЗУ ДАНННЫХ
                КурсорДляАнализаВерсииДанныхАндройда = КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[] { "name,localversionandroid, versionserveraandroid"},
                        "name=?",new String[] {ИмяТаблицыОтАндройда_Локальноая } , null, null, null, null);//"SELECT
                // * FROM MODIFITATION_Client WHERE name=?",ИмяТаблицыОтАндройда_Локальноая
                //  //"SuccessLogin", "date_update","id=","1",null,null,null,null
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////ВАЖНО ЕСЛИ БОЛЬШЕ НУЛ ЗНАЧИТ В АНДРОЙДЕ ТАБЛИЦА С ТАКИМ НАЗВАНИЕМ УЖЕ ЕСТЬ
                if (КурсорДляАнализаВерсииДанныхАндройда.getCount() > 0) {////ВЫЖНОЕ УСЛОВИЕ ЕСЛИ КУРСОР ВЕРНУЛ БОЛЬШЕ НУЛЯ  ДАННАЕ ТОЛЬКО ТОГДА НАЧИНАЕМ АНАЛИЗ ВЕРСИИ ДАННЫХ НА АНДРОЙДЕ
                    КурсорДляАнализаВерсииДанныхАндройда.moveToFirst();
                    Log.d(this.getClass().getName(), "  Курсор_УзнаемВерсиюБазыНаАдройде.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());





                    //////////////
                    //String id = КурсорДляАнализаВерсииДанныхАндройда.getString( КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("name") );
                    try {
                        ДатаВерсииДанныхНаАндройдеДляМетодаGET = КурсорДляАнализаВерсииДанныхАндройда.getString(КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("versionserveraandroid"));


                        Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеДляМетодаGET " + ДатаВерсииДанныхНаАндройдеДляМетодаGET);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if(ДатаВерсииДанныхНаАндройдеДляМетодаGET==null){
                        ДатаВерсииДанныхНаАндройдеДляМетодаGET="1900-01-10 00:00:00";
                    }


                    /////////
                    try {
                        ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = КурсорДляАнализаВерсииДанныхАндройда.getString(КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("localversionandroid"));


                        Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET  " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if( ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET ==null){
                        ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET ="1900-01-10 00:00:00";
                    }







                    ///////////ОПРЕДЕЛЯЕМ ДАТУ АНДРОЙДА ДЛЯ СОСТЫКОВКИ С ДАТОЙ SQ; SERVER//// ПОЛУЧАЕМ ДАТУ НА АНДРОЙДЕ ПОЛСЕДНЕЕ ИЗМЕНЕНИЯ ПРИШЕДЩИЕ ДАННЫЕ С СЕРВЕРА
                    ДатаВерсииДанныхНаАндройдеSERVER = null;
                    if (ДатаВерсииДанныхНаАндройдеДляМетодаGET != null) {///ЕСЛИ НА АНДРОЙДЕ НЕ ПУСТЦЫЕ СТРОЧКИ В ТАБОИЦЕ ВЕРСИЙ КЛИЕНТА
                        try {

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                                ДатаВерсииДанныхНаАндройдеSERVER = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеДляМетодаGET);

                            }else {

                                ДатаВерсииДанныхНаАндройдеSERVER = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеДляМетодаGET);


                            }

                            Log.d(this.getClass().getName()," ДатаВерсииДанныхНаАндройдеSERVER " +ДатаВерсииДанныхНаАндройдеSERVER.toString());







                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        ////////
                        Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеДляМетодаGET  " + ДатаВерсииДанныхНаАндройдеДляМетодаGET +
                                "   ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);

                        ///////////ОПРЕДЕЛЯЕМ ДАТУ АНДРОЙДА ДЛЯ СОСТЫКОВКИ С ДАТОЙ SQ; SERVER //////ПОЛУЧЕНИЕ ДАННЫХ ОБ ИЗМЕННИЯХ ДАННЫХ ЛОКАЛЬНО САМИМ ПОЛЬЗОВАТЛЕМ
                        ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = null;
                        if (ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET != null) {///ЕСЛИ НА АНДРОЙДЕ НЕ ПУСТЦЫЕ СТРОЧКИ В ТАБОИЦЕ ВЕРСИЙ КЛИЕНТА
                            try {


                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                                    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);

                                }else {

                                    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);


                                }

                                Log.d(this.getClass().getName()," ДатаВерсииДанныхНаSqlServer " +ДатаВерсииДанныхНаSqlServer.toString());





                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            ////////
                            Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеДляМетодаGET  " + ДатаВерсииДанныхНаАндройдеДляМетодаGET
                                    + "   ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET   " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET+
                                    "                  ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL "+ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL);
                        }
                    }
                }else{
                    Log.d(this.getClass().getName(), "  КурсорДляАнализаВерсииДанныхАндройда.getCount()" +КурсорДляАнализаВерсииДанныхАндройда.getCount());
                }

            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ////// начало запись в файл

            } finally {



                Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройде " +ДатаВерсииДанныхНаАндройдеSERVER.toString()
                        + " ДатаВерсииДанныхНаSqlServer  " + ДатаВерсииДанныхНаSqlServer.toString() +
                        " ДатаВерсииДанныхНаАндройдеДляЛокальногоОбновления " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString() + " ДатаВерсииДанныхНаАндройдеДляМетодаGET " + ДатаВерсииДанныхНаАндройдеДляМетодаGET);






                if (ДатаВерсииДанныхНаАндройдеSERVER != null && ДатаВерсииДанныхНаSqlServer != null && ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL != null) {
                    ///////////////
                    //СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
                    МетодПринятияРешенияПолучитьДанныесСервераИлиОтправитьДанныесКлиента(ДатаВерсииДанныхНаАндройдеSERVER,
                            ДатаВерсииДанныхНаSqlServer, ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL,
                            ИмяТаблицыОтАндройда_Локальноая, ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                            ДатаВерсииДанныхНаАндройдеДляМетодаGET,    ДанныеПришёлЛиIDДЛяГенерацииUUID);///СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
                }
            }



        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }




    //TODO СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
    void МетодПринятияРешенияПолучитьДанныесСервераИлиОтправитьДанныесКлиента(Date ДатаВерсииДанныхНаАндройдеSERVER,Date ДатаВерсииДанныхНаSqlServer, Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL,
                                                                              String ИмяТаблицыОтАндройда_Локальноая ,String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных ,
                                                                              String ДатаВерсииДанныхНаАндройдеДляМетодаGET,String    ДанныеПришёлЛиIDДЛяГенерацииUUID) {
        //
        Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаАндройдеДляЛокальногоОбновления " +ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toGMTString()+
                " ИмяТаблицыОтАндройда_Локальноая " +ИмяТаблицыОтАндройда_Локальноая + " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных " +ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных);
        try {

/////ОБЯЗАТОЛЬНОЕ УСЛОВИЕ НАЗВАНИЕ ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ НАПРИМЕР  CFO==CFO
            if (ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных.equalsIgnoreCase(ИмяТаблицыОтАндройда_Локальноая)) {//////ОБЯЗАТОЛЬНОЕ УСЛОВИЕ НАЗВАНИЕ ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ НАПРИМЕР  CFO==CFO

////// todo ВНИМАНИЕ ТУТ КОД НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ БОЛЬШЕ И МЫ ДОЛЖНЫ С ТЕЛЕФОНА ОТОСЛАТЬ ДАННЫЕ НА СЕВРЕР SQL SEVER
////// ЛОКАЛЬНАЯ ПРОВЕРКА ВЕРСИИ ДАНННЫХ  #1 НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ ПОСЛЕДНАЯЯ НАДО С АНДРОЙДА ПОСЛАТЬ ДАННЫЕ НА СЕРВЕР
                if (ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.after(ДатаВерсииДанныхНаАндройдеSERVER)) {//ПРОВЕРЯЕМ ДАТЫ КАКАЯ БОЛЬШЕ МЕНЬШЕ тут больше что слева sql server
//////  НАЧАЛО  ЛОКАЛЬНАЯ ПРОВЕРКА ВНУТИРИ АНДРОЙДА ПО ДАТАМ МЕЖДУ СОБОЙ
                    Log.d(this.getClass().getName(),
                            "    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL   " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString()
                                    + " ДатаВерсииДанныхНаАндройдеSERVER   " + ДатаВерсииДанныхНаАндройдеSERVER.toString()
                                    + " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toString());
          /*  ////TODO ПЕРЕДАЕМ ДАТЫ МЕТОДУ ДЛЯ ОТПРАВКИ ДАННЫХ НА СЕРВЕР ДЛЯ ЭТОГО ЕГО НЕМНОГО ПРЕОБРАЗУЕМs
            DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));
            String ДатаВерсииДанныхНаSqlServerДляОтправкиНаСерверДанных =dateFormat.format(ДатаВерсииДанныхНаSqlServer );
                    ///////todo МЕТОД GET запускаем метод POST посылаем Данные на сервер
            /////МетодПосылаемДанныеНаСервер(ИмяТаблицыОтАндройда_Локальноая ,ДатаВерсииДанныхНаSqlServerДляОтправкиНаСерверДанных ); //////МЕТОД POST*/
                    ////// todo МЕТОД POST
                    //МетодПосылаемДанныеНаСервер(ИмяТаблицыОтАндройда_Локальноая ); ////// todo МЕТОД POST


                    ////////
                    Log.d(this.getClass().getName(), " ПОСЛЕ УСПЕШНОЙ ОТПАРВКИ ДАННЫХ НА СЕРВЕР" +
                            " КоличествоУспешныхВставки " +PUBLIC_CONTENT.КоличествоУспешныхВставки + " КоличествоУспешныхОбновлений " +PUBLIC_CONTENT.КоличествоУспешныхОбновлений );


                    //////// TODO  В ДАННОМ СЛУЧАЕ НА СЕРВРЕР ВЕРСИЯ  ДАННЫХ СТАРШЕ ЧЕМ НА АНДЙРОДЕ , И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВЕРА
                } else if (ДатаВерсииДанныхНаSqlServer.after(ДатаВерсииДанныхНаАндройдеSERVER)) { // С СЕРВЕРА
                    //////
                    Log.d(this.getClass().getName(), " НА SQL SERVER  ДАТА больше версия" +
                            " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toString() +
                            " и  ДатаВерсииДанныхНаАндройдеSERVER " + ДатаВерсииДанныхНаАндройдеSERVER.toString()+
                            " и  ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString());

//////////TODO МЕТОД get
                    МетодПолучаемДаннныесСервера(ИмяТаблицыОтАндройда_Локальноая,ДатаВерсииДанныхНаАндройдеДляМетодаGET,   ДанныеПришёлЛиIDДЛяГенерацииUUID,
                            ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL);/// ЗАПУСКАМ МЕТОД ПОЛУЧЕНИЕ ДАННЫХ С СЕРВЕРА    МЕТОД GET

                    ////////
                    Log.d(this.getClass().getName(), " ПОСЛЕ УСПЕШНОЙ ОТПАРВКИ ДАННЫХ НА СЕРВЕР" +
                            " КоличествоУспешныхВставки " +PUBLIC_CONTENT.КоличествоУспешныхВставки + " КоличествоУспешныхОбновлений " +PUBLIC_CONTENT.КоличествоУспешныхОбновлений );
/////В ДАНОМ СЛУЧАЕ ДАННЫЕ СИНХРОНИЗИРОВАТЬ НЕ НАДО ВЕСРИЯ ДАННЫХ НА СЕРВРЕР И НА КЛИЕНТЕ ОДИНАКОВЫ

                }else {

                    Log.d(this.getClass().getName(), " Синхронизация не нужна даты равны на клиенте и сервер"+" ИмяТаблицыОтАндройда_Локальноая " +ИмяТаблицыОтАндройда_Локальноая);

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }



    /////МЕТОД КОГДА НА СЕРВЕРЕ ВЕРСИЯ ДАННЫХ ВЫШЕ И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВРА
    void МетодПолучаемДаннныесСервера(String имяТаблицыОтАндройда_локальноая,String ДатаВерсииДанныхНаАндройдеДляМетодаGET,
                                      String    ДанныеПришёлЛиIDДЛяГенерацииUUID ,Date ДатаВерсииДанныхНаАндройдеДляЛокальногоОбновления) {
        ////
        Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID " + ДанныеПришёлЛиIDДЛяГенерацииUUID);
////
        StringBuffer БуферПолученныйJSON = null;
        try{
            Log.d(this.getClass().getName(), "  МетодПолучаемДаннныесСервера" + "  имяТаблицыОтАндройда_локальноая    " +имяТаблицыОтАндройда_локальноая);




            //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
            StringBuffer БуферПолучениеДанных=new StringBuffer();

            // TODO: 10.06.2021 получение данных
            БуферПолучениеДанных= УниверсальныйБуферПолучениеДанныхсСервера(имяТаблицыОтАндройда_локальноая,"",
                    "","application/json","Хотим Получить  JSON",
                    ДатаВерсииДанныхНаАндройдеДляМетодаGET,ДанныеПришёлЛиIDДЛяГенерацииUUID); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position


            if (БуферПолучениеДанных!=null  && БуферПолучениеДанных.length()>0) {
                ///
                Log.d(this.getClass().getName(), "  МетодПолучаемДаннныесСервера" + "  БуферПолучениеДанных.toString()    " +БуферПолучениеДанных.toString());


                if (БуферПолучениеДанных.length()>0) {

                    /////////

                    БуферПолученныйJSON=new StringBuffer();

                    /////ЦИКЛ ПЕРЕБОРА JSON КОТОРЫЙ ПРИШЁЛ
                    БуферПолученныйJSON.append(БуферПолучениеДанных.toString());

                    Log.d(this.getClass().getName(), " БуферПолученныйJSON внутри цикла  " + БуферПолученныйJSON.toString());

                    ////////Присылаем количестов строчек обработанных на сервлете
                    Log.d(this.getClass().getName(), " БуферПолученныйJSON.length()  " + БуферПолученныйJSON.length());
                    Log.d(this.getClass().getName(), " БуферПолученныйJSON  " + БуферПолученныйJSON.toString());
                    ////
                    ////
                    /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                    ///TODO нет данных для синхрониазции файл пришел 0
                }else{
                    Log.d(this.getClass().getName(), " Данных нет c сервера сам файл JSON  (ПОТОК ПРИШЕЛ НОЛЕВОЙ 0)" );
                }
                /////////
            }else{
                Log.e(this.getClass().getName(), "оШИБКА НЕТ СВЯЗИ  С СЕРВЕРОМ  нет c сервера сам файл JSON  (ПОТОК ПРИШЕЛ НОЛЕВОЙ 0)" );
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }finally {
            //////ЗАПУСКАЕМ МЕТОД РАСПАРСИВАНИЕ JSON  ПОЛУЧЕНЫЙ ИЗ СЕРВЛЕТА ОТ МЕТОДА  GET

            if (БуферПолученныйJSON !=null && БуферПолученныйJSON.toString().toCharArray().length > 3){

                Log.d(this.getClass().getName(), "  БуферПолученныйJSON " + БуферПолученныйJSON.toString());


                ///как только получиили данные как первый запуска переключаем флаг что далее будет не первый запуск , ТО ТОГДА МЫ ФИЛЬТР ОБНОВЛЯНЕМ И ПЕРЕКОЛЮЧЕМ ЕГО НА НЕ ПЕРВЫЙ ЗАПУСК
                if (PUBLIC_CONTENT.ФильтрДляДанныхЯвляетьсяЛиНулевойЗапускКлиента.length()>0){
                    PUBLIC_CONTENT.ФильтрДляДанныхЯвляетьсяЛиНулевойЗапускКлиента="";
                }
                try{
                    //////TODO запускаем метод распарстивая JSON
                    МетодПарсингJSONФайлаОтСерврера(БуферПолученныйJSON,имяТаблицыОтАндройда_локальноая );/////ЗАПУСК МЕТОДА ПАСРИНГА JSON

                    //поймать ошибку всего классаIOException | MyException e    NumberFormatException
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }


            }else{
                Log.i(this.getClass().getName(), " Сервер пристал пустой файл Запрос по вашем параметрам не т данных в сервере (SQL Server)  БуферПолученныйJSON " + БуферПолученныйJSON.toString());
            }
        }}





    /////// TODO МЕТОД ПАСРИНГА ПРИШЕДШЕГО  С СЕРВЕРА ВНУТРИ ASYNSTASK
    void МетодПарсингJSONФайлаОтСерврера(  StringBuffer БуферПолученныйJSON,String имяТаблицыОтАндройда_локальноая ) {
        try{
            ///

            ///
            Log.d(this.getClass().getName(), " имяТаблицыОтАндройда_локальноая" +имяТаблицыОтАндройда_локальноая+" БуферПолученныйJSON "
                    + БуферПолученныйJSON.toString()+ " БуферПолученныйJSON.length() " +БуферПолученныйJSON.toString().length());

            //// TODO ПОЛУЧЕМ ПРИЩЕДЩИЙ JSON ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON
            JSONObject JSON_ПерваяЧасть = new JSONObject(БуферПолученныйJSON.toString());/////ВАЖНО ПОЛУЧЕНИЕ JSON ОБЬЕКТОВ ИЗ БУФЕРА , ЧТОБЫ ДАЛЛЕ РАЗНЕСТИ ЕГО ПО СТРОЧКАМ
            JSONArray JSON_ВтораяЧасть = JSON_ПерваяЧасть.names();////КОЛИЧЕСТВВОсТРОЧЕК В JSON


            ///TODO  ПОДГОТОВКА ПЛЮСУЕМ ВЕСЬ ПОЛУЧЕННЫЙ  JSON
            int ДоТекущийОбработкиСколькоСтрочекJSON = PUBLIC_CONTENT.СколькоСтрочекJSON;


            //////todo СУММА JSONОВ ДО И ПОСЛЕ ЧТОБЫ ПОЛУЧИТЬ ОБЩЕЕ ЗНАЧЕНИЯ JSON ПОЛУЧАЕМ КОЛИЧЕСТВО СТРОК В ПРИШЕДШЕЙ СЕЙЧАС ТАБЛИЦЕ ДЛЯ РАСПАРСИВАНИЯ JOSON
            PUBLIC_CONTENT.СколькоСтрочекJSON = JSON_ВтораяЧасть.length() + ДоТекущийОбработкиСколькоСтрочекJSON ;
            /*Log.d(this.getClass().getName(), " СколькоСтрочекJSON " + СколькоСтрочекJSON[0]);*/
            ///TODO ПЛЮСУЕМ ВЕСЬ ПОЛУЧЕННЫЙ  JSON

            /////todo запуск турбабара
            Log.d(this.getClass().getName(), "  СколькоСтрочекJSON[0]  " + PUBLIC_CONTENT.СколькоСтрочекJSON);


            //поймать ошибку всего классаIOException | MyException e    NumberFormatException
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }

    //////ТУТ БУДЕТ ЗАПИСЫВАТЬСЯ УСПЕШНОЕ ОБНЛВДЕНИ И ВСТАВКИ ДАННЫХ НА СЕРВЕРЕ ДЛЯ КЛИЕНТА


























    // todo ДАННЫЙ КОД ЗАПУСКАЕТЬСЯ ПЕРЕД СИНХРОНИЗАЦИЕ  ДЛЯ ПОЛУЧЕНИЕ JSON И ПОЛУЧЕНИЕ ОБЩЕГО КОЛИЧЕСТВА ТАБЛИЦ ДЛЯ ОБРАБОТКИ СИНХРОНИЗАЦИИ










    boolean   МетодЗапускаемПередНАчаломСинхронизацииЧтобЫПОнятьКоличествоТАблицДляСинхронизации(Context  КонтекстКоторыйДляСинхронизации) throws ExecutionException, InterruptedException {

        /////=----СИНХРОНИЗАЦИЯ
        ///TODO СИНХРОНИЗАЦИЯ ///TODO СИНХРОНИЗАЦИЯ при запуске прилиложения
//TODO ПРОВРЕМ WIFI ПОДКЛЮЧЕН ЛИ
        boolean РезультатПРоверкиПодключениеИнтернету=false;
        //////
        final String[] РезутьтатПроверкиТипПодключениякИнтернету = new String[1];

        try {

            /////todo тут МЫ ПОЛУЧАЕМ В КАКОЙ МОМЕНТ ТИП ПОДКЛЮЧЕНИЯ НА ТЕЛЕФОНЕ МОБИЛЯ ИЛИ  WIFI  И В ЗАВИСИМОСТИ ЧТОБЫ ПОНЯТЬ ЧЕ ЗА ДЕЛА
            РезутьтатПроверкиТипПодключениякИнтернету[0] = МетодОпределяемКакойТипПодключениеWIFIилиMobile(КонтекстКоторыйДляСинхронизации);
            /////
            Log.d(this.getClass().getName(), "   РезутьтатПроверкиТипПодключениякИнтернету " + РезутьтатПроверкиТипПодключениякИнтернету[0]);
            ////TODO КОГДА ПУСТОЙ ОТВЕТ НЕТ И WI FI  И  MOBILE  ТО ПРИСВАИВАЕМ ОДИН ЛЮБОЙ СИМВОЛ
            if (РезутьтатПроверкиТипПодключениякИнтернету[0]==null){
                РезутьтатПроверкиТипПодключениякИнтернету[0]=" ";
            }
            /////TODO ТУТ ПОЛУЧАЕМ  ЗНАЧЕНИЯ ПО УМОЛЧАНИЮ ПРОГРАММЫ РЕЖИМ РАБОТИЫ СИНХРОНИЗАЦИИ ТОЛЬКО ПО  WIFI
            String ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация =  МетодПолучениеЗначенияРежимаРаботыИнтернетаWifiИлиInternet(КонтекстКоторыйДляСинхронизации ,"SuccessLogin","mode_connection");

            Log.d(this.getClass().getName(), "  ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация " + ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация);




            // TODo ДАННЫЙ КОД ОПРЕДЕЛЯЕМ КАК МЫ БУДЕМ УЗУЩЕТСВЛЯТЬ РАБОТУ СИНХРОНИЗАЦИИ СЕРВЕРА ПО УМОЛЧАНИЮ ТОЛЬКО С WIFI НАСТРОЙКА В ПРИЛОЖЕНИИ И ТОЛЬКО ПРИНУДИТЕЛЬНО С ТЕЛЕФОНА

            switch (ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация){

                /// TODO ТОЛЬКО ЗАПУСК СИНХРОНИЗАЦИИ ЕЛИ ЕСТЬ WIFI И ВСЕ
                case "WIFI":
                    // TODo ТОЛЬКО WIFI подключение производим ТУТ ПРАИЛО ЗЕРКАЛЬНО ДОЛЖНО СОВПАСТЬ УСЛОВИЕ WIFI==WIFI
                    if ( РезутьтатПроверкиТипПодключениякИнтернету[0].equals("WIFI")) {
                        Log.d(this.getClass().getName(), "  ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация " + ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация +
                                " РезутьтатПроверкиТипПодключениякИнтернету " + РезутьтатПроверкиТипПодключениякИнтернету[0]);
                        РезультатПРоверкиПодключениеИнтернету= false;
                        ///todo вычитсляем есть если подключение к интренту
                        РезультатПРоверкиПодключениеИнтернету = УниверсальнайМетодПроверкиПодключениекWIFI(КонтекстКоторыйДляСинхронизации);
                        Log.d(this.getClass().getName(), " РезультатПРоверкиПодключениеWIFI " + РезультатПРоверкиПодключениеИнтернету);





                        //////todo НАЧИНАЕМ СИНХРОНИЗАЦИЮ ТОЛЬКО WIFI
                        ////МетодСинхронизацииКогдаВыяснилиРежимПодключенияИНаличияИнтрента(РезультатПРоверкиПодключениеWIFI[0], КонтекстКоторыйДляСинхронизации);


                        ///todo наичнаем обработки если ЕСТЬ ТОЧНОЕ ПОДКЛЮЧЕНИЕ К ИНТЕРНЕТУ
                        if (РезультатПРоверкиПодключениеИнтернету ==true) {
                            Log.d(this.getClass().getName(), "  результатПРоверкиПодключениеWIFI " + РезультатПРоверкиПодключениеИнтернету +
                                    "КонтекстДляПередачиСинхронизации " + КонтекстКоторыйДляСинхронизации.toString());
                            ///TODO СИНХРОНИЗАЦИЯ ///TODO СИНХРОНИЗАЦИЯ при запуске прилиложения
                            //// todo САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ  ПЕРВАЯ ЧАСТЬСИНХРОНИЗАЦИИ ПЕРЕД ГЛАВНОЙ СИНХРОНИЗАЦИЕЙ
                            ///new CONTROLLER_synchronized.java(this). МетодНачалоСихронизацииДляАктивити( КонтекстДляПередачиСинхронизации);
                            new CONTROLLER_synchronized(КонтекстКоторыйДляСинхронизации).МетодНачалоСихронизацииДляАктивити(КонтекстКоторыйДляСинхронизации);
                            //TODO после обмена показываем пльзоватлю
                        }


                    }
                    ///todo Викидываем из кода котому что только WIFI
                    break;

                /// TODO   ТОЛЬКО ЗАПУСК СИНХРОНИЗАЦИИ ЕСЛИ ПОЛЬЗОВАТЕЛЬ ВЫБРАЛ РЕЖИМ РАБОТЫ  MOBILE И ТОГДА ОБМЕН ОМУЩЕСТВЛЯЕТЬСЯ СРАЗУ И ЧЕРЕЗ СИМКУ И ПО WIFI
                case "Mobile":
                    ////TODO ДВА В ОДНОМ ЗАПУСКАЕМ СИНХРОНИЗАУЦЦИЮ И ПРИ МОБАЙЛЕ И ПРИ WIFI
                    if (РезутьтатПроверкиТипПодключениякИнтернету[0].equals("Mobile") || РезутьтатПроверкиТипПодключениякИнтернету[0].equals("WIFI")) {
                        // TODo ТОЛЬКО Mobileподключение производим
                        Log.d(this.getClass().getName(), "  ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация " + ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация +
                                " РезутьтатПроверкиТипПодключениякИнтернету " + РезутьтатПроверкиТипПодключениякИнтернету[0]);
                        РезультатПРоверкиПодключениеИнтернету = false;
                        ///todo вычитсляем есть если подключение к интренту
                        РезультатПРоверкиПодключениеИнтернету = УниверсальнайМетодПроверкиПодключениекWIFI(КонтекстКоторыйДляСинхронизации);
                        Log.d(this.getClass().getName(), " РезультатПРоверкиПодключениеWIFI " + РезультатПРоверкиПодключениеИнтернету);

                        //////todo НАЧИНАЕМ СИНХРОНИЗАЦИЮ ОБА WIFI/MOBILE
                        /*       МетодСинхронизацииКогдаВыяснилиРежимПодключенияИНаличияИнтрента(РезультатПРоверкиПодключениеWIFI[0], КонтекстКоторыйДляСинхронизации);*/



                        ///todo наичнаем обработки если ЕСТЬ ТОЧНОЕ ПОДКЛЮЧЕНИЕ К ИНТЕРНЕТУ
                        if (РезультатПРоверкиПодключениеИнтернету ==true) {
                            Log.d(this.getClass().getName(), "  результатПРоверкиПодключениеWIFI " + РезультатПРоверкиПодключениеИнтернету+
                                    "КонтекстДляПередачиСинхронизации " + КонтекстКоторыйДляСинхронизации.toString());


                            ///TODO СИНХРОНИЗАЦИЯ ///TODO СИНХРОНИЗАЦИЯ при запуске прилиложения
                            //// todo САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ
                            //// todo САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ  ПЕРВАЯ ЧАСТЬСИНХРОНИЗАЦИИ ПЕРЕД ГЛАВНОЙ СИНХРОНИЗАЦИЕЙ
                            ///new CONTROLLER_synchronized.java(this). МетодНачалоСихронизацииДляАктивити( КонтекстДляПередачиСинхронизации);
                            new CONTROLLER_synchronized(КонтекстКоторыйДляСинхронизации).МетодНачалоСихронизацииДляАктивити(КонтекстКоторыйДляСинхронизации);
                            //TODO после обмена показываем пльзоватлю
                        }

                    }
                    ///todo Викидываем из кода котому что только Mobile
                    break;
            }

        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        ///todo удаляем из памяти асинтаск

        //TODO ФУТУРЕ ЗАВЕРШАЕМ
        Log.d(this.getClass().getName(), "  РезультатПРоверкиПодключениеИнтернету " +  РезультатПРоверкиПодключениеИнтернету);

/////TODO команды после успешной встаки и обновления
        return РезультатПРоверкиПодключениеИнтернету;
        ////todo ЕСЛИ РАБОАТЕМ ОФЛАЙН И НЕТ ПОДКЛЮЧЕНИЕ К ИНТРЕНТУ И ЛИ К НАШЕМУ СЕРВЕРУ ТО ЗАПОЛНЯЕМ ДАННЫМИ НАМ ПУБЛИЧНЫЙ ID
    }



    ///////// TODO ПРОВЕРЯЕТ ЕСЛИ ПОДКЛЧБЕНИ В ИНТРЕНТУ
    protected   boolean УниверсальнайМетодПроверкиПодключениекWIFI( Context  КонтекстКоторыйДляСинхронизации) throws ExecutionException, InterruptedException, TimeoutException {

        boolean РезультатПрозвонаСокетом=false;

        System.out.println("УниверсальнайМетодПроверкиПодключениекWIFI ");

        /////todo код ping ip
        // InetAddress АдресПрозвонаСайтаПриВходеВПРОграмму=null;
        //АдресПрозвонаСайтаПриВходеВПРОграмму= InetAddress.getByName("www.google.com"); //"http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet"; //www.google.com
        // Log.d(MODEL_synchronized.class.getName() ," addr.getHostAddress() "+  АдресПрозвонаСайтаПриВходеВПРОграмму.getHostAddress());
        // if (!АдресПрозвонаСайтаПриВходеВПРОграмму.getHostAddress().equalsIgnoreCase("::") && АдресПрозвонаСайтаПриВходеВПРОграмму.getHostAddress().length()>0) {

        //  }
        /////todo код ping ip второйвариант
        try {

            Socket socket = new Socket();
            SocketAddress socketAddress = new InetSocketAddress("80.66.149.58", 8888); //"http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet"; //"216.58.212.131"
            socket.connect(socketAddress, 500);
            РезультатПрозвонаСокетом = true;
            PUBLIC_CONTENT.ПубличныйАдресGlassFish = "http://80.66.149.58:8888/"; //http://80.66.149.58:8888 //8181 ///РЕЖИМ НАСТОЯЩИЕ РАБОТЫ ПРИЛОЖЕНИЯ "http://80.66.149.58:8888/dsu1.glassfish/DSU1JsonServlet";
            //
            Log.d(MODEL_synchronized.class.getName()," PUBLIC_CONTENT.ПубличныйАдресGlassFish " + PUBLIC_CONTENT.ПубличныйАдресGlassFish);
            ///TODO определяем какой вид подкобченеи mobile and wifi

        }catch (IOException e) {
            РезультатПрозвонаСокетом = false;
            ////TODO ВТОРАЯ ПРОВЕРКА
            try {
                if (РезультатПрозвонаСокетом==false) {
         /*   HttpURLConnection ПодключениеИнтернетДляОтправкиНаСервер=null;
            URL Adress = null;
            Adress = new URL("http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet");
            ПодключениеИнтернетДляОтправкиНаСервер = (HttpURLConnection) (Adress).openConnection();/////САМ ФАЙЛ JSON C ДАННЫМИ
            ПодключениеИнтернетДляОтправкиНаСервер.setReadTimeout(500); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ(200);
            ПодключениеИнтернетДляОтправкиНаСервер.setConnectTimeout(10000);//todo САМ ПОТОК ДАННЫХ(1000);
            ПодключениеИнтернетДляОтправкиНаСервер.connect();
            РезультатПрозвонаСокетом = true;*/
                    Socket socket = new Socket();
                    SocketAddress socketAddress = new InetSocketAddress("192.168.254.63",8080); //// "192.168.254.63"//// 8081 8080
                    socket.connect(socketAddress, 500);
                    РезультатПрозвонаСокетом = true;
                    /////
                    String    Adress_String="http://192.168.254.63:8080/";
                    ///
               Adress_String = Adress_String.replace(" ", "%20");
                    ////
                    PUBLIC_CONTENT.ПубличныйАдресGlassFish =Adress_String; // PUBLIC_CONTENT.ПубличныйАдресGlassFish = "http://192.168.254.63:8080  /"; //http://80.66.149.58:8888 //8181 ///РЕЖИМ НАСТОЯЩИЕ РАБОТЫ ПРИЛОЖЕНИЯ
                    /////

                    Log.d(MODEL_synchronized.class.getName(), " PUBLIC_CONTENT.ПубличныйАдресGlassFish " + PUBLIC_CONTENT.ПубличныйАдресGlassFish);
                    ///TODO определяем какой вид подкобченеи mobile and wifi
                }
                //МетодОпределяемКакойТипПодключение();
            }catch (IOException ex) {
                РезультатПрозвонаСокетом = false;
                ///////todo вторая проверка
            }
        }


        return РезультатПрозвонаСокетом;
    }



    ////TODO метод который отпредеяеть КАКОЙ ТИП ПОДКЛЮЧЕНИ К ИНТРЕНТУ ЧЕРЕЗ WIFI ИЛИ MOBILE
    private String МетодОпределяемКакойТипПодключениеWIFIилиMobile(Context  КонтекстКоторыйДляСинхронизации) {

        ConnectivityManager cm = (ConnectivityManager)КонтекстКоторыйДляСинхронизации.getSystemService(Context.CONNECTIVITY_SERVICE);
        ////////
        NetworkInfo wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (wifiInfo != null && wifiInfo.isConnected())
        {
            Log.d(MODEL_synchronized.class.getName()," подключние к интренту через wifi");
            return "WIFI";
        }
        wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (wifiInfo != null && wifiInfo.isConnected())
        {
            Log.d(MODEL_synchronized.class.getName()," подключние к интренту через mobile");
            return "Mobile";
        }
        wifiInfo = cm.getActiveNetworkInfo();
        if (wifiInfo != null && wifiInfo.isConnected())
        {
            Log.d(MODEL_synchronized.class.getName()," подключние к интренту через "+wifiInfo.getTypeName());
            return null;
        }
        return null;
    }

    ///TODO  конец  методы перерд перед  СИНХРОНИЗАЦИЯ ///TODO СИНХРОНИЗАЦИЯ при запуске прилиложения



    public  void МетодОчищаемИзБазыNULLЗначенияя(){


        try{


            // TODO: 26.03.2021 ДОПОЛНИТЕЛЬНО ОБНУЛЯЕМ ВСЕ ТАБЕЛЯ С NULL В ФИО ЧТО БЫ ОБМЕН НЕ РУГАЛЬСЯ

            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE fio IS NULL");
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE cfo IS NULL");
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE nametabel_typename IS NULL");
            ССылкаНаСозданнуюБазу.setTransactionSuccessful();
            ССылкаНаСозданнуюБазу.endTransaction();

            ///////todo\
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }



}



































































































///TODO------------------------------------------------------ ЭТО  ВТОРОЙ КОНТРОЛЛЕР КОТОРЫЙ ЗАПУСКАЕТ СИНХРОНИЗАЦИЮ В ФОНЕ  (ВНУТРИ ПРИЛОЖЕНИЕ)---------------------------------------------------


class CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND extends MODEL_synchronized {

    String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;

   static Context КонтекстСинхроДляКонтроллераВФоне;


    ExecutorService executorService;



    public CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND( @NotNull  Context context) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
        super(context);
        ////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
        // ССылкаНаСозданнуюБазу = this.getWritableDatabase(); //ссылка на схему базы данных;//ссылка на схему базы данных ГЛАВНАЯ ВСТАВКА НА БАЗУ ДСУ-1
        ////// TODO созданеи шифрование
        if (PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки == null) {
            //TODO ключ для шифрование и расщифровки
            byte[] CipherKey = "[C@3841f624[B@6415a86b[B@143c678".getBytes();
            PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки =
                    new SecretKeySpec(CipherKey,
                            "AES");
            PUBLIC_CONTENT.ПолитикаШифрование = Cipher.getInstance("AES");
            PUBLIC_CONTENT.ПолитикаШифрование.init(Cipher.ENCRYPT_MODE, PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки);
            ///////
            PUBLIC_CONTENT.ПолитикаРасшифровки = Cipher.getInstance("AES");
            PUBLIC_CONTENT.ПолитикаРасшифровки.init(Cipher.DECRYPT_MODE, PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки);
            ///// конец шифрование
        }
        ////// конец  TODO созданеи шифрование
    }

    public int УспешноеКоличествоВставокДанныхсСервера;
    public int УспешноеКоличествоОбновлениеДанныхсСервера;
    ////


    /////////////
    ContentValues АдаптерПриОбновленияДанныхсСервера = new ContentValues();
    /////
    ContentValues АдаптерДляВставкиДанныхсСервер = new ContentValues();

    ContentValues        АдаптерДляВставкиДанныхсСерверБуфер=new ContentValues();

    Cursor Курсор_УзнатьЕслиНаАндройдеТакойUUID = null;/// ТУТ ОН ЗАПОНИМАЕНТ ПОСЛЕНИЙ UUID НА СТРОЙКИ
    Cursor  Курсор_УзнатьЕслиНаАндройдеТакойID=null;















    // TODO метод запуска СИНХРОНИЗАЦИИ  в фоне
    // TODO метод запуска СИНХРОНИЗАЦИИ  в фоне
    protected Integer МетодЗАпускаСинхронизациивФоне( @NotNull  Context contextПриШелИзАктивтиКоторомуНужнаСинхронизация,String КтоЗарустилСинхронизацию) {
        //
        Integer ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации = 0;
        try {
            /////TODO ПЕРЕОПРЕДЕЛЯЕМ КОНТЕКСТ С РАБОТАЮЩЕГО АКТИВТИ ДЛЯ ИНХРОНИЗАЦИИ
            if (contextПриШелИзАктивтиКоторомуНужнаСинхронизация != null) {
                ////
                КонтекстСинхроДляКонтроллераВФоне = contextПриШелИзАктивтиКоторомуНужнаСинхронизация;
                ///
            } else {
                Log.e(this.getClass().getName(), " Ошибка нет Конкеста  ЗАПУСК ФОНОВОЙ СИНХРОНИЗАЦИИ ....." + new Date());

            }

            Log.d(this.getClass().getName(), "ЗАПУСК ФОНОВОЙ СИНХРОНИЗАЦИИ ....." + new Date());
//              ////////

            ///
/////
            ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных
            ////


            ///
            ExecutorService cachedThreadPoolФоноваяСинхронизация = null; //newSingleThreadExecutor()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                cachedThreadPoolФоноваяСинхронизация = Executors.newWorkStealingPool(); //newSingleThreadExecutor()

            } else {

                cachedThreadPoolФоноваяСинхронизация = Executors.newCachedThreadPool(); //newSingleThreadExecutor()


            }
            // TODO: 25.05.2021


            ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации = 0;

            CompletionService<Integer> КомплитФоноваяСинхронизация = new ExecutorCompletionService<Integer>(cachedThreadPoolФоноваяСинхронизация);






            //////TODO ДО ПОТОКА КОД
            /////TODO ПОСЛЕ  СИНХРОНИЗАЦИЕЙ ОБНУЛЯЕМ КОЛИЧЕСТВО СТРОК JSON ОБЩЕЕ  , ПЕРЕД ПОЛУЧЕНИЕМ НОВОГО ЗНАЧЕНИЯ
            МетодДоНачалоФоновойСинхронизации();


            ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными


            КомплитФоноваяСинхронизация.submit(new Callable<Integer>() {
                @Override
                public Integer call() throws Exception {

                    ///

                    МетодСамогоФоновойСинхронизации();

/////

                    Integer ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизациивнутри = 0;

                    Log.d(this.getClass().getName(), " ФОНОВАЯ СИНХОРОНИЗАЦИИИ ИДЁТ... СЛУЖБА ");

                    //////TODO  КОД ПОСЛЕ ПОТОКА
                    ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизациивнутри = МетодПослеФононовойСинхроигзации();///результат фоновой синхронизции
                    //

                    Log.d(this.getClass().getName(), " ФОНОВАЯ СЛУЖБА КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ/И ОБНОВЛЕНИЙ " + ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизациивнутри);

                    return ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизациивнутри;
                }
            });
// TODO: 23.05.2021
            Future<Integer> futureОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации = КомплитФоноваяСинхронизация.poll(1, TimeUnit.MINUTES);

            ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации = futureОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации.get();


            if (futureОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации.isDone()) {


                // TODO: 25.05.2021  резульата потока

                Log.d(this.getClass().getName(), " ФОНОВАЯ СИНХОРОНИЗАЦИИИ КОНЧАЕТЬСЯ ... СЛУЖБА " + cachedThreadPoolФоноваяСинхронизация.isTerminated() + "\n" +
                        " ФИНАЛ ФОНОВАЯ СЛУЖБА КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ/И ОБНОВЛЕНИЙ количество: " + ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации);


                // TODO: 08.06.2021





                Log.d(this.getClass().getName(), " ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации "
                        + ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации);


                // TODO: 08.06.2021  если синхронизацию запустили локально то показываем результа пользователю
                
                
                if(КтоЗарустилСинхронизацию.equalsIgnoreCase("СинхронизацияЛокальная")){

                    Toast toast=       Toast.makeText(КонтекстСинхроДляКонтроллераВФоне, "Обмен с данными завершён !!!"+"\n"+
                            "( кол :"+ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации+" )", Toast.LENGTH_LONG);

                    toast.setGravity(Gravity.BOTTOM,0,40);
                    toast.show();
                }




                futureОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации.cancel(false);

                cachedThreadPoolФоноваяСинхронизация.shutdown();


            }


            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

        return ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации;
    }



















    private void МетодДоНачалоФоновойСинхронизации() {
        /////
        PUBLIC_CONTENT.СколькоСтрочекJSON = 0;
        /////TODO ПОСЛЕ  СИНХРОНИЗАЦИЕЙ синхронизации по всем таблицам обнулем общее количество успешных вставко и обновлений
        PUBLIC_CONTENT.КоличествоУспешныхВставки = 0;
        ///////////////
        PUBLIC_CONTENT.КоличествоУспешныхОбновлений = 0;
        ////

        PUBLIC_CONTENT.ИменаТаблицыОтАндройда.clear();
    }


    // TODO  КОНЕЦ метод запуска СИНХРОНИЗАЦИИ  в фоне

    Integer МетодПослеФононовойСинхроигзации( ) {


        int ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации=0;
        try {
            Log.d(this.getClass().getName(), " КОНЕЦ синхронизация В ФОНЕ onStopLoading()  ");

            ////TODO КОГДА СИНХРОНИЗАЦИЯ ЗАКАНЧИВАЕТЬСЯ МЫ ДАННЫМИ МЕТОДОМ ОБНУДЯЕМ ПЕРЕМЕННЫЕ И И ЗАПУВСКАМ АКТИВТИ FACEAPP
         /*   ((Activity) КонтекстСинхроДляКонтроллераВФоне).runOnUiThread(new Runnable() {
                public void run() {
                    ///TODO после синхронизации ПОКАЗЫВАЕМ ПОЛЬЗОВАТЕЛЮ ЧТО КОЛИЧЕСТОВ УСПЕШНЫХ ВСТАВОК И ОБНОВЕЛЕНИЙ СИНХРОНИЗАЦИИ В ФОНЕ
                    if (PUBLIC_CONTENT.КоличествоУспешныхВставки > 0 || PUBLIC_CONTENT.КоличествоУспешныхОбновлений > 0) {
                        /////TODO  ФИНАЛ СИНХРОНИЗАЦИИ ВИЗУАЛИАЦИЯ

                        ((Activity) КонтекстСинхроДляКонтроллераВФоне).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                Toast aa = Toast.makeText(КонтекстСинхроДляКонтроллераВФоне, "OPEN", Toast.LENGTH_SHORT);
                                ImageView cc = new ImageView(КонтекстСинхроДляКонтроллераВФоне);
                                //  cc.setImageResource(R.drawable.icon_dsu1_sunchronizasiy_down);//icon_dsu1_synchronisazia_dsu1_success
                                aa.setView(cc);
                                aa.show();
                                /////
                            }
                        });
                        // Toast.makeText(context, "Cинхронизация в фоне успешно прошла !!!" , Toast.LENGTH_SHORT).show();
                    } else {

                        ((Activity) КонтекстСинхроДляКонтроллераВФоне).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                Toast aa = Toast.makeText(КонтекстСинхроДляКонтроллераВФоне, "OPEN", Toast.LENGTH_SHORT);
                                ImageView cc = new ImageView(КонтекстСинхроДляКонтроллераВФоне);
                                //   cc.setImageResource(R.drawable.icon_dsu1_synchronis_error_down);//icon_dsu1_synchronisazia_dsu1_success
                                aa.setView(cc);
                                aa.show();
                            }});
                        ////
                        //  Toast.makeText(context, "данных для Cинхронизации в фоне нет !!!!" , Toast.LENGTH_SHORT).show();
                    }*/






/*
                }
            });//END UI*/


                   Log.d(this.getClass().getName(), " Всё КОНЕЦ  В ФОНЕ СИНХРОНИЗАЦИИ (100% )......... stopLoading() ");
    ///TODO ПОСЛЕ УСПЕШНОЙ СИНХРНИЗАЦИИ ОБНУЛЯЕМ ВСЕ ПЕРЕМЕННЫЕ КОТОРЫЕ УЧАСТВОВАЛИ В СИНХРОНИЗАЦИИ

            ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации=  PUBLIC_CONTENT.КоличествоУспешныхВставки+    PUBLIC_CONTENT.КоличествоУспешныхОбновлений;



            Log.d(this.getClass().getName(), " ФОНОВАЯ СЛУЖБА КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ/И ОБНОВЛЕНИЙ " +ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации);


    ///TODO флаг который показывает запускали ли мы уже Активити FaceApp
    /////TODO ПОСЛЕ  СИНХРОНИЗАЦИЕЙ ОБНУЛЯЕМ КОЛИЧЕСТВО СТРОК JSON ОБЩЕЕ  , ПЕРЕД ПОЛУЧЕНИЕМ НОВОГО ЗНАЧЕНИЯ
    PUBLIC_CONTENT.СколькоСтрочекJSON = 0;
    /////TODO ПОСЛЕ  СИНХРОНИЗАЦИЕЙ синхронизации по всем таблицам обнулем общее количество успешных вставко и обновлений
    PUBLIC_CONTENT.КоличествоУспешныхВставки = 0;
    ///////////////
    PUBLIC_CONTENT.КоличествоУспешныхОбновлений = 0;
    ////

                    PUBLIC_CONTENT.ИменаТаблицыОтАндройда.clear();

            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
return  ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизации;
    }










    ///TODO САМ ФОНОВЫЙ ПОТОК МЕТОД

    void МетодСамогоФоновойСинхронизации() {


        final int[] ФиналОбщееКоличествоСколькоСтрочекJSON = {0};

        final String[] ТекущаяТаблицаДляОБменаДанными = {null};

        ////TODO уставналиваем констанку что метод onStart запускалься только один раз

        int[] ОбщееКоличествоСколькоСтрочекJSON = new int[1];
        try {

            /////TODO 1  ШАГ СИНХРОНИЗАЦИИ ПОЛУЧАЕМ СПИСОК ТАБЛИЦ КОТОРЫЕ НУЖНО  СИНХРОНИЗИРОВАТЬ 100% процентов
            boolean ФлагПередНачаломСинхронизацииЕслиВообщеСвязьсИнтренетом = new CONTROLLER_synchronized_ROWS_JSON_AND_ALL_TABLES(КонтекстСинхроДляКонтроллераВФоне).
                    МетодЗапускаемПередНАчаломСинхронизацииЧтобЫПОнятьКоличествоТАблицДляСинхронизации(КонтекстСинхроДляКонтроллераВФоне);

            //TODO ФУТУРЕ ЗАВЕРШАЕМ
            Log.d(this.getClass().getName(), "  ФлагПередНачаломСинхронизацииЕслиВообщеСвязьсИнтренетом " + ФлагПередНачаломСинхронизацииЕслиВообщеСвязьсИнтренетом +
                    "PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size() " + PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size());


            ////////TODO общеее КОЛИЧЕСТВО ТАБЛИЦ
            PUBLIC_CONTENT.ОбщееКоличествоТаблиц = PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size();


            // TODO: 01.05.2021 запускаем если все активти невидны спущены вниз





            Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА ВНУТРИ startService   Вещятеля BroadcastReceiver  Synchronizasiy_Data " + new Date() +
                    "\n" + " Build.BRAND " + Build.BRAND.toString() );










            //TODO ВАЖНО НАЧИНАЕМ СИНХРОНИЗХАЦИЮ  ,, ТОЛЬКО КОГДА ЕСТЬ СВЯЗЬ С ИНТРЕНТОМ С СЕРВЕРОМ ЧЕРЕЗ MOBILE ЛИБО WIFI  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            if (ФлагПередНачаломСинхронизацииЕслиВообщеСвязьсИнтренетом == true
                    && (int) PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size() > 0 ) {// && ФлагЛюбогоЗапущеногоАктивти==false


                ////TODO ТОЛЬКО ПРИ НАЛИЧИИ ИНТРЕНТА  !!!!!!!!!!!!!!!! ЗАПУСК СИНХРОНИЗАЦИИ

                //////TODO ШАГ ТРЕТИЙ  ЗАПУСКАЕМ САМУ СИНХРОНИЗАЦИЮ  сама синхронизация в фоне
                МетодНачалоСихронизациивФоне(КонтекстСинхроДляКонтроллераВФоне); ////Получение Версии Данных Сервера для дальнейшего анализа

                //todo нет json ля вситавки

                ///TODO ЗАПУСКАЕМ СРАЗУ МЕТОД ONSTOP В ASYNTASKLOADER ПОТОМУ ЧТО НЕТ ИНТРЕНТА И НЕТ СМЫСЛА ДЕЛАТЬ СИНХРОНИЗАЦИЮ

            } else {
                /////TODO запус метода после ОТРАБОТАНОЙ СИНХРОНИЗАЦИИИ
                МетодПослеФононовойСинхроигзации();
            }

            /////////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }


    }


//////ПЕРВЫЙ МЕТОД ОБМЕНА ДАННЫМИ С СЕРВЕРОМ МЕТОД GET

    void МетодНачалоСихронизациивФоне( @NotNull  Context context) throws InterruptedException, ExecutionException, TimeoutException, JSONException {
        try {
            ////////todo ОБНУЛЯЕМ КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ ОБНОВЛЕНИЙ

            ////TODO ДАННЫЙ ЦИКЛ НУЖЕН ПЕРВЫЙ ШАГОМ ВЫ ВСТАВЛЯЕМ ДАННЫЕ ЕСЛИ ОНИ ЕСТЬ , А ВТОРЫМ ШАГОМ И ИХ ДОГОНЯЕМ ОБНОВЛЕМ ДАННЫЕ ВОТ ТАК  ДЛЯ СИНХРОНИЗАЦИИ

            //// TODO САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ В ФОНЕ
            МетодПолучениеIDотСервераДляГеренированиеUUID(); ////САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ///// TODO ГЛАВНЫЙ МЕТОД ОБМЕНА ДАНЫМИ  НА АКТИВИТИ FACE_APP
            ///todo конец финал обрабоатываем обновлениея
            ///todo конец финал обрабоатываем обновлениея

            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }


    void МетодПолучениеIDотСервераДляГеренированиеUUID() throws JSONException, InterruptedException, ExecutionException, TimeoutException {
        ///
        String ДанныеПришёлЛиIDДЛяГенерацииUUID = new String();
        /////
        PUBLIC_CONTENT.ПУбличныйДанныеПришёлЛиIDДЛяГенерацииUUID = ДанныеПришёлЛиIDДЛяГенерацииUUID;
        try {
            Log.d(this.getClass().getName(), " public   void МетодПолучениеIDОтСервераДляГеренированиеUUID ()" + " ДанныеПришёлЛиIDДЛяГенерацииUUID " + ДанныеПришёлЛиIDДЛяГенерацииUUID +
                    " ДанныеПришёлЛиIDДЛяГенерацииUUID.length()  " + ДанныеПришёлЛиIDДЛяГенерацииUUID.length());

            StringBuffer БуферПолучениеДанных=new StringBuffer();


            //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
             БуферПолучениеДанных = УниверсальныйБуферПолучениеДанныхсСервера("", "", "", "application/text", "Хотим Получить ID для Генерации  UUID", "", ""); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position

           ///////
            if (БуферПолучениеДанных != null) {
                do {
                    ДанныеПришёлЛиIDДЛяГенерацииUUID = БуферПолучениеДанных.toString();
                    Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID  " + ДанныеПришёлЛиIDДЛяГенерацииUUID);
                    //////TODO ПРИСВАИВАЕМ ПОЛУЧЕННЫЙ ID ПУБЛИЧНЫЙ
                    PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID = БуферПолучениеДанных.toString(); ///ИЗ ОТВЕТА ПОЛУЧАЕМ ID ПОЛЬЗОВАТЕЛЯ ДЛЯ ГЕНЕРАЦИИ  UUID//
                    ///
                    ///todo если мы прошли один раз и нет данных выходим
                    if (ДанныеПришёлЛиIDДЛяГенерацииUUID.length() == 0) {
                        break;
                    }
                } while (ДанныеПришёлЛиIDДЛяГенерацииUUID.length() == 0);/////конец for # количество респонсев
                //////
                Log.d(this.getClass().getName(), "  ПубличноеIDПолученныйИзСервлетаДляUUID  " + PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID);
                ////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК


                if (ДанныеПришёлЛиIDДЛяГенерацииUUID!=null) {
                    ///
                    if (ДанныеПришёлЛиIDДЛяГенерацииUUID.length() > 0 ) {//ЕСЛИ МЫ ПОЛУЧИЛИ ID  и СОЗДАЛИ НА ЕГО БАЗЕ UUID ТО ПРОХОДИИМ К СЛЕДУЮЩЕМУ КОДУ ПОЛУЧАЕМ ВЕРСИЮ ДАННЫХ СЕРВВЕРА


                        // TODO: 29.03.2021 записываем полученный пуюдтичны ID
                        Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID  " + ДанныеПришёлЛиIDДЛяГенерацииUUID.length());




                        ////запускаем слуд.ющий метод получение версии базы данных
                        МетодПолучениеСпискаТаблицДляОбменаДанными(ДанныеПришёлЛиIDДЛяГенерацииUUID);//получаем ID для генерирования UUID
                    }
                }


                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера  ");
            }
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }

    ///////////////////метод получение ОТ СЕРВЕРА КОНКРЕТНЫЙ СПИСОК ТАДОИЦЦ ДЛЯ ОБМЕНА


    ////////////МЕТОД ПОЛУЧЕНИЕ  ВЕРСИИ ДАННЫХ
    void МетодПолучениеСпискаТаблицДляОбменаДанными( @NotNull String ДанныеПришёлЛиIDДЛяГенерацииUUID) throws JSONException, InterruptedException, ExecutionException, TimeoutException {///второй метод получаем версию данных на СЕРВЕР ЧТОБЫ СОПОЧТАВИТЬ ДАТЫ
//////

        Log.d(this.getClass().getName(), " ДанныеПришёлЛиIDДЛяГенерацииUUID" + ДанныеПришёлЛиIDДЛяГенерацииUUID);

        String ДанныеПришлаСпискаТаблицДляОбмена = new String();
        
        StringBuffer БуферПолученияСпискаТАблицДляОбмена = new StringBuffer();


        ////TODO ПОСЛЕ ОБРАБОТКИ ТАБЛИЦ ОБНУЛЯЕМ
        PUBLIC_CONTENT.ИменаТаблицыОтАндройда.clear();

        try {
            //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
            БуферПолученияСпискаТАблицДляОбмена = УниверсальныйБуферПолучениеДанныхсСервера("view_data_modification", "", "", "application/json",
                    "Хотим Получить Версию Данных Сервера", "", ДанныеПришёлЛиIDДЛяГенерацииUUID); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position

            Log.d(this.getClass().getName(), " БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length " + БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length);
            
            if (БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length > 3) {
                do {
                    ДанныеПришлаСпискаТаблицДляОбмена = БуферПолученияСпискаТАблицДляОбмена.toString();
                    //////
                    БуферПолученияСпискаТАблицДляОбмена.append(ДанныеПришлаСпискаТаблицДляОбмена).append("\n");
                    Log.d(this.getClass().getName(), " ДанныеПришлаЛиВерсияДанныхсСервера " + ДанныеПришлаСпискаТаблицДляОбмена);
                } while (ДанныеПришлаСпискаТаблицДляОбмена == null);/////конец for # количество респонсев
                /////
                Log.d(this.getClass().getName(), "  ПубличноеIDПолученныйИзСервлетаДляUUID  " + PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID +
                        " БуферПолученияСпискаТАблицДляОбмена " + БуферПолученияСпискаТАблицДляОбмена.toString());
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
                ///ПОЛУЧЕННЫЙ СПИСОК ЗАПИСЫВАЕМ В ТАБЛИЦУ НАШУ ПЕРЕРМЕННЦУЮ
                JSONObject ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента = new JSONObject(БуферПолученияСпискаТАблицДляОбмена.toString());///упаковываем в j
                ///
                JSONArray МассивJSONТаблиц = ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.names();
                String НазваниеИзПришедшихТаблицДляКлиента;
                String СодержимоеИзПришедшихТаблицДляКлиента;
                String JSONСтрочка;
                String JSONНазваниеСтолбика;
                String JSONСодержимоеСтолика;
                String JSONСодержимоеСтоликаДляХэша;
                /////ЦИКЛ КРУТИТЬ JSON

                PUBLIC_CONTENT.ИменаТаблицыОтАндройда.clear();

                /////ЦИКЛ КОТРЫЙ БЕЖИТ ПО СТОРОКА ПРИГЕДШЕГО JSON ФАЙЛА И НАХОДИМ НАЩШИ ТАЮЛИЦЫ ДЛЯ УКАЗАННОГО ПОЛЬЗОВАТСЯ
                for (int ИндексТаблицыДляДанногоКлиента = 0; ИндексТаблицыДляДанногоКлиента < ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.names().length(); ИндексТаблицыДляДанногоКлиента++) {
                    ////// распарсиваем  josn
                    НазваниеИзПришедшихТаблицДляКлиента = МассивJSONТаблиц.getString(ИндексТаблицыДляДанногоКлиента);
                    СодержимоеИзПришедшихТаблицДляКлиента = ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.getString(НазваниеИзПришедшихТаблицДляКлиента); // Here's
                    JSONObject ОбьектJSON = new JSONObject(СодержимоеИзПришедшихТаблицДляКлиента);
                    JSONСтрочка = String.valueOf(ОбьектJSON.names());
                    /////ЦИКЛ КОТРЫЙ БЕЖИТ ПО СТОЛБЦАМ  ПРИГЕДШЕГО JSON ФАЙЛА И НАХОДИМ НАЩШИ ТАЮЛИЦЫ ДЛЯ УКАЗАННОГО ПОЛЬЗОВАТСЯ
                    for (int ИндексТаблицыДляДанногоКлиентаСтолбцы = 0; ИндексТаблицыДляДанногоКлиентаСтолбцы < ОбьектJSON.length(); ИндексТаблицыДляДанногоКлиентаСтолбцы++) {
                        JSONНазваниеСтолбика = String.valueOf(ОбьектJSON.names().get(ИндексТаблицыДляДанногоКлиентаСтолбцы));
                        JSONСодержимоеСтолика = ОбьектJSON.getString(JSONНазваниеСтолбика);
                        ///ЗАПОЛНЯЕМ ТОЛЬКО НАЗВАНИЯ ТАБЛИЦ  ПРЕДНАЗВАНЧЕН ТОЛЬКО ДЛЯ ДАННГО ПОЛЬЗОВАТЕЛЯ ТАБЛИЦЫ ПО КОТОРЫМ БУДЕТ ОБМЕН
                        ///todo вытаскмваем название таблиц для заполения таблицы модификейшен клеинта на андройде
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ИМЯ ИЗ МОДИФИКАЦИИ СЕРВЕР")) {

                            ////////TODO ЗАПОЛНЯЕМ АРАЙЛИСТ ЗНАЧЕНИЯ НАЗВАНИЕ ТАБЛИЦ ДЛЯ ОБРАБОТКИ

                            PUBLIC_CONTENT.ИменаТаблицыОтАндройда.add(JSONСодержимоеСтолика); //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ

                            Log.d(this.getClass().getName(), " JSONСодержимоеСтолика " + JSONСодержимоеСтолика);
                        }
                        /////А ТУТ МЫ ПРОСТО ЗАПОМИНАЕМ НАЗВАНИЕ ТАБЛИЦ С СЕРВЕРА  И ПЛЮС ИХ ДАТЫ ПОСЛЕДНЕГО ИЗМЕНЕНИЕ ДАННЫХ НА ДАННЫХ ТАБЛИЦАХ НА СЕРВЕРЕ
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ИМЯ ИЗ МОДИФИКАЦИИ СЕРВЕР")) {
                            //////ОТДЕЛЬНО ДляХэшМап
                            JSONСодержимоеСтоликаДляХэша = ОбьектJSON.getString("ДАТА ВЕРСИИ СЕРВЕРА");/////ТОЛЬКО ДЛЯ HSMAP
                            PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.put(JSONСодержимоеСтолика, JSONСодержимоеСтоликаДляХэша); ///// ЗАПОЛНЯЕМ ХЭШМАП ДЛЯ КРНКРЕТНОГО ПОЛЬЗОВАТЕЛЯ ТАБЛИЦ ДЛЯ ТОЛЬКО СЕСИИ
                            Log.d(this.getClass().getName(), " JSONСодержимоеСтолика " + JSONСодержимоеСтолика + "  JSONСодержимоеСтоликаДляХэша  " + JSONСодержимоеСтоликаДляХэша);
                        }
                        //todo проект имена
                        if (JSONНазваниеСтолбика.equalsIgnoreCase("ПРОЕКТЫ")) {
                            PUBLIC_CONTENT.ИменаПроектовОтСервера.add(JSONСодержимоеСтолика); //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ
                            Log.d(this.getClass().getName(), " ИменаПроектовОтСервера " + PUBLIC_CONTENT.ИменаПроектовОтСервера.toString());
                        }

                    }
                }
                //////
                /////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера  ");


            }
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        } finally {
            Log.i(this.getClass().getName(), " ИменаТаблицыОтАндройда " + PUBLIC_CONTENT.ИменаТаблицыОтАндройда.toString() +
                    " ДатыТаблицыВерсииДанныхОтСервера " + PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.toString());
            if (ДанныеПришлаСпискаТаблицДляОбмена.length() > 2) {//ЕСЛИ МЫ ПОЛУЧИЛИ ID  и СОЗДАЛИ НА ЕГО БАЗЕ UUID ТО ПРОХОДИИМ К СЛЕДУЮЩЕМУ КОДУ ПОЛУЧАЕМ ВЕРСИЮ ДАННЫХ СЕРВВЕРА
                ////запускаем слуд.ющий метод получение версии базы данных
                if (БуферПолученияСпискаТАблицДляОбмена != null) ;
                //// TODO запускам если ОТ СЕРВЕРА ПРИШЛИ  ДАННЫЕ СПИСОК ТАБЛИЦ ДЛЯ СОЗДАНИЕ СПИСК ДЛЯ ПОЛЬЗОВАТЕЯД

                ////TODO ТОЛЬКО НЕ ДЛЯ АКТИВТИ АНОНИМНЫЙ ОБМЕН БЕЗ ВИЗУАЛИЗАЦИИ СИНХРОНИЗАЦИИ
                МетодЗапускаемЦиклПоТаблицамДляДанногоПользователя(ДанныеПришёлЛиIDДЛяГенерацииUUID);

            }
        }
    }


    /////TODO МЕТОД ЗАПУСКА ЦИКЛА ПО ПОЛУЧЕННЫСМ ТАБЛИЦ С СЕРВЕРА ДАННЫХ ЦИКЛ FOR

/////

    void МетодЗапускаемЦиклПоТаблицамДляДанногоПользователя(String ДанныеПришёлЛиIDДЛяГенерацииUUID) {//КонтекстСинхроДляКонтроллера
        try {
/// ТУТ МЫ ЗАПУСКАЕМ ЦИКЛ С ПОЛУЧЕНЫМИ ДО  ЭТГО ТАБЛИЦАП КОНКРЕТНО ДЛЯ  ЭТОГО ПОДЛЬЗОВАТЛЯ
            Log.i(this.getClass().getName(), " ИменаТаблицыОтАндройда " + PUBLIC_CONTENT.ИменаТаблицыОтАндройда.toString()
                    + " ДатыТаблицыВерсииДанныхОтСервера " + PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.toString());
//          ////TODO настройки поо расширению количесво потоков в момент выполенния
            ////TODO текущая ТАБЛИЦА ПРИ ОБРАБОТКИ СИНХРОНИЗАЦИИ КОТОРАЯ УВЕЛИЧИВАЕТЬСЯ В ЦИКДЕ ПРИ ОБМЕНЕН
            //////TODO выводими обратно в UI вставка

            /////todo КОНЕЦ цикла фор
            ////////
            PUBLIC_CONTENT.ОбщееКоличествоТаблиц = PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size();



            ///TODO SLEEP
            int  countNew=PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size();

            CountDownLatch countDownLatchДляСинхрониазцииФоновой=new CountDownLatch(countNew);




            ////// TODO ГЛАВНЫЙ ПЕРВЫЙ ЦИКЛ ОБМЕНА ДАННЫХ в фоне         //////ГЛАВНЫЙ ПЕРВЫЙ ЦИКЛ ОБМЕНА ДАННЫХ         //////ГЛАВНЫЙ ПЕРВЫЙ ЦИКЛ ОБМЕНА ДАННЫХ
            for (String ТекущаяТаблицаДляОБменаДанными : PUBLIC_CONTENT.ИменаТаблицыОтАндройда) {
                //////
                // TODO: 30.03.2021 синхронизация в фоне
                

                Log.d(this.getClass().getName(), " ТекущаяТаблицаДляОБменаДанными " + ТекущаяТаблицаДляОБменаДанными);


                //todo sleeep
                ///TODO Все таблицы внутри клинета
                boolean ОтветЕслиТакаяТаблицаВнутриОбработкиДляПринятияРешениеНачинатьОбрабткуИлиНет=            МетодВЫчисляемВсеТаблицыВнутриКлинета(ТекущаяТаблицаДляОБменаДанными );


                Log.d(this.getClass().getName(), " ОтветЕслиТакаяТаблицаВнутриОбработкиДляПринятияРешениеНачинатьОбрабткуИлиНет "
                        + ОтветЕслиТакаяТаблицаВнутриОбработкиДляПринятияРешениеНачинатьОбрабткуИлиНет);

                /// TimeUnit.MILLISECONDS.sleep(100);

                ////TODO Если название таблиц из севреа совпадаию с названеим таблиц на клиенте начинаем синхронизацию
                if (ОтветЕслиТакаяТаблицаВнутриОбработкиДляПринятияРешениеНачинатьОбрабткуИлиНет==true) {

                    /////
                    try {
                        ///TODO сон
                        //////TODO метод обрабтки п таюлицам
                        МетодДляАнализаВерсийДанныхПолучаемДатыСервера(ТекущаяТаблицаДляОБменаДанными, ДанныеПришёлЛиIDДЛяГенерацииUUID); ////Получение Версии Данных Сервера для дальнейшего анализа
                        ///todo публикум название таблицы или цифру его
                        ///TODO увеличиваем таюлицу оработки
                        ////TODO
                    } catch (Exception e) {
                        //  Block of code to handle errors
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                     new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }
                }
                ////// todo  ПАРСИНГ ПРИШЕДЩЕГО JOSN ЗАПСКАЕМ МЕТОД ЕСЛИ РЕАЛЬНО ДАННЫЕ ПРИШЛИ ОТ СЕРВЕРА В ВИДЕ JSON

                ///TODO засыпаем


                try {
                    ///TODO после синхронизации ПОКАЗЫВАЕМ ПОЛЬЗОВАТЕЛЮ ЧТО КОЛИЧЕСТОВ УСПЕШНЫХ ВСТАВОК И ОБНОВЕЛЕНИЙ СИНХРОНИЗАЦИИ В ФОНЕ
                  //  if (PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице > 0) {

                        //todo ВО ВРЕМЯ СИНХРОНИЗХАЦИИ В ФОНЕ ИЗМЕНЯЕМ ДАТЫ ТАБЛИЦ ТОЛЬКО ПО ТАБЛИЦАМ КОГДА ИДЕМ
                        int Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы = new MODEL_synchronized(КонтекстСинхроДляКонтроллераВФоне).
                                МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанных(ТекущаяТаблицаДляОБменаДанными, new Date());

                        Log.i(this.getClass().getName(), "   Результат_ПриписиИзменнийВерсииДанныхВФоне:" + Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы);

                        ///TODO обнулем
                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице = 0;


                 //   }

                    /////////////////
                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }


                // TODO: 01.04.2021 внцтри цикла

// TODO: 23.05.2021  
                countDownLatchДляСинхрониазцииФоновой.countDown();




            }/// todo end for по таблицам


// TODO: 13.03.2021 авайт всех таблиц в фоне
            /////////////после цикла всегда
            // TODO: 23.05.2021
            countDownLatchДляСинхрониазцииФоновой.await();


        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }


    ///TODO вычисляем если такая таблиЦА ВНУТРИ БАЗЫ
    private boolean МетодВЫчисляемВсеТаблицыВнутриКлинета(String ТекущаяТаблицаДляОБменаДанными) {
        boolean ЕслиТАкаяТаблица = false;

        try{

            Cursor КурсорВсехТаблицВнутри=ССылкаНаСозданнуюБазу.rawQuery("SELECT name FROM sqlite_master WHERE type = 'table'",null);

            if(КурсорВсехТаблицВнутри.getCount()>0) {
                КурсорВсехТаблицВнутри.moveToFirst();
                Log.d(this.getClass().getName(), "  КурсорВсехТаблицВнутри."  +  КурсорВсехТаблицВнутри.getCount());

                do {
                    ////
                    if (ТекущаяТаблицаДляОБменаДанными.equals(КурсорВсехТаблицВнутри.getString(0))) {
                        Log.d(this.getClass().getName(), "  ТекущаяТаблицаДляОБменаДанными." + ТекущаяТаблицаДляОБменаДанными +
                                "  КурсорВсехТаблицВнутри.getString(0)) " + КурсорВсехТаблицВнутри.getString(0));

                        ЕслиТАкаяТаблица = true;

                        break;
                    }


                    Log.d(this.getClass().getName(), "  ТекущаяТаблицаДляОБменаДанными." + ТекущаяТаблицаДляОБменаДанными +
                            "  КурсорВсехТаблицВнутри.getString(0)) " + КурсорВсехТаблицВнутри.getString(0));


                }while(КурсорВсехТаблицВнутри.moveToNext());
                ////////
                КурсорВсехТаблицВнутри.close();

            }else{
                Log.d(this.getClass().getName(), "  КурсорВсехТаблицВнутри."  +  КурсорВсехТаблицВнутри.getCount());
                ЕслиТАкаяТаблица=false;
            }


            ///todo публикум название таблицы или цифру его
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

////
        return ЕслиТАкаяТаблица;
    }




































    /////////////////////ИЩЕМ ДАТУ СЕРВЕРВА
    void МетодДляАнализаВерсийДанныхПолучаемДатыСервера(String ТекущаяТаблицаДляОБменаДанными, String ДанныеПришёлЛиIDДЛяГенерацииUUID)
            throws JSONException, InterruptedException, ExecutionException, TimeoutException {
        //
        Date ДатаВерсииДанныхНаSqlServer = null;
        Log.d(this.getClass().getName(), " ДанныеПришёлЛиIDДЛяГенерацииUUID  " + ДанныеПришёлЛиIDДЛяГенерацииUUID + " ТекущаяТаблицаДляОБменаДанными " + ТекущаяТаблицаДляОБменаДанными);

        String ПолученнаяДатыSqlServer;
        JSONObject ОбьектыJSONФайлJSONсСервераВерсияSQlserver = new JSONObject();
        String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных = "";
        String ИмитацияВремяДляПроверки;
        Date ИмитациДатыДляПроверки = null;
        ///////
        String ТесктДатыSqlServer = null;
        try {
/////ТУТ -- КОД АНАЛИЗА ДАННЫХ SQL SERVER  ПРИШЕДШЕЙ ТЕКУЩЕЙ ТАБЛИЦЕ ПОЛУЧАЕМ НАЗВАНИЕ БАЗЫ И К НЕЙ ПОЛУЧАЕМ ДАТУ Е НЕЙ
//анализируем записи и ищем нашут текущаю таблицу и дату к ней
            for (Map.Entry<String, String> ХэшДляАнализаТекущейТаблицыВерсииДанных : PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.entrySet()) {
                //////
                System.out.println(ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey() + " - " + ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue());
                if (ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey().equalsIgnoreCase(ТекущаяТаблицаДляОБменаДанными)) {///ищем в текущей строчке текущуе название таблицы например CFO==CFO
                    ////записываем в json  получену.юю текущаю названеи табиуви к ней дата ВЕРСИЯ ДАННЫХ
                    /////
                    ОбьектыJSONФайлJSONсСервераВерсияSQlserver.put(ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey(), ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue());
                    /////
                    Log.d(this.getClass().getName(), " ОбьектыJSONФайлJSONсСервераВерсияSQlserver " + ОбьектыJSONФайлJSONсСервераВерсияSQlserver.toString());
                    ////////
                    ////ПЕРЕРДАЕМ ИМЯ ТАБЛИЦЫ ОТ SQL SERVER
                    ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных = ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey();
                    //// ПЕРЕДАЕМ ДАТУ ИЗ ТАБЛИЦЫ ОТ SQL SERVER
                    ПолученнаяДатыSqlServer = ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue();
                    if (ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных != null) {///ЕСЛИ НА SQL SERVER НЕ ПУСТЦЫЕ СТРОЧКИ В ТАБОИЦЕ ВЕРСИЙ СЕРВЕРА




                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                            ДатаВерсииДанныхНаSqlServer = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ПолученнаяДатыSqlServer);// получена ДАТА ВЕРСИИ ДАННЫХ СЕРВЕРА

                        }else {

                            ДатаВерсииДанныхНаSqlServer = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ПолученнаяДатыSqlServer);// получена ДАТА ВЕРСИИ ДАННЫХ СЕРВЕРА


                        }

                        Log.d(this.getClass().getName()," ДатаВерсииДанныхНаSqlServer " +ДатаВерсииДанныхНаSqlServer.toString());


                        //// как все сделали выходим
                        break;
                    }
                }
            }


///// todo КОНЕЦ ТУТ -- КОД АНАЛИЗА ДАННЫХ SQL SERVER  ПРИШЕДШЕЙ ТЕКУЩЕЙ ТАБЛИЦЕ ПОЛУЧАЕМ НАЗВАНИЕ БАЗЫ И К НЕЙ ПОЛУЧАЕМ ДАТУ Е НЕЙ
            /////////////////////////////////имитация///////////////////////////////// TODO ИМИТАЦИЯ НУЖНА КОГДА ДАТА SQL SERVER НУЛЕВАЯ И МЫ ЕЕ ИМИТИРУЕМ
            Calendar calendar = new GregorianCalendar(1800, 02, 01);////имитируем дату на андройде
            ИмитациДатыДляПроверки = calendar.getTime();
            DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
            dateFormat.format(ИмитациДатыДляПроверки);
            ИмитацияВремяДляПроверки = dateFormat.format(ИмитациДатыДляПроверки);
            Log.d(this.getClass().getName(), " ИмитациДатыДляПроверки " + ИмитациДатыДляПроверки.toString());
            //////////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        } finally {
            ////////
            Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаSqlServer  " + ДатаВерсииДанныхНаSqlServer.toString() + "  ИмитациДатыДляПроверки " + ИмитациДатыДляПроверки.toString());
            if (ДатаВерсииДанныхНаSqlServer.after(ИмитациДатыДляПроверки)) {
/////////////
                МетодДляВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером(ОбьектыJSONФайлJSONсСервераВерсияSQlserver, ДатаВерсииДанныхНаSqlServer, ТекущаяТаблицаДляОБменаДанными,
                        ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных, ДанныеПришёлЛиIDДЛяГенерацииUUID);////метод получение даты версии данных из андройда
            }
        }
    }


    /////////////////////TODO метод ВЫРАВНИВАНИЯ ТАБЛИЦ МЕЖДУ КЛИЕНТОМ И СЕРВЕРОМ КОЛИЧЕСТВО ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ
    void МетодДляВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером(JSONObject ФайлJSONcВерсиейДанныхСервера, Date ДатаВерсииДанныхНаSqlServer,
                                                                          String ИмяТаблицыОтАндройда_Локальноая,
                                                                          String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                                                                          String ДанныеПришёлЛиIDДЛяГенерацииUUID)
            throws InterruptedException, ExecutionException, TimeoutException {

        Log.d(this.getClass().getName(), " ФайлJSONcВерсиейДанныхСервера " + ФайлJSONcВерсиейДанныхСервера.toString());
        JSONObject ОбьектыJSONvalue;
        JSONArray КлючJSONПолей = null;
        Cursor КурсорДляАнализаВерсииДанныхАндройда;
        String ТекстВерсииБазыАндрод = "";
////////
        String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;
        Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновления = null;
        String ДатаВерсииДанныхНаАндройдеДляМетодаGET = null;
        Date ДатаВерсииДанныхНаАндройде = null;
        try {
            //// #1 РАСПАРСИВАЕМ ПРИШЕДШИЙ JSON С СЕРВРЕА ОТ SQL SERVER
            JSONArray КлючиJSONПолей = ФайлJSONcВерсиейДанныхСервера.names();
            for (int ИндексПолучениеВерсииДанныхАндройда = 0; ИндексПолучениеВерсииДанныхАндройда < ФайлJSONcВерсиейДанныхСервера.names().length(); ИндексПолучениеВерсииДанныхАндройда++) {
                String ИмяПоляДляВставкиВАндйрод = КлючиJSONПолей.getString(ИндексПолучениеВерсииДанныхАндройда); // Here's your key
                Log.d(this.getClass().getName(), " ИмяПоляДляВставкиВАндйрод " + ИмяПоляДляВставкиВАндйрод);
                String СодержимоеПоляДляВставкиВАндйрод = ФайлJSONcВерсиейДанныхСервера.getString(ИмяПоляДляВставкиВАндйрод); // Here's your value
                Log.d(this.getClass().getName(), " ЗначениеСтолбикаНазваниеТаблицНаСервере " + ИмяПоляДляВставкиВАндйрод + " ЗначениеСтолбикаВерсииТаблицНаСервере   " +
                        СодержимоеПоляДляВставкиВАндйрод);
                ///// #2 ТЕПЕРЬ ПОЛУЧЕНЫЕ ДАННЫЕ А ТОЧНЕЕ НАЗВАНИЕ ТАБЛИЦ ЗАПИСЫВАЕМ В ВЕРСИЮ ДАННЫХ АНДРОЙД
                КурсорДляАнализаВерсииДанныхАндройда = КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[]{"name"}, "name=?", new String[]{ИмяПоляДляВставкиВАндйрод},
                        null, null, null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                //"SuccessLogin", "date_update","id=","1",null,null,null,null
                ////////вставляем ноое название талицы если ее нет на андройде в таблице модификаци данных
                if (КурсорДляАнализаВерсииДанныхАндройда != null) {
                    КурсорДляАнализаВерсииДанныхАндройда.moveToFirst();
                    Log.d(this.getClass().getName(), " КурсорДляАнализаВерсииДанныхАндройда.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());
                }
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
                //ОЧЕНЬ ВАЖНО ЕСЛИ ЭТОТ КУРСОР ВЕРНЕТЬ ПОЛОЖИТЕЛЬНО ЦИФРУ ЭТО ЗНАЧИИТ ЧТО ТАКАЯ ТАБЛИЦУ УЖЕ ЕСТЬ НА АНДРОЙДЕ И ВСТАВЛЯЕТЬ ЕЕ НЕ НАДО
                if (КурсорДляАнализаВерсииДанныхАндройда.getCount() < 1) {/////ЕСЛИ КУРСОР ВОЗВРЯЩАЕТ ЦИФРУ 1 ТО ТОГДА ДАННАЯ ТАБОИЦА УЖЕ ЕСТЬ В ТАБЛИЦЕ ВЕРСИЙ ДАНЫХ АНДРОЙДА
                    Log.d(this.getClass().getName(), " КурсорДляАнализаВерсииДанныхАндройда.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());
                    ContentValues КонтейнерВствкаНовыхИменТаблицМодифика = new ContentValues();
                    КонтейнерВствкаНовыхИменТаблицМодифика.put("name", ИмяПоляДляВставкиВАндйрод);////ЗАПОЛЯНЕМ КОНТЕРЙНЕР ИМЯ ТАБЛИЦЫ КОТОРОЙ НЕТ ИЗ  СЕРВЕРА
                    //КонтейнерВствкаНовыхИменТаблицМодифика.put("versionserveraandroid", "2001-11-01 00:00:00");////ЗАПОЛЯНЕМ КОНТЕРЙНЕР ДАТУ ГЕНЕРИРУЕМ В ТАБЛИЦУ КОТОРО НЕТ
                    /////записываем если такой таблицы нет  на андройде в таблице модификация данных
                    Long РезультатВставкиДанных = ВставкаДанныхЧерезКонтейнерУниверсальная("MODIFITATION_Client", КонтейнерВствкаНовыхИменТаблицМодифика, ИмяТаблицыОтАндройда_Локальноая, "", false, 0, false,
                            КонтекстСинхроДляКонтроллераВФоне); ////false  не записывать изменениея в таблице модификавет версия
                    Log.d(this.getClass().getName(), " РезультатВставкиДанных " + РезультатВставкиДанных);
                    ////
                    /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                }
                Log.i(this.getClass().getName(), " НазваниеТаблицНаСервере  " + ИмяПоляДляВставкиВАндйрод + " ФайлJSONcВерсиейДанныхСервера.names().length() "
                        + ФайлJSONcВерсиейДанныхСервера.names().length() + " КурсорДляАнализаВерсииДанныхАндройда.getCount()  " + КурсорДляАнализаВерсииДанныхАндройда.getCount());
//внутри цикла
            }
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        } finally {
            //// ПОЛУЧИЛИ ДАТУ ОТ SQL SERVER  ДЛЯ ОПРЕЕЛЕННОЙ ТАБЛИЦЫ И ЗАПОЛНИЛИ ТАБЛИЦУ МОДИФИКАЦИЯ ДАНЫХ НА КЛИЕНТЕ  И ИДЕМ УЖЕ АНАЛИЗИРОВАТЬ ИХ НИЖЕ
            if (ДатаВерсииДанныхНаSqlServer.toString().length() > 0) {
                Log.d(this.getClass().getName(), " ИмяТаблицыОтАндройда_Локальноая " + ИмяТаблицыОтАндройда_Локальноая + " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toString() + " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных "
                        + ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных);
                //////////метод анализа данных
                МетодАнализаВресииДАнныхКлиента(ИмяТаблицыОтАндройда_Локальноая, ДатаВерсииДанныхНаSqlServer, ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных, ДанныеПришёлЛиIDДЛяГенерацииUUID);
            }
        }
    }


    ////////////////////////////ДАННЫЙ МЕТОД ПОСЛЕ ВЫШЕ СТОЯШЕГО ВЫРАВНИЯНИЯ НАЗВАНИЙ ТАБЛИЦ ПРИСТУПАЕТ К САМОМУ АНАЛИЗУ ДАННЫХ ВЕРСИИ ДАННЫХ НАХОДЯЩИХСЯ НА АНДРОЙДЕ
    void МетодАнализаВресииДАнныхКлиента(String ИмяТаблицыОтАндройда_Локальноая, Date ДатаВерсииДанныхНаSqlServer, String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных, String ДанныеПришёлЛиIDДЛяГенерацииUUID) {

        Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toGMTString());
        Cursor КурсорДляАнализаВерсииДанныхАндройда;
        String ДатаВерсииДанныхНаАндройдеДляМетодаGET = null;
        Date ДатаВерсииДанныхНаАндройдеSERVER = null;
        // String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;
        Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = null;
        try {
            ////#3 ТРЕТИТЬ КОГДА ЕСИ ОТСУТТВУЕТ НАЗВАНИЕ ТАБЛИЦ НА АНДРОЙДЕ И МЫ ИХ ТУДА ВПИСАЛИ , ТО ПРИСТУПАЕМ  К ТРЕТЬЕМУ ШАГУ К АНАЛИЗУ ДАНННЫХ
            КурсорДляАнализаВерсииДанныхАндройда = КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[]{"name,localversionandroid, versionserveraandroid"},
                    "name=?", new String[]{ИмяТаблицыОтАндройда_Локальноая}, null, null, null, null);//"SELECT
            // * FROM MODIFITATION_Client WHERE name=?",ИмяТаблицыОтАндройда_Локальноая
            //  //"SuccessLogin", "date_update","id=","1",null,null,null,null
            ////
            /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
            /////////ВАЖНО ЕСЛИ БОЛЬШЕ НУЛ ЗНАЧИТ В АНДРОЙДЕ ТАБЛИЦА С ТАКИМ НАЗВАНИЕМ УЖЕ ЕСТЬ
            if (КурсорДляАнализаВерсииДанныхАндройда.getCount() > 0) {////ВЫЖНОЕ УСЛОВИЕ ЕСЛИ КУРСОР ВЕРНУЛ БОЛЬШЕ НУЛЯ  ДАННАЕ ТОЛЬКО ТОГДА НАЧИНАЕМ АНАЛИЗ ВЕРСИИ ДАННЫХ НА АНДРОЙДЕ
                КурсорДляАнализаВерсииДанныхАндройда.moveToFirst();
                Log.d(this.getClass().getName(), "  Курсор_УзнаемВерсиюБазыНаАдройде.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());
                //////////////
                //String id = КурсорДляАнализаВерсииДанныхАндройда.getString( КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("name") );
                ДатаВерсииДанныхНаАндройдеДляМетодаGET = КурсорДляАнализаВерсииДанныхАндройда.getString(КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("versionserveraandroid"));
                ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = КурсорДляАнализаВерсииДанныхАндройда.getString(КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("localversionandroid"));
                Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеДляМетодаGET " + ДатаВерсииДанныхНаАндройдеДляМетодаGET
                        + " ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET  " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);

                ///////////ОПРЕДЕЛЯЕМ ДАТУ АНДРОЙДА ДЛЯ СОСТЫКОВКИ С ДАТОЙ SQ; SERVER//// ПОЛУЧАЕМ ДАТУ НА АНДРОЙДЕ ПОЛСЕДНЕЕ ИЗМЕНЕНИЯ ПРИШЕДЩИЕ ДАННЫЕ С СЕРВЕРА
                ДатаВерсииДанныхНаАндройдеSERVER = null;
                if (ДатаВерсииДанныхНаАндройдеДляМетодаGET != null) {///ЕСЛИ НА АНДРОЙДЕ НЕ ПУСТЦЫЕ СТРОЧКИ В ТАБОИЦЕ ВЕРСИЙ КЛИЕНТА
                    try {





                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                            ДатаВерсииДанныхНаАндройдеSERVER = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеДляМетодаGET);

                        }else {

                            ДатаВерсииДанныхНаАндройдеSERVER = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеДляМетодаGET);


                        }
                        Log.d(this.getClass().getName()," ДатаВерсииДанныхНаАндройдеSERVER " +ДатаВерсииДанныхНаАндройдеSERVER.toString());


                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    ////////
                    Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеДляМетодаGET  " + ДатаВерсииДанныхНаАндройдеДляМетодаGET +
                            "   ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);

                    ///////////ОПРЕДЕЛЯЕМ ДАТУ АНДРОЙДА ДЛЯ СОСТЫКОВКИ С ДАТОЙ SQ; SERVER //////ПОЛУЧЕНИЕ ДАННЫХ ОБ ИЗМЕННИЯХ ДАННЫХ ЛОКАЛЬНО САМИМ ПОЛЬЗОВАТЛЕМ
                    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = null;
                    if (ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET != null) {///ЕСЛИ НА АНДРОЙДЕ НЕ ПУСТЦЫЕ СТРОЧКИ В ТАБОИЦЕ ВЕРСИЙ КЛИЕНТА
                        try {



                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                                ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);

                            }else {

                                ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);


                            }

                            Log.d(this.getClass().getName()," ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL " +ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString());



                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        ////////
                        Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройдеДляМетодаGET  " + ДатаВерсииДанныхНаАндройдеДляМетодаGET
                                + "   ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET   " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);
                    }
                }
            } else {
                Log.d(this.getClass().getName(), "  КурсорДляАнализаВерсииДанныхАндройда.getCount()" + КурсорДляАнализаВерсииДанныхАндройда.getCount());
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл

        } finally {
            Log.d(this.getClass().getName(), "   ДатаВерсииДанныхНаАндройде " + ДатаВерсииДанныхНаАндройдеSERVER.toString()
                    + " ДатаВерсииДанныхНаSqlServer  " + ДатаВерсииДанныхНаSqlServer.toString() +
                    " ДатаВерсииДанныхНаАндройдеДляЛокальногоОбновления " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString() + " ДатаВерсииДанныхНаАндройдеДляМетодаGET " + ДатаВерсииДанныхНаАндройдеДляМетодаGET);
            if (ДатаВерсииДанныхНаАндройдеSERVER != null && ДатаВерсииДанныхНаSqlServer != null && ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL != null) {
                ///////////////
                //СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
                МетодПринятияРешенияПолучитьДанныесСервераИлиОтправитьДанныесКлиента(ДатаВерсииДанныхНаАндройдеSERVER,
                        ДатаВерсииДанныхНаSqlServer, ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL,
                        ИмяТаблицыОтАндройда_Локальноая, ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                        ДатаВерсииДанныхНаАндройдеДляМетодаGET, ДанныеПришёлЛиIDДЛяГенерацииUUID);///СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
            }
        }
    }


    //TODO СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
    void МетодПринятияРешенияПолучитьДанныесСервераИлиОтправитьДанныесКлиента(Date ДатаВерсииДанныхНаАндройдеSERVER, Date ДатаВерсииДанныхНаSqlServer,
                                                                              Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL,
                                                                              String ИмяТаблицыОтАндройда_Локальноая, String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                                                                              String ДатаВерсииДанныхНаАндройдеДляМетодаGET, String ДанныеПришёлЛиIDДЛяГенерацииUUID) {
        //
        Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаАндройдеДляЛокальногоОбновления " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toGMTString() +
                " ИмяТаблицыОтАндройда_Локальноая " + ИмяТаблицыОтАндройда_Локальноая + " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных " + ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных);
        try {

///// TODO НАЗВАНИЯ  ОБЯЗАТОЛЬНОЕ УСЛОВИЕ НАЗВАНИЕ ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ НАПРИМЕР  CFO==CFO
            if (ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных.equalsIgnoreCase(ИмяТаблицыОтАндройда_Локальноая)) {//////ОБЯЗАТОЛЬНОЕ УСЛОВИЕ НАЗВАНИЕ ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ НАПРИМЕР  CFO==CFO


////// todo ВНИМАНИЕ ТУТ КОД НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ БОЛЬШЕ  ЧЕМ НА СЕРВЕРЕ   ,,,,,,, И МЫ ДОЛЖНЫ С ТЕЛЕФОНА ОТОСЛАТЬ ДАННЫЕ НА СЕВРЕР SQL SEVER   POST ()

////// ЛОКАЛЬНАЯ ПРОВЕРКА ВЕРСИИ ДАНННЫХ  #1 НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ ПОСЛЕДНАЯЯ НАДО С АНДРОЙДА ПОСЛАТЬ ДАННЫЕ НА СЕРВЕР
                if (ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.after(ДатаВерсииДанныхНаАндройдеSERVER)) {//ПРОВЕРЯЕМ ДАТЫ КАКАЯ БОЛЬШЕ МЕНЬШЕ тут больше что слева sql server
//////  НАЧАЛО  ЛОКАЛЬНАЯ ПРОВЕРКА ВНУТИРИ АНДРОЙДА ПО ДАТАМ МЕЖДУ СОБОЙ

                    Log.d(this.getClass().getName(),
                            "    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL   " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString()
                                    + " ДатаВерсииДанныхНаАндройдеSERVER   " + ДатаВерсииДанныхНаАндройдеSERVER.toString()
                                    + " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toString());
          /*  ////TODO ПЕРЕДАЕМ ДАТЫ МЕТОДУ ДЛЯ ОТПРАВКИ ДАННЫХ НА СЕРВЕР ДЛЯ ЭТОГО ЕГО НЕМНОГО ПРЕОБРАЗУЕМs
            DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));
            String ДатаВерсииДанныхНаSqlServerДляОтправкиНаСерверДанных =dateFormat.format(ДатаВерсииДанныхНаSqlServer );
                    ///////todo МЕТОД GET запускаем метод POST посылаем Данные на сервер
            /////МетодПосылаемДанныеНаСервер(ИмяТаблицыОтАндройда_Локальноая ,ДатаВерсииДанныхНаSqlServerДляОтправкиНаСерверДанных ); //////МЕТОД POST*/
                    ////// todo МЕТОД POST
                    МетодПосылаемДанныеНаСервервФоне(ИмяТаблицыОтАндройда_Локальноая); ////// todo МЕТОД POST() в фоне

////// todo ВНИМАНИЕ ТУТ КОД НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ БОЛЬШЕ  ЧЕМ НА СЕРВЕРЕ   ,,,,,,, И МЫ ДОЛЖНЫ С ТЕЛЕФОНА ОТОСЛАТЬ ДАННЫЕ НА СЕВРЕР SQL SEVER   POST ()











                    //////// TODO  В ДАННОМ СЛУЧАЕ НА СЕРВРЕР ВЕРСИЯ  ДАННЫХ СТАРШЕ ЧЕМ НА АНДЙРОДЕ , И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВЕРА  GET()
                    ////////
                } else if (ДатаВерсииДанныхНаSqlServer.after(ДатаВерсииДанныхНаАндройдеSERVER)) { // С СЕРВЕРА
                    //////
                    ///////
                    Log.d(this.getClass().getName(), " НА SQL SERVER  ДАТА больше версия" +
                            " ДатаВерсииДанныхНаSqlServer " + ДатаВерсииДанныхНаSqlServer.toString() +
                            " и  ДатаВерсииДанныхНаАндройдеSERVER " + ДатаВерсииДанныхНаАндройдеSERVER.toString() +
                            " и  ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL " + ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL.toString());

//////////TODO МЕТОД get
                    МетодПолучаемДаннныесСервера(ИмяТаблицыОтАндройда_Локальноая, ДатаВерсииДанныхНаАндройдеДляМетодаGET, ДанныеПришёлЛиIDДЛяГенерацииUUID,
                            ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияLOCAL);/// ЗАПУСКАМ МЕТОД ПОЛУЧЕНИЕ ДАННЫХ С СЕРВЕРА    МЕТОД GET


                    Log.d(this.getClass().getName(), " ПОСЛЕ УСПЕШНОЙ ОТПАРВКИ ДАННЫХ НА СЕРВЕР" +
                            " КоличествоУспешныхВставки " + PUBLIC_CONTENT.КоличествоУспешныхВставки + " КоличествоУспешныхОбновлений " + PUBLIC_CONTENT.КоличествоУспешныхОбновлений);
/////В ДАНОМ СЛУЧАЕ ДАННЫЕ СИНХРОНИЗИРОВАТЬ НЕ НАДО ВЕСРИЯ ДАННЫХ НА СЕРВРЕР И НА КЛИЕНТЕ ОДИНАКОВЫ










                    ////TODO КОГДА ДАТЫ РАВНЫ И НЕ ПОЛУЧАТЬ ДАННЫЕ И ОТСЫЛАТЬ НЕ НАДО GET() И POST() ОБА НЕ СРАБОТАЛИ
                } else {

                    Log.d(this.getClass().getName(),
                            " ХОЛОСТОЙ ОБМЕН   КОГДА ДАТЫ РАВНЫ И НЕ ПОЛУЧАТЬ ДАННЫЕ И ОТСЫЛАТЬ НЕ НАДО GET() И POST() ОБА НЕ СРАБОТАЛИ  "+
                                    " ИмяТаблицыОтАндройда_Локальноая " + ИмяТаблицыОтАндройда_Локальноая );


                }
                //////// TODO  В ДАННОМ СЛУЧАЕ НА СЕРВРЕР ВЕРСИЯ  ДАННЫХ СТАРШЕ ЧЕМ НА АНДЙРОДЕ , И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВЕРА  GET()


            }


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }


    /////МЕТОД КОГДА НА СЕРВЕРЕ ВЕРСИЯ ДАННЫХ ВЫШЕ И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВРА
    void МетодПолучаемДаннныесСервера(String имяТаблицыОтАндройда_локальноая, String ДатаВерсииДанныхНаАндройдеДляМетодаGET,
                                      String ДанныеПришёлЛиIDДЛяГенерацииUUID, Date ДатаВерсииДанныхНаАндройдеДляЛокальногоОбновления) {
        ////
        Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID " + ДанныеПришёлЛиIDДЛяГенерацииUUID);
////
        StringBuffer БуферПолученныйJSON = null;
        try {
            Log.d(this.getClass().getName(), "  МетодПолучаемДаннныесСервера" + "  имяТаблицыОтАндройда_локальноая" + имяТаблицыОтАндройда_локальноая);

            //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
            StringBuffer БуферПолучениеДанных= new StringBuffer();

            // TODO: 15.06.2021 получение данных ссервера в фоне
            
            
            БуферПолучениеДанных = УниверсальныйБуферПолучениеДанныхсСервера(имяТаблицыОтАндройда_локальноая, "",
                    "", "application/json", "Хотим Получить  JSON", ДатаВерсииДанныхНаАндройдеДляМетодаGET, ДанныеПришёлЛиIDДЛяГенерацииUUID); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position



            if (БуферПолучениеДанных != null && БуферПолучениеДанных.length()>0) {
                /////

                БуферПолученныйJSON = new StringBuffer();

                /////ЦИКЛ ПЕРЕБОРА JSON КОТОРЫЙ ПРИШЁЛ\
                Log.d(this.getClass().getName(), "  БуферПолучениеДанных.toString()) " + БуферПолучениеДанных.toString());
                do {
                    БуферПолученныйJSON.append(БуферПолучениеДанных.toString());
                    Log.d(this.getClass().getName(), " БуферПолученныйJSON внутри цикла  " + БуферПолученныйJSON.toString());
                } while (БуферПолучениеДанных == null);
                ////////Присылаем количестов строчек обработанных на сервлете
                Log.d(this.getClass().getName(), " БуферПолученныйJSON.length()  " + БуферПолученныйJSON.length());
                Log.d(this.getClass().getName(), " БуферПолученныйJSON  " + БуферПолученныйJSON.toString());
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера сам файл JSON  ");
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        } finally {
            //////ЗАПУСКАЕМ МЕТОД РАСПАРСИВАНИЕ JSON  ПОЛУЧЕНЫЙ ИЗ СЕРВЛЕТА ОТ МЕТОДА  GET

            if (БуферПолученныйJSON!=null && БуферПолученныйJSON.toString().toCharArray().length > 3) {

                Log.d(this.getClass().getName(), "  БуферПолученныйJSON " + БуферПолученныйJSON.toString());

                ///как только получиили данные как первый запуска переключаем флаг что далее будет не первый запуск , ТО ТОГДА МЫ ФИЛЬТР ОБНОВЛЯНЕМ И ПЕРЕКОЛЮЧЕМ ЕГО НА НЕ ПЕРВЫЙ ЗАПУСК
                if (PUBLIC_CONTENT.ФильтрДляДанныхЯвляетьсяЛиНулевойЗапускКлиента.length() > 0) {
                    PUBLIC_CONTENT.ФильтрДляДанныхЯвляетьсяЛиНулевойЗапускКлиента = "";
                }
                try {
                    //////TODO запускаем метод распарстивая JSON
                    МетодПарсингJSONФайлаОтСервреравФоне(БуферПолученныйJSON, имяТаблицыОтАндройда_локальноая);/////ЗАПУСК МЕТОДА ПАСРИНГА JSON

                    //поймать ошибку всего классаIOException | MyException e    NumberFormatException
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }


            } else {
                Log.i(this.getClass().getName(), " Сервер пристал пустой файл Запрос по вашем параметрам не т данных в сервере (SQL Server)  БуферПолученныйJSON " + БуферПолученныйJSON.toString());
            }
        }
    }






    /////// TODO МЕТОД ПАСРИНГА ПРИШЕДШЕГО  С СЕРВЕРА ВНУТРИ ASYNSTASK В ФОНЕ
    void МетодПарсингJSONФайлаОтСервреравФоне(StringBuffer БуферПолученныйJSON, String имяТаблицыОтАндройда_локальноая) {
        ///


        try {
            Log.d(this.getClass().getName()," БуферПолученныйJSON " +БуферПолученныйJSON.toString());
            /////ПАРСИНГ JSON ПРИШЁЛ С СЕРВЕРА SQL SERVER
            final String[] JSON_ИмяСтолбца = {""};
            final String[] JSON_ИмяСтолбцаПосик = {""};
            final String[] JSON_ИмяСодержимое = {""};



            ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных

            //////
            //////
            ////TODO ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON
            JSONObject JSON_ПерваяЧасть = new JSONObject(БуферПолученныйJSON.toString());/////ВАЖНО ПОЛУЧЕНИЕ JSON ОБЬЕКТОВ ИЗ БУФЕРА , ЧТОБЫ ДАЛЛЕ РАЗНЕСТИ ЕГО ПО СТРОЧКАМ
            ////TODO ДВИЖОК ПАРСИНГ JSON
            JSONArray JSON_ВтораяЧасть = JSON_ПерваяЧасть.names();////КОЛИЧЕСТВВОсТРОЧЕК В JSON
            //////todoОбнуялем
            ///TODO
            boolean СработалПоворот=false;
            ///////TODO ОПРЕДЕЛЯЕМ ОБЩЕЕ КОЛИЧЕСТВО JSON ВСЕГО МЕТОД
            ///TODO симофор устанавлием


            ///TODO SLEEP

            ReentrantLock reentrantLock=new ReentrantLock();
            ////

            ///

            АдаптерПриОбновленияДанныхсСервера=new ContentValues();
            АдаптерДляВставкиДанныхсСервер=new ContentValues();

            HashMap<String,Integer> ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек=new HashMap<>();



            //// todo парсинг данных которы е пришли с сервера JSON ОБРАБОТКАТ СТРОК
            for (Iterator<String> iterator = JSON_ПерваяЧасть.keys(); iterator.hasNext(); ) {
                try {

                    //TODO ЗАСЫПАЕТ ЦИКЛ ВАЖНО ДЛЯ ОТОБРАЖЕНИЯ КОЛИЧЕСТВРОСТРОК ПРИ РАСПАРСИВАНИИ JSON ПЕРВЫЙ  ---ПОЛУЧЕНИЕ ДАННЫХ
                 /*   try {
                        TimeUnit.MILLISECONDS.sleep(0);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }*/
//     .tryLock(5, TimeUnit.MILLISECONDS);



                    ////
                    reentrantLock.lock();
//////////


                    String UUIDПолученныйИзПришедшегоJSON =null ;
                    String IDИзПришедшегоJSON = null;



                    /// ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ


                    ///////  ----- TODO НЕПОСРЕДСТВЕННО САМ JSON
                    String JSON_ТретьяЧасть = null;

                    ////TODO СДВИГАЕМ ИТЕРАТОР ПРИ СИНХРОНИЗАЦИИИ НЕ СНАЧАЛА

                    ///TODO без сдвига
                    JSON_ТретьяЧасть = iterator.next();
                    /////
                    Log.d(this.getClass().getName(), " Текущая строка json которй пришел сервера " + iterator.toString() + " JSON_ТретьяЧасть " + JSON_ТретьяЧасть);

////todo передаем количество операций для визуализации обновлениея  вставки

                    ///

                    Log.d(this.getClass().getName(), " JSON_ТретьяЧасть  " + JSON_ТретьяЧасть + " JSON_ТретьяЧасть   " + JSON_ТретьяЧасть.length());
                    /////
                    JSONObject JSON_ЧетвертаяЧасть = null;

                    JSON_ЧетвертаяЧасть = JSON_ПерваяЧасть.getJSONObject(JSON_ТретьяЧасть);

                    Log.d(this.getClass().getName(), " JSON_ЧетвертаяЧасть " + JSON_ЧетвертаяЧасть.toString() + " JSON_ЧетвертаяЧасть " + JSON_ЧетвертаяЧасть.length());
                    //////
                    JSONObject JSON_ПятаяЧасть = null;



                    JSON_ПятаяЧасть = new JSONObject(String.valueOf(JSON_ЧетвертаяЧасть));

                    Log.d(this.getClass().getName(), " ОбьектыJSONvalue" + JSON_ПятаяЧасть.toString());


                    ////// TODO JSON ОБРАБОТКА СТОЛБЦОВ
                    for (int ИндексПеремещенияПоСтрокеJSON = 0; ИндексПеремещенияПоСтрокеJSON < JSON_ЧетвертаяЧасть.length(); ИндексПеремещенияПоСтрокеJSON++) {




                        //TODO сомо имя json
                        JSON_ИмяСтолбца[0] = ((String) JSON_ПятаяЧасть.names().get(ИндексПеремещенияПоСтрокеJSON));


                        System.out.println("  JSON_ИмяСтолбца[0]  " +JSON_ИмяСтолбца[0] );





                        ////TODO само значение json

                        JSON_ИмяСодержимое[0] = String.valueOf(JSON_ПятаяЧасть.get(String.valueOf(JSON_ИмяСтолбца[0])));








/////TODO если нет UUID
                        if (UUIDПолученныйИзПришедшегоJSON==null) {
                            for (int ИндексИмяИщемUUID = 0; ИндексИмяИщемUUID < JSON_ЧетвертаяЧасть.length(); ИндексИмяИщемUUID++) {
                                JSON_ИмяСтолбцаПосик [0] = ((String) JSON_ПятаяЧасть.names().get(ИндексИмяИщемUUID));

                                Log.d(this.getClass().getName(), "  JSON_ИмяСтолбца[0] " + JSON_ИмяСтолбцаПосик [0] );

                                if (JSON_ИмяСтолбцаПосик [0].equals("uuid")){

                                    UUIDПолученныйИзПришедшегоJSON =   String.valueOf(JSON_ПятаяЧасть.get("uuid"));
                                    ///////////

                                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON[0] " + UUIDПолученныйИзПришедшегоJSON);
                                    break;
                                    /////TODO когда нет uuid используетм ID
                                }
                            }
                        }

/////TODO если  ID

                        if (IDИзПришедшегоJSON==null) {
                            for (int ИндексИмяИщемUUID = 0; ИндексИмяИщемUUID < JSON_ЧетвертаяЧасть.length(); ИндексИмяИщемUUID++) {
                                JSON_ИмяСтолбцаПосик [0] = ((String) JSON_ПятаяЧасть.names().get(ИндексИмяИщемUUID));

                                Log.d(this.getClass().getName(), "  JSON_ИмяСтолбца[0] " + JSON_ИмяСтолбцаПосик [0] );

                                if (JSON_ИмяСтолбца[0].equals("id")) {

                                    IDИзПришедшегоJSON = String.valueOf(JSON_ПятаяЧасть.get("id"));
                                    ///
                                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON[0] " + IDИзПришедшегоJSON);
                                    break;
                                }
                            }
                        }


                        Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца[0] + " JSON_ИмяСодержимое  " + JSON_ИмяСодержимое[0] + " IDИзПришедшегоJSON "
                                + IDИзПришедшегоJSON + "  JSON_ИмяСодержимое.length() " + JSON_ИмяСодержимое[0].length());





                        // TODO: 27.05.2021 механиз удаление из таблицы Уведомлений Лишних Значений


                        if (имяТаблицыОтАндройда_локальноая.equalsIgnoreCase("notification") && JSON_ИмяСтолбцаПосик [0].equalsIgnoreCase("id")) {

                            // TODO: 27.05.2021  заполянем ХЭШ для только дтаблица Уведомления
                            ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек.put(JSON_ИмяСтолбцаПосик [0],Integer.parseInt(IDИзПришедшегоJSON));

                            ///////
                            Log.d(this.getClass().getName(), "   ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек "+
                                    ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек.values());
                        }























                        ////// todo ЗАПОЛЯНЕМ КОНТЕРЙНЕР ЕСЛИ И СТОЛБИК И СОДЕРЖИМОЕ СТОЛБЬИКА ПРИСУТВУЕТ
                        if (JSON_ИмяСтолбца[0].length() > 0) {///ЕСЛИ НЕ ПУСТОЕ ИМЯ И СОДЕРЖИМОЕ JSON


                            /////todo метод заполенения получым json файлом В АДАПТЕР ВСТАВКИ И/ИЛИ ОБНОВЛЕНИЕ ПРОСТО ЗАПОЛЯНЕМ
                            МетодЗаполнениеПолученымJSONсСервераВКонтейнервФоне(UUIDПолученныйИзПришедшегоJSON, JSON_ИмяСтолбца[0], JSON_ИмяСодержимое[0], имяТаблицыОтАндройда_локальноая,
                                    IDИзПришедшегоJSON);//////МЕТОД ЗАПОЛЕНЕНИЯ JSON ПОЛЕЙ ПОЛУЧЕННЫЙ С СЕРВЕРА В КОНТЕЙНЕР  ДЛЯ ОПРЕДЕЛЕНИЯ ВСТАВЛЯИ ИЛИ ОБНОВЛЯТЬ

                        }
                        Log.d(this.getClass().getName(), " JSON_ИмяСтолбца[0].toString() " + JSON_ИмяСтолбца[0]);

                    }///todo end for СТОЛБЦЫ


                    Log.d(this.getClass().getName(), "JSON_ИмяСтолбца[0].toString() "+ JSON_ИмяСтолбца[0]);




                    ////---СТРОГО КАК ТОЛЬКО МЫ ЗАПОЛНИЛИ В КОНТЕНЕР ДАННЫХ СТРОЧКУ JSON ИЗ СЕРВЕРА в фоне

                    executorService=Executors.newSingleThreadExecutor();
                    ///
                    String finalUUIDПолученныйИзПришедшегоJSON = UUIDПолученныйИзПришедшегоJSON;
                    String finalIDИзПришедшегоJSON = IDИзПришедшегоJSON;
                    ///
                    Future future= executorService.submit(new Runnable() {
                        @Override
                        public void run() {



                            //////// TODO МЕТОД ПЕРОСРЕДСТВЕНОЙ ЗАПИСЬ В  БАЗУ АНДРОЙДА ДАННЫМИС SQL SERVER метод конкретной записо заполеного контерйнра json в  базуу

                            МетодаЗаписиВБазуКонтейнераобновлениеИлиВставкиJSONвФоне(имяТаблицыОтАндройда_локальноая,
                                    finalUUIDПолученныйИзПришедшегоJSON, finalIDИзПришедшегоJSON);///////после того как


                            /////TODO вставка строк меньше ста



                        }
                    });
                    //
                    future.get();
                    if(future.isDone()) {
                        executorService.shutdown();
                        Log.d(this.getClass().getName(), " Конец  имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);
                        //
                        future.cancel(false);

                    }




/////TODO попытка заполнить Все Строки





/////TODO увеличиваем строку на 1

                    Log.d(this.getClass().getName(), " Конец  Записали в Базу синхронизация " );
                    /////

                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    ////// начало запись в файл
                }finally {
                    reentrantLock.unlock();
                }
            }/////todo end for




            // TODO: 27.05.20 после обоаьртки ьалицы улалояем лишине цвдомления      после for





         new CONTROLLER_synchronized(КонтекстСинхроДляКонтроллераВФоне).   МетодВнутриСинхронизацииКоторыйУдаляетЗначенияЛишниеИзТаблицыУведомления(JSON_ИмяСтолбцаПосик [0],
                    "notification",
                    ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек);






            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }


    //////МЕТОД ТОЛЬКО ЗАПОЛЕНИЕЯ КОНТЕЙНЕРА ВСТАВКИ И ОБНОВЛЕНИЕ ДАННЫХ КОТОРЫЕ ПРИШЛИ С СЕРВЕРА
    void МетодЗаполнениеПолученымJSONсСервераВКонтейнервФоне(String UUIDПолученныйИзПришедшегоJSON, String JSON_ИмяСтолбца, String JSON_ИмяСодержимое
            , String имяТаблицыОтАндройда_локальноая, String IDИзПришедшегоJSON) { /////МЕТОД ЗАПОЛЕНЕИЯ КОНТЕЙНЕРОМ JSON ПОЛЯМИы
        //

        //////TODO анализиует СТОЛЮИК UUID


        try {





            ///TODO ДАННЫЙ КОД ОБРЕЗАЮТ ДАТУ А ТРИ НАЗАД ЕСЛИ ДЛИНА ДАТЫ РОВНЯЕТЬСЯ 22 СИМВОЛА
            if (JSON_ИмяСтолбца.equalsIgnoreCase("date_update")) {
                //Todo цикл обработаки лишних символом даты date_update
                while (true) {
                    if (JSON_ИмяСодержимое.length() > 19) {
                        ////TODO УДАЛЯЕМ СИЩГИЕ СИМВОЛЫ В  ДАТЕ
                        JSON_ИмяСодержимое = JSON_ИмяСодержимое.substring(0, JSON_ИмяСодержимое.length() - 1);

                    } else {
                        // code block to be executed
                        Log.d(this.getClass().getName(), " JSON_ИмяСодержимое " + JSON_ИмяСодержимое + " JSON_ИмяСодержимое.length()  " + JSON_ИмяСодержимое.length());
                        break;
                    }

                }
            }

            ////ДЛЯ НАЧАЛО ОЦЕНИВАЕМ ЕСЛИ UUID В ЭТОЙ ТЕКУЩЕЙ ЗАПИСИ ,, ЗАПОМИНАЕМ ЕГО И ДАЛЕЕ ОТ РЕЗУЛЬТАТО В НАЧИНАЕМ ЛИБО ВСТАКУ ЛИБО ОБНОВЛЕНИЕ АДАЕЫХ
            ////////ПРОВЕРЯЕМ UUID ЕСЛИ Т ЕКУЩЕЕ ПОЛЕ UUID
            Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца);


            String ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде = null;

            String ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде = null;


            //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ      //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ        //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ

            //////TODO вторым флагом запрещем при первом запуске заниматься обновдениям  только вставка  при синхронизации ==false значить обнолвение включено ,,,,, ЗНАЧАЕТ ЧТО ИДЕТ ТОЛЬКО ВСТАВКА ДАННЫХ TRUE
            // final boolean ДанныйФлагРазрешаетОбновлеениеТОлькоПослеПерсвойСинхронизации = PUBLIC_CONTENT.ФлагПриПервомЗапускеОграничитьОперациюТолькоВставка;




//final boolean СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации=PUBLIC_CONTENT.ФлагРазрешаетОбновлениеПриСинхронизации;
            //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID


            //////
            // TODO: 16.03.2021 выбираем как обнолять через uuid and id
            if (UUIDПолученныйИзПришедшегоJSON!=null) {
                //////
                if (  UUIDПолученныйИзПришедшегоJSON.length()    > 0 ) {
                    /////TODO запрет на обновление если Первая Синхронизация

                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON " + UUIDПолученныйИзПришедшегоJSON.length()+"JSON_ИмяСтолбца " +JSON_ИмяСтолбца );

                    //TODO UUID
                    МетодАнализаUUIDСинхрониазциявФоне(UUIDПолученныйИзПришедшегоJSON, JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая, IDИзПришедшегоJSON);



                    //////TODO анализиует СТОЛЮИК UUID
                } else   {


                    if (  IDИзПришедшегоJSON.length() > 0) {
                        ///
                        Log.d(this.getClass().getName(), "JSON_ИмяСтолбца " +JSON_ИмяСтолбца+ " IDИзПришедшегоJSON " +IDИзПришедшегоJSON);
                        ////TODO ID
                        МетодАнализаIDСинхрониазциивФоне(UUIDПолученныйИзПришедшегоJSON, JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая, IDИзПришедшегоJSON);
                    }


                }





                // TODO: 16.03.2021 когда нет UUID
            }else{

                if (  IDИзПришедшегоJSON.length() > 0) {
                    ///
                    Log.d(this.getClass().getName(), "JSON_ИмяСтолбца " +JSON_ИмяСтолбца+ " IDИзПришедшегоJSON " +IDИзПришедшегоJSON);
                    ////TODO ID
                    МетодАнализаIDСинхрониазциивФоне(UUIDПолученныйИзПришедшегоJSON, JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая, IDИзПришедшегоJSON);
                }

            }

            // Log.d(this.getClass().getName(), " СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации " + СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации);





            //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ


            ////TODO САМО ДЕЛЕНИЕ ДАННЫХ С СЕРВЕРА НА ВСТАВКУ ДАННЫХ ИЛИ ЕЕ ОБНОВЛЕНИЯ ЗАВИСМОСТИ ЕСЛИ  UUID ИЛИ ID



            ////
            /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }





    //////////////TODO метод непосредвственой запись в базу данных json КОТОРЫЙ ПРИШЁЛ С СЕРВЕРА
    void МетодаЗаписиВБазуКонтейнераобновлениеИлиВставкиJSONвФоне(String имяТаблицыОтАндройда_локальноая, String UUIDПолученныйИзПришедшегоJSON,String  IDИзПришедшегоJSON) {////запись полученого json   от сервера через контейнер

        Log.d(this.getClass().getName()," UUIDПолученныйИзПришедшегоJSON  " +UUIDПолученныйИзПришедшегоJSON);

        try {

            int КоличествоJSON=PUBLIC_CONTENT.СколькоСтрочекJSON;
            //////////todo ВСТАВКА JSON НА КЛИЕНТА ДАННЫЕ С СЕРВЕРА
            Log.i(this.getClass().getName(), "  АдаптерДляВставкиПриВставкиДанныхсСервера      "+  АдаптерДляВставкиДанныхсСервер.size());
            if (АдаптерДляВставкиДанныхсСервер.size()>0) {///если в контенер заполнилься то начинаем вставку
                ////////ВЫЗЫВАЕМ ВСТАВКУ ДАННЫХ
                long РезультатВставкиЧерезКонтрейнер=0;

                РезультатВставкиЧерезКонтрейнер = ВставкаДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая,  АдаптерДляВставкиДанныхсСервер,имяТаблицыОтАндройда_локальноая,
                        "",true,
                        КоличествоJSON,true, КонтекстСинхроДляКонтроллераВФоне);

                /// после вствки в базу обнуляем контейнер данные от сервера
                if (РезультатВставкиЧерезКонтрейнер>0) {
                    //////
                    //// todo ПРИ УСПЕШНОЙ ВСТАВКИ ДАННЫХ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                    PUBLIC_CONTENT.КоличествоУспешныхВставки++;
                    /////
                    //// TODO ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице++;
                    /////TODO ВАЖНО ПОСЛЕ УСПЕШНОЙ ОБРАБОТКИ ПРИСВАИВАЕМ ЗНАЧЕНИЕ присваиваем наверх факсическое значение идущего цикла После Успешного прохода ТАБЛИЦЫ одной ИЗ
                    Log.d(this.getClass().getName()," КоличествоУспешныхВставки JSON " +PUBLIC_CONTENT.КоличествоУспешныхВставки);
                    ///TODO переводим ввобщим в универсальный индификатор



                    ///



                }
                ///
                //  АдаптерДляВставкиДанныхсСерверБуфер.clear();

                АдаптерДляВставкиДанныхсСервер.clear();


                //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON
                ///


            }
            //////////todo ВСТАВКА JSON НА КЛИЕНТА ДАННЫЕ С СЕРВЕРА










            ////////// TODO ОБНОВЛЕНИЕ JSON НА КЛИЕНТА
            Log.i(this.getClass().getName(), "  АдаптерДляОбновленияПриВставкиДанныхсСервера "+  АдаптерПриОбновленияДанныхсСервера.size());
            if ( АдаптерПриОбновленияДанныхсСервера.size()>0) {///если в контенер заполнилься то начинаем обновление
                ////////ВЫЗЫВАЕМ ОБНОВЛЕНИЕ
                long РезультатОбновлениеЧерезКонтрейнер=0;

                /////TODO делим обновление на два вида если есть UUID ИЛИ НЕТ А ЕСТЬ ID


                ///TODO когда есть только UUID
                if (UUIDПолученныйИзПришедшегоJSON!=null){

                    if(UUIDПолученныйИзПришедшегоJSON.length()>0){

                        //////todo UUID UPDATE
                        РезультатОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая, АдаптерПриОбновленияДанныхсСервера,
                                UUIDПолученныйИзПришедшегоJSON,
                                КоличествоJSON,true, КонтекстСинхроДляКонтроллераВФоне,
                                "uuid");



                        ///TODO когда есть только ID

                    } else if (IDИзПришедшегоJSON!=null){
                        if (IDИзПришедшегоJSON.length()>0) {

                            String ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID;

                            if (имяТаблицыОтАндройда_локальноая.equals("tabels") || имяТаблицыОтАндройда_локальноая.equals("fio")){



                                ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID="_id";

                            }else{
                                ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID="id";
                            }


                            //////todo ID UPDATE
                            РезультатОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая, АдаптерПриОбновленияДанныхсСервера,
                                    IDИзПришедшегоJSON,
                                    КоличествоJSON,
                                    true, КонтекстСинхроДляКонтроллераВФоне,ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID);

                        }
                    }
// TODO: 08.04.2021 НЕТ UUID И ОБНОВЛЕМ ПО ID
                } else if (IDИзПришедшегоJSON!=null){
                    if (IDИзПришедшегоJSON.length()>0) {

                        String ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID;

                        if (имяТаблицыОтАндройда_локальноая.equals("tabels") || имяТаблицыОтАндройда_локальноая.equals("fio")){



                            ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID="_id";

                        }else{
                            ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID="id";
                        }


                        //////todo ID UPDATE
                        РезультатОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая, АдаптерПриОбновленияДанныхсСервера,
                                IDИзПришедшегоJSON,
                                КоличествоJSON,
                                true, КонтекстСинхроДляКонтроллераВФоне,ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID);

                    }
                }











                /// после обновление  в базу обнуляем контейнер  данные от сервера
                if (РезультатОбновлениеЧерезКонтрейнер>0) {
//////////////////
                    //// todo ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                    PUBLIC_CONTENT.КоличествоУспешныхОбновлений++;
                    ////
                    //// TODO ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице++;
                    /////TODO ВАЖНО ПОСЛЕ УСПЕШНОЙ ОБРАБОТКИ ПРИСВАИВАЕМ ЗНАЧЕНИЕ присваиваем наверх факсическое значение идущего цикла После Успешного прохода ТАБЛИЦЫ одной ИЗ
                    Log.d(this.getClass().getName()," КоличествоУспешныхОбновлений JSON " +PUBLIC_CONTENT.КоличествоУспешныхОбновлений);
                    ///TODO переводим ввобщим в универсальный индификатор

                    /////TODO ВАЖНО ПОСЛЕ УСПЕШНОЙ ОБРАБОТКИ ПРИСВАИВАЕМ ЗНАЧЕНИЕ присваиваем наверх факсическое значение идущего цикла После Успешного прохода ТАБЛИЦЫ одной ИЗ






                }

                АдаптерПриОбновленияДанныхсСервера.clear();
                ////


                ////TODO вставка
            }


            //////Удаляем из памяти Асинтаск
            if (Курсор_УзнатьЕслиНаАндройдеТакойUUID!=null) {
                Курсор_УзнатьЕслиНаАндройдеТакойUUID.close();
                Курсор_УзнатьЕслиНаАндройдеТакойUUID=null;
            }

            ////
            if (Курсор_УзнатьЕслиНаАндройдеТакойID!=null) {
                Курсор_УзнатьЕслиНаАндройдеТакойID.close();
                Курсор_УзнатьЕслиНаАндройдеТакойID=null;

            }

            ///TODO если что -то открыта закрыть

            /////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }

    }










    ///----------- ТУТ КОД УЖЕ ПОСЫЛАНИЕ ДАННЫХ НА СЕРВЕР МЕТОДУ POST (данные андройда посылаються на сервер)


    /////todo POST МЕТОД КОГДА НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ ВЫШЕ ЧЕМ НА СЕРВРЕР И МЫ  JSON ФАЙЛ ТУДА МЕТОД POST
    void МетодПосылаемДанныеНаСервервФоне(String имяТаблицыОтАндройда_локальноая) {
        ////
        Log.d(this.getClass().getName(), "  имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);
        Cursor КурсорДляОтправкиДанныхНаСервер = null;
        int КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки = 0;
        int КоличествоКолоноквОтправвляемойТаблице = 0;
        try {
            Log.d(this.getClass().getName(), "  МетодПосылаемДанныеНаСервер в фоне ");
            final Cursor[] КурсорДляАнализаДатыПоследнейОтпракиНаСервер = {null};







            КурсорДляАнализаДатыПоследнейОтпракиНаСервер[0] = КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[]{"versionserveraandroid"},
                    "name=?", new String[]
                            {имяТаблицыОтАндройда_локальноая}, null, null, null, null);
            ////////

            //////ОЧИСТКА ПАМЯТИ ОТ ASYNSTASK



            /////////
            if (КурсорДляАнализаДатыПоследнейОтпракиНаСервер[0].getCount() > 0) {///// КУРСОР ПО ПОИСКУ ДАТФ ПОСЛЕДНЕЙ ОТПРАВКИ НА СЕРВЕР
                КурсорДляАнализаДатыПоследнейОтпракиНаСервер[0].moveToFirst();
                ///// todo УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                Log.i(this.getClass().getName(), " КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount() " + КурсорДляАнализаДатыПоследнейОтпракиНаСервер[0].getCount());
                String ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер = null;
                ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер = КурсорДляАнализаДатыПоследнейОтпракиНаСервер[0].getString(0);
                ///TODO ЕСЛИ НЕТ ДАТЫ НЕЧЕГО ОТПРАВЛЯТЬ
                if (ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер != null) {
                    Log.d(this.getClass().getName(), " ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер " + ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер +
                            "  имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);
                    int КоличествоСтрокПолученыеДляОтпарвкиПоДате = КурсорДляАнализаДатыПоследнейОтпракиНаСервер[0].getCount();
                    Log.d(this.getClass().getName(), " ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер   " + ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер);
                    Log.d(this.getClass().getName(), " ДатаВерсииДанныхНаSqlServer.toString() " + ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер
                            + " ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер андройд " + ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер);
                    ///todo
                    ///todo закрываем куроср
                    КурсорДляАнализаДатыПоследнейОтпракиНаСервер[0].close();






                    ////// todo ГЛАВНЫЙ КУРСОР ДЛЯ ОТПРАВКИ ДАННЫХ НА СЕРВЕР
                /* КурсорДляОтправкиДанныхНаСервер =КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,new String[] { "*"}, "date_update >?",
                         new String[] {ДатаВерсииДанныхНаSqlServer}  , null, null, null, null); ///ДатаВерсииДанныхНаSqlServer.toString() / ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер*/
                    if (имяТаблицыОтАндройда_локальноая.equalsIgnoreCase("tabels")) {
                        КурсорДляОтправкиДанныхНаСервер = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая, new String[]{"*"}, " date_update > ? AND fio IS NOT NULL",
                                new String[]{ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер}, null, null, null, null);


                        // TODO: 28.05.2021 все остальные таблицы
                    } else {
                        // TODO: 29.03.2021 все другие таблицы в фоне
                        КурсорДляОтправкиДанныхНаСервер = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая, new String[]{"*"}, " date_update > ? ",
                                new String[]{ДатаВерсияДанныхАндройДляОтправкиДанныхНАсервер}, null, null, null, null);
                    }










                    //////ОЧИСТКА ПАМЯТИ ОТ ASYNSTASK
                    /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                    Log.d(this.getClass().getName(), " КурсорДляОтправкиДанныхНаСервер.getCount() " + КурсорДляОтправкиДанныхНаСервер.getCount());

                    if (КурсорДляОтправкиДанныхНаСервер.getCount() > 0) {/////работаем уже в сгенерированных даннных которые мы отправим на сервер
                        КурсорДляОтправкиДанныхНаСервер.moveToFirst();
                        КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки = КурсорДляОтправкиДанныхНаСервер.getCount();////КОЛИЧЕСТВО СТРОК В АНДРОЙДЕ ДАННЫЕ КОТОРЫЕ НУЖНО ПОСЛЛАТЬ
                        КоличествоКолоноквОтправвляемойТаблице = КурсорДляОтправкиДанныхНаСервер.getColumnCount();/////КОЛИЧЕСТВО СТОЛЮЦОВ НА АНДРОДЕ БАЗЕ КОТОРОЫЕ НУЖНО ОТОСЛАТЬ
                        ////
                        Log.d(this.getClass().getName(), " КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки  " + КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки +
                                "  КоличествоКолоноквОтправвляемойТаблице  " + КоличествоКолоноквОтправвляемойТаблице);
                    }
                }
            }else{

                ///// todo УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                Log.i(this.getClass().getName(), " Нет ДАнных Для Отпрвки на сервреКурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount() " + КурсорДляАнализаДатыПоследнейОтпракиНаСервер[0].getCount());
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        } finally {

            Log.d(this.getClass().getName(), "КурсорДляОтправкиДанныхНаСервер.getCount() " + КурсорДляОтправкиДанныхНаСервер.getCount()
                    + " имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);


            ////TODO провеояем чтобы  JSON ФАЙЛ БЫЛ НЕ ПУСТЫМ ДЛЯ ОТПРПВИК ЕГО НЕ СЕРВЕР
            if (КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки > 0) {

                //////// todo упаковываем в  json ПЕРЕХОДИМ НА СЛЕДУЩИМ МЕТОД для отрправки на сервер метод POST()

                МетодГенеррируемJSONИзНашыхДанныхвФоне(КурсорДляОтправкиДанныхНаСервер, КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки,
                        КоличествоКолоноквОтправвляемойТаблице, имяТаблицыОтАндройда_локальноая);


                ///todo закрываем куроср
                КурсорДляОтправкиДанныхНаСервер.close();
            }
        }
    }


    ////////МЕТОД ГЕНЕРИРОУЕМ JSON ПОЛЯ НА ОСНОВАНИЕ НАШИХ ДАННЫХ ДЛЯ ПОСЛЕДЖУЮЩЕ ОТПРАВКИ
    void МетодГенеррируемJSONИзНашыхДанныхвФоне(Cursor КурсорДляОтправкиДанныхНаСерверОтАндройда, int КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки,
                                                int КоличествоКолоноквОтправвляемойТаблице, String имяТаблицыОтАндройда_локальноая) {
        ///
        Log.d(this.getClass().getName(), " КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки " + КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки);

        int ЕслиUUIDПриЗабросеДанныхНаСервер = 0;
        int ЕслиIDПриЗабросеДанныхНаСервер=0;

        JSONObject ГенерацияJSONполейФинал = new JSONObject();///генериция финального поля дляJSON;  ////ПОЛЯ  ДЛЯ  JSON
        try {
///////метод создание josn из наших данных на отправку
            ////
        String ПерхнееПолеJSONПоследнаяОперация = null;////ПЕРЕРВОДИМ ИЗ INT TO STRING


            Log.d(this.getClass().getName(), " КурсорДляОтправкиДанныхНаСервер.getCount())   " + КурсорДляОтправкиДанныхНаСерверОтАндройда.getCount()+" имяТаблицыОтАндройда_локальноая " +имяТаблицыОтАндройда_локальноая);
            boolean СработалПоворот = false;
            ///// ДО DO WHILE ОБЯЗАТЕЛЬНО
            КурсорДляОтправкиДанныхНаСерверОтАндройда.moveToFirst();
            final int[] КакаяСтрочкаОбработкиТекущаяя = {1};/////ОСТЛЕЖИВАЕМ ТЕКУЩУЮ СТРОЧКУ ОБРАБОТКИ
            ///TODO ЗАПУСКАЕМ  ПуллПамяти
            ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных


            //todo бежим по строчкам json
            do {/////КРУТИТЬ ДАННЫЕ ЧЕРЕЗ ЦИКЛ ОТВЕТЫ ОТ МЕТОДА POST

                /// ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ
                ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных
                /// ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ


                /////////////////
                JSONObject ГенерацияJSONполей = new JSONObject();  ////ПОЛЯ  ДЛЯ  JSON ///ВАЖНО ГЕНЕРАЦИЯ НОВЫХ ОБЬЕКТОВ JSON НУЖНО СТАВИТЬ ВНУТРИ DO WHILE  НО ДО FOR ЦИКЛА МЕЖДУ НИМИ
                //todo бежим по столбцам
                for (int ИндексПоТАблицамДляОтправки = 0; ИндексПоТАблицамДляОтправки < КоличествоКолоноквОтправвляемойТаблице; ИндексПоТАблицамДляОтправки++) {
                    try {

                        //////////TODO ЭКСПЕРЕМЕНТ С JSON
                        //////ПОЛЯ ДЛЯ ВСТВКИ В JSON  ДЛЯ ОТПРАВКИ ЕГО НА СЕРВЕЛТ
                        String КлючJsonСтроки = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnName(ИндексПоТАблицамДляОтправки);


                        //TODO сомо имя json
                        System.out.println(" КлючJsonСтроки  " +КлючJsonСтроки );










                        /////////
                        Object ЗначниеJsonСтроки = КурсорДляОтправкиДанныхНаСерверОтАндройда.getString(ИндексПоТАблицамДляОтправки);

                        Log.d(this.getClass().getName(), " КлючJsonСтроки ::    "
                                + КлючJsonСтроки + "  ЗначниеJsonСтроки " + ЗначниеJsonСтроки);


                        //TODO НАЧИНАЕМ ОБРАБАТЫВАТЬ КОГДА ЗНАЧЕНИЕ ПО СТОЛБИКУ ОТРУСТУЕТ VALUE==BULL  #ПЕРВАЯ ЧАСТЬ
                        Log.d(this.getClass().getName(), " КлючJsonСтроки " + КлючJsonСтроки);
                        if (ЗначниеJsonСтроки == null) {
                  /*      ////todo если пустые значение по столбику имитируем его как текст но и как цифра для столиков fio and uuid
                        Log.d(this.getClass().getName(), " КлючJsonСтроки " +КлючJsonСтроки );
                        if (КлючJsonСтроки.equalsIgnoreCase("fio") || КлючJsonСтроки.equalsIgnoreCase("uuid") || КлючJsonСтроки.equalsIgnoreCase("id")){
                            //ЗначниеJsonСтроки=null;////чтобы небыло ошибки ПРИНУДИТЕЛЬНО В СОДРЕЖИСОА JSON ГЕНЕРИРУЕМОГО ДОБАВЛЯЕМ ПРОБЕЛЫ ЧТОБЫ JSON ПОД ДАНОМУ ПОЛЮ БЫЛ ЗОЗДАН
                            ////////// TODO КОНКРЕТАНАЯ ГЕНЕРАЦИЯ  JSON СТРОКИ
                                    ////разрешаем вставку с NULL
                                    if (КлючJsonСтроки!=null ) {
                                        ///todo генерация самой строки json ниже ключ к нему после for
                                        ГенерацияJSONполей.put(КлючJsonСтроки, ЗначниеJsonСтроки); ////заполение полей JSON
                                        ///
                                        Log.d(this.getClass().getName(), " КлючJsonСтроки  " + КлючJsonСтроки + "  ЗначниеJsonСтроки " +ЗначниеJsonСтроки );
                                        //todo обнуление после вставки
                                        КлючJsonСтроки=null;
                                        ЗначниеJsonСтроки=null;
                                    }
                        }
*/

                            //TODO НАЧИНАЕМ ОБРАБАТЫВАТЬ КОГДА ЗНАЧЕНИЕ ПО СТОЛБИКУ ЕСТЬ , ВСЕ  ХОРОШО И ИМЯ СТОБЛИКА ЕСТЬИ ЕГО ЗНАЧЕНИЕ ТОЖЕ ЕСТЬ #ВТОРАЯ ЧАСТЬ
                            Log.d(this.getClass().getName(), " КлючJsonСтроки " + КлючJsonСтроки);
                        } else if (ЗначниеJsonСтроки != null) {
                            ////////// TODO КОНКРЕТАНАЯ ГЕНЕРАЦИЯ  JSON СТРОКИ
                            if (КлючJsonСтроки != null && ЗначниеJsonСтроки != null) {//ПРОИЗВОДИМ ВСТАВКИ JSON ПОЛЕЙ ТОЛЬКО ЕСЛИ ОНИ НЕ NULL



                                ////TODO в обратную сторону обмена из _id в таблице tabels на id меняем ы фоне

                                if (имяТаблицыОтАндройда_локальноая.equals("tabels")
                                        && КлючJsonСтроки.equals("_id")){
                                    /////////
                                    КлючJsonСтроки="id";
                                    System.out.println("  КлючJsonСтроки  " +КлючJsonСтроки );



                                    //TODO для таблицы fio
                                }else if (имяТаблицыОтАндройда_локальноая.equals("fio")
                                        && КлючJsonСтроки.equals("_id")){
                                    /////////
                                    КлючJsonСтроки="id";
                                    System.out.println("  КлючJsonСтроки  " +КлючJsonСтроки );


                                }
                                //////

                                /////TODO вытаемся отслидить хотябы один заполненый день
                                Log.d(this.getClass().getName(), "КлючJsonСтроки " + "--" + КлючJsonСтроки +  " З начниеJsonСтроки " +ЗначниеJsonСтроки);/////


                                ///todo генерация самой строки json ниже ключ к нему после for//   && ЗначниеJsonСтроки.toString().matches("[1-9]"
                                if (КлючJsonСтроки.matches("[d].*") &&  КлючJsonСтроки.length()<=3) {
                                    ///////
                                    ГенерацияJSONполей.put(КлючJsonСтроки, ЗначниеJsonСтроки); ////заполение полей JSON

                                }else if (ЗначниеJsonСтроки!=null){
                                    ///////
                                    ГенерацияJSONполей.put(КлючJsonСтроки, ЗначниеJsonСтроки); ////заполение полей JSON
                                }




                                ///
                                Log.d(this.getClass().getName(), " КлючJsonСтроки  " + КлючJsonСтроки + "  ЗначниеJsonСтроки " + ЗначниеJsonСтроки);
                                //todo обнуление после вставки
                                КлючJsonСтроки = null;
                                ЗначниеJsonСтроки = null;
                            }
                            ///////////////ДОБАЛВЕНИЕ ВЕПХНЕГО ID ПО ВЕРХ JSON ПОЛЕЙ
                        }


                        //////////TODO  КОНЕЦ ЭКСПЕРЕМЕНТ С JSON
                        ///todo  только uuid
                        ЕслиUUIDПриЗабросеДанныхНаСервер = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("uuid");

                        if (ЕслиUUIDПриЗабросеДанныхНаСервер >= 0) {

                            Log.d(this.getClass().getName(), "ЕслиUUIDИлиIDПриЗабросеДанныхНаСервер " + ЕслиUUIDПриЗабросеДанныхНаСервер);
                            ///////////////ЕСЛИ ID ПОЛЕ ПУСТОЕ ТО ЗАПОЛНЕМЕМ ЕГО ВТОРЫМ ПОЛЕМ
                            int ИндексДвижениеПОПОлямДЛяФОрмированиеID = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("uuid");
                            ////todo
                            ПерхнееПолеJSONПоследнаяОперация = КурсорДляОтправкиДанныхНаСерверОтАндройда.getString(ИндексДвижениеПОПОлямДЛяФОрмированиеID);

                        }




                        ///todo  только id
                        ЕслиIDПриЗабросеДанныхНаСервер = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("id");

                        if (ЕслиIDПриЗабросеДанныхНаСервер >= 0 && ПерхнееПолеJSONПоследнаяОперация==null) {

                            Log.d(this.getClass().getName(), "ЕслиUUIDИлиIDПриЗабросеДанныхНаСервер " + ЕслиIDПриЗабросеДанныхНаСервер);
                            ///////////////ЕСЛИ ID ПОЛЕ ПУСТОЕ ТО ЗАПОЛНЕМЕМ ЕГО ВТОРЫМ ПОЛЕМ
                            int ИндексДвижениеПОПОлямДЛяФОрмированиеID = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("id");
                            ////todo
                            ПерхнееПолеJSONПоследнаяОперация = КурсорДляОтправкиДанныхНаСерверОтАндройда.getString(ИндексДвижениеПОПОлямДЛяФОрмированиеID);

                        }




                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                     new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ////// начало запись в файл
                    }
                }
                ///future



                ////TODO упаковываем jon если хоть какое поле есть   , ЕСЛИ ЕСТЬ ИЛИ ID ИЛИ UUID
                if (ПерхнееПолеJSONПоследнаяОперация!=null   &&  ГенерацияJSONполей!=null  && ГенерацияJSONполей.length()>0 )
                {


                    /// todo МЕЖДУ FOR И WHILE
                    Log.i(this.getClass().getName(), " ПерхнееПолеJSONПоследнаяОперация  :     " + ПерхнееПолеJSONПоследнаяОперация
                            + " ГенерацияJSONполей " + ГенерацияJSONполей.toString());


                    /////////
                    try {
                        //////////todo КОНКРЕТАНАЯ ГЕНЕРАЦИЯ  JSON ВЕРХНЕГО КЛЮЧА
                        ГенерацияJSONполейФинал.put(ПерхнееПолеJSONПоследнаяОперация, ГенерацияJSONполей);////ВСТАВЛЯЕМ ОДИН JSON в ДРУГОЙ JSON ПОЛУЧАЕМ ФИНАЛЬНЫЙ РЕЗУЛЬТАТ JSON"А

                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                     new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ////// начало запись в файл
                    }

                }


                КакаяСтрочкаОбработкиТекущаяя[0]++;////ЛОВИМ ТЕКУУЩЮ СТРОЧКУ ОБРАБОТКИ


                //todo ////


                //todo  ////

                ////// todo  КОНЕЦ МЕЖДУ FOR И WHILE
                ///todo идем по сторчкам  json
            } while (КурсорДляОтправкиДанныхНаСерверОтАндройда.moveToNext());////ДАННЫЕ КРУТИЯТЬСЯ ДО КОНЦА ДАННЫХ И ГЕНЕРИРУЮ JSON
            ///todo



            КурсорДляОтправкиДанныхНаСерверОтАндройда.close();

            /////

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл

        } finally {
            ////// TODO сгенировали JSON файл для отправки его на сервер


            /////////
            if (ГенерацияJSONполейФинал.toString().length() > 3) {

                ///////// TODO ФИНАЛ ПРОСМАТРИВАЕМ СГЕНЕРИРОВАНЫЙ JSON  ФАЙЛ ПОСЛЕ ЦИКЛА DO WHILE СОЗДАИНИЕ НА СТОРОНЕ АНДРОЙДА JSON ПОЛЕЙ
                Log.d(this.getClass().getName(), " ГенерацияJSONполейФинал  "+   ГенерацияJSONполейФинал+ " ГенерацияJSONполейФинал "+ ГенерацияJSONполейФинал.toString() + " ГенерацияJSONполейФинал.length() " + ГенерацияJSONполейФинал.length());
                //TODO ЗАКРЫВАЕМ КУРСОР
                ///todo МЫ СОЗДАЛИ ФАЙЛ JSON  И ПОСЫЛАЕМ ЕГО НА СЕРВЕР
                МетодПосылаетНаСерверСозданныйJSONФайлвФоне(ГенерацияJSONполейФинал, имяТаблицыОтАндройда_локальноая); ////СГЕНЕРИРОВАНЫЙ JSON ФАЙЛ ЕСЛИ БОЛЬШЕ 2 ССИМВОЛОМ В НЕМ ТО ОТПРАВЛЯЕМ
            }
        }

    }









    //////todo МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST
    void МетодПосылаетНаСерверСозданныйJSONФайлвФоне(JSONObject ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда, String имяТаблицыОтАндройда_локальноая) {
        /////
        Log.d(this.getClass().getName(), " ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString() "
                + ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString() +
                " ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString().toCharArray().length  "
                + ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString().toCharArray().length+
                " имяТаблицыОтАндройда_локальноая " +имяТаблицыОтАндройда_локальноая);




        String ДанныеПришёлВОтветОтМетодаPOST = new String();
        ///

        StringBuffer БуферОтправкаДанных=new StringBuffer();
        try {
            Log.d(this.getClass().getName(), "  МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST ");

            // TODO: 15.06.2021 проверяем если таблица табель то еси в нутри потока отпралеемого хоть один день d1,d2,d3 защита от пустого траыфика\





            if (имяТаблицыОтАндройда_локальноая.equalsIgnoreCase("tabels")) {

                boolean РезультатАнализа =   new MODEL_synchronized(КонтекстСинхроДляКонтроллераВФоне).
                        МетодКоторыйВычисляетЕслиДНИвПотоке (имяТаблицыОтАндройда_локальноая ,ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда );


                if (РезультатАнализа==true) {
                    ////
                    //////todo МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST
                    БуферОтправкаДанных = УниверсальныйБуферОтправкиДанныхНаСервера(ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда,
                            PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID, имяТаблицыОтАндройда_локальноая,
                            "Получение JSON файла от Андройда"); ///БУФЕР ОТПРАВКИ ДАННЫХ НА СЕРВЕР

                    Log.d(this.getClass().getName(), "БуферОтправкаДанных.toString() "+БуферОтправкаДанных.toString());
                }


                // TODO: 15.06.2021 ве сотадльные таблицы кроме табелей
            }else{


                //////todo МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST
                БуферОтправкаДанных = УниверсальныйБуферОтправкиДанныхНаСервера(ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда,
                        PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID, имяТаблицыОтАндройда_локальноая,
                        "Получение JSON файла от Андройда"); ///БУФЕР ОТПРАВКИ ДАННЫХ НА СЕРВЕР

                Log.d(this.getClass().getName(), "БуферОтправкаДанных.toString() "+БуферОтправкаДанных.toString());

            }





            ////TODO  ОТВЕТ ОТ СЕРВЕРА ПОСЛЕ ОТПРАВКИ ДАННЫХ НА СЕРВЕР
            if (БуферОтправкаДанных!=null && БуферОтправкаДанных.length()>0) {
                ///
                Log.d(this.getClass().getName(), "  БуферОтправкаДанных.toString()  " + БуферОтправкаДанных.toString());
                do {
                    ДанныеПришёлВОтветОтМетодаPOST = БуферОтправкаДанных.toString();

                    Log.d(this.getClass().getName(), "  ДанныеПришёлВОтветОтМетодаPOST  " + ДанныеПришёлВОтветОтМетодаPOST);

                } while (ДанныеПришёлВОтветОтМетодаPOST == null);/////конец for # количество респонсев


                ////TODO ответ от сервера РЕЗУЛЬТАТ
                Log.d(this.getClass().getName(), "Успешный Ответ от сервера ДанныеПришёлВОтветОтМетодаPOST в фоне " + ДанныеПришёлВОтветОтМетодаPOST);
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА


                Log.d(this.getClass().getName(), " Данных нет c сервера  БуферОтправкаДанных.length() в фоне " +БуферОтправкаДанных.length());
            }





        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        } finally {
            ////TODO ОТВЕТ ОТ СЕРВЕРА
            Log.d(this.getClass().getName(), " ДанныеПришёлВОтветОтМетодаPOST " + ДанныеПришёлВОтветОтМетодаPOST);
            if (ДанныеПришёлВОтветОтМетодаPOST.length() > 0) {
                /////// данные код анализирует успешные и/ил обновление данных на серврер кторые ему присла пользователь
                МетодАнализаОтветаОтСервераУспешныеВставкиИлиОбновлениевФоне(ДанныеПришёлВОтветОтМетодаPOST, имяТаблицыОтАндройда_локальноая);

            }
        }
    }
















    ///TODO ОТТВЕТ ОТ СЕРВЕРАР ОТ МЕТОДА POST() С РЕЗУЛЬТАТАМИ ВСТАВКИ И ЛИ ОБНОВЛЕНЕИ ДАННЫХ



    /////// данные код анализирует успешные и/ил обновление данных на серврер кторые ему присла пользователь
    void МетодАнализаОтветаОтСервераУспешныеВставкиИлиОбновлениевФоне(String ДанныеПришёлВОтветОтМетодаPOST, String имяТаблицыОтАндройда_локальноая) {
        //////
        Log.d(this.getClass().getName(), "  ДанныеПришёлВОтветОтМетодаPOST " + ДанныеПришёлВОтветОтМетодаPOST);

        StringBuffer ОтветОтСервераДляВставки = new StringBuffer();
        try {
            Log.d(this.getClass().getName(), " ДанныеПришёлВОтветОтМетодаPOST             " + ДанныеПришёлВОтветОтМетодаPOST);
/////// данные код анализирует успешные и/ил обновление данных на серврер кторые ему присла пользователь

            ////todo обновление ответной от сервера
            int УспешноеОбновлениеНаСерверe = 0;
            int УспешноеВставкаНаСервере = 0;
            String ВытащилиUUIDИзPOST = "";
            //TODO ОБНОВЛНИЕ
            int УспешныеЛиОтветыОтСервераИлиНет = ДанныеПришёлВОтветОтМетодаPOST.indexOf("::");///TODO если в теле ответа от сервера POSt вообще ::
            if (УспешныеЛиОтветыОтСервераИлиНет > 0) {
                ///////
                for (String ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера : ДанныеПришёлВОтветОтМетодаPOST.split("::")) {
                    /////
                    if (УспешноеОбновлениеНаСерверe == 0) {
                        УспешноеОбновлениеНаСерверe = ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера.indexOf("Обновление");
                    }
                    if (УспешноеВставкаНаСервере == 0) {
                        УспешноеВставкаНаСервере = ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера.indexOf("Вставка");
                    }
                    //////////
                    for (String ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений : ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера.split(" ")) {
                        Log.d(this.getClass().getName(), "  ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений " + ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений);
                        boolean РезультатЯвляетьсяЦифройВесьТекст = МетодОпределениеВселиЦифрыВстроке(ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений);
                        Log.d(this.getClass().getName(), " РезультатЯвляетьсяЦифройВесьТекст            " + РезультатЯвляетьсяЦифройВесьТекст);
                        if (РезультатЯвляетьсяЦифройВесьТекст == true) {
                            ВытащилиUUIDИзPOST = ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений;
                            ////
                            long РезультатПослеОбновлениеЧерезКонтрейнер = 0;
                            РезультатПослеОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерВозвращениеРезультатаОтСервераУниверсальная(имяТаблицыОтАндройда_локальноая,
                                    Long.parseLong(ВытащилиUUIDИзPOST),
                                    ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET);
                            /// после обновление  в базу обнуляем контейнер  данные от сервера


/////TODO РЕЗУЛЬТАТА ВСТАВКИ ОТВЕТА ОТ СЕРВРЕ НА КЛИНЕТ ПРИ УСПЕШНОЙ ОБНОВЛЕНИИ ИЛИ ВСТАВКЕ
                            if (РезультатПослеОбновлениеЧерезКонтрейнер > 0) {
                                //todo обявлем успешное встаку
                                if (УспешноеОбновлениеНаСерверe > 0) {
                                    PUBLIC_CONTENT.КоличествоУспешныхОбновлений++;
                                    ////todo после успешной операции обнуяем
                                    //// TODO ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице++;
                                    ///////
                                    УспешноеОбновлениеНаСерверe = 0;

                                    ////TODOECGTI
                                } else if (УспешноеВставкаНаСервере > 0) {
                                    PUBLIC_CONTENT.КоличествоУспешныхВставки++;
                                    //////
                                    //// TODO ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице++;
                                    ////todo после успешной операции обнуяем
                                    УспешноеВставкаНаСервере = 0;
                                }
                                ////TODO метод POST ответ от сервера
                                //todo обявлем успешное обнолвнение
                                Log.d(this.getClass().getName(), " КоличествоУспешныхВставки +КоличествоУспешныхОбновлений МЕТОД POST() ОТПРАВИЛИ НА СЕВЕР "
                                        + PUBLIC_CONTENT.КоличествоУспешныхВставки + " КоличествоУспешныхОбновлений " + PUBLIC_CONTENT.КоличествоУспешныхОбновлений);
                            }
                        }
                    }
                    ////// todo Удаляем из памяти Асинтаск

                }
            }


            //////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }


    ///todo являеться ли весь текст числом
    boolean МетодОпределениеВселиЦифрыВстроке(String ВселиЦифрыВтексе) {
        boolean Результат = false;
        try {
            Long.parseLong(ВселиЦифрыВтексе);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }

    }
    ///TODO подсчет часов

    protected int МетодПосчётаЧасовПоСотруднику(Cursor курсор_ЗагружаемТабеляСозданный) {
        int СуммаЧасов = 0;
        if (курсор_ЗагружаемТабеляСозданный.getCount() > 0) {
            курсор_ЗагружаемТабеляСозданный.moveToFirst();
        }
        do {

            for (int ИндексДляИзмененияДней = 1; ИндексДляИзмененияДней < 32; ИндексДляИзмененияДней++) {

                int ИндексЧассыСотрудника = курсор_ЗагружаемТабеляСозданный.getColumnIndex("d" + ИндексДляИзмененияДней);

                int ЧассыСотрудника = курсор_ЗагружаемТабеляСозданный.getInt(ИндексЧассыСотрудника);

                СуммаЧасов = СуммаЧасов + ЧассыСотрудника;

                Log.d(this.getClass().getName(), "    СуммаЧасов " + СуммаЧасов);

            }///TODO END FOR  ПО СТОЛБЦАМ БЕЖИМ

        } while (курсор_ЗагружаемТабеляСозданный.moveToNext());
        ////TODO ПРИСВАИВАЕМ ПОЛУЧЕННЫЕ ЧАСЫ ИЗ БАЗЫ УЖЕ ПЕРЕДЕМ ЕЕ НА АКТИВТИ
        ////todo и ставим курсор на место на первое
        курсор_ЗагружаемТабеляСозданный.moveToFirst();
        return СуммаЧасов;
    }









    ///todo метод подсчёта сотрудниколв их ЧАСЫ
    String МетодПосчётаЧасовСотрудниковВТабеле(Context КонтекстДляЧасов, long UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников ,int месяцДляПермещенияПоТабелю,int годДляПермещенияПоТабелю) {
        ///////

        String ОбщееКоличествоЛюдейВТабелеТекущемВнутри = null;



        try {
            Cursor Курсор_ЗагружаемТабеляДляПодсчетаЧасов = new MODEL_synchronized(КонтекстДляЧасов).
                    МетодЗагружетУжеготовыеТабеля(КонтекстДляЧасов, UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников,месяцДляПермещенияПоТабелю,годДляПермещенияПоТабелю);



            //TODO цикл ПЕРЕБОРКИ ДАННЫХ
            ОбщееКоличествоЛюдейВТабелеТекущемВнутри = String.valueOf(new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(КонтекстДляЧасов).
                    МетодПосчётаЧасовПоСотруднику(Курсор_ЗагружаемТабеляДляПодсчетаЧасов));

            Log.d(this.getClass().getName(), "  ОбщееКоличествоЛюдейВТабелеТекущемВнутри " + ОбщееКоличествоЛюдейВТабелеТекущемВнутри);

            Курсор_ЗагружаемТабеляДляПодсчетаЧасов.close();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName()
                    + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

        return ОбщееКоличествоЛюдейВТабелеТекущемВнутри;
    }
    //////ТУТ БУДЕТ ЗАПИСЫВАТЬСЯ УСПЕШНОЕ ОБНЛВДЕНИ И ВСТАВКИ ДАННЫХ НА СЕРВЕРЕ ДЛЯ КЛИЕНТА












    /////TODO ЛОКАЛЬНАЯ ОБНОВЛЕНИЕ ВНУТРИ ТАБЕЛЯ

    Long МетодЛокальноеОбновлениеВТабеле(ContentValues КонтейнерЗаполненияДаннымиПриЛокальномОбновлении, String ПолучениеЗначениеСтолбикUUID,
                                         long[] результатОбновлениеЧерезКонтрейнер,
                                         long[] результат_ИзмененияВерсииДанныхНаАндройде, Context КонтексДляЛокальногоОбновления) throws InterruptedException, ExecutionException {
        //////
        CountDownLatch countDownLatchДляЛольногоОбновлениеВТабеле=new CountDownLatch(1);

Future<Long> futureЛокальноеОбновлениеТАбеля=Executors.newSingleThreadExecutor().submit(new Callable<Long>() {
    @Override
    public Long call() throws Exception {



                try {
                    ///////TODO САМ ВЫЗОВ МЕТОДА ОБНОВЛЕНИЕ ЛОКАЛЬНОГО обновление uuid
                    результатОбновлениеЧерезКонтрейнер[0] = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(КонтексДляЛокальногоОбновления).
                            ЛокальногоОбновлениеДанныхЧерезКонтейнерУниверсальная("tabels",
                                    КонтейнерЗаполненияДаннымиПриЛокальномОбновлении,
                                    ПолучениеЗначениеСтолбикUUID, "uuid");


                    if (  результатОбновлениеЧерезКонтрейнер[0]>0) {
                        /// TODO После Успешной Операциии  ЛОКАЛЬНОГО ОБНОВЛЕНИЯ записать в табблицу версии данных на клиенте ИЗМЕНЯЕМ ВЕРСИЮ ДАННЫХ
                        результат_ИзмененияВерсииДанныхНаАндройде[0] = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(КонтексДляЛокальногоОбновления).
                                МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных("tabels", new Date());
                        /////ПОСЛЕ УСПЕШНОЙ ОБНОВЛЕНИЯ ЗАПИСЫВАЕМ В ТАБЛИЦУ ВЕРСИЙ ДАННЫХ  ТИПА ТРИГЕРА
                    }


                    /////todo третье действие подсичтываем общее количество часов в табеле
                    ///TODO метод загружет уже готовые табеля на АКТИВТИ
                    ///



                    Log.d(this.getClass().getName(), "результат_ИзмененияВерсииДанныхНаАндройде[0]" +  результат_ИзмененияВерсииДанныхНаАндройде[0]+
                            "  результатОбновлениеЧерезКонтрейнер[0] " +  результатОбновлениеЧерезКонтрейнер[0] );



                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName()
                            + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

        //////////
        countDownLatchДляЛольногоОбновлениеВТабеле.countDown();
                /////
        return результат_ИзмененияВерсииДанныхНаАндройде[0];
    }
});


        /////
        countDownLatchДляЛольногоОбновлениеВТабеле.await();

return  (Long) futureЛокальноеОбновлениеТАбеля.get();



    }
















    //TODO Метод ПОДЧСЧЕТА ЧАСОВ ПО ВСЕМ ТАБЕЛЯМ СРАЗУ
    String МетодДосчётаЧасовПоВсемТабелям(long finalПолученныйUUID, Context КонтекстДЛляПодсчетаЧасовПоВсемТабелям,

                                          int месяцДляПермещенияПоТабелю,int годДляПермещенияПоТабелю) {

         /* return (String) new AsyncTaskLoader(КонтекстДЛляПодсчетаЧасовПоВсемТабелям) {
              @Override
              public Object loadInBackground() {*/
        String ПолученыеСуммаЧасовСотрудникаВнутри = null;
        try {
            //TODO вытастиваем непостредственный табель для которго и нужно посчитать часы
            Cursor Курсор_ЗагружаемТабеляДляПодсчетаЧасовПовсемТАбелям = new MODEL_synchronized(КонтекстДЛляПодсчетаЧасовПоВсемТабелям).
                    МетодЗагружетУжеготовыеТабеля(КонтекстДЛляПодсчетаЧасовПоВсемТабелям, finalПолученныйUUID,месяцДляПермещенияПоТабелю,годДляПермещенияПоТабелю);


            //TODO Считаем Сумму часов по всем табелям
            ПолученыеСуммаЧасовСотрудникаВнутри = String.valueOf(new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(КонтекстДЛляПодсчетаЧасовПоВсемТабелям).
                    МетодПосчётаЧасовПоСотруднику(Курсор_ЗагружаемТабеляДляПодсчетаЧасовПовсемТАбелям));

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    /*              return ПолученыеСуммаЧасовСотрудникаВнутри;
              }
          }.loadInBackground();
      }*/

        return ПолученыеСуммаЧасовСотрудникаВнутри;

    }



























    ///todo АНАЛИЗ UUID
    void МетодАнализаUUIDСинхрониазциявФоне(String UUIDПолученныйИзПришедшегоJSON, String JSON_ИмяСтолбца, String JSON_ИмяСодержимое,
                                            String имяТаблицыОтАндройда_локальноая, String IDИзПришедшегоJSON)
            throws ExecutionException, InterruptedException, TimeoutException {

        try{


            ////// TODO ИЗ ПРАВИЛА ЧТО НЕЛЬЗЯ ОБНОЛВЛЯТЬ ПОЕЛ UUID ПРОПУСКАЕМ ЕГО ЭТО КОГДА СТОЛБИК ID ПРОПУСКАЕМ
            if (имяТаблицыОтАндройда_локальноая.equals("tabels")){

                if( JSON_ИмяСтолбца.equals("id")) {
                    JSON_ИмяСтолбца = "_id";
                }
                /////////
                System.out.println("  JSON_ИмяСтолбца[0]  " +JSON_ИмяСтолбца );

            }

            //TODO для таблицы fio

            if (имяТаблицыОтАндройда_локальноая.equals("fio")){

                if( JSON_ИмяСтолбца.equals("id")) {
                    JSON_ИмяСтолбца = "_id";
                }
                /////////
                System.out.println("  JSON_ИмяСтолбца[0]  " +JSON_ИмяСтолбца );

            }






/////
            String ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде;
            ////
            ////todo  ПЫТАЕМСЯ ОРГАНИЗОВАТЬ ОБНОВЛЕНИЕ НО ТОЛЬКО ЕСЛИ ВЛАГ  TRUE











            Курсор_УзнатьЕслиНаАндройдеТакойUUID = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,
                    new String[]{"uuid"}, "uuid=?", new String[]{UUIDПолученныйИзПришедшегоJSON}, null, null,
                    null, null);//"SuccessLogin", "date_update","id=","1",null,null,null,null




            ////////






            if (Курсор_УзнатьЕслиНаАндройдеТакойUUID!=null) {
                if (Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount() > 0) {
                    Курсор_УзнатьЕслиНаАндройдеТакойUUID.moveToFirst();
                    ///
                    ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде = Курсор_УзнатьЕслиНаАндройдеТакойUUID.getString(0);
                    Log.d(this.getClass().getName(), " ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде " + ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде);


                    ////////
                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON " + UUIDПолученныйИзПришедшегоJSON.length() + " Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount()  "
                            + Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount() +
                            " IDИзПришедшегоJSON " + IDИзПришедшегоJSON);

                    Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца + " JSON_ИмяСодержимое " + JSON_ИмяСодержимое);
                    //////МЕТОДКОТРЫЙ ПРИ ОТСТВИИИ UUID ЕГО ГЕНЕРИРЕТ НА ПРИШЕЛДХИ ДАННЫХ

                    /////второе условие чтобы uuid не вставлем тоже



                    /// TODO ТУТ ПРОИЗВОДИТЬСЯ ОБНОВЛЕНИЕ ДАННЫХ
                    АдаптерПриОбновленияДанныхсСервера.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);////заполняем контрейнер обнолвеними

                    ////
                    Log.d(this.getClass().getName(), " Курсор_УзнатьЕслиНаАндройдеТакойUUID " + Курсор_УзнатьЕслиНаАндройдеТакойUUID + " АдаптерПриОбновленияДанныхсСервера.size() "
                            + АдаптерПриОбновленияДанныхсСервера.size());



                    ///TODO ВСТАВКА ЧЕРЕЗ UUID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID
                }  else {
                    ///TODO ВСТАВКА ЧЕРЕЗ UUID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID

                    АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                    Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер UUID " +АдаптерДляВставкиДанныхсСервер.size());

                }
            }else {
                ///TODO ВСТАВКА ЧЕРЕЗ UUID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID

                АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер UUID " +АдаптерДляВставкиДанныхсСервер.size());

            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }


////////


    ///////todo АНАЛИХ ID
    void МетодАнализаIDСинхрониазциивФоне(String UUIDПолученныйИзПришедшегоJSON, String JSON_ИмяСтолбца, String JSON_ИмяСодержимое,
                                          String имяТаблицыОтАндройда_локальноая, String IDИзПришедшегоJSON) throws ExecutionException, InterruptedException, TimeoutException {



        try {

            String ИндификаторДляIDВзависмостиОтТаблицы = "id";
            ///
            if (имяТаблицыОтАндройда_локальноая.equals("tabels")) {
                /////////

                ИндификаторДляIDВзависмостиОтТаблицы = "_id";
                /////////
                if (JSON_ИмяСтолбца.equals("id")) {
                    ////////TODO сам столбик
                    JSON_ИмяСтолбца = ИндификаторДляIDВзависмостиОтТаблицы;
                }


                System.out.println("  JSON_ИмяСтолбца[0]  " + JSON_ИмяСтолбца + " ИндификаторДляIDВзависмостиОтТаблицы " + ИндификаторДляIDВзависмостиОтТаблицы);
                System.out.println("  JSON_ИмяСтолбца[0]  " + JSON_ИмяСтолбца);

            }
            //TODO для таблицы fio

            if (имяТаблицыОтАндройда_локальноая.equals("fio")) {
                /////////

                ИндификаторДляIDВзависмостиОтТаблицы = "_id";
                /////////
                if (JSON_ИмяСтолбца.equals("id")) {
                    ////////TODO сам столбик
                    JSON_ИмяСтолбца = ИндификаторДляIDВзависмостиОтТаблицы;
                }


                System.out.println("  JSON_ИмяСтолбца[0]  " + JSON_ИмяСтолбца + " ИндификаторДляIDВзависмостиОтТаблицы " + ИндификаторДляIDВзависмостиОтТаблицы);
                System.out.println("  JSON_ИмяСтолбца[0]  " + JSON_ИмяСтолбца);

            }


            /////
            String ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде;///////
            ////todo  ПЫТАЕМСЯ ОРГАНИЗОВАТЬ ОБНОВЛЕНИЕ НО ТОЛЬКО ЕСЛИ ВЛАГ  TRUE



            //////
            Курсор_УзнатьЕслиНаАндройдеТакойID = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,
                    new String[]{ИндификаторДляIDВзависмостиОтТаблицы}, ИндификаторДляIDВзависмостиОтТаблицы + "=?", new String[]{IDИзПришедшегоJSON}, null, null,
                    null, null);//"SuccessLogin", "date_update","id=","1",null,null,null,null

///////



            if (Курсор_УзнатьЕслиНаАндройдеТакойID != null) {
                if (Курсор_УзнатьЕслиНаАндройдеТакойID.getCount() > 0) {
                    Курсор_УзнатьЕслиНаАндройдеТакойID.moveToFirst();

                    ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде = Курсор_УзнатьЕслиНаАндройдеТакойID.getString(0);
                    Log.d(this.getClass().getName(), "ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде" + ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде);


                    ////////
                    Log.d(this.getClass().getName(),   " Курсор_УзнатьЕслиНаАндройдеТакойID.getCount() " + Курсор_УзнатьЕслиНаАндройдеТакойID.getCount() +
                            " IDИзПришедшегоJSON " + IDИзПришедшегоJSON);

                    Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца + " JSON_ИмяСодержимое " + JSON_ИмяСодержимое);
                    //////МЕТОДКОТРЫЙ ПРИ ОТСТВИИИ UUID ЕГО ГЕНЕРИРЕТ НА ПРИШЕЛДХИ ДАННЫХ

                    /////второе условие чтобы uuid не вставлем тоже


                    ////// TODO ИЗ ПРАВИЛА ЧТО НЕЛЬЗЯ ОБНОЛВЛЯТЬ ПОЕЛ UUID ПРОПУСКАЕМ ЕГО ЭТО КОГДА СТОЛБИК ID ПРОПУСКАЕМ


                    ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID
                    АдаптерПриОбновленияДанныхсСервера.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);////заполняем контрейнер обнолвеними

                    ////
                    Log.d(this.getClass().getName(), " Курсор_УзнатьЕслиНаАндройдеТакойUUID " + Курсор_УзнатьЕслиНаАндройдеТакойID + " АдаптерПриОбновленияДанныхсСервера.size() "
                            + АдаптерПриОбновленияДанныхсСервера.size());


                    ///TODO ВСТАВКА ЧЕРЕЗ ID       ///TODO ВСТАВКА ЧЕРЕЗ ID
                } else {
                    ///TODO ВСТАВКА ЧЕРЕЗ ID

                    АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                    Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер ID " + АдаптерДляВставкиДанныхсСервер.size());


                    /////
                }//todo end     ///////TODO КОГДА ЕСТЬ ТОЛЬКО ID ШНИК ОБНОВЛЕНИЕ


            } else {
                ///TODO ВСТАВКА ЧЕРЕЗ ID

                АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер ID " + АдаптерДляВставкиДанныхсСервер.size());


                /////
            }//todo end     ///////TODO КОГДА ЕСТЬ ТОЛЬКО ID ШНИК ОБНОВЛЕНИЕ


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


    }

    public  void МетодОчищаемИзБазыNULLЗначенияя(){


        try{


            // TODO: 26.03.2021 ДОПОЛНИТЕЛЬНО ОБНУЛЯЕМ ВСЕ ТАБЕЛЯ С NULL В ФИО ЧТО БЫ ОБМЕН НЕ РУГАЛЬСЯ

            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE fio IS NULL");
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE cfo IS NULL");
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE nametabel_typename IS NULL");
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE uuid IS NULL");
            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM fio   WHERE uuid IS NULL");
            ССылкаНаСозданнуюБазу.setTransactionSuccessful();
            ССылкаНаСозданнуюБазу.endTransaction();


            Log.d(this.getClass().getName(), "Удаление даных перед Синхронизацией NULL значения ");

            ///////todo\
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }


    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
    public String ГлавнаяДатаИВремяОперацийСБазойДанных() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        //  dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);
    }




}



