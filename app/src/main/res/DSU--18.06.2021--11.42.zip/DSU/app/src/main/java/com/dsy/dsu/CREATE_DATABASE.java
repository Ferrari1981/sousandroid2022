
//////КНАЧАЛО  КЛАССА ПО СОЗДАНИЮ СХЕМЫ ДАННЫХ
package com.dsy.dsu;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;


//этот класс создает базу данных SQLite
public class CREATE_DATABASE extends SQLiteOpenHelper {

    /////TODO ВЕРСИЯ ДАННЫХ МЕНЯЕМ И УДАЛЯЕМ ДАННЫЕ И ЗАГРУЖАЕМ НОВЫЕ
    private static final int VERSION =629;//ПРИ ЛЮБОМ ИЗМЕНЕНИЕ В СТРУКТУРЕ БАЗЫ ДАННЫХ НУЖНО ДОБАВИТЬ ПЛЮС ОДНУ ЦИФРУ К ВЕРСИИ 1=1+1=2 ИТД.1
Context contextСозданиеБАзы;

    public static SQLiteDatabase ССылкаНаСозданнуюБазу;// 'ЭТА СССЫЛКА ДЛЯ ВСЕХ НА ПОДКЛЮЧЕНИ ДАННЫХ




///TODO ДЛЯ ОБРАБОТКИ КОЛИЧЕСТВА ТАБЛИЦ В СИНХРОНИЗХАЦИИ


    ///////КОНСТРУКТОР главного класса по созданию базы данных
    public CREATE_DATABASE(Context context) {/////КОНСТРУКТОР КЛАССА ПО СОЗДАНИЮ БАЗЫ ДАННЫХ


        super(context, "Database DSU-1.db", null, VERSION); // определяем имя базы данных  и ее версию
        ///

        ССылкаНаСозданнуюБазу = this.getWritableDatabase(); //ссылка на схему базы данных;//ссылка на схему базы данных ГЛАВНАЯ ВСТАВКА НА БАЗУ ДСУ-1

        contextСозданиеБАзы=context;
        try{


        //////метод по созданию тригеров
        /////
        ////
       // this.rawExecSQL("PRAGMA journal_mode=OFF;");
        //////
   /*     PUBLIC_CONTENT.ССылкаНаСозданнуюБазу.rawQuery("PRAGMA journal_mode=OFF", null);
            PUBLIC_CONTENT.ССылкаНаСозданнуюБазу.rawQuery("PRAGMA busy_timeout=5 ", null);*/


    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
      new   КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }



    ////метод потока создание  базы днных
    //Cоздание ТАблиц
    ReentrantLock reentrantLock=new ReentrantLock();
    @Override
    public void onCreate(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        try {
            reentrantLock.lock();
            Log.d(this.getClass().getName(), "Запущен.... метод  on public void onCreate(SQLiteDatabase ССылкаНаСозданнуюБазу)  ; ");
            /////////ЗАПУСКАМ  ТРАНЗАКЦИЮ ПО СОЗДАНИЮ ТАБЛИЦ ДЛЯ БАЗЫ ДАННЫХ
         ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();//запускаем тарнзакцию
            ///////
////
            //ССылкаНаСозданнуюБазу.setMaxSqlCacheSize(100);

         /*   // ССылкаНаСозданнуюБазу.rawExecSQL("DETACH DATABASE encrypted;");

            ////
            ССылкаНаСозданнуюБазу.setPageSize(90000000);*/
            ///

///---ТУТ БЛОК ТЕХНИЧЕСКИХ ТАБЛИЦ
            МетодСозданиеТаблицыОшибок(ССылкаНаСозданнуюБазу);


            //таблица SuccessLogin
            МетодСозданиеТаблицыЛогинов(ССылкаНаСозданнуюБазу);


            //таблица MODIFITATION_Client



            //таблица MODIFITATION_Client
           ССылкаНаСозданнуюБазу.execSQL("drop table  if exists MODIFITATION_Client");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table  if not exists MODIFITATION_Client (" +
                    "name  TEXT NOT NULL " +
                    ",  localversionandroid NUMERIC DEFAULT '1900-01-10 00:00:00' , " +
                    "versionserveraandroid NUMERIC DEFAULT '1900-01-10 00:00:00'   )");
            //////////
            Log.d(this.getClass().getName(), " сработала ... INSERT  INTO MODIFITATION_Client");

///---ТУТ КОНЕЦ  БЛОК ТЕХНИЧЕСКИХ ТАБЛИЦ
   /*
        //  ССылкаНаСозданнуюБазу.execSQL("drop table  if exists MODIFITATION_Client");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table  if not exists MODIFITATION_Client (" +
                    "name  TEXT NOT NULL," +
                    "localversionandroid NUMERIC ," +
                    " versionserveraandroid NUMERIC  )");

            /////todo встака данных по умолчанию
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO MODIFITATION_Client (name) VALUES('organization')");
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO MODIFITATION_Client (name) VALUES('depatment')");
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO MODIFITATION_Client (name) VALUES('fio')");
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO MODIFITATION_Client (name) VALUES('region')");
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO MODIFITATION_Client (name) VALUES('cfo')");
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO MODIFITATION_Client (name) VALUES('tabels')");
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO MODIFITATION_Client (name) VALUES('notification')");
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO MODIFITATION_Client (name) VALUES('Templates')");
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO MODIFITATION_Client (name) VALUES('Fio_Template')");

            ////////
            ССылкаНаСозданнуюБазу.execSQL("UPDATE MODIFITATION_Client SET localversionandroid = '1900-01-10 00:00:00',versionserveraandroid ='1900-01-10 00:00:00' WHERE name IN ('tabels','notification','Templates','Fio_Template')");



            ////
*/



      /*      //таблица MODIFITATION_Client
            //ССылкаНаСозданнуюБазу.execSQL("drop table  if exists MODIFITATION_Client");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table  if not exists MODIFITATION_Client (" +
                    "name  TEXT NOT NULL " +
                    ",  localversionandroid NUMERIC DEFAULT '1900-01-10 00:00:00', " +
                    "versionserveraandroid NUMERIC DEFAULT '1900-01-10 00:00:00'   )");*/
            //////////
            Log.d(this.getClass().getName(), " сработала ... INSERT  INTO MODIFITATION_Client");

///---ТУТ КОНЕЦ  БЛОК ТЕХНИЧЕСКИХ ТАБЛИЦ














///// ---ТУТ ДЕЙСТВУЮЩИЕ ТАБЛИЦЫ ПРОЕКТА ТАБЕЛЬНЫЙ УЧЁТ ///// ---ТУТ ДЕЙСТВУЮЩИЕ ТАБЛИЦЫ ПРОЕКТА ТАБЕЛЬНЫЙ УЧЁТ





            //таблица organization            //таблица organization            //таблица organization            //таблица organization
            ССылкаНаСозданнуюБазу.execSQL("drop table  if exists organization");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists organization (" +
                    "id  INTEGER    ," +
                    " name TEXT  ," +
                    " fullname  TEXT ," +
                    " inn TEXT ," +
                    " kpp  TEXT  ," +
                    " date_update  NUMERIC," +
                    "  user_update   INTEGER ," +
                    " chosen_organization INTEGER  )");
            Log.d(this.getClass().getName(), " сработала ...  создание таблицы organization");


            //таблица depatment         //таблица depatment         //таблица depatment         //таблица depatment
          ССылкаНаСозданнуюБазу.execSQL("drop table  if exists depatment");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists depatment (" +
                    "id  INTEGER    ," +
                    " name TEXT  ," +
                    " organization INTEGER ," +
                    " date_update NUMERIC," +
                    " user_update TEXT," +
                    "FOREIGN KEY(organization) REFERENCES organization  (id)  ON UPDATE CASCADE)");
            Log.d(this.getClass().getName(), " сработала ...  создание таблицы depatment");






            //таблица   fio        //таблица   fio         //таблица   fio         //таблица   fio
            МетодСозданиеТаблицыФИО(ССылкаНаСозданнуюБазу);





            //таблица  cfo      //таблица   cfo     //таблица cfo      //таблица   cfo
          ССылкаНаСозданнуюБазу.execSQL("drop table  if exists   cfo");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists   cfo (" +
                    "id  INTEGER     ," +
                    " name TEXT ," +
                    " region  INTEGER ," +
                    " boss  INTEGER ," +
                    " kod TEXT  ," +
                    " date_update NUMERIC  ," +
                    " user_update INTEGER  ," +
                    " closed INTEGER  ," +
                    "FOREIGN KEY(boss) REFERENCES fio   (_id)  ON UPDATE CASCADE)");
            Log.d(this.getClass().getName(), " сработала ...  создание таблицы   cfo");





            //таблица  region     //таблица   cfo     //таблица cfo      //таблица   cfo
            ССылкаНаСозданнуюБазу.execSQL("drop table  if exists  region");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists   region (" +
                    "id  INTEGER     ," +
                    " name TEXT ," +
                    " date_update NUMERIC  ," +
                    " user_update INTEGER )");
            Log.d(this.getClass().getName(), " сработала ...  создание таблицы  region");






            //таблица tabels   //таблица tabels   //таблица tabels   //таблица tabels  ///"_id  INTEGER    ," +
            МетодСозданияТаблицыТабель(ССылкаНаСозданнуюБазу);


            /////

            // todo таблица  metki_tabel
            МетодСозданиеМетокТабеля(ССылкаНаСозданнуюБазу);







            // todo таблица  settings_tabels
            ССылкаНаСозданнуюБазу.execSQL("drop table  if exists  settings_tabels");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists    settings_tabels  (" +
                    "id  INTEGER  ," +
                    " date_update NUMERIC  ," +
                    " user_update INTEGER  ," +
                    " version_dsu1 INTEGER ," +
                    "organizations  INTEGER DEFAULT '1' ," +
                    " uuid  NUMERIC  )");
            /////todo встака данных по умолчанию


//            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO settings_tabels (metka,fullname_metka,id) VALUES('В','Выходной','1')");
//            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO settings_tabels (metka,fullname_metka,id) VALUES('О','Отпуск','2')");
//            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO settings_tabels (metka,fullname_metka,id) VALUES('Б','Больничный','3')");
//            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO settings_tabels (metka,fullname_metka,id) VALUES('А','Отпуск без оплаты','4')");
//            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO settings_tabels (metka,fullname_metka,id) VALUES('П','Прогулы','5')");
//            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO settings_tabels (metka,fullname_metka,id) VALUES('Р','Ремонт','6')");
//            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO settings_tabels (metka,fullname_metka,id) VALUES('Д','Дежурство','7')");

            ////////
            Log.d(this.getClass().getName(), " сработала ...  создание таблицы settings_tabels");








            // todo таблица Notifications
            ССылкаНаСозданнуюБазу.execSQL("drop table  if exists notification");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists    notification  (" +
                    "id  INTEGER ," +
                    " user_update INTEGER ,"+
                    " date_update NUMERIC,"+
                    " clock NUMERIC,"+
                    " date_start NUMERIC ," +
                    " message  NUMERIC ," +
                    "rights INTEGER   ," +
                     "uuid  NUMERIC UNIQUE )");

            /////todo встака данных по умолчанию

            ////////
            Log.d(this.getClass().getName(), " сработала ...  создание таблицы Notification");

            // todo таблица Notifications ///Результат_ВставкаДанныхДатойDate_WORk
            ССылкаНаСозданнуюБазу.execSQL("drop table  if exists date_work");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists    date_work  (" +
                    "id  INTEGER  ," +
                    "date_work NUMERIC,"+
                    " date_update NUMERIC)");
            /////todo встака данных по умолчанию
            /////todo встака данных по умолчанию
           // ССылкаНаСозданнуюБазу.execSQL("INSERT INTO date_work (id) VALUES('1')");
            ////////
            Log.d(this.getClass().getName(), " сработала ...  создание таблицы date_work");


            // todo таблица Templates
           ССылкаНаСозданнуюБазу.execSQL("drop table  if exists Templates");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists    Templates  (" +
                    "id  INTEGER ," +
                    " name_templates TEXT  ," +
                    " user_update INTEGER ,"+
                    " date_update NUMERIC,"+
                    " uuid  NUMERIC UNIQUE  ," +
                    " status_send  TEXT ) ");

            /////todo встака данных по умолчанию

            Log.d(this.getClass().getName(), " сработала ...  создание таблицы Templates");

            // todo таблица Fio_Template
            ССылкаНаСозданнуюБазу.execSQL("drop table  if exists Fio_Template");//test
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists    Fio_Template  (" +
                    "id  INTEGER ," +
                    " uuid  NUMERIC UNIQUE," +
                    " fio_template NUMERIC ," +
                    "fio_uuid  NUMERIC   ,"+
                    " date_update NUMERIC,"+
                    " user_update INTEGER," +
                    "FOREIGN KEY(fio_uuid  ) REFERENCES fio (uuid)  ON UPDATE CASCADE," +
                    "FOREIGN KEY( fio_template  ) REFERENCES Templates (uuid)  ON UPDATE CASCADE ," +
                    "FOREIGN KEY( fio_template  ) REFERENCES Templates (uuid)   ON DELETE CASCADE," +
                    "PRIMARY KEY(fio_template,fio_uuid )) ");

            /////todo встака данных по умолчанию

            Log.d(this.getClass().getName(), " сработала ...  создание таблицы Fio_Template");



            // todo таблица Chats
            МетодСозданияТаблицаChats(ССылкаНаСозданнуюБазу);


            // todo таблица Fio_Template
            МетодСозданияТаблицыData_Chat(ССылкаНаСозданнуюБазу);


            // TODO: 19.03.2021 запуск создание таблиц




///////// КОНЕЦ ФИКСИРУЕМ И ЗАВЕРШАЕМ ТРАНЗАКЦИЮ ПО СОЗДАНИЮ ТАБЛИЦ ДЛЯ БАЗЫ ДАННЫХ





            /////TODO СТАРЫЙ ТЕСТ КОД
/*
                    ССылкаНаСозданнуюБазу.execSQL("drop view  if exists viewtabel");//test
            //ВИД View_TABEL
            ССылкаНаСозданнуюБазу.execSQL("CREATE VIEW if not exists viewtabel AS  SELECT             tabels.id,  tabels.fio,  tabels.cfo,  tabels.year_tabels, " +
                    " tabels.month_tabels,  tabels.d1,  tabels.d2,  tabels.d3,  tabels.d4,  tabels.d5,  tabels.d6,  tabels.d7,  tabels.d8, \n" +
                    "                          tabels.d9,  tabels.d10,  tabels.d11,  tabels.d12,  tabels.d13,  tabels.d14,  tabels.d15,  tabels.d16, " +
                    " tabels.d17,  tabels.d18,  tabels.d19,  tabels.d21,  tabels.d20,  tabels.d22, \n" +
                    "                          tabels.d23,  tabels.d24,  tabels.d27,  tabels.d26,  tabels.d25,  tabels.d29,  tabels.d28,  tabels.d30, " +
                    " tabels.d31,  tabels.uuid,  tabels.date_update,  tabels.status_send, \n" +
                    "                          tabels.department,  tabels.user_update,  tabels.organizations,  tabels.nametabel,  fio.BirthDate,  fio.snils,  fio.name\n" +
                    "FROM             tabels LEFT OUTER JOIN\n" +
                    "                          fio ON  tabels.fio =  fio.uuid");
            Log.d(this.getClass().getName(), " сработала ...  создание вид  viewtabel");
*/




//// TODO ТУТ СОЗДАЕМ ВИДЫ ДАННЫХ

           // ССылкаНаСозданнуюБазу.execSQL("drop view  if exists viewtabel");//test
            //ВИД View_TABEL
            МетодСозданияViewТабеля(ССылкаНаСозданнуюБазу);




//// TODO ТУТ СОЗДАЕМ ВИДЫ ДАННЫХ
         //   ССылкаНаСозданнуюБазу.execSQL("drop view  if exists notification_insider");//test
            //ВИД View_TABEL
            ССылкаНаСозданнуюБазу.execSQL("drop VIEW  if exists notification_insider");//test
            ССылкаНаСозданнуюБазу.execSQL("CREATE VIEW if not exists notification_insider AS  SELECT notification.id," +
                    " notification.user_update, notification.date_update,   notification.clock," +
                    "notification.date_start,notification.message,date_work.date_work  FROM" +
                    "     notification  JOIN date_work ON notification.id = date_work.id");
            //////
            Log.d(this.getClass().getName(), " сработала ...  создание вид  notification_insider");


        /*    ССылкаНаСозданнуюБазу.execSQL("drop view  if exists viewtabeladapter");//test
            //ВИД View_TABEL
            ССылкаНаСозданнуюБазу.execSQL("CREATE VIEW if not exists viewtabeladapter AS  SELECT tabels.id, tabels.fio, tabels.cfo,  tabels.year_tabels,tabels.month_tabels, tabels.d1," +
                    " tabels.d2, tabels.d3, tabels.d4, tabels.d5," +
                    " tabels.d6, tabels.d7, tabels.d8, tabels.d9, \n" +
                    "                  tabels.d10, tabels.d11, tabels.d12, tabels.d13, tabels.d14, tabels.d15, tabels.d16, tabels.d17," +
                    " tabels.d18, tabels.d19, tabels.d20, tabels.d21, tabels.d22, tabels.d23, tabels.d24, \n" +
                    "                  tabels.d25, tabels.d26, tabels.d27, tabels.d28, tabels.d29, tabels.d30," +
                    " tabels.d31, tabels.uuid," +
                    " tabels.date_update, tabels.status_send, tabels.department, tabels.user_update, tabels.organizations, tabels.nametabel, \n" +
                    "                  fio.BirthDate, fio.snils,fio.name,_id._id  FROM     tabels LEFT OUTER JOIN fio ON tabels.fio = fio.uuid AND _id  LEFT OUTER JOIN fio ON _id._id = fio.id");
            Log.d(this.getClass().getName(), " сработала ...  создание вид  viewtabeladapter");*/









/////////ФИКСИРУЕМ И ЗАВЕРШАЕМ ТРАНЗАКЦИЮ ПО СОЗДАНИЮ ТАБЛИЦ ДЛЯ БАЗЫ ДАННЫХ
            if (ССылкаНаСозданнуюБазу.inTransaction()) {
                ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                ССылкаНаСозданнуюБазу.endTransaction();

                Log.d(this.getClass().getName(), "БАЗА ДАННЫХ    ...  УСПЕШНОЕ СОЗДАНИЕ БАЗЫ ДАННЫХ И ВЫХОД ИЗ КЛАССА "+new Date());


            }





            //end thread-2*/
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
          new   КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
             ////
            ССылкаНаСозданнуюБазу.endTransaction();
        }finally {

            reentrantLock.unlock();
        }
    }

    private void МетодСозданияТаблицыData_Chat(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        ССылкаНаСозданнуюБазу.execSQL("drop table  if exists Data_Chat");//test
        ССылкаНаСозданнуюБазу.execSQL("Create table if not exists    Data_Chat  (" +
                "id  INTEGER ," +
                " uuid  NUMERIC UNIQUE," +
                " body_chat TEXT ," +
                " image_chat BLOB ," +
                " status_write NUMERIC DEFAULT 0 ," +
                "chat_uuid  NUMERIC   ,"+
                " date_update NUMERIC,"+
                "FOREIGN KEY(chat_uuid  ) REFERENCES Chats (uuid)  ON UPDATE CASCADE ON DELETE CASCADE) ");

        /////todo встака данных по умолчанию

        Log.d(this.getClass().getName(), " сработала ...  создание таблицы Data_Chat");
    }

    private void МетодСозданияТаблицаChats(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        ССылкаНаСозданнуюБазу.execSQL("drop table  if exists Chats");//test
        ССылкаНаСозданнуюБазу.execSQL("Create table if not exists    Chats  (" +
                "id  INTEGER ," +
                " name TEXT  ," +
                " users_chats NUMERIC UNIQUE ,"+
                " user_update INTEGER ,"+
                " date_update NUMERIC,"+
                " uuid  NUMERIC UNIQUE  ," +
                " status_send  TEXT,"+
                "FOREIGN KEY(users_chats  ) REFERENCES fio (uuid)  ON UPDATE CASCADE) ");

        /////todo встака данных по умолчанию

        Log.d(this.getClass().getName(), " сработала ...  создание таблицы Chats");
    }

    private void МетодСозданияViewТабеля(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        //

                    ССылкаНаСозданнуюБазу.execSQL("drop view  if exists viewtabel");//test
            //ВИД View_TABEL
            ССылкаНаСозданнуюБазу.execSQL("CREATE VIEW if not exists viewtabel AS  SELECT             tabels._id,  tabels.fio,  tabels.cfo,  tabels.year_tabels, " +
                    " tabels.month_tabels,  tabels.d1,  tabels.d2,  tabels.d3,  tabels.d4,  tabels.d5,  tabels.d6,  tabels.d7,  tabels.d8, \n" +
                    "                          tabels.d9,  tabels.d10,  tabels.d11,  tabels.d12,  tabels.d13,  tabels.d14,  tabels.d15,  tabels.d16, " +
                    " tabels.d17,  tabels.d18,  tabels.d19,  tabels.d21,  tabels.d20,  tabels.d22, \n" +
                    "                          tabels.d23,  tabels.d24,  tabels.d27,  tabels.d26,  tabels.d25,  tabels.d29,  tabels.d28,  tabels.d30, " +
                    " tabels.d31,  tabels.uuid,  tabels.date_update,  tabels.status_send, \n" +
                    "                           tabels.user_update,   fio.BirthDate,  fio.snils,  fio.name,tabels.status_carried_out\n" +
                    "FROM             tabels LEFT OUTER JOIN\n" +
                    "                          fio ON  tabels.fio =  fio.uuid");
            Log.d(this.getClass().getName(), " сработала ...  создание вид  viewtabel");

    }

    private void МетодСозданияТаблицыТабель(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        ССылкаНаСозданнуюБазу.execSQL("drop table  if exists tabels");//test
        ССылкаНаСозданнуюБазу.execSQL("Create table if not exists tabels(" +
                "_id  INTEGER    ," +
                " fio NUMERIC," +
                "cfo NUMERIC ," +
                "month_tabels NUMERIC," +
                "year_tabels NUMERIC," +
                "d1 INTEGER  ," +
                "d2 INTEGER    ," +
                "d3 INTEGER      ," +
                "d4 INTEGER      ," +
                "d5 INTEGER    ," +
                "d6 INTEGER    ," +
                "d7 INTEGER      ," +
                "d8 INTEGER      ," +
                "d9 INTEGER    ," +
                "d10 INTEGER    ," +
                "d11 INTEGER      ," +
                "d12 INTEGER    ," +
                "d13 INTEGER      ," +
                "d14 INTEGER    ," +
                "d15 INTEGER      ," +
                "d16 INTEGER      ," +
                "d17 INTEGER    ," +
                "d18 INTEGER      ," +
                "d19 INTEGER    ," +
                "d20 INTEGER      ," +
                "d21 INTEGER  ," +
                "d22 INTEGER     ," +
                "d23 INTEGER     ," +
                "d24 INTEGER     ," +
                "d25 INTEGER     ," +
                "d26 INTEGER     ," +
                "d27 INTEGER    ," +
                "d28 INTEGER     ," +
                "d29 INTEGER     ," +
                "d30 INTEGER     ," +
                "d31 INTEGER     ," +
                "date_update  NUMERIC   ," +
                " uuid  NUMERIC UNIQUE ," +
                " status_send  TEXT ," +
                " user_update INTEGER ," +
                "status_carried_out   INTEGER  ,"+
                "FOREIGN KEY(cfo ) REFERENCES cfo (id)  ON UPDATE CASCADE ,"+/// "FOREIGN KEY(organizations) REFERENCES SuccessLogin (organizations)  ON UPDATE CASCADE ,"+
                "FOREIGN KEY(fio ) REFERENCES fio (uuid)  ON UPDATE CASCADE  ON DELETE CASCADE," +
                "PRIMARY KEY(fio,cfo ,month_tabels,year_tabels)) ");
        ///
        ////////////////////
        Log.d(this.getClass().getName(), " сработала ...  создание таблицы  TABELS");//"FOREIGN KEY(organizations) REFERENCES SuccessLogin (organizations)  ON UPDATE CASCADE ,"+
    }

    private void МетодСозданиеТаблицыФИО(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        ССылкаНаСозданнуюБазу.execSQL("drop table  if exists   fio");//test
        ССылкаНаСозданнуюБазу.execSQL("Create table if not exists   fio (" +
                "_id  INTEGER   ," +
                " name TEXT  ," +
                " f TEXT ," +
                " n TEXT," +
                " o TEXT  ," +
                " BirthDate NUMERIC," +
                " snils TEXT," +
                " date_update NUMERIC," +
                " user_update INTEGER," +
                " uuid  NUMERIC UNIQUE," +
                " current_organization INTEGER," +
                "FOREIGN KEY(user_update) REFERENCES users  (id)  ON UPDATE CASCADE," +
                "FOREIGN KEY(current_organization) REFERENCES organization  (id)  ON UPDATE CASCADE)");
        Log.d(this.getClass().getName(), " сработала ...  создание таблицы   fio");
    }

    private void МетодСозданиеМетокТабеля(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        ССылкаНаСозданнуюБазу.execSQL("drop table  if exists  metki_tabel");//test
        ССылкаНаСозданнуюБазу.execSQL("Create table if not exists    metki_tabel  (" +
                "id  INTEGER PRIMARY KEY AUTOINCREMENT ," +
                " metka TEXT ," +
                " fullname_metka TEXT ," +
                " date_update NUMERIC  ," +
                " user_update INTEGER )");
        /////todo встака данных по умолчанию
        ССылкаНаСозданнуюБазу.execSQL("INSERT INTO metki_tabel (metka,fullname_metka) VALUES('В','Выходной')");
        ССылкаНаСозданнуюБазу.execSQL("INSERT INTO metki_tabel (metka,fullname_metka) VALUES('О','Отпуск')");
        ССылкаНаСозданнуюБазу.execSQL("INSERT INTO metki_tabel (metka,fullname_metka) VALUES('Б','Больничный')");
        ССылкаНаСозданнуюБазу.execSQL("INSERT INTO metki_tabel (metka,fullname_metka) VALUES('А','Отпуск без оплаты')");
        ССылкаНаСозданнуюБазу.execSQL("INSERT INTO metki_tabel (metka,fullname_metka) VALUES('П','Прогулы')");
        ССылкаНаСозданнуюБазу.execSQL("INSERT INTO metki_tabel (metka,fullname_metka) VALUES('Р','Ремонт')");
        ССылкаНаСозданнуюБазу.execSQL("INSERT INTO metki_tabel (metka,fullname_metka) VALUES('Д','Дежурство')");
        ССылкаНаСозданнуюБазу.execSQL("INSERT INTO metki_tabel (metka,fullname_metka) VALUES('К','Командировка')");

        ////////
        Log.d(this.getClass().getName(), " сработала ...  создание таблицы metki_tabel");
    }

    private void МетодСозданиеТаблицыЛогинов(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        ССылкаНаСозданнуюБазу.execSQL("drop table  if exists SuccessLogin");//test
        ССылкаНаСозданнуюБазу.execSQL("Create table  if not exists SuccessLogin (" +
                " id   INTEGER ," +
                " success_users  TEXT  ," +
                " success_login  TEXT ,  " +
                " date_update  NUMERIC," +
                " mode_weekend  TEXT DEFAULT 'Выключить'," +
                "mode_connection TEXT DEFAULT 'Mobile' )");
        //ССылкаНаСозданнуюБазу.execSQL("INSERT INTO SuccessLogin (id) VALUES('')");
        Log.d(this.getClass().getName(), " сработала ...  создание таблицы  SuccessLogin");
    }


    private void МетодСозданиеТаблицыОшибок(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        try{
        ССылкаНаСозданнуюБазу.execSQL("drop table  if exists ErrorDSU1 ");//ТАБЛИЦА ГЕНЕРАЦИИ ОШИБОК
        ССылкаНаСозданнуюБазу.execSQL("Create table if not exists ErrorDSU1 (" +
                "ID_Table_ErrorDSU1 INTEGER PRIMARY KEY AUTOINCREMENT  ," +
                " Error TEXT    NOT NULL  ," +
                "Klass TEXT NOT NULL ," +
                "Metod TEXT NOT NULL," +
                "LineError INTEGER NOT NULL ," +
                "Data_Operazii_E NUMERIC NOT NULL ,"+
                "whose_error INTEGER NOT NULL )");
        Log.d(this.getClass().getName(), " сработала ...  создание таблицы ErrorDSU1 ");

    } catch (SQLException e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }





    @Override
    public void onUpgrade(SQLiteDatabase ССылкаНаСозданнуюБазу, int oldVersion, int newVersion) {
        //принудительное запускаем заново для создание новых таблиц






/*

            // TODO: 14.05.2021 лучшие только таблицы ФИО
        if ( newVersion==  588) {
            ExecutorService executorServiceКонктетныеИзмения= Executors.newCachedThreadPool();
            executorServiceКонктетныеИзмения.execute(new Runnable() {
                @Override
                public void run() {

            ОчисткаТаблицысЗаписьюВMODIFITATION_Client("fio",true);
            ////
                    ОчисткаТаблицысЗаписьюВMODIFITATION_Client("tabels",true);

                    //
                    executorServiceКонктетныеИзмения.shutdown();


                }
            });

        }else{*/

        CompletionService completionServiceсозданиебазы=new ExecutorCompletionService<String>(Executors.newCachedThreadPool());


        completionServiceсозданиебазы.submit(new Callable<Object>() {
                    @Override
                    public String call() throws InterruptedException {


                        if (newVersion==629) {

                            // todo таблица Chats
                            МетодСозданияТаблицаChats(ССылкаНаСозданнуюБазу);


                            // todo таблица Fio_Template
                            МетодСозданияТаблицыData_Chat(ССылкаНаСозданнуюБазу);


                            //таблица tabels   //таблица tabels   //таблица tabels   //таблица tabels  ///"_id  INTEGER    ," +
                            МетодСозданияТаблицыТабель(ССылкаНаСозданнуюБазу);



                            ///
                        }else {

                            if (newVersion > oldVersion) {


                                //TODo созадем таблицу сос старами ошибками
                                МетодСозданиеOLD_ТаблицыОшибок(ССылкаНаСозданнуюБазу);


                                // TODO: 08.06.2021 создание Базы Данных

                                onCreate(ССылкаНаСозданнуюБазу);
                                //



                            }

                        }


                        // TODO: 16.06.2021 будущее закрытие сервиса с потоками

                        completionServiceсозданиебазы.poll(20,TimeUnit.MINUTES);
                        //////////////////////////////////////

                        Log.i(this.getClass().getName(), "  Создана/Изменена База Данных !!! "+new Date());

                        return  "Создана новая база данных !!! ";
                    }
                });


    }




    @Override
    public void onDowngrade(SQLiteDatabase ССылкаНаСозданнуюБазу, int oldVersion, int newVersion) {
        onCreate(ССылкаНаСозданнуюБазу);
    }

    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
    public String ГлавнаяДатаИВремяОперацийСБазойДанных() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);
    }









    public void ОчисткаТаблицысЗаписьюВMODIFITATION_Client(String ИмяТаблицы,boolean ОчищатьПоЗначениюДлины){

        try {


            if (ОчищатьПоЗначениюДлины==true) {
                ССылкаНаСозданнуюБазу.execSQL("delete from " + ИмяТаблицы+" where length(uuid)>18");
            } else {
                ССылкаНаСозданнуюБазу.execSQL("delete from " + ИмяТаблицы+"");

            }
            Log.d(this.getClass().getName(), " сработала ...  очистка таблицы " + ИмяТаблицы);



            ContentValues contentValuesОчисткаТаблиц=new ContentValues();
            ///
            contentValuesОчисткаТаблиц.put("localversionandroid","1900-01-10 00:00:00");
            contentValuesОчисткаТаблиц.put("versionserveraandroid","1900-01-10 00:00:00");
            ////////
            long ОчисткаТаблиц=ССылкаНаСозданнуюБазу.update("MODIFITATION_Client", contentValuesОчисткаТаблиц, "name=?", new String[]{ИмяТаблицы}); ////вставка данных имя и пароль

            if(ОчисткаТаблиц>0){
                Log.d(this.getClass().getName(), " сработала ...  обнуление версии в MODIFITATION_Client для таблицы " + ИмяТаблицы);

            }




        } catch (SQLException e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new   КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }





    public void ОчисткаВнутреннейТаблицы(String ИмяТаблицы){

        try {

            ССылкаНаСозданнуюБазу.execSQL("delete from " + ИмяТаблицы+"");
            Log.d(this.getClass().getName(), " сработала ...  очистка таблицы " + ИмяТаблицы);



        } catch (SQLException e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
          new КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }

    public void ОчисткаТаблицДляПользователя(){

        try {
            if (!ССылкаНаСозданнуюБазу.inTransaction()) {
                ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


                // TODO: 19.03.2021 просто очистка таблиц без дат

                ОчисткаВнутреннейТаблицы("ErrorDSU1");
                ОчисткаВнутреннейТаблицы("SuccessLogin");
                ОчисткаВнутреннейТаблицы("settings_tabels");


                // TODO: 19.03.2021 разниза в том что таблицы ниже участвуют при обменен и им нужно устанивть пепрвоначальные даты после очистки

                ОчисткаТаблицысЗаписьюВMODIFITATION_Client("tabels",false);
                ОчисткаТаблицысЗаписьюВMODIFITATION_Client("notification",false);
                ОчисткаТаблицысЗаписьюВMODIFITATION_Client("date_work",false);
                ОчисткаТаблицысЗаписьюВMODIFITATION_Client("Fio_Template",false);
                ОчисткаТаблицысЗаписьюВMODIFITATION_Client("Templates",false);



            /*ОчисткаТаблицы("viewtabel");
            ОчисткаТаблицы("notification_insider");
*/


                /////todo встака данных по умолчанию


                ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                ССылкаНаСозданнуюБазу.endTransaction();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
         new   КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

                ССылкаНаСозданнуюБазу.endTransaction();

        }
    }


    // TODO: 08.06.2021 перед созданием делем Old копию базы данных

    private void МетодСозданиеOLD_ТаблицыОшибок(SQLiteDatabase ССылкаНаСозданнуюБазу) {
        try{
            ССылкаНаСозданнуюБазу.execSQL("drop table  if exists OLD_ErrorDSU1 ");//ТАБЛИЦА ГЕНЕРАЦИИ ОШИБОК
            ССылкаНаСозданнуюБазу.execSQL("Create table if not exists OLD_ErrorDSU1 (" +
                    "ID_Table_ErrorDSU1 INTEGER PRIMARY KEY AUTOINCREMENT  ," +
                    " Error TEXT    NOT NULL  ," +
                    "Klass TEXT NOT NULL ," +
                    "Metod TEXT NOT NULL," +
                    "LineError INTEGER NOT NULL ," +
                    "Data_Operazii_E NUMERIC NOT NULL ,"+
                    "whose_error INTEGER NOT NULL )");
            //
            ССылкаНаСозданнуюБазу.execSQL("INSERT INTO OLD_ErrorDSU1  (Error,Klass,Metod,LineError,Data_Operazii_E,whose_error) SELECT Error,Klass,Metod,LineError,Data_Operazii_E,whose_error FROM ErrorDSU1;");

            Log.d(this.getClass().getName(), " сработала ...  создание таблицы Old_ErrorDSU1 ");

        } catch (SQLException e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }

























}// конец public class CREATE_DATABASE extends SQLiteOpenHelper






































































































