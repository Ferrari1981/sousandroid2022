package com.dsy.dsu;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ClassActityty {
    public ClassActityty(Activity activity) throws ExecutionException, InterruptedException {

        Log.d(this.getClass().getName(), " ClassActitytyClassActityty  ");
        Toast.makeText(activity, "вы зашли в класс через преданный контет класа.", Toast.LENGTH_SHORT).show();


        Future<Boolean> dddd = Executors.newSingleThreadExecutor().submit(new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                Log.d(this.getClass().getName(), " Executors.newWorkStealingPool(). ClassActitytyClassActityty  ");
                return true;

            }

        });
    Boolean hh=    dddd.get();
        dddd.cancel(false);
        Log.d(this.getClass().getName(), " CompletionService  ClassActitytyClassActityty  "+hh);

    }
    void modd(){
        Log.d(this.getClass().getName(), "  modd ClassActitytyClassActityty  ");
    }
}
