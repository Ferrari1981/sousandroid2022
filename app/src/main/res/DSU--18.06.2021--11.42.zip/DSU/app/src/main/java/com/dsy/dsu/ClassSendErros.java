package com.dsy.dsu;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import java.util.Date;

public class ClassSendErros {
    Activity contextПосылаепмВставку;
    public ClassSendErros(Activity activity) {
        contextПосылаепмВставку=activity;
    }

    void МетодПослываемОшибкиАдминистаторуПо(StringBuffer ЗаписьОшибковВстврочку) {
        try{


            // TODO: 11.05.2021  почта для ошибок
           /// errorstimekeeping@gmail.com


            Intent i = new Intent(Intent.ACTION_SEND);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.setData(Uri.parse("mailto::errorstimekeeping@gmail.com"));
            i.setType("message/rfc822");
            //i.setType("text/html");
           i.putExtra(Intent.EXTRA_CC, new String[] { "errorstimekeeping@gmail.com"});
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
           i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"errorstimekeeping@gmail.com"});
            i.putExtra(Intent.EXTRA_SUBJECT, "Ошибки посылаем Администатору ПО Табельный  Учёт");
            i.putExtra(Intent.EXTRA_TEXT   ,ЗаписьОшибковВстврочку.toString());

            try {

                    contextПосылаепмВставку. startActivity(Intent.createChooser(i, "Отправка на Почту......"));
                contextПосылаепмВставку.    finish();


            } catch (android.content.ActivityNotFoundException ex) {
            }

        //ловим ошибку
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e( КлассВставкиОшибок.class.getClass().getName(), "Ошибка в самом классе создание ОШИБКА" + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        //закрытие классса и метода
    }
    }
}
