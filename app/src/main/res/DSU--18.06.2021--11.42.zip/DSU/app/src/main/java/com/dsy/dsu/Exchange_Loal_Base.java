package com.dsy.dsu;
import android.app.Activity;
import android.content.AsyncTaskLoader;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.widget.TextView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;

import static com.dsy.dsu.MainActivity_Sinfrozisaziy_Prograssbar.ТекстВидBarСинх;
public class Exchange_Loal_Base  extends CREATE_DATABASE {

    public Exchange_Loal_Base(Context context) {
        super(context);
    }

    public Cursor Get_Table (String Name){
        Cursor Cur = null;

        // "SELECT * FROM Name"

        return Cur;
    }

    public Cursor Get_FIO_by_UUID (long UUID){
        Cursor Cur = null;

        // "SELECT * FROM fio where UUID=?"

        return Cur;
    }

}





