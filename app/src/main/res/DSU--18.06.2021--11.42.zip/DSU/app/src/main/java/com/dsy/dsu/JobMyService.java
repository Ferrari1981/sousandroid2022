package com.dsy.dsu;

import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.AsyncTaskLoader;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class JobMyService extends JobService {
    public JobMyService() {
    }


    @Override
    public boolean onStartJob(JobParameters params) {

        Log.d(this.getClass().getName(), "СЛУЖБА JOb onStartJob "+new Date());
        Toast.makeText(getApplicationContext(), "СЛУЖБА  JOb onStartJob "+new Date(), Toast.LENGTH_SHORT).show();

////////////////////


        /////////////////////
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {

        Log.d(this.getClass().getName(), "СЛУЖБА  JOb onStopJob  "+new Date());
        Toast.makeText(getApplicationContext(), "СЛУЖБА  JOb onStopJob "+new Date(), Toast.LENGTH_SHORT).show();



        return false;
    }
}