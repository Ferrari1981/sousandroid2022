package com.dsy.dsu;

import android.app.Activity;
import android.content.AsyncTaskLoader;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.core.graphics.PathUtils;
import androidx.navigation.NavOptionsDsl;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.ToDoubleBiFunction;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;




///////Универсальный Класс Обмена Данными  Два Стачичных Метода и Плюс Сттичный Курсор
public class MODEL_synchronized extends CREATE_DATABASE {

    ///////

    /////TODO ОБЬЕДИНЕННЫЙ КОНТЕ

    static Context КонтекстСинхроДляМодели;

    MODEL_synchronized ссылка_MODELsynchronized = null;

    public MODEL_synchronized(Context context) {
        super(context);
        //TODO контроль потоков


    }
    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET    //#GET


    ///МЕТОД ПОЛУЧЕНИЕ ДАННЫХ С СЕРВЕРА
    StringBuffer УниверсальныйБуферПолучениеДанныхсСервера(String ПУбличныйИмяТаблицыОтАндройдаВнутриПотока,
                                                           String КонкретнаяТаблицаВПотокеВнутриПотока,
                                                           String МакАдресТелефонаВнутриПотока,
                                                           String ТипОтветаTEXTилиJSONВнутриПотока,
                                                           String ЗаданиеДляСервлетаВнутриПотока,
                                                           String ДатаНаДанныеВнутриПотока,
                                                           String IDДляПолучениеКонткртнойНабораТаблиц) throws IOException, ExecutionException, InterruptedException, TimeoutException, NoSuchAlgorithmException, KeyManagementException {

        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ
        // AsyncTask AsyncTaskУнивермальныйДляОбмена=null;

        HttpURLConnection ПодключениеИнтернетДляОтправкиНаСервер = null;
        ///

        StringBuffer  БуферПолученнниеДанныхОтМетодаGETУниверсальныйБуферПолучениеДанныхсСервера = new StringBuffer();



        System.out.println("УниверсальныйБуферПолучениеДанныхсСервера");
        ////////перевод перменных внутрь Анисакска
        ///////// ПРИ НУЛЕВОМ ЗАПУСКЕ ЛОВИМ ЭТОТ МОМЕНТ ДАТОЙ ИЗ ТАБЛИЦЫ АНДОЙД
        //////КОНЕЦ ЛОВЛИ НУЛОЙ ДАТЫ ТАБЛИЦЫ
        Object ОшибкаТекущегоМетода=new Object();

        ///
        ReentrantLock reentrantLockУниверсальныйБуферПолучениеДанныхсСервера=new ReentrantLock();
        ////
        try {
            ////
            reentrantLockУниверсальныйБуферПолучениеДанныхсСервера.lock();

            String Adress_String = new String();
            ////
            String Params= new String();
            ////
            // Adress_String = "http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet";///СТРОЧКА УКАЗЫВАЕТ НА КАКОЙ СЕРВЕЛ НА СЕРВЕР МЫ БУДЕМ СТУЧАТЬСЯ /// 80.66.149.58
            Adress_String = PUBLIC_CONTENT.ПубличныйАдресGlassFish + "dsu1.glassfish/DSU1JsonServlet";///СТРОЧКА УКАЗЫВАЕТ НА КАКОЙ СЕРВЕЛ НА СЕРВЕР МЫ БУДЕМ СТУЧАТЬСЯ /// 80.66.149.58
            Params = "?" + "ИмяТаблицыОтАндройда= " + ПУбличныйИмяТаблицыОтАндройдаВнутриПотока + "&" + "КонкретнаяТаблицаВПотоке=" + КонкретнаяТаблицаВПотокеВнутриПотока + ""
                    + "&" + "МакАдресТелефона=" + МакАдресТелефонаВнутриПотока + "" +
                    "&" + "ЗаданиеДляСервлетаВнутриПотока=" + ЗаданиеДляСервлетаВнутриПотока + "" + "&" + "ДатаНаДанныеВнутриПотока=" + ДатаНаДанныеВнутриПотока + ""
                    + "&" + "IDДляПолучениеКонткртнойНабораТаблиц=" + IDДляПолучениеКонткртнойНабораТаблиц + "";
            Log.d(this.getClass().getName(), " Params" + Params);

            ///////////
            Adress_String = Adress_String + Params;
            Log.d(this.getClass().getName(), "Adress_String " + Adress_String);

            ////
            Adress_String = Adress_String.replace(" ", "%20");
            ///
            Log.d(this.getClass().getName(), " Adress_String " +Adress_String);


            // TODO: 25.05.2021  адереса

            URL  Adress = new URL(Adress_String);
            //
            ПодключениеИнтернетДляОтправкиНаСервер = (HttpURLConnection) (Adress).openConnection();/////САМ ФАЙЛ JSON C ДАННЫМИ
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty("Content-Type", ТипОтветаTEXTилиJSONВнутриПотока + " ;charset=UTF-8");
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty("Accept-Encoding", "gzip,deflate,sdch");
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty("Connection", "Keep-Alive");
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty("Accept-Language", "ru-RU");
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestMethod("GET"); ///GET //ПРОВЕРЯЕМ ЕСЛИ ПОДКЛЮЧЕНИЕ К СЕВРЛЕТУ НА СЕРВЕР ВЫБРАСЫВАЕМ
            ПодключениеИнтернетДляОтправкиНаСервер.setReadTimeout(15000); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ(30000);
            ПодключениеИнтернетДляОтправкиНаСервер.setConnectTimeout(1000);//todo САМ ПОТОК ДАННЫХ(1000);
            ПодключениеИнтернетДляОтправкиНаСервер.setUseCaches(true);
            //////////
            Log.d(this.getClass().getName(), "  PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета  " +PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета+
                    " PUBLIC_CONTENT.ПубличноеПарольДлСервлета " +PUBLIC_CONTENT.ПубличноеПарольДлСервлета);
            /////
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty(PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета, PUBLIC_CONTENT.ПубличноеПарольДлСервлета);

            ПодключениеИнтернетДляОтправкиНаСервер.connect(); /////////////ТОЛЬКО СОЕДИНЕНИЕ

            ПодключениеИнтернетДляОтправкиНаСервер.getResponseCode();///ВАЖНАЯ КОМАНДА  СТУЧИТЬСЯ В СЕРВЛЕТ ECLIPSE СТУЧИМСЯ ВТОРОЙ РАЗ ЧТОБЫ ПОЛУЧИТЬ УЖЕ САМ JSON

            ПодключениеИнтернетДляОтправкиНаСервер.getContent(); ////РЕАЛЬНОЕ ПОЛУЧЕНИЕ ДАННЫХ С ИНТРЕНЕТА


//




            Log.d(this.getClass().getName(), "ПодключениеИнтернетДляОтправкиНаСервер.getContentLength() "+ПодключениеИнтернетДляОтправкиНаСервер.getHeaderField("stream_size"));

            Long РазмерПришедшегоПотока=Long.parseLong(ПодключениеИнтернетДляОтправкиНаСервер.getHeaderField("stream_size"));

            Log.d(this.getClass().getName(), "РазмерПришедшегоПотока "+РазмерПришедшегоПотока);

            ////TODO И ЕСЛИ ПРИШЕЛ ОТ СЕРВЕРА ОТВЕТ ПОЛОЖИТЕЛЬНО ТО ТОГДА ЗАПУСКАМ ПРОЧТЕНИЯ ПОТОКА ПРИШЕДШЕГО С СЕРВЕРА
            if (ПодключениеИнтернетДляОтправкиНаСервер.getResponseCode() == 200 && РазмерПришедшегоПотока>0) {
                //TODO шифровани
                // Log.d(this.getClass().getName(), "  ПолитикаРасшифровки  " +PUBLIC_CONTENT. ПолитикаРасшифровки);



                    Log.d(MODEL_synchronized.class.getName(), "  СЛУЖБА СИНХРОНИЗАЦИИ РАЗМЕР ПОТОКА КОТОРЫЙ ПРИШЁЛ ... " + "\n"+
                            " КонкретнаяТаблицаВПотокеВнутриПотока " +КонкретнаяТаблицаВПотокеВнутриПотока+"\n"+
                            " ПодключениеИнтернетДляОтправкиНаСервер.getContentLength()  " +ПодключениеИнтернетДляОтправкиНаСервер.getHeaderField("stream_size"));//  "   ПодключениеИнтернетДляОтправкиНаСервер.getHeaderField(Content-Length "+

                // ПодключениеИнтернетДляОтправкиНаСервер.getHeaderField("Content-Length").length()

                CipherInputStream GZIPПотокОтСЕРВЕРА=null;
                ///
                BufferedReader РидерОтСервераМетодаGET=null;


                try{
                    //////тест шифрование
                    GZIPПотокОтСЕРВЕРА = new CipherInputStream(new GZIPInputStream(ПодключениеИнтернетДляОтправкиНаСервер.getInputStream()), PUBLIC_CONTENT.ПолитикаРасшифровки);
                    ///// todo получаем данные с сервера
                    //GZIPInputStream GZIPПотокОтСЕРВЕРА = new GZIPInputStream(ПодключениеИнтернетДляОтправкиНаСервер[0].getInputStream(),Deflater.BEST_COMPRESSION);///byte[] data = new byte[512];
                    РидерОтСервераМетодаGET = new BufferedReader(new InputStreamReader(GZIPПотокОтСЕРВЕРА, StandardCharsets.UTF_16));//



                    ////////
                    ////

                } catch (IOException ex) {
                    ex.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(MODEL_synchronized.class.getName(), "Ошибка " + ОшибкаТекущегоМетода + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber()+ " ОшибкаТекущегоМетода " +ОшибкаТекущегоМетода.toString());
                    new    КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(ex.toString(), MODEL_synchronized.class.getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                }

                ////

                int РазмерБуфера = 8192;///// 8192;  ///РидерОтСервераМетодаGET.toString().toCharArray().length ;//////8192;// РидерОтСервераМетодаGET.toString().toCharArray().length; ///8192


                ///
                Log.d(this.getClass().getName(), " РазмерБуфера"+ РазмерБуфера);/////



                int ФлагНекончильсяЛиПотокДанных=0;

                char[] СамБУфер = new char[РазмерБуфера];
                ///TODO  цикл
                try{

                    do {
                        ФлагНекончильсяЛиПотокДанных = РидерОтСервераМетодаGET.read(СамБУфер);
                        if (ФлагНекончильсяЛиПотокДанных < 0) {

                            ////
                            break;
                        }
                        // TODO: 14.05.2021 получаем данные с сервера

                        if (ФлагНекончильсяЛиПотокДанных>0) {

                            // TODO: 03.06.2021 заполение данными от сервер аот на положительные вставки и обновление
                            БуферПолученнниеДанныхОтМетодаGETУниверсальныйБуферПолучениеДанныхсСервера.append(СамБУфер, 0, ФлагНекончильсяЛиПотокДанных);
                        }


                    } while (true);


                    ////
                    ///
                    Log.d(this.getClass().getName(), " БуферПолученнниеДанныхОтМетодаGETУниверсальныйБуферПолучениеДанныхсСервера.toString()"+ БуферПолученнниеДанныхОтМетодаGETУниверсальныйБуферПолучениеДанныхсСервера.toString());/////

                    if (БуферПолученнниеДанныхОтМетодаGETУниверсальныйБуферПолучениеДанныхсСервера!=null &&
                            БуферПолученнниеДанныхОтМетодаGETУниверсальныйБуферПолучениеДанныхсСервера.toString().length()>0) {
                        ///
                        /////НАЗВАНИЕ ПОТОКА
                        Log.i(this.getClass().getName(), "НАЗВАНИЕ ПОТОКА В aSYNSTASK " + Thread.currentThread().getName().toUpperCase() + " БуферПолученнниеДанныхОтМетодаGET "
                                + БуферПолученнниеДанныхОтМетодаGETУниверсальныйБуферПолучениеДанныхсСервера.toString());
                    }


                } catch (IOException ex) {
                    ex.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(MODEL_synchronized.class.getName(), "Ошибка " + ОшибкаТекущегоМетода + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber()+ " ОшибкаТекущегоМетода " +ОшибкаТекущегоМетода.toString());
                    new    КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(ex.toString(), MODEL_synchronized.class.getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                }finally {
                    /////togo закрывает приходящие потоки от сервера

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                        ///TODO закрываем метод получение данных
                        if (РидерОтСервераМетодаGET!=null) {
                            ///
                            РидерОтСервераМетодаGET.close();
                        }
                        ///////
                        if (GZIPПотокОтСЕРВЕРА!=null) {
                            ///
                            GZIPПотокОтСЕРВЕРА.close();
                        }
                    }else {

                        ///TODO закрываем метод получение данных
                        if (РидерОтСервераМетодаGET!=null) {
                            /////
                            РидерОтСервераМетодаGET.close();
                        }
                    }

                    // TODO: 14.05.2021 закрываем соединение после получения данных с сервера




                }




                ////TODO нет ответа от сервер или поток нулевой
            }else{
                Log.i(this.getClass().getName(), "ПОТОК ПРИШЕЛ НУЛОВОЙ ОТ СЕРВЕРА  " +ПодключениеИнтернетДляОтправкиНаСервер.getInputStream().available());
            }




        } catch (IOException ex) {
            ex.printStackTrace();
            ///метод запись ошибок в таблицу
            ОшибкаТекущегоМетода = ex.toString();

            if(!ex.toString().trim().equals("java.io.EOFException") && !ex.toString().trim().equals("java.net.SocketTimeoutException: timeout")){


                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + ОшибкаТекущегоМетода + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber()+ " ОшибкаТекущегоМетода " +ОшибкаТекущегоМетода.toString());
                new    КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(ex.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            }

        }finally {
            // TODO: 03.06.2021 зарытоваем метод получение лданных

            ПодключениеИнтернетДляОтправкиНаСервер.disconnect();

            reentrantLockУниверсальныйБуферПолучениеДанныхсСервера.lock();

        }



        //// todo get ASYNtASK
        return (StringBuffer)   БуферПолученнниеДанныхОтМетодаGETУниверсальныйБуферПолучениеДанныхсСервера;

    }

























///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST///#POST


    ///////метод ОТПРАВКИ ДАННЫХ НА СЕРВЕР
    StringBuffer УниверсальныйБуферОтправкиДанныхНаСервера( @NonNull JSONObject СгенерированыйФайлJSONДляОтправкиНаСервер,
                                                            String ПУбличныйИмяТаблицыМетодPOST,
                                                            String ПубличноеИмяПользовательМетодPOST,
                                                            String ЗаданиеДляСервлета

    ) throws IOException, ExecutionException, InterruptedException, TimeoutException {

        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        ///
        Log.d(MODEL_synchronized.class.getName(), " СгенерированыйФайлJSONДляОтправкиНаСервер.length() " + СгенерированыйФайлJSONДляОтправкиНаСервер.toString().length());

        StringBuffer БуферПолученнниеДанныхОтМетодаPOST = new StringBuffer();

        HttpURLConnection ПодключениеИнтернетДляОтправкиНаСервер = null;

        System.out.println(" УниверсальныйБуферОтправкиДанныхНаСервера");
        ////////перевод перменных внутрь Анисакска

        String ОшибкаТекущегоМетода=new String();

        ReentrantLock reentrantLockУниверсальныйБуферОтправкиДанныхНаСервера=new ReentrantLock();


        try {
            reentrantLockУниверсальныйБуферОтправкиДанныхНаСервера.lock();

            /////
            String Adress_String=new String();
            // String Adress_String = "http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet";
            Adress_String =PUBLIC_CONTENT. ПубличныйАдресGlassFish + "dsu1.glassfish/DSU1JsonServlet";

            // TODO: 25.05.2021
            String Params=new String();

            Params = "?" + "ИмяТаблицыОтАндройда=" +ПубличноеИмяПользовательМетодPOST  + "&" + "СотрудникТаблицыОтАндройда=" + ПУбличныйИмяТаблицыМетодPOST +
                    "&" + "ЗаданиеДляСервлетаВнутриПотока=" + ЗаданиеДляСервлета + "";
            Adress_String = Adress_String + Params;


            ////
            Adress_String = Adress_String.replace(" ", "%20");
            ///
            Log.d(this.getClass().getName(), " Adress_String " +Adress_String);


            URL Adress = new URL(Adress_String);
            Log.d(this.getClass().getName(), " Adress  " + Adress);

            ///TODO ПОДКЛЮЧЕНИЕ К СЕРВЛЕТУ С СЕРВЕРУ ДСУ-1
            ПодключениеИнтернетДляОтправкиНаСервер = (HttpURLConnection) (Adress).openConnection();/////САМ ФАЙЛ JSON C ДАННЫМИ
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty("Content-Type", "application/json ;charset=UTF-8");
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty("Accept-Encoding", "gzip,deflate,sdch");
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty("Connection", "Keep-Alive");
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty("Accept-Language", "ru-RU");
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestMethod("POST"); ///GET //ПРОВЕРЯЕМ ЕСЛИ ПОДКЛЮЧЕНИЕ К СЕВРЛЕТУ НА СЕРВЕР ВЫБРАСЫВАЕМ
            ПодключениеИнтернетДляОтправкиНаСервер.setReadTimeout(15000); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ(30000);
            ПодключениеИнтернетДляОтправкиНаСервер.setConnectTimeout(1000);//todo САМ ПОТОК ДАННЫХ(1000);
            ПодключениеИнтернетДляОтправкиНаСервер.setUseCaches(true);

            ///////
            ///////
            Log.i(this.getClass().getName(), " PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета " + PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета+
                    " PUBLIC_CONTENT.ПубличноеПарольДлСервлета   "+ PUBLIC_CONTENT.ПубличноеПарольДлСервлета);
            ///TODO И ПАРОЛЬ
            ПодключениеИнтернетДляОтправкиНаСервер.setRequestProperty(PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета,
                    PUBLIC_CONTENT.ПубличноеПарольДлСервлета);
            //TODO КОНЕКТИМСЯ С СЕРВЕРОМ ИМЕНЕМ И ПАРОЛЕМ
            ПодключениеИнтернетДляОтправкиНаСервер.connect();
            /////////



            //////TODO ОТПРАВЛЕМ ДАННЫЕ НА СЕРВЕР ЕЛСИ ДАННЫЕ НОВЫЕ КАК ОТПАРВЯЕМ ТО ОБНЦЛЕМ БУФЕР С JSON АГА !!!!
            if (СгенерированыйФайлJSONДляОтправкиНаСервер.toString().length() > 0) { //////ОТПРАВЛЕМ ДАННЫЕ НА СЕРВЕР ЕЛСИ ДАННЫЕ НОВЫЕ КАК ОТПАРВЯЕМ ТО ОБНЦЛЕМ БУФЕР С JSON АГА !!!!
                //#2 ///СОЗДАЕМ СТРИМ ДЛЯ ОТПРАВКИ НА СЕРВЕР WEB ДСУ-1 , StandardCharsets.UTF_16) ,Charset.forName("UTF-16"))
                //BufferedWriter БуферПосылаемМетодуPOSTJSONФайл = null;/// ОТПРАВКА JSON НА СЕРВЕР


                CipherOutputStream GZIPПотокаДляОтправкиНаСервер =null;
                ///
                BufferedWriter       БуферПосылаемМетодуPOSTJSONФайл =null;

                try{


                    //TODO шифровани ОТПРАВЛЕМ НА СЕРВЕР ЗАШИФРОВАНЫЕ
                    GZIPПотокаДляОтправкиНаСервер = new CipherOutputStream(new GZIPOutputStream(ПодключениеИнтернетДляОтправкиНаСервер.getOutputStream()), PUBLIC_CONTENT.ПолитикаШифрование);
                    //////
//////TODO GZIP ФАЙЛ ОТПРАВЛЯЕМ НА СЕРВЕР метод POST
                    // GZIPOutputStream GZIPПотокаДляОтправкиНаСервер = new GZIPOutputStream(ПодключениеИнтернетДляОтправкиНаСервер[0].getOutputStream(),Deflater.BEST_COMPRESSION);
                    //   GZIPПотокаДляОтправкиНаСервер.flush();



                    int СмещениеБуфера = 0;
                    int ОбщийРазмерЗаписываемогоФайла = СгенерированыйФайлJSONДляОтправкиНаСервер.toString().toCharArray().length;

                    ////todo создаени буфера
                    БуферПосылаемМетодуPOSTJSONФайл = new BufferedWriter(new OutputStreamWriter(GZIPПотокаДляОтправкиНаСервер, StandardCharsets.UTF_16),ОбщийРазмерЗаписываемогоФайла);
                    ////// сам цикл

                    ////буфер
                    // TODO: 03.06.2021  сама запись


                    ////// ОТПРАВЛЯЕМ САМИ ДАННЫЕ НА КЛИЕНТ JSON

                    ///
                    БуферПосылаемМетодуPOSTJSONФайл.write(СгенерированыйФайлJSONДляОтправкиНаСервер.toString(), 0,ОбщийРазмерЗаписываемогоФайла);/// ЗАПИСЫВАЕМ В ПОТОК



                    /////TODO

                    //РАБОТАЕТ ПОКА НЕ РАВНО ПО РАЗМЕРУ
                    /////TODO
                    //TODO ЗАКРЫВАЕТ ПОТОКИ КОТОРЫЕ ОТПРАВИЛИ НА СЕРВЕР  от клиента послем на сервер

                    БуферПосылаемМетодуPOSTJSONФайл.flush();///ПРОТАЛКИВАЕМ О
                    ////
                    if (СгенерированыйФайлJSONДляОтправкиНаСервер!=null) {
                        ///
                        Log.i(this.getClass().getName(), " СгенерированыйФайлJSONДляОтправкиНаСервер.toString() " + СгенерированыйФайлJSONДляОтправкиНаСервер.toString());
                    }
                    /////закрыть
                    /////TODO
                    /////TODO



                    /////
                } catch (IOException ex) {
                    ex.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(MODEL_synchronized.class.getName(), "Ошибка " + ex + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(ex.toString(), MODEL_synchronized.class.getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }finally {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                        if (GZIPПотокаДляОтправкиНаСервер!=null) {
                            ///
                            GZIPПотокаДляОтправкиНаСервер.close();
                        }
                        /////
                        if (БуферПосылаемМетодуPOSTJSONФайл!=null) {
                            /////
                            БуферПосылаемМетодуPOSTJSONФайл.close();///ЗАКРАВАЕМ ПОТОК
                        }
                    }else {

                        /////
                        if (БуферПосылаемМетодуPOSTJSONФайл!=null) {
                            ////
                            БуферПосылаемМетодуPOSTJSONФайл.close();///ЗАКРАВАЕМ ПОТОК
                        }
                    }



                }





                //TODO второй ПОЛУЧАЕМ ОТВЕТ работат с сервером получение данных от сервре о положительный обновлений и встакок и стату сОтпрвленный метод POST
                /////////
                ПодключениеИнтернетДляОтправкиНаСервер.getResponseCode();///ЩЕЛКАЕМ КОННЕКТ ЧТОБЫ ОБРАТНО ПРИШЕЛ ОТВЕТ ОТ СЕРВЕРА
                /////////
                ПодключениеИнтернетДляОтправкиНаСервер.getContent();
            }


            // TODO: 15.06.2021  вторая часть метода отпарвки данных
            Log.d(this.getClass().getName(), "ПодключениеИнтернетДляОтправкиНаСервер.getContentLength() "+ПодключениеИнтернетДляОтправкиНаСервер.getHeaderField("stream_size"));

            Long РазмерПришедшегоПотока=Long.parseLong(ПодключениеИнтернетДляОтправкиНаСервер.getHeaderField("stream_size"));

            Log.d(this.getClass().getName(), "РазмерПришедшегоПотока "+РазмерПришедшегоПотока);



            ///////TODO ФИНАЛЬНАЯ ОПЕРАЦИЯ ОТВЕТ ТТ СЕРВЕЛТА С ПОЛОЖИТЕЛЬНЫМИ И ЛИИ ВСТВКАМИ ИЛИ ОБНОВЛЕНИЕ ОТ СЕРВЕРА ДЛЯ АНАЛИЗА В  ВСТАВКИ В БАЗУ КАК СТАТУС ОТПРАВЛЕННЫЙ
            if (ПодключениеИнтернетДляОтправкиНаСервер.getResponseCode() == 200 && РазмерПришедшегоПотока>0) {
                ///////////
                //GZIPInputStream  GZIPПодключениеИнтернетДляОтправкиНаСервер=new  GZIPInputStream(ПодключениеИнтернетДляОтправкиНаСервер[0].getInputStream());
                Log.i(this.getClass().getName(), " ПодключениеИнтернетДляОтправкиНаСервер[0].getResponseCode() " + ПодключениеИнтернетДляОтправкиНаСервер.getResponseMessage()+"\n"+
                        " \"ПодключениеИнтернетДляОтправкиНаСервер.getContentLength() " +ПодключениеИнтернетДляОтправкиНаСервер.getHeaderField("stream_size") );


                ///

                CipherInputStream GZIPПодключениеИнтернетДляОтправкиНаСервер =null;
                ////
                BufferedReader БуферОтветОтМетодаPOSTЕслиОбновлениеИлиВставка =null;


                try{
                    ///


                    // TODO  ОТ ОТ СЕРВЕРА МЕТОД POST разшифрование потока который пришел от сервера с поличжительными результатами вствко и обновлений чтобы в базу вписать статус Отправленный
                    GZIPПодключениеИнтернетДляОтправкиНаСервер = new CipherInputStream(new GZIPInputStream(ПодключениеИнтернетДляОтправкиНаСервер.getInputStream()), PUBLIC_CONTENT.ПолитикаРасшифровки);
                    ////
                    //////после получения отключаемся
                    БуферОтветОтМетодаPOSTЕслиОбновлениеИлиВставка = new BufferedReader(new InputStreamReader(GZIPПодключениеИнтернетДляОтправкиНаСервер,
                            StandardCharsets.UTF_16));
                    ///ПОЛУЧЕНИЕ В ОТВЕТ ОТ СЕРВЕРА КАКИЕ ЗАПИСЬ КОНКРЕТНО ВСТАВЛИЛИ А КАКИЕ ОБНОЛВИЛИСЬ МЕТОД POST
//////////////////БАЙТОВЫЙ РИДЕР ИЗ СЕРВЕРА
                    int РазмерБуфера =8192;   ////// 8192;
                    ////


                    int ФлагНекончильсяЛиПотокДанных=0;
                    ////
                    char[] СамБУфер = new char[РазмерБуфера];

                    // TODO: 01.06.2021 цикл буферит

                    do {
                        ФлагНекончильсяЛиПотокДанных = БуферОтветОтМетодаPOSTЕслиОбновлениеИлиВставка.read(СамБУфер);


                        //////
                        if (ФлагНекончильсяЛиПотокДанных < 0) {
                            break;
                        }



                        // TODO: 13.05.2021 получаем ответ от сервер произошда вставкка данных от клиента или нет
                        БуферПолученнниеДанныхОтМетодаPOST.append(СамБУфер, 0, ФлагНекончильсяЛиПотокДанных);



                    } while (true);


// TODO: 11.06.2021  пришёл ответ
                    Log.d(this.getClass().getName(), "   БуферПолученнниеДанныхОтМетодаPOST.toString() "+БуферПолученнниеДанныхОтМетодаPOST.toString());





                    /////
                } catch (IOException ex) {
                    ex.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(MODEL_synchronized.class.getName(), "Ошибка " + ex + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(ex.toString(), MODEL_synchronized.class.getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }finally {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                        GZIPПодключениеИнтернетДляОтправкиНаСервер.close();
                        /////
                        БуферОтветОтМетодаPOSTЕслиОбновлениеИлиВставка.close();///ЗАКРАВАЕМ ПОТОК
                    }else {

                        /////
                        БуферОтветОтМетодаPOSTЕслиОбновлениеИлиВставка.close();///ЗАКРАВАЕМ ПОТОК
                    }



                }
            }




            /////
        } catch (IOException ex) {
            ex.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + ex + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(ex.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }finally {
            ////
            ПодключениеИнтернетДляОтправкиНаСервер.disconnect();
            //////
            reentrantLockУниверсальныйБуферОтправкиДанныхНаСервера.unlock();
        }

        return   (StringBuffer)  БуферПолученнниеДанныхОтМетодаPOST;

    }


//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR//# UNIVERSAL CURSOR






    //УНИВЕРСАЛЬНЫЙ КУРСОР С ПАРАМЕТРАМИ
    Cursor КурсорУниверсальныйДляБазыДанных(String таблица, String[] колонки, String фильтр, String[] условияфильтра, String групировка, String хэвинг, String ордербай, String лимиты)
            throws ExecutionException, InterruptedException, TimeoutException {
////




        ССылкаНаСозданнуюБазу = this.getWritableDatabase();



        ////
        Cursor  Курсор_Универсальный = null;
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        Log.i(this.getClass().getName(), "  колонки " + колонки.length);
        try {
            ////TODO сам курсор универсальный
            Курсор_Универсальный = ССылкаНаСозданнуюБазу.query(true,таблица, колонки, фильтр, условияфильтра, групировка, хэвинг, ордербай, лимиты); //todo включен dictict
            /////НАЗВАНИЕ ПОТОКА

            Log.i(this.getClass().getName(), "НАЗВАНИЕ ПОТОКА В aSYNSTASK " + Thread.currentThread().getName().toUpperCase()
                    + " Курсор_Универсальный строчки :   " + Курсор_Универсальный.getCount() + " Курсор_Универсальный колонки  : "
                    + Курсор_Универсальный.getColumnCount() + "  таблица " + таблица);
////
        } catch (Exception e) {///////ошибки
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


        //// todo get ASYNtASK
        return Курсор_Универсальный;
    }


    //TODO УНИВЕРСАЛЬНЫЙ КУРСОР  БЕЗ ПАРАМЕТРАМИ


    Cursor КурсорУниверсальныйБазыДанных(String ПишемЧистыйSQL) throws ExecutionException, InterruptedException, TimeoutException {
        ////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        ////

        ССылкаНаСозданнуюБазу = this.getWritableDatabase();




        System.out.println(" КурсорУниверсальныйБазыДанных , null");
        Cursor Курсор_Универсальный = null;
        String ОшибкаТекущегоМетода;
        //  Cursor cursor = db.rawQuery("SELECT name, amount FROM accounts WHERE name = ?", new String[]{"Lucy"});
        try {
            Курсор_Универсальный = ССылкаНаСозданнуюБазу.rawQuery(ПишемЧистыйSQL, null);
            /////НАЗВАНИЕ ПОТОКА
            Log.i(this.getClass().getName(), "НАЗВАНИЕ ПОТОКА В aSYNSTASK " + Thread.currentThread().getName().toUpperCase());
            /////
        } catch (Exception e) {///////ошибки
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            ОшибкаТекущегоМетода = e.toString();
            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

        //// todo get ASYNtASK
        return Курсор_Универсальный;

    }













    ////--- TODO ТУТ НАХОДЯТЬСЯ КОНТЕРЙНЕРЫ ДЛЯ ВСТАВКИ И ОБНОВЛЕНИИ ДАННЫХ  ЧЕРЕЗ КОНТЕЙНЕРЫ


    ///////// TODO УНИВЕРСАЛЬНЫЙ МЕТОД ВСТАВКИ ДАННЫХ
    Long ВставкаДанныхЧерезКонтейнерУниверсальная(String ТаблицаКудаВставляем, ContentValues КонтейнерДляВставки, String ИмяТаблицыОтАндройда_Локальноая,
                                                  String ПолученнаяДатаДляПониманияДатуСейчасВставляетьИлиНет,
                                                  boolean ФлагОбновлятьДатуВерсииДанных,int    ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON,
                                                  boolean СинхронизациюВизуализировать,Context  КонтекстСинхроДляКонтроллера)
            throws ExecutionException, InterruptedException, TimeoutException {
        ///////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ
        long  Результат_ВставкиДанных = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;
/////


        try {

            ///
            ССылкаНаСозданнуюБазу = this.getWritableDatabase();


            if (!ССылкаНаСозданнуюБазу.inTransaction()) {
                ///
                ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


/////


                /////
                //////САМА ВСТАВКА ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                Результат_ВставкиДанных = ССылкаНаСозданнуюБазу.insert(ТаблицаКудаВставляем, null, КонтейнерДляВставки);
                ///////todo результат вставки

                ///////
                //////
                if (Результат_ВставкиДанных > 0) {
                    ////успешная вставка данных
                    ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                    ///TODO ПЕРВАЯ ТРАНЗАКЦИЯ

                    ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ


                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();



                    ///
                    КонтейнерДляВставки.clear();
                    Log.d(this.getClass().getName(), " Результат_ВставкиДанных   " + Результат_ВставкиДанных);

                    //метод анализируем стоит ли вставлять дату сейчас в таблицу модификацию версия данных локального
                    ////////вторая часть операции после успешной вствки изменяем данные на дабоавляем дату в таблицу модификаци  клиент
                    //////TODO ВАЖВАНО ПЕРВЫЙ ЗАПУСК БАЗЫ ВСЕГОДА FALSE ДЛЯ ПОНИМАНИЯ ЕСЛИ ЭТО НУЛЕВОЙ ЗАПУСК ТО НЕ НАДО В ТАБЛИЦУК МОДИФИКАФЕН КЛИЕНТ ВСТАЯЛТЬ ДАТУ СЕЙЧАС

                }


                ССылкаНаСозданнуюБазу.endTransaction();
            }


            ///////////TODO визуализация даных по строчно из НИЖНЕГО ПОТОКА ПОДМИНИМАЕМСЯ НА ВЕРХ ОПЕРЦИЯ ВСТАВКА
            float ОбщееКоличествоСтрокВJSON = PUBLIC_CONTENT.СколькоСтрочекJSON;
            ////////

            int finalКоличествоУспешныхВставки = PUBLIC_CONTENT.КоличествоУспешныхВставки;


            if (СинхронизациюВизуализировать  && Результат_ВставкиДанных > 0 && ОбщееКоличествоСтрокВJSON>0 ){

                ///
                Log.d(MODEL_synchronized.class.getName(), " ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON " + ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON +
                        "   ПубличныйУниверсальныйИндификаторОбновленияиВставки  " + finalКоличествоУспешныхВставки);

                //////todo обработка внутри потока
                Log.d(this.getClass().getName(), " ПроцентыДляВизуализацииИхПриСинхронизации" + finalКоличествоУспешныхВставки + " ОбщееКоличествоСтрокВJSON " + ОбщееКоличествоСтрокВJSON);
                String ФиналПроцентыДляВизуализацииИхПриСинхронизации = null;



                //TODO считаем проценты от цифры
                float ФиналПроценты = (finalКоличествоУспешныхВставки / ОбщееКоличествоСтрокВJSON) * 100;

                ////
                ФиналПроценты = (float) Math.ceil(ФиналПроценты);
                ////
                ФиналПроцентыДляВизуализацииИхПриСинхронизации = String.valueOf(ФиналПроценты);
                ////TODO ищем Точку
                Log.d(this.getClass().getName(), "  ФиналПроцентыДляВизуализацииИхПриСинхронизации " + ФиналПроцентыДляВизуализацииИхПриСинхронизации);


                DecimalFormat decimalFormat = new DecimalFormat("#.#");


                //////TODO К ЦИФРЕ ДОБАВЛЯЕМ ЗНАЧЕК ПРОЦЕНТ %
                ФиналПроцентыДляВизуализацииИхПриСинхронизации = decimalFormat.format(ФиналПроценты) ;

                /////TODO СТАВИМ ОГРАНИЧЕНИЯ ПРОЦЕНТЫ НЕ ВЫШЕ 100 %
                int ФиналПроцентыДляВизуализацииИхПриСинхронизацииОгорниченияЦифра=Integer.valueOf(ФиналПроцентыДляВизуализацииИхПриСинхронизации);
                if(ФиналПроцентыДляВизуализацииИхПриСинхронизацииОгорниченияЦифра>100){
                    ////todo если процентов больше 100 %  уменьваем их принудтельно
                    ФиналПроцентыДляВизуализацииИхПриСинхронизации="100";
                }

                //todo удаляем ТОчку
                Log.d(this.getClass().getName(), "  ФиналПроцентыДляВизуализацииИхПриСинхронизации " + ФиналПроцентыДляВизуализацииИхПриСинхронизации);

                ////TODO вставка backcalls ВСТАВКА ФИНИАЛЬНЫЕ ПРОЦЕНТЫ

                final String ВозвратВПотокЗначенияСнизу = ФиналПроцентыДляВизуализацииИхПриСинхронизации+ " %";
                //TODO ПОСЫЛАЕМ ВВЕРХ ПО ПОТОКУ

                Log.d(this.getClass().getName(), " ВозвратВПотокЗначенияСнизу " + ВозвратВПотокЗначенияСнизу);
                //////TODO выводими обратно в UI вставка
                ((Activity)  КонтекстСинхроДляКонтроллера).runOnUiThread(new Runnable() {
                    public void run() {

                        ///TODO ВСТАВКА
                        if (ВозвратВПотокЗначенияСнизу.matches("[0-9].*")) {
                            //////////TODO ВСТАВКА ПРОЦЕНТОВ ПРИ ВСТАВКЕ
                            MainActivity_Sinfrozisaziy_Prograssbar. ТекстВидBarСинх.setText(ВозвратВПотокЗначенияСнизу.trim());
                        }
                        //////

                        ///////TODO обработкаи  ГОризонтального PrograssBARA

                        /////TODO ДЛЯ ТЕКСТА ПОКАЗЫВАЕМ КОЛИЧЕСТВРО
                         /*Toast.makeText(Публичный_КонтекстДляСинхронизацииОбмена, " Проценты Вставки %   " +ВозвратВПотокЗначенияСнизу +
                                 " Количество Успешных Вставок :  " +ПроцентыДляВизуализацииИхПриСинхронизации + " Таблица Куда Вставляем " +ТаблицаКудаВставляем, Toast.LENGTH_SHORT).show();*/
                    }
                });
                ////



            }

            //////
        } catch (Exception e) {///////ошибки
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            ССылкаНаСозданнуюБазу.endTransaction();
        }
        ////TODO метод вставки
        return Результат_ВставкиДанных;
    }



    //////TODO метод пребразует цифры из цикла в проценты




















    /////////TODO  ОБНОВЛЕНИЕ КОНТЕЙНЕР ВСТВКИ ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long ОбновлениеДанныхЧерезКонтейнерУниверсальная(String ТаблицаКудаОбновляем, ContentValues КонтейнерДляОбновления,
                                                     String UUIDДляСостыковПриОбновления,int ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON,
                                                     boolean СинхронизациюВизуализировать,Context  КонтекстСинхроДляКонтроллера,String ИндификаторЧерезЧегоОбнолвяемсяUUIDИлиID)
            throws ExecutionException, InterruptedException, TimeoutException {
        /////////////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ
        long Результат_ОбновлениеДанных = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;

/////

        ////
        try {
            //////TODO вторым флагом запрещем при первом запуске заниматься обновдениям  только вставка  при синхронизации ==false значить обнолвение включено ,,,,, ЗНАЧАЕТ ЧТО ИДЕТ ТОЛЬКО ВСТАВКА ДАННЫХ TRUE
            //   if (     finalФлагПриПервомЗапускеОграничитьОперациюТолькоВставка == true ) {


            ССылкаНаСозданнуюБазу = this.getWritableDatabase();


            if (!ССылкаНаСозданнуюБазу.inTransaction()) {
                ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
                ///
                /////TODO ОБНОВЛЕМСЯ UUID

          /*              ///TODO ОБНОЛВЕНИЕ
                       ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();

                    ////// TODO САМО ОБНОВЛЕНИЕ ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                    Результат_ОбновлениеДанных = ССылкаНаСозданнуюБазу.update(ТаблицаКудаОбновляем, КонтейнерДляОбновления, ИндификаторЧерезЧегоОбнолвяемсяUUIDИлиID+"= ?",
                            new String[]{UUIDДляСостыковПриОбновления});
                    //////////*/
                ///////


                /////TODO ОБНОВЛЕМСЯ UUID
                Cursor    Курсор_ПроизводимОбновлениеЕслиУКонкретногоUUIDДатаДольше=null;

                Курсор_ПроизводимОбновлениеЕслиУКонкретногоUUIDДатаДольше = КурсорУниверсальныйДляБазыДанных(ТаблицаКудаОбновляем,
                        new String[]{""+ИндификаторЧерезЧегоОбнолвяемсяUUIDИлиID+",date_update"},
                        ИндификаторЧерезЧегоОбнолвяемсяUUIDИлиID+"=?", new String[]{UUIDДляСостыковПриОбновления},  null, null, null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере +"%"  // KEY_NAME + " LIKE ?"
                ////
                if (Курсор_ПроизводимОбновлениеЕслиУКонкретногоUUIDДатаДольше.getCount()>0){


                    Log.d(this.getClass().getName(), " Курсор_ПроизводимОбновлениеЕслиУКонкретногоUUIDДатаДольше.getCount() "+Курсор_ПроизводимОбновлениеЕслиУКонкретногоUUIDДатаДольше.getCount());

                    Date ДатаВнутранаяОтКлиентаВнутри=null;

                    Курсор_ПроизводимОбновлениеЕслиУКонкретногоUUIDДатаДольше.moveToFirst();
                    String ДатаДаныхлкальная=Курсор_ПроизводимОбновлениеЕслиУКонкретногоUUIDДатаДольше.getString(1);

                    SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));
                    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));

                    ДатаВнутранаяОтКлиентаВнутри = simpleDateFormat.parse(ДатаДаныхлкальная);

                    Log.d(this.getClass().getName(), " ДатаВнутранаяОтКлиентаВнутри "+ДатаВнутранаяОтКлиентаВнутри.toString());








                    /////todo внешний
                    boolean ДатаВнешнаяЕслиЕсть=   КонтейнерДляОбновления.containsKey("date_update");

                    Date ДатаВнешнаяПришлаОтСинхронизации = null;

                    if (ДатаВнешнаяЕслиЕсть=true) {
                        Object ДатаВнешнаяяСравнения = КонтейнерДляОбновления.get("date_update");




                        ДатаВнешнаяПришлаОтСинхронизации = simpleDateFormat.parse(ДатаВнешнаяяСравнения.toString());

                        Log.d(this.getClass().getName(), " ДатаВнешнаяПришлаОтСинхронизации "+ДатаВнешнаяПришлаОтСинхронизации.toString()+" ДатаВнутранаяОтКлиентаВнутри " +ДатаВнутранаяОтКлиентаВнутри.toString());
                    }

                    ////////////
                    if( ДатаВнешнаяПришлаОтСинхронизации.after(ДатаВнутранаяОтКлиентаВнутри)){

                        ////// TODO САМО ОБНОВЛЕНИЕ ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                        Результат_ОбновлениеДанных = ССылкаНаСозданнуюБазу.update(ТаблицаКудаОбновляем, КонтейнерДляОбновления, ИндификаторЧерезЧегоОбнолвяемсяUUIDИлиID+"= ?",
                                new String[]{UUIDДляСостыковПриОбновления});
                        //////////
                        ///////
                    }
                }
                //
                // TODO: 16.03.2021
                Курсор_ПроизводимОбновлениеЕслиУКонкретногоUUIDДатаДольше.close();


                /////


                ///////
                if (Результат_ОбновлениеДанных > 0) {

                    ///TODO ПЕРВАЯ ТРАНЗАКЦИЯ

                    ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ


                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();


                }
                //////todo закрыть ранзакция


                ССылкаНаСозданнуюБазу.endTransaction();


                //////
            }


            ///////////TODO визуализация даных по строчно из НИЖНЕГО ПОТОКА ПОДМИНИМАЕМСЯ НА ВЕРХ ОПЕРЦИЯ ОБНОВЛЕНЕЕЕЕ


            //////
            float ОбщееКоличествоСтрокВJSON = PUBLIC_CONTENT.СколькоСтрочекJSON;
            ///
            int finalКоличествоУспешныхОбновлений = PUBLIC_CONTENT.КоличествоУспешныхОбновлений;
            ///////////////

            if (СинхронизациюВизуализировать  && Результат_ОбновлениеДанных >0 && ОбщееКоличествоСтрокВJSON>0 ){




                ///=
                Log.d(MODEL_synchronized.class.getName(), " ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON " + ДляСинхронизацииОбщееКоличествоСколькоСтрочекJSON +
                        " ПубличныйУниверсальныйИндификаторОбновленияиВставки  " + finalКоличествоУспешныхОбновлений);
/////

                Log.d(this.getClass().getName(), " ПроцентыДляВизуализацииИхПриСинхронизации" + finalКоличествоУспешныхОбновлений + " ОбщееКоличествоСтрокВJSON " + ОбщееКоличествоСтрокВJSON);

                String ФиналПроцентыДляВизуализацииИхПриСинхронизации = null;
                //TODO считаем проценты от цифры
                float ФиналПроценты = 0;
                if(ОбщееКоличествоСтрокВJSON>0) {

                    ФиналПроценты = (finalКоличествоУспешныхОбновлений / ОбщееКоличествоСтрокВJSON) * 100;
                    ////
                }

                ФиналПроценты = (float) Math.ceil(ФиналПроценты);
                //////
                ////
                ФиналПроцентыДляВизуализацииИхПриСинхронизации = String.valueOf(ФиналПроценты);
                ////TODO ищем Точку
                Log.d(this.getClass().getName(), "  ФиналПроцентыДляВизуализацииИхПриСинхронизации " + ФиналПроцентыДляВизуализацииИхПриСинхронизации+" ФиналПроценты"
                        + ФиналПроценты + " ОбщееКоличествоСтрокВJSON " +ОбщееКоличествоСтрокВJSON );


                DecimalFormat decimalFormat = new DecimalFormat("#.#");



                ФиналПроцентыДляВизуализацииИхПриСинхронизации = decimalFormat.format(ФиналПроценты) ;

                /////TODO СТАВИМ ОГРАНИЧЕНИЯ ПРОЦЕНТЫ НЕ ВЫШЕ 100 %
                int ФиналПроцентыДляВизуализацииИхПриСинхронизацииОгорниченияЦифра=Integer.valueOf(ФиналПроцентыДляВизуализацииИхПриСинхронизации);
                if(ФиналПроцентыДляВизуализацииИхПриСинхронизацииОгорниченияЦифра>100){
                    ////todo если процентов больше 100 %  уменьваем их принудтельно
                    ФиналПроцентыДляВизуализацииИхПриСинхронизации="100";
                }


                Log.d(this.getClass().getName(), "  ФиналПроцентыДляВизуализацииИхПриСинхронизации " + ФиналПроцентыДляВизуализацииИхПриСинхронизации);

                ////TODO вставка backcalls ВСТАВКА ФИНИАЛЬНЫЕ ПРОЦЕНТЫ

                final String ВозвратВПотокЗначенияСнизу = ФиналПроцентыДляВизуализацииИхПриСинхронизации+ " %";
                //TODO ПОСЫЛАЕМ ВВЕРХ ПО ПОТОКУ

                Log.d(this.getClass().getName(), " ВозвратВПотокЗначенияСнизу " + ВозвратВПотокЗначенияСнизу );
                //////TODO выводими обратно в UI обновления
                ((Activity) КонтекстСинхроДляКонтроллера).runOnUiThread(new Runnable() {
                    public void run() {

                        ///TODO ОБВНОВЛЕНИЕ false это првидбно начит это не первый запуск и нужно и обновление
                        if (ВозвратВПотокЗначенияСнизу.matches("[0-9].*") ) {
                            //////////TODO ВСТАВКА ПРОЦЕНТОВ ПРИ ОБНОВЛЕНИИ
                            MainActivity_Sinfrozisaziy_Prograssbar.  ТекстВидBarСинх.setText(ВозвратВПотокЗначенияСнизу.trim());
                        }
                        //////


              /*          Toast.makeText(Публичный_КонтекстДляСинхронизацииОбмена, " Проценты Обновления %   " +ВозвратВПотокЗначенияСнизу +
                                " Количество Успешных Обновлений :   " +ПроцентыДляВизуализацииИхПриСинхронизации+ " Таблица Куда Обновляем " +ТаблицаКудаОбновляем, Toast.LENGTH_SHORT).show();*/
                        ///////TODO обработкаи  ГОризонтального PrograssBARA


                    }
                });
                //////////TODO  В ФОНЕ
            }
            //   }///// todo  if (     finalФлагПриПервомЗапускеОграничитьОперациюТолькоВставка == false) {
        } catch (Exception e) {///////ошибки
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ССылкаНаСозданнуюБазу.endTransaction();
        }
        return Результат_ОбновлениеДанных;
    }










    ///-------TODO ДАННЫЕЙ МЕТОД ОБНОЛДЯЕТЬ ДАННЫЕ ТОЛЬКО ВЕРСИИ ДАННЫХ ИЗМЕНЯЕТЬ ПРОТО  ДАТЫ В MODIFICATION CLIENT








































    ////// TODO  ДЛЯ СИНХРОНИЗАЦИИ метод записывает данные о времени в таблицу модификации ерсии данных
    protected int МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанных(String ТаблицаКудаОбновляем ,Date ДатаДляИзмененияВерсииДанныхНаАндройде) throws ExecutionException, InterruptedException {
        final int[] Результат_ПриписиИзменнийВерсииДанных = {0};

        ReentrantLock reentrantLock=new ReentrantLock();

        try {
            reentrantLock.lock();
            //////ВРЕМЯ ДЛЯ МОДИФИКАЦИИ ДАННЫХ
            //Date Дата = Calendar.getInstance().getTime();
            DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd'T'HH:mm:ss'Z'
            //dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
            dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
            String СтрокаИзДаты = dateFormat.format(ДатаДляИзмененияВерсииДанныхНаАндройде);
            StringBuffer БилдерДляДаты = new StringBuffer(СтрокаИзДаты); // создаем StringBuilder из нашей строки
            БилдерДляДаты.toString();

            Log.i(this.getClass().getName(), "БилдерДляДаты.toString() " + БилдерДляДаты.toString());
            //////ВРЕМЯ ДЛЯ МОДИФИКАЦИИ ДАННЫХ
            ContentValues АдаптерПриЛокальномОбновленииСамимПользоватем = new ContentValues();
            АдаптерПриЛокальномОбновленииСамимПользоватем.put("versionserveraandroid", БилдерДляДаты.toString());////ДЛЯ НОРМАЛЬНОЙ СИНХРОНИЗАЦИИ
            ////
            АдаптерПриЛокальномОбновленииСамимПользоватем.put("localversionandroid", БилдерДляДаты.toString());



            ////TOdo начинаем таранзакццию




            ///
            ССылкаНаСозданнуюБазу = this.getWritableDatabase();

            ///
            ///
            if (!ССылкаНаСозданнуюБазу.inTransaction()) {
                ///
                ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


                /////


                //
                /////TODO меняем версию данных в приложении только когда есть JSON , НУ НЕ ХОЛОСТОЙ ПРОГОН СИНХРОНИЗАЦИИ БЕЗ ДНАННЫХ

                /////TODO Само Обновление Даты После Изменния Данных
                Результат_ПриписиИзменнийВерсииДанных[0] = ССылкаНаСозданнуюБазу.update("MODIFITATION_Client", АдаптерПриЛокальномОбновленииСамимПользоватем, "name=?",
                        new String[]{ТаблицаКудаОбновляем});

                ///todo РЕЗУЛЬТАТ ЗАПИСИ ИЗМЕНЕНИЯ ВЕРСИИ ДАННЫХ В ТАБЛИЦУ МОИФИКАШЕН ВЕРСИЯ , И
                // ///TODO меняем версию данных в приложении только когда есть JSON , НУ НЕ ХОЛОСТОЙ ПРОГОН СИНХРОНИЗАЦИИ БЕЗ ДНАННЫХ
                Log.d(this.getClass().getName(), "PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице " + PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице);
                ////
                if (Результат_ПриписиИзменнийВерсииДанных[0] > 0 ) {
                    //////////


                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();

                    /////TODO ПОСЛЕ УСПЕШНОГО ИЗМЕНЕНИЯ  ВЕРСИИ ДАННЫХ В АНДРОЙДЕ  ОБНУЛЯЕМ ФЛАГ
                    PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице=0;

                }
                //////

                ССылкаНаСозданнуюБазу.endTransaction();
            }


            АдаптерПриЛокальномОбновленииСамимПользоватем.clear();



            /////НАЗВАНИЕ ПОТОКА
            Log.i(this.getClass().getName(), "НАЗВАНИЕ ПОТОКА В aSYNSTASK " + Thread.currentThread().getName().toUpperCase());
            /////


            ///
        } catch (Exception e) {///////ошибки
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }finally {
            reentrantLock.unlock();
        }


        return Результат_ПриписиИзменнийВерсииДанных[0];
    }

    ///////// TODO  КОНЕЦ УНИВЕРСАЛЬНЫЙ МЕТОД ВСТАВКИ ДАННЫХ











    ////// TODO  НЕ ДЛЯ  СИНХРОНИЗАЦИИ  ДЛЯ ЛОКАЛЬНОГО ИСПОЛЬЗОВАНИЯ метод записывает данные о времени в таблицу модификации ерсии данных
    protected int МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхБезУсловияНаличияJSON(String ТаблицаКудаОбновляем ,Date ДатаДляИзмененияВерсииДанныхНаАндройде) throws ExecutionException, InterruptedException {
        final int[] Результат_ПриписиИзменнийВерсииДанных = {0};

        try {

            //////ВРЕМЯ ДЛЯ МОДИФИКАЦИИ ДАННЫХ
            //Date Дата = Calendar.getInstance().getTime();
            DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd'T'HH:mm:ss'Z'
            //dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
            dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
            String СтрокаИзДаты = dateFormat.format(ДатаДляИзмененияВерсииДанныхНаАндройде);
            StringBuffer БилдерДляДаты = new StringBuffer(СтрокаИзДаты); // создаем StringBuilder из нашей строки
            БилдерДляДаты.toString();

            Log.i(this.getClass().getName(), "БилдерДляДаты.toString() " + БилдерДляДаты.toString());
            //////ВРЕМЯ ДЛЯ МОДИФИКАЦИИ ДАННЫХ
            ContentValues АдаптерПриЛокальномОбновленииСамимПользоватем = new ContentValues();
            АдаптерПриЛокальномОбновленииСамимПользоватем.put("versionserveraandroid", БилдерДляДаты.toString()); /// ТОЛЬКО СОХРАНЕНИЕ НО ТОЛЬКО БЕЗ ПРОВЕРКИ ЕСЛИ JSON
            АдаптерПриЛокальномОбновленииСамимПользоватем.put("localversionandroid", БилдерДляДаты.toString());



            ////TOdo начинаем таранзакццию

            ///

//
            ССылкаНаСозданнуюБазу = this.getWritableDatabase();
            ///
            ///

            if (!ССылкаНаСозданнуюБазу.inTransaction()) {
                ///
                ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


                /////


                //
                /////TODO меняем версию данных в приложении только когда есть JSON , НУ НЕ ХОЛОСТОЙ ПРОГОН СИНХРОНИЗАЦИИ БЕЗ ДНАННЫХ

                /////TODO Само Обновление Даты После Изменния Данных
                Результат_ПриписиИзменнийВерсииДанных[0] = ССылкаНаСозданнуюБазу.update("MODIFITATION_Client", АдаптерПриЛокальномОбновленииСамимПользоватем, "name=?",
                        new String[]{ТаблицаКудаОбновляем});

                ///todo РЕЗУЛЬТАТ ЗАПИСИ ИЗМЕНЕНИЯ ВЕРСИИ ДАННЫХ В ТАБЛИЦУ МОИФИКАШЕН ВЕРСИЯ , И
                // ///TODO меняем версию данных в приложении только когда есть JSON , НУ НЕ ХОЛОСТОЙ ПРОГОН СИНХРОНИЗАЦИИ БЕЗ ДНАННЫХ
                Log.d(this.getClass().getName(), "PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице " + PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице);
                ////
                if (Результат_ПриписиИзменнийВерсииДанных[0] > 0 ) {
                    //////////

                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();

                }
                //////

                ССылкаНаСозданнуюБазу.endTransaction();
            }


            АдаптерПриЛокальномОбновленииСамимПользоватем.clear();
            /////НАЗВАНИЕ ПОТОКА
            Log.i(this.getClass().getName(), "НАЗВАНИЕ ПОТОКА В aSYNSTASK " + Thread.currentThread().getName().toUpperCase());
            /////


            ///
        } catch (Exception e) {///////ошибки
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


        return Результат_ПриписиИзменнийВерсииДанных[0];
    }

    ///////// TODO  КОНЕЦ УНИВЕРСАЛЬНЫЙ МЕТОД ВСТАВКИ ДАННЫХ






    ////// TODO  НЕ ДЛЯ  СИНХРОНИЗАЦИИ  ДЛЯ ЛОКАЛЬНОГО ИСПОЛЬЗОВАНИЯ метод записывает данные о времени в таблицу модификации ерсии данных
    protected int МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных(String ТаблицаКудаОбновляем ,
                                                                                                              Date ДатаДляИзмененияВерсииДанныхНаАндройде)
            throws ExecutionException, InterruptedException {
        ////
        final int[] Результат_ПриписиИзменнийВерсииДанных = {0};

        try {

            //////ВРЕМЯ ДЛЯ МОДИФИКАЦИИ ДАННЫХ
            //Date Дата = Calendar.getInstance().getTime();
            DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd'T'HH:mm:ss'Z'
            //dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
            dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
            String СтрокаИзДаты = dateFormat.format(ДатаДляИзмененияВерсииДанныхНаАндройде);
            StringBuffer БилдерДляДаты = new StringBuffer(СтрокаИзДаты); // создаем StringBuilder из нашей строки
            БилдерДляДаты.toString();

            Log.i(this.getClass().getName(), "БилдерДляДаты.toString() " + БилдерДляДаты.toString());
            //////ВРЕМЯ ДЛЯ МОДИФИКАЦИИ ДАННЫХ
            ContentValues АдаптерПриЛокальномОбновленииСамимПользоватем = new ContentValues();

            /// TODO ЗАКОМЕНТИРОВАНО ПОТОМУ ЧТО ЭТОТ МЕТОД РАБОТАЕТ ПРИ ЛОКАЛЬНОМ ОБНОВЛЕННИИ
            // //// АдаптерПриЛокальномОбновленииСамимПользоватем.put("versionserveraandroid", БилдерДляДаты.toString());
            АдаптерПриЛокальномОбновленииСамимПользоватем.put("localversionandroid", БилдерДляДаты.toString());



            ////TOdo начинаем таранзакццию

            ///



//
            ССылкаНаСозданнуюБазу = this.getWritableDatabase();

            ///

            ///
            if (!ССылкаНаСозданнуюБазу.inTransaction()) {
                ///
                ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


                /////


                //
                /////TODO меняем версию данных в приложении только когда есть JSON , НУ НЕ ХОЛОСТОЙ ПРОГОН СИНХРОНИЗАЦИИ БЕЗ ДНАННЫХ

                /////TODO Само Обновление Даты После Изменния Данных
                Результат_ПриписиИзменнийВерсииДанных[0] = ССылкаНаСозданнуюБазу.update("MODIFITATION_Client", АдаптерПриЛокальномОбновленииСамимПользоватем, "name=?",
                        new String[]{ТаблицаКудаОбновляем});

                ///todo РЕЗУЛЬТАТ ЗАПИСИ ИЗМЕНЕНИЯ ВЕРСИИ ДАННЫХ В ТАБЛИЦУ МОИФИКАШЕН ВЕРСИЯ , И
                // ///TODO меняем версию данных в приложении только когда есть JSON , НУ НЕ ХОЛОСТОЙ ПРОГОН СИНХРОНИЗАЦИИ БЕЗ ДНАННЫХ
                Log.d(this.getClass().getName(), "PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице " + PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице);
                ////
                if (Результат_ПриписиИзменнийВерсииДанных[0] > 0 ) {
                    //////////

                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();

                }
                //////

                ССылкаНаСозданнуюБазу.endTransaction();
            }


            АдаптерПриЛокальномОбновленииСамимПользоватем.clear();
            /////НАЗВАНИЕ ПОТОКА
            Log.i(this.getClass().getName(), "НАЗВАНИЕ ПОТОКА В aSYNSTASK " + Thread.currentThread().getName().toUpperCase());
            /////


            ///
        } catch (Exception e) {///////ошибки
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ССылкаНаСозданнуюБазу.endTransaction();
        }

        return Результат_ПриписиИзменнийВерсииДанных[0];
    }

    ///////// TODO  КОНЕЦ УНИВЕРСАЛЬНЫЙ МЕТОД ВСТАВКИ ДАННЫХ














    /////////TODO КОНТЕЙНЕР ЛОКАЛЬНОГО ОБНОВЛЕНИЯ  ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long ЛокальногоОбновлениеДанныхЧерезКонтейнерУниверсальная(String ТаблицаКудаОбновляем,
                                                               ContentValues КонтейнерДляОбновления,
                                                               String UUIDДляСостыковПриОбновления,
                                                               String ФлагЧерезЧегоОбновляетьсяIDилиUUID ) throws ExecutionException, InterruptedException, TimeoutException {
        //////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long Результат_ЛокальногоОбновлениеДанных = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;

        System.out.println(" ОбновлениеДанныхЧерезКонтейнерУниверсальная ");

        String ОшибкаТекущегоМетода;


//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();


        ///
        ///
        if (!ССылкаНаСозданнуюБазу.inTransaction()) {
            ///
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


            try {
                //////САМО ОБНОВЛЕНИЕ ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                Результат_ЛокальногоОбновлениеДанных = ССылкаНаСозданнуюБазу.update(ТаблицаКудаОбновляем, КонтейнерДляОбновления, ФлагЧерезЧегоОбновляетьсяIDилиUUID + "= ?",
                        new String[]{UUIDДляСостыковПриОбновления});
                ///////////
                if (Результат_ЛокальногоОбновлениеДанных > 0) {
                    ///todo первое сохранение транзакции
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();

                }
                ССылкаНаСозданнуюБазу.endTransaction();



            } catch (Exception e) {///////ошибки
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                ОшибкаТекущегоМетода = e.toString();
                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ССылкаНаСозданнуюБазу.endTransaction();
            }
        }


        //   publishProgress(Результат_ПриписиИзменнийВерсииДанных);

        return (Long) Результат_ЛокальногоОбновлениеДанных ;
    }
    //////метод записывает данные о времени в таблицу модификации ерсии данных







    /////////КОНТЕЙНЕР ВСТВКИ ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long ВставкаДанныхЧерезКонтейнерТолькоПриСозданииНовогоСотрудникаУниверсальная(String ТаблицаКудаВставляем, ContentValues КонтейнерДляВставки,
                                                                                   String ИмяТаблицыОтАндройда_Локальноая,
                                                                                   String ПолученнаяДатаДляПониманияДатуСейчасВставляетьИлиНет,
                                                                                   boolean ФлагОбновлятьДатуВерсииДанных) throws ExecutionException,
            InterruptedException, TimeoutException {
        ///////////////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ
        //AsyncTask AsyncTaskУнивермальныйДляОбмена=null;

        long Результат_ВставкиДанныхТолькоДляСотрудникаНового = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;


        System.out.println(" Вставка Данных Через Контейнер Универсальная");







//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();
        /////ССылкаНаСозданнуюБазу.enableWriteAheadLogging();
        //////




        ////TOdo начинаем таранзакццию
        if (!ССылкаНаСозданнуюБазу.inTransaction()) {
            ///
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


            try {
                //////САМА ВСТАВКА ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                Результат_ВставкиДанныхТолькоДляСотрудникаНового = ССылкаНаСозданнуюБазу.insert(ТаблицаКудаВставляем, null, КонтейнерДляВставки);

                //////////
                if (Результат_ВставкиДанныхТолькоДляСотрудникаНового > 0) {
                    ////успешная вставка данных
                    ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    PUBLIC_CONTENT.КоличествоУспешныхВставки++;
                    КонтейнерДляВставки.clear();
                    Log.d(this.getClass().getName(), " Результат_ВставкиДанныхТолькоДляСотрудникаНового   " + Результат_ВставкиДанныхТолькоДляСотрудникаНового);
                }
                ССылкаНаСозданнуюБазу.endTransaction();


                //метод анализируем стоит ли вставлять дату сейчас в таблицу модификацию версия данных локального
                ////////вторая часть операции после успешной вствки изменяем данные на дабоавляем дату в таблицу модификаци  клиент
                //////ДЛЯ ПОНИМАНИЯ ЕСЛИ ЭТО НУЛЕВОЙ ЗАПУСК ТО НЕ НАДО В ТАБЛИЦУК МОДИФИКАФЕН КЛИЕНТ ВСТАЯЛТЬ ДАТУ СЕЙЧАС
                if (ФлагОбновлятьДатуВерсииДанных == true && Результат_ВставкиДанныхТолькоДляСотрудникаНового > 0) {/////ПРИ УКАЗАНОЙ ДАТЕ ПОДТВЕРЖДАТЬ ВРЕМЯ НЕ НАДО
                    /////запускаем втроую транзакцию

                    ///TODO ВТОРАЯ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                    Результат_ПриписиИзменнийВерсииДанных = МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных(
                            ИмяТаблицыОтАндройда_Локальноая,new Date());/////ПОСЛЕ УСПЕШНОЙ ВСТАВКИ ЗАПИСЫВАЕМ В ТАБЛИЦУ ВЕРСИЙ ДАННЫХ  ТИПА ТРИГЕРА


                    if(Результат_ПриписиИзменнийВерсииДанных>0){

                        ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                        Log.d(this.getClass().getName(), " Результат_ПриписиИзменнийВерсииДанных   " + Результат_ПриписиИзменнийВерсииДанных);
                    }


                }








            } catch (Exception e) {///////ошибки
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///
                ССылкаНаСозданнуюБазу.endTransaction();
            }
        }

        //// todo get ASYNtASK
        return Результат_ВставкиДанныхТолькоДляСотрудникаНового;
    }

















    /////////КОНТЕЙНЕР ВСТВКИ ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long ВставкаДанныхЧерезКонтейнерОрганизацияДляТекущегоСотрудникаУниверсальная(String ТаблицаКудаВставляем, ContentValues КонтейнерДляВставки,
                                                                                  String ИмяТаблицыОтАндройда_Локальноая,
                                                                                  String ПолученнаяДатаДляПониманияДатуСейчасВставляетьИлиНет,
                                                                                  boolean ФлагОбновлятьДатуВерсииДанных,int  ПубличныйIDДляорганизацции,String ДатаДляОбновлениеОргназации) throws ExecutionException,
            InterruptedException, TimeoutException {
        ///////////////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long Результат_ВставкиДанныхОрганизация = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;

        //////

        /////
        //  String ПУбличноеИмяIDДляЗаписи=PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID;
//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();
        ////TOdo начинаем таранзакццию
        ///
        if (!ССылкаНаСозданнуюБазу.inTransaction()) {
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


            try {
                //////САМА ВСТАВКА ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                Результат_ВставкиДанныхОрганизация = ССылкаНаСозданнуюБазу.update(ТаблицаКудаВставляем, КонтейнерДляВставки, "user_update=?",
                        new String[]{String.valueOf(ПубличныйIDДляорганизацции)});
                ///////
                if (Результат_ВставкиДанныхОрганизация > 0) {
                    ////успешная вставка данных
                    ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    ССылкаНаСозданнуюБазу.endTransaction();
                    КонтейнерДляВставки.clear();
                    Log.d(this.getClass().getName(), " Результат_ВставкиДанныхОрганизация   " + Результат_ВставкиДанныхОрганизация);

                }else {



                    ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
                    //////САМА ВСТАВКА ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                    Результат_ВставкиДанныхОрганизация = ССылкаНаСозданнуюБазу.insert(ТаблицаКудаВставляем, null, КонтейнерДляВставки);

                    if (Результат_ВставкиДанныхОрганизация > 0) {

                        ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                        ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                        ССылкаНаСозданнуюБазу.endTransaction();
                        КонтейнерДляВставки.clear();
                        Log.d(this.getClass().getName(), " Результат_ВставкиДанныхОрганизация   " + Результат_ВставкиДанныхОрганизация);

                    }else{


                    }
                }

                //////








                ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();



                ContentValues ДляВерсииДанных=new ContentValues();


                ДляВерсииДанных.put("localversionandroid",ДатаДляОбновлениеОргназации);


                //////САМА ВСТАВКА ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                Результат_ВставкиДанныхОрганизация = ССылкаНаСозданнуюБазу.update("MODIFITATION_Client", ДляВерсииДанных, "name=?",
                        new String[]{String.valueOf(ТаблицаКудаВставляем)});


                if (Результат_ВставкиДанныхОрганизация > 0) {

                    ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    ССылкаНаСозданнуюБазу.endTransaction();
                    КонтейнерДляВставки.clear();
                    Log.d(this.getClass().getName(), " Результат_ВставкиДанныхОрганизация   " + Результат_ВставкиДанныхОрганизация);

                }



                //////
            } catch (Exception e) {///////ошибки
                e.printStackTrace();
                ///метод запись ошибок в таблицу

                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                //////
                ССылкаНаСозданнуюБазу.endTransaction();
            }
        }

        return Результат_ВставкиДанныхОрганизация;
    }









    /////////КОНТЕЙНЕР ВСТВКИ ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long ВставкаДанныхЧерезКонтейнерПервыйолученныйПубличныйIDотСервера(String ТаблицаКудаВставляем, ContentValues КонтейнерДляВставки
    ) throws ExecutionException,
            InterruptedException, TimeoutException {
        ///////////////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long Результат_ВставкиДанныхОрганизация = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;
        try {
            //////

            //  String ПУбличноеИмяIDДляЗаписи=PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID;
//
            ССылкаНаСозданнуюБазу = this.getWritableDatabase();
            ////TOdo начинаем таранзакццию
            ///
            if (!ССылкаНаСозданнуюБазу.inTransaction()) {
                ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


                //////САМА ВСТАВКА ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                Результат_ВставкиДанныхОрганизация = ССылкаНаСозданнуюБазу.insert(ТаблицаКудаВставляем, null, КонтейнерДляВставки);

                if (Результат_ВставкиДанныхОрганизация > 0) {

                    ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    КонтейнерДляВставки.clear();
                    Log.d(this.getClass().getName(), " Результат_ВставкиДанныхОрганизация   " + Результат_ВставкиДанныхОрганизация);

                }


                //////
                ССылкаНаСозданнуюБазу.endTransaction();
            }

            //////
        } catch (Exception e) {///////ошибки
            e.printStackTrace();
            ///метод запись ошибок в таблицу

            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            //////
            ССылкаНаСозданнуюБазу.endTransaction();
        }

        return Результат_ВставкиДанныхОрганизация;
    }
























































    /////////TODO  ОБНОВЛЕНИЕ КОНТЕЙНЕР ВСТВКИ ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long ОбновлениеДанныхЧерезКонтейнерТолькоПриСозданииНовогоСотрудникаУниверсальная(String ТаблицаКудаОбновляем, ContentValues КонтейнерДляОбновления,
                                                                                      String UUIDДляСостыковПриОбновления) throws ExecutionException,
            InterruptedException, TimeoutException {
        /////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long Результат_ОбновлениеДанныхОбновлениеСозданииНового = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;

        System.out.println(" ОбновлениеДанныхЧерезКонтейнерУниверсальная ");
//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();


        if (!ССылкаНаСозданнуюБазу.inTransaction()){




            ////TOdo начинаем таранзакццию
            ///
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();





            try {
                //////САМО ОБНОВЛЕНИЕ ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                Результат_ОбновлениеДанныхОбновлениеСозданииНового = ССылкаНаСозданнуюБазу.update(ТаблицаКудаОбновляем, КонтейнерДляОбновления, "uuid= ?",
                        new String[]{UUIDДляСостыковПриОбновления});
                ///////
                if (Результат_ОбновлениеДанныхОбновлениеСозданииНового > 0) {
                    ///TODO ПЕРВАЯ ТРАНЗАКЦИЯ
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();


                    ///TODO НАЧИНАЕМ ВТОРОУЮ ТРАНЗАКЦИЮ ВЕРСИЮ ДАННЫХ

                    ///ПослеУспешнойОперациии записать в табблицу версии данных на клиенте
                    ////  Результат_ПриписиИзменнийВерсииДанных = МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанных(ТаблицаКудаОбновляем,new Date());/////ПОСЛЕ УСПЕШНОЙ ОБНОВЛЕНИЯ ЗАПИСЫВАЕМ В ТАБЛИЦУ ВЕРСИЙ ДАННЫХ  ТИПА ТРИГЕРА

                }

                ССылкаНаСозданнуюБазу.endTransaction();

            } catch (Exception e) {///////ошибки
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }

        }
        return Результат_ОбновлениеДанныхОбновлениеСозданииНового;
    }






    /////////КОНТЕЙНЕР ВСТВКИ ДАННЫХ УНИВЕРСАЛЬНЫЙ ТОЛЬКО ДЛЯ ЗАПИСИ ОШИБКИ
    Long ВставкаДанныхЧерезКонтейнерУниверсальнаяТолькоДляЗаписиОшибки(String ТаблицаКудаВставляем, ContentValues КонтейнерДляВставки)
            throws ExecutionException, InterruptedException, TimeoutException {
        ////////////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long Результат_ВставкиДанныхДляЗаписиОшибки = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;

        System.out.println(" ВставкаДанныхЧерезКонтейнерУниверсальная");


//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();
        ////TOdo начинаем таранзакццию
        ///
        if (! ССылкаНаСозданнуюБазу.inTransaction()) {
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


            /////

            try {
                //////САМА ВСТАВКА ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                Результат_ВставкиДанныхДляЗаписиОшибки = ССылкаНаСозданнуюБазу.insert(ТаблицаКудаВставляем, null, КонтейнерДляВставки);
                if (Результат_ВставкиДанныхДляЗаписиОшибки > 0) {
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    КонтейнерДляВставки.clear();
                    Log.d(this.getClass().getName(), " Результат_ВставкиДанныхДляЗаписиОшибки  " + Результат_ВставкиДанныхДляЗаписиОшибки);

                }
                //////////
                ССылкаНаСозданнуюБазу.endTransaction();
                /////НАЗВАНИЕ ПОТОКА
                Log.i(this.getClass().getName(), "НАЗВАНИЕ ПОТОКА В aSYNSTASK " + Thread.currentThread().getName().toUpperCase());
                /////
            } catch (Exception e) {///////ошибки
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }

        return Результат_ВставкиДанныхДляЗаписиОшибки;
    }








    /////////TODO  ОБНОВЛЕНИЕ КОНТЕЙНЕР ВСТВКИ ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long ОбновлениеДанныхЧерезКонтейнерВозвращениеРезультатаОтСервераУниверсальная(String ТаблицаКудаОбновляем,
                                                                                   Long UUIDДляСостыковПриОбновления,
                                                                                   String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET) throws ExecutionException,
            InterruptedException, TimeoutException {
        ///////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long Результат_ОбновлениеДанных = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;
        long РезультатДополнителбногоПослеОтправкиДаннхНаСерверВыравниваемВерсийЛокальнуюИСервреную = 0;

        System.out.println(" ОбновлениеДанныхЧерезКонтейнерУниверсальная ");
        //
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();

        try {
            //////САМО ОБНОВЛЕНИЕ ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
            ////todo второй дополнительнй метод выравнивани я версий local server на андройд

            РезультатДополнителбногоПослеОтправкиДаннхНаСерверВыравниваемВерсийЛокальнуюИСервреную =
                    МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхБезУсловияНаличияJSON(ТаблицаКудаОбновляем,new Date());
            //todo результат обработки


        } catch (Exception e) {///////ошибки
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        // publishProgress(Результат_ПриписиИзменнийВерсииДанных);



        return  РезультатДополнителбногоПослеОтправкиДаннхНаСерверВыравниваемВерсийЛокальнуюИСервреную;
    }









    /////////TODO КОНТЕЙНЕР УДАЛЕНИЕ СОТРУДНИКА ИЗ ТАБЕЛЯ  ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long УдалениеДанныхЧерезКонтейнерУниверсальная(String ТаблицаОткудаУдлаяемЗапись,
                                                   String ЧерезКакоеПолеУдлаяемФлаг,
                                                   String UUIDДляСостыковПриОбновления) throws ExecutionException,
            InterruptedException, TimeoutException {
        /////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long Результат_УдалениеДанных = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;

        System.out.println(" УдалениеДанныхЧерезКонтейнерУниверсальная ");
//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();
        ///todo начинаем транзакцию
        if (!ССылкаНаСозданнуюБазу.inTransaction()) {
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


            try {
                ContentValues АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная = new ContentValues();
                ////// АдаптерПриЛокальномОбновленииСамимПользоватем.put("versionserveraandroid", БилдерДляДаты.toString());
                АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("status_send", "Удаленная");
                // АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("fio", 0);
                ////АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("nametabel_typename", 0);

                //////todo изменяем дату операции
                StringBuffer БилдерДляДаты = МетодПолучениеДатыДляТекущейОперации();
                АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("date_update", БилдерДляДаты.toString());





                //////САМО ОБНОВЛЕНИЕ ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                Результат_УдалениеДанных = ССылкаНаСозданнуюБазу.update(ТаблицаОткудаУдлаяемЗапись, АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная,
                        ЧерезКакоеПолеУдлаяемФлаг + "= ?", new String[]{UUIDДляСостыковПриОбновления});


                // TODO: 18.05.2021 успешное удалени сотрудника
                if (Результат_УдалениеДанных > 0) {
                    ///todo первое сохранение транзакции

                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();


                    АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.clear();

                    ////TODO дополнительно



                   /* /////TODO Дополнительно делаем ФИО поле НУЛЛ
                  ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
                    ССылкаНаСозданнуюБазу.execSQL("UPDATE tabels SET  fio= NULL WHERE fio=0");
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    ССылкаНаСозданнуюБазу.endTransaction();
*/

                 /*   int idServizo = 150;
                    String updateQuery ="UPDATE myTable SET sync = 1 WHERE id_servizio = "+idServizio;
                    dbManager.RawQuery(updateQuery, null);
    */

                /*    /////TODO Дополнительно делаем ФИО поле НУЛЛ
                    ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
                    ССылкаНаСозданнуюБазу.execSQL("UPDATE tabels SET  nametabel_typename= NULL WHERE nametabel_typename=0");
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    ССылкаНаСозданнуюБазу.endTransaction();*/





                    ////todo второе сохоанени транзацкии дата модернизации вреисии данных

                    ///ПослеУспешнойОперациии записать в табблицу версии данных на клиенте
                    Результат_ПриписиИзменнийВерсииДанных = МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных(ТаблицаОткудаУдлаяемЗапись,new Date());/////ПОСЛЕ УСПЕШНОЙ ОБНОВЛЕНИЯ ЗАПИСЫВАЕМ В ТАБЛИЦУ ВЕРСИЙ ДАННЫХ  ТИПА ТРИГЕРА


                    Log.e(this.getClass().getName(), "Результат_ПриписиИзменнийВерсииДанных" +Результат_ПриписиИзменнийВерсииДанных);

                }





                ССылкаНаСозданнуюБазу.endTransaction();

            } catch (Exception e) {///////ошибки
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }

        return Результат_УдалениеДанных;
    }

    //TODO МЕТОД КОТРЫЙ ОПРЕДЕЛЯЕТЬ ТИП ПОДКЛЧЮЧЕНИЯ WIFI ИЛИ MOBILE (ЧЕРЕЗ SIM)
    @NotNull
    private StringBuffer МетодПолучениеДатыДляТекущейОперации() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd'T'HH:mm:ss'Z'
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        String СтрокаИзДаты = dateFormat.format(Дата);
        StringBuffer БилдерДляДаты = new StringBuffer(СтрокаИзДаты); // создаем StringBuilder из нашей строки
        БилдерДляДаты.toString();
        return БилдерДляДаты;
    }











    /////////TODO КОНТЕЙНЕР УДАЛЕНИЕ СОТРУДНИКА ИЗ ТАБЕЛЯ  ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long УдалениеТолькоПустогоТабеляЧерезКонтейнерУниверсальная(String ТаблицаОткудаУдлаяемЗапись,
                                                                String ЧерезКакоеПолеУдлаяемФлаг,
                                                                Long UUIDДляСостыковПриОбновления)
            throws ExecutionException,
            InterruptedException, TimeoutException {
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long Результат_ОбновлениеДанных = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;

        System.out.println(" УдалениеДанныхЧерезКонтейнерУниверсальная ");




        ///todo начинаем транзакцию
//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();


        if (!ССылкаНаСозданнуюБазу.inTransaction()) {
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


            try {

                ///todo ПРИ УДАЛЕНИ И СОТРУДНИКА ОЧИЩАЕМ ПОЛЯ ЧТОБЫ НЕБЛОЫ СВЯКЗКИ С ТАБЕЛЕМ
                ContentValues АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная = new ContentValues();
                АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("status_send", "Удаленная");///ПОКА НЕ ОТКЛЮЧИЛИ
                // АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("nametabel", "");///ПОКА НЕ ОТКЛЮЧИЛИ
                //  АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("fio",0);///ПОКА НЕ ОТКЛЮЧИЛИ
                // АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("nametabel_typename", 0);///ПОКА НЕ ОТКЛЮЧИЛИ



                ///
                SimpleDateFormat    ФоорматДат = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
                ФоорматДат.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));

                Calendar КалендарьВремениСейчас = Calendar.getInstance();
                КалендарьВремениСейчас.setTime(new Date()); // Now use today date.
                ФоорматДат.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                String ДатаВремениСейчаcДляУдаления = ФоорматДат.format(КалендарьВремениСейчас.getTime());
                /////


                АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("date_update", ДатаВремениСейчаcДляУдаления);///ПОКА НЕ ОТКЛЮЧИЛИ

                // ССылкаНаСозданнуюБазу.execSQL("INSERT INTO tabels (fio) VALUES ('DEFAULT VALUES') WHERE uuid="+UUIDДляСостыковПриОбновления+";");//ТАБЛИЦА ГЕНЕРАЦИИ ОШИБОК
                // ССылкаНаСозданнуюБазу.execSQL(" insert into tabels (fio) values ( DEFAULT) WHERE uuid="+UUIDДляСостыковПриОбновления+";");//ТАБЛИЦА ГЕНЕРАЦИИ ОШИБОК



                /////TODO конец  ЧИСТИМ ДНИ
                //////todo изменяем дату операции

            /*    //////////сама операция обновлени удаление сотрууника из табеля
                        Результат_ОбновлениеДанных =   ССылкаНаСозданнуюБазу.delete(ТаблицаОткудаУдлаяемЗапись,
                                ЧерезКакоеПолеУдлаяемФлаг+"= ?", new String[]{UUIDДляСостыковПриОбновления});*/


                if (UUIDДляСостыковПриОбновления>0) {
                    ////

                    ////
                    Результат_ОбновлениеДанных = ССылкаНаСозданнуюБазу.update(ТаблицаОткудаУдлаяемЗапись, АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная,
                            ЧерезКакоеПолеУдлаяемФлаг + "= ?", new String[]{String.valueOf(UUIDДляСостыковПриОбновления)});


                }


                Log.d(this.getClass().getName(), " Результат_ОбновлениеДанных   " + Результат_ОбновлениеДанных );


                if (Результат_ОбновлениеДанных > 0) {
                    ///todo первое сохранение транзакции
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    ССылкаНаСозданнуюБазу.endTransaction();

           /*       /////TODO Дополнительно делаем ФИО поле НУЛЛ
                   ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
                       ССылкаНаСозданнуюБазу.execSQL("UPDATE tabels SET  fio= NULL WHERE fio="+UUIDДляСостыковПриОбновления+"");
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    ССылкаНаСозданнуюБазу.endTransaction();
                    ///*/

                 /*   int idServizo = 150;
                    String updateQuery ="UPDATE myTable SET sync = 1 WHERE id_servizio = "+idServizio;
                    dbManager.RawQuery(updateQuery, null);
    */

              /*      /////TODO Дополнительно делаем ФИО поле НУЛЛ
                    ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
                    ССылкаНаСозданнуюБазу.execSQL("UPDATE tabels SET  nametabel_typename= NULL WHERE nametabel_typename=0");
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    ССылкаНаСозданнуюБазу.endTransaction();*/

                    /////TODO  конец Дополнительно делаем ФИО поле НУЛЛ



                    ////todo второе сохоанени транзацкии дата модернизации вреисии данных

                    ///ПослеУспешнойОперациии записать в табблицу версии данных на клиенте
                    Результат_ПриписиИзменнийВерсииДанных =
                            МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных(ТаблицаОткудаУдлаяемЗапись,new Date());/////ПОСЛЕ УСПЕШНОЙ ОБНОВЛЕНИЯ ЗАПИСЫВАЕМ В ТАБЛИЦУ ВЕРСИЙ ДАННЫХ  ТИПА ТРИГЕРА



                    Log.d(this.getClass().getName(), " Результат_ПриписиИзменнийВерсииДанных   " + Результат_ПриписиИзменнийВерсииДанных );


                }

            } catch (Exception e) {///////ошибки
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e.toString() + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                //
                ССылкаНаСозданнуюБазу.endTransaction();
            }
        }


        return Результат_ОбновлениеДанных;
    }


    /////////TODO КОНТЕЙНЕР УДАЛЕНИЕ СОТРУДНИКА ИЗ ТАБЕЛЯ  ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long УдалениеТолькоШАблонЧерезКонтейнерУниверсальная(String ТаблицаОткудаУдлаяемЗапись,
                                                         String ЧерезКакоеПолеУдлаяемФлаг,
                                                         String UUIDДляСостыковПриОбновления) throws ExecutionException,
            InterruptedException, TimeoutException {
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long Результат_ОбновлениеДанных = 0;
        int Результат_ПриписиИзменнийВерсииДанных = 0;

        System.out.println(" УдалениеДанныхЧерезКонтейнерУниверсальная ");

        ///todo начинаем транзакцию
//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();


        if (! ССылкаНаСозданнуюБазу.inTransaction()) {
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();


            try {

                ///todo ПРИ УДАЛЕНИ И СОТРУДНИКА ОЧИЩАЕМ ПОЛЯ ЧТОБЫ НЕБЛОЫ СВЯКЗКИ С ТАБЕЛЕМ
                ContentValues АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная = new ContentValues();


                ///
                SimpleDateFormat    ФоорматДат = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
                ФоорматДат.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));

                Calendar КалендарьВремениСейчас = Calendar.getInstance();
                КалендарьВремениСейчас.setTime(new Date()); // Now use today date.
                ФоорматДат.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                String ДатаВремениСейчаcДляУдаления = ФоорматДат.format(КалендарьВремениСейчас.getTime());
                /////


                АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("date_update", ДатаВремениСейчаcДляУдаления);///ПОКА НЕ ОТКЛЮЧИЛИ

                АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("status_send", "Удаленная");///ПОКА НЕ ОТКЛЮЧИЛИ


                ///
                ///   АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная.put("name_templates", "");///ПОКА НЕ ОТКЛЮЧИЛИ


                /////TODO конец  ЧИСТИМ ДНИ
                //////todo изменяем дату операции

                //////////сама операция обновлени удаление сотрууника из табеля
                      /*  Результат_ОбновлениеДанных =   ССылкаНаСозданнуюБазу.delete(ТаблицаОткудаУдлаяемЗапись,
                                ЧерезКакоеПолеУдлаяемФлаг+"= ?", new String[]{UUIDДляСостыковПриОбновления});*/



                Результат_ОбновлениеДанных = ССылкаНаСозданнуюБазу.update(ТаблицаОткудаУдлаяемЗапись, АдаптерУстанавливаемФлагНазАписьЧтоОнаУдаленная,
                        ЧерезКакоеПолеУдлаяемФлаг + "= ?", new String[]{UUIDДляСостыковПриОбновления});






                if (Результат_ОбновлениеДанных > 0) {
                    ///todo первое сохранение транзакции
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();


                    ССылкаНаСозданнуюБазу.endTransaction();

                    ////todo второе сохоанени транзацкии дата модернизации вреисии данных

                    ///ПослеУспешнойОперациии записать в табблицу версии данных на клиенте
                    Результат_ПриписиИзменнийВерсииДанных =
                            МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных(ТаблицаОткудаУдлаяемЗапись,new Date());/////ПОСЛЕ УСПЕШНОЙ ОБНОВЛЕНИЯ ЗАПИСЫВАЕМ В ТАБЛИЦУ ВЕРСИЙ ДАННЫХ  ТИПА ТРИГЕРА


                    if(Результат_ПриписиИзменнийВерсииДанных>0) {
                        Log.d(this.getClass().getName(), " Результат_ПриписиИзменнийВерсииДанных   " + Результат_ПриписиИзменнийВерсииДанных);
                    }

                }



            } catch (Exception e) {///////ошибки
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e.toString() + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                ССылкаНаСозданнуюБазу.endTransaction();
            }
        }


        return Результат_ОбновлениеДанных;
    }































    /////////TODO КОНТЕЙНЕР УДАЛЕНИЕ СОТРУДНИКА ИЗ ТАБЕЛЯ  ДАННЫХ УНИВЕРСАЛЬНЫЙ
    Long УдалениеСтатусаУдаленныйТолькоПослеУспешнойСинхронизацииЧерезКонтейнерУниверсальная() throws ExecutionException,
            InterruptedException, TimeoutException {
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        long  Результат_УдаленныйТолькоПослеУспешнойСинхронизации= 0;

        System.out.println(" УдалениеДанныхЧерезКонтейнерУниверсальная ");
//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();


        if (!ССылкаНаСозданнуюБазу.inTransaction()) {
            ///todo начинаем транзакцию
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();

            /////

            try {

                /////TODO конец  ЧИСТИМ ДНИ
                //////todo изменяем дату операции

                //////////сама операция обновлени удаление сотрууника из табеля
                Результат_УдаленныйТолькоПослеУспешнойСинхронизации =   ССылкаНаСозданнуюБазу.delete("tabels",
                        "status_send= ?", new String[]{"Удаленная"});

                if ( Результат_УдаленныйТолькоПослеУспешнойСинхронизации > 0) {
                    ///todo первое сохранение транзакции
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();

                    ССылкаНаСозданнуюБазу.endTransaction();

                    ///ПослеУспешнойОперациии записать в табблицу версии данных на клиенте
                    int Результат_ПриписиИзменнийВерсииДанных = МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанных("tabels",new Date());/////ПОСЛЕ УСПЕШНОЙ ОБНОВЛЕНИЯ ЗАПИСЫВАЕМ В ТАБЛИЦУ ВЕРСИЙ ДАННЫХ  ТИПА ТРИГЕРА
                    //////
                    Log.d(this.getClass().getName(), "         Результат_ПриписиИзменнийВерсииДанных   " +     Результат_ПриписиИзменнийВерсииДанных);
                }






            } catch (Exception e) {///////ошибки
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e.toString() + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }


        return  Результат_УдаленныйТолькоПослеУспешнойСинхронизации;
    }







///todo записываем выбраную  ОРГАНИЗАЦИЮ В БАЗУ

    long МетодКоторыйЗаписываемВыбраннуюОргназациювБазуЧтобыПотомЕеНеБывырать(TextView ВыбранаяОрнанизация, Context КонтекстWIFI) {
        //
/////todo КОД ЗАПОЛЕНЕИЯ ДАННЫМИ В СПИНЕР ЦФО ДЕПАРТАМЕНТ МЕСЯЦ
        long РезультатОбновлениеЧерезКонтрейнер=0;
//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();
        try {
            Log.d(this.getClass().getName(), " ВыбранаяОрнанизация.toString() " +ВыбранаяОрнанизация.getText().toString());
            ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
            ////
            /////
            ContentValues ВставляемВБАзуВыбраннуюОргнизацию=new ContentValues();
            ////TODO ОБНУЛЯЕМ КАКУЮ ОРГАНИЗАЦИЮ ВЫБРАЛИ ОЧИЩАЕМ
            ВставляемВБАзуВыбраннуюОргнизацию.put("chosen_organization","");
            РезультатОбновлениеЧерезКонтрейнер = ССылкаНаСозданнуюБазу.update("organization", ВставляемВБАзуВыбраннуюОргнизацию, "chosen_organization= ?", new String[]{"1"});



            /////
            if ( РезультатОбновлениеЧерезКонтрейнер>0) {
                ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                Log.d(this.getClass().getName(), "РезультатОбновлениеЧерезКонтрейнер " +РезультатОбновлениеЧерезКонтрейнер);

            }else{

                РезультатОбновлениеЧерезКонтрейнер = ССылкаНаСозданнуюБазу.insert("organization", null, ВставляемВБАзуВыбраннуюОргнизацию);


                if ( РезультатОбновлениеЧерезКонтрейнер>0) {
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    Log.d(this.getClass().getName(), "РезультатОбновлениеЧерезКонтрейнер " +РезультатОбновлениеЧерезКонтрейнер);

                }


            }

            ССылкаНаСозданнуюБазу.endTransaction();

            ////todo ПОСЛЕ ЗАПИСИ ЦИФРВ 1 ИДЕМ В САМО ДОБАВЛЕНИЕ ДАННЫХ

            if (РезультатОбновлениеЧерезКонтрейнер>0) {
                /////
                Log.d(this.getClass().getName(), "РезультатОбновлениеЧерезКонтрейнер " +РезультатОбновлениеЧерезКонтрейнер);

                ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
                ////TODO ОБНУЛЯЕМ УЖЕ ВСТАВЛЯЕМ НОВУЮ ВЫБРАНОУЮ СОТРУДНИКОВ ОРГАНИЗАЦИЮ
                ВставляемВБАзуВыбраннуюОргнизацию.clear();
                /////
                String ПубличныйIDТекущегоПользователя=PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID;


                if (ПубличныйIDТекущегоПользователя!=null) {
                    Cursor    Курсор_ПолучемПубличныйID = КурсорУниверсальныйДляБазыДанных("SuccessLogin", new String[]{"*"},
                            null, null,  null, null, "date_update DESC", "1");///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере +"%"  // KEY_NAME + " LIKE ?"

                    if (     Курсор_ПолучемПубличныйID.getCount()>0) {
                        Курсор_ПолучемПубличныйID.moveToFirst();

                        int ИНдексПубличногоID=Курсор_ПолучемПубличныйID.getColumnIndex("id");

                        int ИНдексПубличногоIDЗначение=Курсор_ПолучемПубличныйID.getInt(ИНдексПубличногоID);

                        ПубличныйIDТекущегоПользователя=String.valueOf(ИНдексПубличногоIDЗначение);


                        ПубличныйIDТекущегоПользователя=String.valueOf(PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID);

                        if (ПубличныйIDТекущегоПользователя==null) {
                            // TODO: 24.03.2021 ЕслиВубличногоНЕтТоНАходим ЕГо
                            final int[] ПолученныйID = {0};



                            Cursor    Курсор_ИщемПУбличныйIDКогдаегоНетВстатике=null;
                            try {
                                Курсор_ИщемПУбличныйIDКогдаегоНетВстатике =
                                        КурсорУниверсальныйДляБазыДанных("SuccessLogin",
                                                new String[]{"id"}, " id IS NOT NULL", null, null, null, null, null);//
                                ///
                                if(Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount()>0){
                                    Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.moveToFirst();
                                    ////
                                    Log.d(this.getClass().getName(), " Курсор_ИщемПУбличныйIDКогдаегоНетВстатике " + Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount());

                                    ПолученныйID[0] =Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getInt(0);



                                }


                                Log.d(this.getClass().getName(), "   ПолученныйID[0] " +   ПолученныйID[0]);
                            } catch (ExecutionException e) {
                                e.printStackTrace();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            } catch (TimeoutException e) {
                                e.printStackTrace();
                            }


                            PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID=String.valueOf(ПолученныйID[0]);

                            Log.d(this.getClass().getName(), "  PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID" +
                                    PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID+ " String.valueOf(ПолученныйID[0]) " +String.valueOf(ПолученныйID[0]));

                            ПубличныйIDТекущегоПользователя=String.valueOf(ПолученныйID[0]);
                        }


                        Log.d(this.getClass().getName(), "ИНдексПубличногоIDЗначение " +ИНдексПубличногоIDЗначение);





                    }

                    ////
                }





                ВставляемВБАзуВыбраннуюОргнизацию.put("user_update",ПубличныйIDТекущегоПользователя);




                ВставляемВБАзуВыбраннуюОргнизацию.put("chosen_organization","1");
                ВставляемВБАзуВыбраннуюОргнизацию.put("date_update",ДатаДляОрганизации());

///////todo вставка организации
                //ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();

                Log.i(this.getClass().getName(), " ВыбранаяОрнанизация.getText().toString()" + ВыбранаяОрнанизация.getText().toString());

                ////// TODO САМО ОБНОВЛЕНИЕ ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                long      РезультатОбновлениеЧерезКонтрейнерОбновления = ССылкаНаСозданнуюБазу.update("organization", ВставляемВБАзуВыбраннуюОргнизацию, "name= ?", new String[]{ВыбранаяОрнанизация.getText().toString()});

                /////
                if ( РезультатОбновлениеЧерезКонтрейнерОбновления>0) {
                    ССылкаНаСозданнуюБазу.setTransactionSuccessful();

                }
                ССылкаНаСозданнуюБазу.endTransaction();
                Log.i(this.getClass().getName(), " РезультатОбновлениеЧерезКонтрейнерОбновления" + РезультатОбновлениеЧерезКонтрейнерОбновления);

                //todo ВО ВРЕМЯ СИНХРОНИЗХАЦИИ В ФОНЕ ИЗМЕНЯЕМ ДАТЫ ТАБЛИЦ ТОЛЬКО ПО ТАБЛИЦАМ КОГДА ИДЕМ
                int Результат_ПриписиИзменнийВерсииДанныхВФонеПриСменеОрганизации = МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных("organization", new Date());
                Log.i(this.getClass().getName(), "   Результат_ПриписиИзменнийВерсииДанныхВФонеПриСменеОрганизации :" + Результат_ПриписиИзменнийВерсииДанныхВФонеПриСменеОрганизации );


                /////
                Log.i(this.getClass().getName(), " Результат_ПриписиИзменнийВерсииДанныхВФонеПриСменеОрганизации" + Результат_ПриписиИзменнийВерсииДанныхВФонеПриСменеОрганизации);
            }


            ///поймать ошибку
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///////
        }
        return РезультатОбновлениеЧерезКонтрейнер;



















    }

    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
    public String ДатаДляОрганизации() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);
    }



//


    ////TODO КОТОТРЫЙ УЗНАЕТ ИЗ БАЗЫ КАКОЙ РЕЖИМ РАБОТЫ ИНТРЕНТА WIFI AND MOBILE
    String МетодПолучениеЗначенияРежимаРаботыИнтернетаWifiИлиInternet(Context КонтекстДляРежимаИнтрента ,String Таблица, String Поле){
        Cursor asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля=null;
        String РезультаРежимИнтренета = null;

        try {
            asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля     =  new MODEL_synchronized(КонтекстДляРежимаИнтрента).КурсорУниверсальныйДляБазыДанных(Таблица, new String[]
                            {Поле}, null,
                    null, null, null,null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
            //////
            if ( asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля.getCount()>0) {
                asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля.moveToFirst();

                РезультаРежимИнтренета=  asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля.getString(0);
            }else{

                РезультаРежимИнтренета="Mobile";
            }
            ///поймать ошибку
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///////
        }

        return  РезультаРежимИнтренета;
    }




///todo записываем выбраную  ОРГАНИЗАЦИЮ В БАЗУ

    Integer  МетодКоторыйЗаписываемВыбранныйРежимИнтрернетаWifiИлиMobile(String ПередаваемыйРежимИнтрентета, Context КонтекстWIFI  ,String Таблица ,String Поля) {
        //
/////todo КОД ЗАПОЛЕНЕИЯ ДАННЫМИ В СПИНЕР ЦФО ДЕПАРТАМЕНТ МЕСЯЦ
//
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();
        Integer  asyncTaskLoaderОбновляемВыбрануюОрганизацию = (Integer) new AsyncTaskLoader(КонтекстWIFI) {
            Integer   РезультатОбновлениеЧерезКонтрейнер=0;
            @Override
            public Object loadInBackground() {
                try {
                    Log.d(this.getClass().getName(), " ПередаваемыйРежимИнтрентета  " +ПередаваемыйРежимИнтрентета);
                    ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
                    ////
                    /////
                    ContentValues ВставляемВБАзуВыбранныйРежимИнтренета=new ContentValues();
                    ////TODO ОБНУЛЯЕМ КАКУЮ ОРГАНИЗАЦИЮ ВЫБРАЛИ ОЧИЩАЕМ
                    ВставляемВБАзуВыбранныйРежимИнтренета.put(Поля,"");

                    РезультатОбновлениеЧерезКонтрейнер = ССылкаНаСозданнуюБазу.update(Таблица, ВставляемВБАзуВыбранныйРежимИнтренета, "id= ?",
                            new String[]{PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID});

                    ////TODO ОБНУЛЯЕМ УЖЕ ВСТАВЛЯЕМ НОВУЮ ВЫБРАНОУЮ СОТРУДНИКОВ ОРГАНИЗАЦИЮ
                    ВставляемВБАзуВыбранныйРежимИнтренета.clear();
                    /////////
                    ВставляемВБАзуВыбранныйРежимИнтренета.put("id",PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID);
                    ВставляемВБАзуВыбранныйРежимИнтренета.put(Поля,ПередаваемыйРежимИнтрентета);
                    ВставляемВБАзуВыбранныйРежимИнтренета.put("date_update",ДатаДляОрганизации());

                    ////// TODO САМО ОБНОВЛЕНИЕ ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
                    РезультатОбновлениеЧерезКонтрейнер = ССылкаНаСозданнуюБазу.update(Таблица, ВставляемВБАзуВыбранныйРежимИнтренета, "id= ?", new String[]{PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID});

                    /////
                    if ( РезультатОбновлениеЧерезКонтрейнер>0) {
                        ССылкаНаСозданнуюБазу.setTransactionSuccessful();

                    }
                    ССылкаНаСозданнуюБазу.endTransaction();

                    //todo ВО ВРЕМЯ СИНХРОНИЗХАЦИИ В ФОНЕ ИЗМЕНЯЕМ ДАТЫ ТАБЛИЦ ТОЛЬКО ПО ТАБЛИЦАМ КОГДА ИДЕМ
//                    int Результат_ПриписиИзменнийВерсииДанныхВФонеПриСменеРежимаИнтретета= МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных("SuccessLogin", new Date());
//                    Log.i(this.getClass().getName(), "  Результат_ПриписиИзменнийВерсииДанныхВФонеПриСменеРежимаИнтретета :" + Результат_ПриписиИзменнийВерсииДанныхВФонеПриСменеРежимаИнтретета);

                    ///поймать ошибку
                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    ///////
                }

                return РезультатОбновлениеЧерезКонтрейнер;
            }

            //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
            public String ДатаДляОрганизации() {
                Date Дата = Calendar.getInstance().getTime();
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
                dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
                return dateFormat.format(Дата);
            }

        }.loadInBackground();
        return asyncTaskLoaderОбновляемВыбрануюОрганизацию;
    }



    ////TODO КОТОТРЫЙ УЗНАЕТ ИЗ БАЗЫ КАКОЙ РЕЖИМ РАБОТЫ ИНТРЕНТА WIFI AND MOBILE
    String МетодПолучениеИмяСистемыДляСменыПользователя(Context КонтекстДляРежимаИнтрента){
        //
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();
        Cursor asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля = (Cursor) new AsyncTaskLoader(КонтекстДляРежимаИнтрента) {
            @Override
            public Object loadInBackground() {
                final Cursor[] Курсор_ЗагружаетДанныеПриСозданииТабеля = {null};
                try {
                    Курсор_ЗагружаетДанныеПриСозданииТабеля[0] =  new MODEL_synchronized(КонтекстДляРежимаИнтрента).КурсорУниверсальныйДляБазыДанных("SuccessLogin", new String[]
                                    {"success_users"}, null,
                            null, null, null,null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                    //////
                    if (Курсор_ЗагружаетДанныеПриСозданииТабеля[0].getCount()>0) {
                        Курсор_ЗагружаетДанныеПриСозданииТабеля[0].moveToFirst();
                    }
                    ///поймать ошибку
                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    ///////
                }
                return Курсор_ЗагружаетДанныеПриСозданииТабеля[0];
            }
        }.loadInBackground();
        return  asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля.getString(0);
    }





    //////todo метод ДЛЯ ТАБЕЛЯ  ЗАГРУЖАЕТ СОТРУДНИКОВ В КОНТЕРТНЫЙ ТАБЕЛЬ
    Cursor МетодЗагружаетСотрудниковListViewТабеля(int IDЧьиДанныеДляСотрудников, Long полученнаяUUIDНазванияОрганизации, String finalУниверсальноеИмяТабеля,Context контекстLIstView,
                                                   int МЕсяцДляКурсораТабелей,int ГодДляКурсораТабелей,String ЦифровоеИмяНовгоТабеля) {
        ////

        ССылкаНаСозданнуюБазу = this.getWritableDatabase();


        Cursor Курсор_ДляЗагрузкиСотрудниковНепостредственнов = null;
        try {
            Курсор_ДляЗагрузкиСотрудниковНепостредственнов = new MODEL_synchronized(контекстLIstView).КурсорУниверсальныйДляБазыДанных("viewtabel",
                    new String[]{"name,uuid,BirthDate,snils,_id,status_carried_out"},//     new String[]{"name,id,uuid,BirthDate,snils},
                    " user_update= ?  AND  month_tabels=?  AND year_tabels=? AND nametabel=? AND organizations=? AND status_send!=?  AND nametabel_typename=? AND name IS NOT NULL",//AND status_send IS NULL//"Удаленная" //AND status_send!=?" /AND status_send IS NULL AND  name IS NOT NULL AND fio IS NOT NULL
                    new String[]{String.valueOf(IDЧьиДанныеДляСотрудников), String.valueOf(МЕсяцДляКурсораТабелей), String.valueOf(ГодДляКурсораТабелей),
                            finalУниверсальноеИмяТабеля.trim(), String.valueOf(полученнаяUUIDНазванияОрганизации), "Удаленная",String.valueOf(ЦифровоеИмяНовгоТабеля)}, null, null, "date_update DESC", null);

            //////
            if (Курсор_ДляЗагрузкиСотрудниковНепостредственнов.getCount()>0) {
                Курсор_ДляЗагрузкиСотрудниковНепостредственнов.moveToFirst();
            }

            /////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        // new String[] { filter+"%" }, // new String[] {"%"+ filter+ "%" }, n
        //todo КУРСОР ЧЕРЕЗ ПОИСК LIKE
        Log.i(this.getClass().getName(), " Курсор_ДляЗагрузкиСотрудниковНепостредственновListView.getCount() " + Курсор_ДляЗагрузкиСотрудниковНепостредственнов.getCount());

        return Курсор_ДляЗагрузкиСотрудниковНепостредственнов;

    }










// TODO: 12.03.2021 Метод который получает данные при возврате из ШАБЛОНОВ

    //////todo метод ДЛЯ ТАБЕЛЯ  ЗАГРУЖАЕТ СОТРУДНИКОВ В КОНТЕРТНЫЙ ТАБЕЛЬ
    Cursor МетодЗагружаетСотрудниковListViewТабеляПриВозвратеИЗШаблона(Context контекстLIstView,String ЦифровоеИмяНовгоТабеля,int месяцДляПермещенияПоТабелю,int годДляПермещенияПоТабелю) {
        ////

        ССылкаНаСозданнуюБазу = this.getWritableDatabase();

// TODO: 07.05.2021  ГЛАВНЫЙ КУРСОР СОГРУЗКИ СОТУРДНИКОВ В ТАБЕЛЬ

        Cursor Курсор_ДляЗагрузкиСотрудниковНепостредственновИзШаблона = null;
        try {
            Курсор_ДляЗагрузкиСотрудниковНепостредственновИзШаблона = new MODEL_synchronized(контекстLIstView).КурсорУниверсальныйДляБазыДанных("viewtabel",
                    new String[]{"*"},//     new String[]{"name,id,uuid,BirthDate,snils},
                    "status_send!=?  AND cfo=? AND fio !=?  AND month_tabels=? AND  year_tabels =?  AND fio IS NOT NULL AND name IS NOT NULL",//  nametabel_typename  AND nametabel IS NOT NULL",//AND status_send IS NULL//"Удаленная" //AND status_send!=?" /AND status_send IS NULL AND  name IS NOT NULL AND fio IS NOT NULL
                    new String[]{ "Удаленная",String.valueOf(ЦифровоеИмяНовгоТабеля),"",String.valueOf(месяцДляПермещенияПоТабелю), String.valueOf(годДляПермещенияПоТабелю)},
                    "name", null, "name", null);

            // TODO: 07.05.2021  данный курсор с датой показывает какой сотрудника изменили такой и сверху
/*
            Курсор_ДляЗагрузкиСотрудниковНепостредственновИзШаблона = new MODEL_synchronized(контекстLIstView).КурсорУниверсальныйДляБазыДанных("viewtabel",
                    new String[]{"*"},//     new String[]{"name,id,uuid,BirthDate,snils},
                    "status_send!=?  AND nametabel_typename=? AND uuid !=? AND uuid IS NOT NULL AND name IS NOT NULL",// AND nametabel IS NOT NULL",//AND status_send IS NULL//"Удаленная" //AND status_send!=?" /AND status_send IS NULL AND  name IS NOT NULL AND fio IS NOT NULL
                    new String[]{ "Удаленная",String.valueOf(ЦифровоеИмяНовгоТабеля),""},
                    "name", null, "date_update DESC", null);*/

            //////
            if (Курсор_ДляЗагрузкиСотрудниковНепостредственновИзШаблона.getCount()>0) {
                Курсор_ДляЗагрузкиСотрудниковНепостредственновИзШаблона.moveToFirst();
            }

            /////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        // new String[] { filter+"%" }, // new String[] {"%"+ filter+ "%" }, n
        //todo КУРСОР ЧЕРЕЗ ПОИСК LIKE
        Log.i(this.getClass().getName(), " Курсор_ДляЗагрузкиСотрудниковНепостредственновИзШаблонаListView.getCount() " + Курсор_ДляЗагрузкиСотрудниковНепостредственновИзШаблона.getCount());

        return Курсор_ДляЗагрузкиСотрудниковНепостредственновИзШаблона;

    }












//TODO МЕТОД ЗАГРУЗНИ НОВОГО СОТРУДНИКА

    Cursor МетодЗагружаетЗначенияНовгоСотрудника(Context КонтекстДЛяСотрудника) {
     /*   Cursor asyncTaskLoader= (Cursor) new AsyncTaskLoader(КонтекстДЛяСотрудника) {
            @Override
            public Object loadInBackground() {*/

        Cursor Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеляВнутри = null;
        try {
            Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеляВнутри = new MODEL_synchronized(КонтекстДЛяСотрудника).КурсорУниверсальныйДляБазыДанных("tabels", new String[]
                            {"month_tabels,year_tabels,cfo"}, "status_send!=?   AND month_tabels IS NOT NULL  AND year_tabels IS NOT NULL ",new String[]{"Удаленная"},
                    "month_tabels,year_tabels",
                    null, "date_update DESC", null);
            ////
            ///
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        ///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
        ////
        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК //tabels
        /////

      /*          return Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеляВнутри;
            }
        }.loadInBackground();*/
        return Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеляВнутри ;
    }













//TODO МЕТОД ЗАГРУЗНИ НОВОГО шаблона

    Cursor МетодЗагружаетЗначенияШаблонов(int полученнаяUUIDОрганизациидДляКурсораСпинераДаты,Context КонтекстДЛяСотрудника) {
     /*   Cursor asyncTaskLoader= (Cursor) new AsyncTaskLoader(КонтекстДЛяСотрудника) {
            @Override
            public Object loadInBackground() {*/

        Cursor Курсор_ЗагружаетАрайдистЗначенийНовогоШаблонаВнутри = null;
        try {
            Курсор_ЗагружаетАрайдистЗначенийНовогоШаблонаВнутри = new MODEL_synchronized(КонтекстДЛяСотрудника).КурсорУниверсальныйДляБазыДанных("Templates", new String[]
                            {"*"}, "user_update=?",
                    new String[]{String.valueOf(полученнаяUUIDОрганизациидДляКурсораСпинераДаты)},
                    null, null, "date_update DESC", null);
            ////
            ///
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        ///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
        ////
        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК //tabels
        /////

      /*          return Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеляВнутри;
            }
        }.loadInBackground();*/
        return Курсор_ЗагружаетАрайдистЗначенийНовогоШаблонаВнутри ;
    }




















    //todo загружет уже готовые созданные табеля
    Cursor МетодЗагружетУжеготовыеТабеля(Context КонтекстДляЗагружемыхТАбелей, Long UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников,int месяцДляПермещенияПоТабелю,int годДляПермещенияПоТабелю) {
        /*Cursor asyncTaskLoaderЗагружаемТабеляСозданный = (Cursor) new AsyncTaskLoader(КонтекстДляЗагружемыхТАбелей) {
            @Override
            public Object loadInBackground() {*/
//////TODO ГЛАВНЫЙ КУРСОР ДЛЯ НЕПОСРЕДТСВЕНОГО ЗАГРУЗКИ СОТРУДНИКА
        ////

        ССылкаНаСозданнуюБазу = this.getWritableDatabase();

        Cursor Курсор_ЗагружаемТабеляСозданныйВнутрений = null;
        try {
            Курсор_ЗагружаемТабеляСозданныйВнутрений = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(КонтекстДляЗагружемыхТАбелей).КурсорУниверсальныйДляБазыДанных(
                    "viewtabel", new String[]{"*"},
                    "uuid=?    AND status_send !=? \n" +
                            "AND month_tabels=? AND  year_tabels =? AND fio IS NOT NULL", new String[]{String.valueOf(UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников),
                            "Удаленная",String.valueOf(месяцДляПермещенияПоТабелю), String.valueOf(годДляПермещенияПоТабелю)},
                    null, null, null, "1");
            ///////todoс сортиртировной по дате кто последний изменяли сотрудника тот и сверху


            ////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

///TODO ЗАПУСКАЕМ  ПуллПамяти
        return Курсор_ЗагружаемТабеляСозданныйВнутрений;
      /*      }
        }.loadInBackground();
        return asyncTaskLoaderЗагружаемТабеляСозданный;*/
    }

























    //todo загружет уже готовые созданные табеля
    Cursor МетодЗагружетУжеготовыеТабеляДляСкролаПОТабелю(Context КонтекстДляЗагружемыхТАбелей, int ЦифровоеИмяНовгоТабеля,int месяцДляПермещенияПоТабелю,int годДляПермещенияПоТабелю) {
        /*Cursor asyncTaskLoaderЗагружаемТабеляСозданный = (Cursor) new AsyncTaskLoader(КонтекстДляЗагружемыхТАбелей) {
            @Override
            public Object loadInBackground() {*/
//////TODO ГЛАВНЫЙ КУРСОР ДЛЯ НЕПОСРЕДТСВЕНОГО ЗАГРУЗКИ СОТРУДНИКА
        ////

        ССылкаНаСозданнуюБазу = this.getWritableDatabase();

        Cursor Курсор_ЗагружаемТабеляСозданныйВнутрений = null;
        try {
            Курсор_ЗагружаемТабеляСозданныйВнутрений = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(КонтекстДляЗагружемыхТАбелей).КурсорУниверсальныйДляБазыДанных(
                    "viewtabel", new String[]{"*"},
                    "cfo=?  AND status_send !=?  AND month_tabels=?   AND  year_tabels=? AND fio IS NOT NULL", new String[]{String.valueOf(ЦифровоеИмяНовгоТабеля),"Удаленная", String.valueOf(месяцДляПермещенияПоТабелю), String.valueOf(годДляПермещенияПоТабелю)},
                    null, null, "name", null);




            ///////todo\
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

///TODO ЗАПУСКАЕМ  ПуллПамяти
        return Курсор_ЗагружаемТабеляСозданныйВнутрений;
      /*      }
        }.loadInBackground();
        return asyncTaskLoaderЗагружаемТабеляСозданный;*/
    }



    //todo загружет уже готовые созданные табеля
    Cursor МетодЗагружетУжеготовыеТабеляДляСкролаПОТабелюТолькоКоличествоСТорочек(Context КонтекстДляЗагружемыхТАбелей, int ЦифровоеИмяНовгоТабеля, int месяцДляПермещенияПоТабелю,int годДляПермещенияПоТабелю) {
        /*Cursor asyncTaskLoaderЗагружаемТабеляСозданный = (Cursor) new AsyncTaskLoader(КонтекстДляЗагружемыхТАбелей) {
            @Override
            public Object loadInBackground() {*/
//////TODO ГЛАВНЫЙ КУРСОР ДЛЯ НЕПОСРЕДТСВЕНОГО ЗАГРУЗКИ СОТРУДНИКА
        ////

        ССылкаНаСозданнуюБазу = this.getWritableDatabase();

        Cursor Курсор_ЗагружаемТабеляСозданныйВнутрений = null;
        try {
            Курсор_ЗагружаемТабеляСозданныйВнутрений = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(КонтекстДляЗагружемыхТАбелей).КурсорУниверсальныйДляБазыДанных(
                    "viewtabel", new String[]{"*"},
                    "cfo=? AND status_send !=? AND month_tabels=? AND  year_tabels=? AND fio IS NOT NULL ", new String[]{String.valueOf(ЦифровоеИмяНовгоТабеля),"Удаленная", String.valueOf(месяцДляПермещенияПоТабелю), String.valueOf(годДляПермещенияПоТабелю)},
                    null, null, "date_update DESC", null);




            ///////todo\
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

///TODO ЗАПУСКАЕМ  ПуллПамяти
        return Курсор_ЗагружаемТабеляСозданныйВнутрений;
      /*      }
        }.loadInBackground();
        return asyncTaskLoaderЗагружаемТабеляСозданный;*/
    }












    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
    public String ГлавнаяДатаИВремяОперацийСБазойДанных() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        //  dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);
    }









    Long МетодЗАписиПолученогоОтСервреаIDПубличного(@NonNull String ПолученныйотСервреаПубличныйID) throws ExecutionException, InterruptedException {


        final long[] РезультатИзмененияВерсииДанныхПриЗаписиОрганизации = {0l};

        final String[] finalПолученныйотСервреаПубличныйID = {ПолученныйотСервреаПубличныйID};
        /////
        CountDownLatch countDownLatch=new CountDownLatch(1);

        ///////

        ///
        countDownLatch.countDown();
        //////
        Future futureЗаписьОрганизации=Executors.newCachedThreadPool().submit(new Callable<Long>() {
            @Override
            public Long call() throws Exception {


                try{



                    if (finalПолученныйотСервреаПубличныйID[0] !=null) {
                        ///TODO ВСТАВКА НОВГО ТАБЕЛЯ В ТАБЛИЦУ
                        if (finalПолученныйотСервреаПубличныйID[0].length()>0  ) {
                            ////////
                            finalПолученныйотСервреаПубличныйID[0] =    finalПолученныйотСервреаПубличныйID[0].replaceAll("[^0-9]","");

                            ContentValues АдаптерВставкиПолученогоПубличногоID=new ContentValues();

                            АдаптерВставкиПолученогоПубличногоID.put("user_update",Integer.parseInt(finalПолученныйотСервреаПубличныйID[0]));

                            АдаптерВставкиПолученогоПубличногоID.put("date_update", ГлавнаяДатаИВремяОперацийСБазойДанных());

                            // TODO: 02.05.2021
                            Random random=new Random();
                            int ГнерацияДляОрганизацииUUDi=random.nextInt(10000);
                            ///////
                            String ФиналUUIDДляоргнанизации=finalПолученныйотСервреаПубличныйID[0]+ГнерацияДляОрганизацииUUDi;

                            АдаптерВставкиПолученогоПубличногоID.put("uuid", ФиналUUIDДляоргнанизации);

                            /////////
                            // TODO: 20.04.2021 определяем ели UUID или нет
                            Cursor     Курсор_УзнаемЕслиUUIDВТАблицеОрганизация=null;
                            try {
                                Курсор_УзнаемЕслиUUIDВТАблицеОрганизация =
                                        КурсорУниверсальныйДляБазыДанных("settings_tabels",
                                                new String[]{"user_update"}, "user_update=?", new String[]{String.valueOf(ПолученныйотСервреаПубличныйID)}, null, null, null, null);//
                            } catch (ExecutionException e) {
                                e.printStackTrace();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            } catch (TimeoutException e) {
                                e.printStackTrace();
                            }
                            int UUIDдлянастроуки = 0;

                            if (Курсор_УзнаемЕслиUUIDВТАблицеОрганизация!=null){
                                if (Курсор_УзнаемЕслиUUIDВТАблицеОрганизация.getCount()>0){
                                    Курсор_УзнаемЕслиUUIDВТАблицеОрганизация.moveToFirst();
                                    int IndexUUID=Курсор_УзнаемЕслиUUIDВТАблицеОрганизация.getColumnIndex("user_update");
                                    /////
                                    int UUIDОрншанизации=Курсор_УзнаемЕслиUUIDВТАблицеОрганизация.getInt(IndexUUID);

                                    Log.d(this.getClass().getName(), "IndexUUID " + IndexUUID);
                                }else{

                                    //////
                                    long РезультатВставкиПолученогоОтСервераID= ВставкаДанныхЧерезКонтейнерПервыйолученныйПубличныйIDотСервера("settings_tabels",
                                            АдаптерВставкиПолученогоПубличногоID);
                                    Log.d(this.getClass().getName(), "РезультатВставкиПолученогоОтСервераID " + РезультатВставкиПолученогоОтСервераID );


                                    // TODO: 02.05.2021

                                    ////// TODO ВРЕМЯ ДЛЯ МОДИФИКАЦИИ ДАННЫХ
/*

                            SimpleDateFormat simpleDateFormat =
                                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));

                            String ДатаДляОрганизации = simpleDateFormat.format(new Date());
*/




                                    РезультатИзмененияВерсииДанныхПриЗаписиОрганизации[0] =
                                            МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных("settings_tabels", new Date());

                                    Log.d(this.getClass().getName(), "РезультатИзмененияВерсииДанныхПриЗаписиОрганизации " + РезультатИзмененияВерсииДанныхПриЗаписиОрганизации[0]);





                                }
                            }


                            // TODO: 27.04.2021
                        }


                    }




                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

                return РезультатИзмененияВерсииДанныхПриЗаписиОрганизации[0];
            }
        });

        //////
        try {
            futureЗаписьОрганизации.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ////////
        countDownLatch.await();
        ////
        if(futureЗаписьОрганизации.isDone()){
            //

            //////
            //  futureЗаписьОрганизации.cancel(false);
        }
        return (Long) futureЗаписьОрганизации.get();
    }






























    // TODO: 09.04.2021 ПОЛУЧЕНИЕ ПОСЛЕ JSON ПОЛУЧАЕМ САМ ФАЙЛ APK
    // TODO: 09.04.2021 ПОЛУЧЕНИЕ ПОСЛЕ JSON ПОЛУЧАЕМ САМ ФАЙЛ APK
    File УниверсальныйБуферAPKФайлаПОсСервера(String АдресЗагрузки,String НазваниеФайлаКоторыйНадоЗагрузить,Context context) throws IOException, ExecutionException, InterruptedException,
            TimeoutException, NoSuchAlgorithmException, KeyManagementException {
        //final File[] СамФайлAPK = {null};
        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ
        //File БуферПолученнниеAPKФайл =null;


        HttpURLConnection[] ПодключениеИнтернетДляОтправкиНаСервер = {null};
        ///

        //////
        Future<File> СамФайлAPK=     Executors.newSingleThreadExecutor().submit(new Callable<File>() {
            @Override
            public File call() throws Exception {
                File СамФайлAPKВнутри = null;

                System.out.println("УниверсальныйБуферAPKФайловсСервера");
                ////////перевод перменных внутрь Анисакска
                ///////// ПРИ НУЛЕВОМ ЗАПУСКЕ ЛОВИМ ЭТОТ МОМЕНТ ДАТОЙ ИЗ ТАБЛИЦЫ АНДОЙД
                //////КОНЕЦ ЛОВЛИ НУЛОЙ ДАТЫ ТАБЛИЦЫ
                Object ОшибкаТекущегоМетода;
                int РазмерФАйла = 0;
                try {
                    String Adress_String =null;
                    Adress_String = PUBLIC_CONTENT.ПубличныйАдресGlassFish + АдресЗагрузки; /////"dsu1.glassfish/update_android_dsu1/output-metadata.json";

                    Log.d(this.getClass().getName(), "Adress_String " + Adress_String);

                    ////
                    Adress_String = Adress_String.replace(" ", "%20");
                    ///
                    Log.d(this.getClass().getName(), " Adress_String " +Adress_String);


                    URL Adress = null;
                    Adress = new URL(Adress_String);
                    ПодключениеИнтернетДляОтправкиНаСервер[0] = (HttpURLConnection) (Adress).openConnection();/////САМ ФАЙЛ JSON C ДАННЫМИ
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestProperty("Content-Type","application/octet-stream");
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestProperty("Accept-Encoding", "gzip,deflate,sdch");
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestProperty("Connection", "Keep-Alive");
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestProperty("Accept-Language", "ru-RU");
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestMethod("GET"); ///GET //ПРОВЕРЯЕМ ЕСЛИ ПОДКЛЮЧЕНИЕ К СЕВРЛЕТУ НА СЕРВЕР ВЫБРАСЫВАЕМ
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setReadTimeout(15000); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ(30000);
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setConnectTimeout(1000);//todo САМ ПОТОК ДАННЫХ(1000);
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setUseCaches(true);
                    //////////

                    ПодключениеИнтернетДляОтправкиНаСервер[0].connect(); /////////////ТОЛЬКО СОЕДИНЕНИЕ
                    ПодключениеИнтернетДляОтправкиНаСервер[0].getResponseCode();///ВАЖНАЯ КОМАНДА  СТУЧИТЬСЯ В СЕРВЛЕТ ECLIPSE СТУЧИМСЯ ВТОРОЙ РАЗ ЧТОБЫ ПОЛУЧИТЬ УЖЕ САМ JSON
                    ПодключениеИнтернетДляОтправкиНаСервер[0].getContent(); ////РЕАЛЬНОЕ ПОЛУЧЕНИЕ ДАННЫХ С ИНТРЕНЕТА



                    //////


                    ////TODO И ЕСЛИ ПРИШЕЛ ОТ СЕРВЕРА ОТВЕТ ПОЛОЖИТЕЛЬНО ТО ТОГДА ЗАПУСКАМ ПРОЧТЕНИЯ ПОТОКА ПРИШЕДШЕГО С СЕРВЕРА
                    if (ПодключениеИнтернетДляОтправкиНаСервер[0].getResponseCode() == 200) {
                        //TODO шифровани
                        //   Log.d(this.getClass().getName(), "  ПолитикаРасшифровки  " +PUBLIC_CONTENT. ПолитикаРасшифровки);
                        //////тест шифрование
                        ///// todo получаем данные с сервера



                        // TODO: 09.04.2021 подождать когда файлы дло грузяться
                       /* if (!НазваниеФайлаКоторыйНадоЗагрузить.equalsIgnoreCase("analysis_version.json")) {
                            try {
                                TimeUnit.MILLISECONDS.sleep(50);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }else{
                            try {
                                TimeUnit.MILLISECONDS.sleep(10);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                        }*/



                        int lenghtOfFile = ПодключениеИнтернетДляОтправкиНаСервер[0].getContentLength();


                        ByteArrayOutputStream buffer = null;

                        // TODO: 12.05.2021 запускаем если файл пришел
                        if (lenghtOfFile>0) {
                            InputStream  input=null;
                            ///////
                            input = ПодключениеИнтернетДляОтправкиНаСервер[0].getInputStream();
                            //////
                            Log.i(this.getClass().getName(), " ПРИШЛОЙ ФАЙЛ СЛУЖБА ЗАГРУЗКА ОБНОВЛЕНИЯ  ДЛИНА ФАЙЛА : " +lenghtOfFile);


                            buffer = new ByteArrayOutputStream();
                            int nRead;
                            byte[] data = new byte[8192];///8192

                            while ((nRead = input.read(data, 0, data.length)) != -1) {
                                buffer.write(data, 0, nRead);
                            }
                            //  buffer.toByteArray();
                        }else {
                            Log.i(this.getClass().getName(), " нулевой файл  ошибка ПРИШЛОЙ ФАЙЛ СЛУЖБА ЗАГРУЗКА ОБНОВЛЕНИЯ  ДЛИНА ФАЙЛА : " +lenghtOfFile);
                        }

                        //File file = new File(contextСозданиеБАзы.getExternalFilesDir(null), "DemoFile.jpg");
                        File ПутькФайлу = null;
                        if (Build.VERSION.SDK_INT >= 30)  {


                            ПутькФайлу = contextСозданиеБАзы.getExternalFilesDir(null);

                        }else{


                            ПутькФайлу = Environment.getExternalStoragePublicDirectory(
                                    Environment.DIRECTORY_DOWNLOADS);
                        }


                        СамФайлAPKВнутри = new File(ПутькФайлу, "/" + НазваниеФайлаКоторыйНадоЗагрузить);





// TODO: 18.05.2021 Второй вариант созданияя файла для Samsung
                        Log.i(this.getClass().getName(), " СамФайлAPKВнутри.getParentFile().mkdirs() " +СамФайлAPKВнутри.length());



                        ////
                        СамФайлAPKВнутри.getParentFile().mkdirs();


                        if (СамФайлAPKВнутри.createNewFile()) {


                            Log.d(this.getClass().getName(), "Будущий файл успешно создалься , далее запись на диск новго APk файла ");

                            FileOutputStream fos = null;
                            try {
                                fos = new FileOutputStream(СамФайлAPKВнутри);


                                // Put data in your baos

                                buffer.writeTo(fos);




                            } catch (Exception e) {
                                e.printStackTrace();
                                ///метод запись ошибок в таблицу
                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                new   КлассВставкиОшибок(context).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                            } finally {
                                fos.close();
                                buffer.close();
                            }



                            //////




                        } else {
                            System.out.println(" Ошибка не создалься Будущий файл успешно создалься , далее запись на диск новго APk файла ");

                            Log.e(this.getClass().getName(), "Ошибка не создалься Будущий файл успешно создалься , далее запись на диск новго APk файла  СЛУЖБА ");
                        }
                    } else {
                        Log.e(this.getClass().getName(), "Ошибка не создалься Будущий файл успешно создалься , далее запись на диск новго APk файла  СЛУЖБА ");
                    }



                } catch (IOException  ex) {
                    ex.printStackTrace();
                    ///метод запись ошибок в таблицу
                    ОшибкаТекущегоМетода = ex.toString();

                    if(!ex.toString().equals("java.io.EOFException")){


                        Log.e(MODEL_synchronized.class.getName(), "Ошибка " + ОшибкаТекущегоМетода + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber()+ " ОшибкаТекущегоМетода " +ОшибкаТекущегоМетода.toString());
                        new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(ex.toString(), MODEL_synchronized.class.getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                    }


                }finally {
                    ПодключениеИнтернетДляОтправкиНаСервер[0].disconnect();

                }
                return  СамФайлAPKВнутри ;
            }
        });




        //// todo get ASYNtASK
        return (File)   СамФайлAPK.get();

    }








    // TODO: 09.04.2021 метод получение УниверсальныйБуферAPKФайловсСервера обнвоения
    int УниверсальныйБуферJSONВерсииПОсСервера(String АдресЗагрузки) throws IOException, ExecutionException, InterruptedException,
            TimeoutException, NoSuchAlgorithmException, KeyManagementException {

        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ
        StringBuffer БуферПолученнниеJOSNФайла =new StringBuffer();
        ///


        // AsyncTask AsyncTaskУнивермальныйДляОбмена=null;

        Future<Integer>  futureВерсияJSON= Executors.newSingleThreadExecutor().submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {

                int   ПолученнаяВерсияПОДЛяОбновления=0;
                HttpURLConnection[] ПодключениеИнтернетДляОтправкиНаСервер = {null};
                ///


                System.out.println("УниверсальныйБуферAPKФайловсСервера");
                ////////перевод перменных внутрь Анисакска
                ///////// ПРИ НУЛЕВОМ ЗАПУСКЕ ЛОВИМ ЭТОТ МОМЕНТ ДАТОЙ ИЗ ТАБЛИЦЫ АНДОЙД
                //////КОНЕЦ ЛОВЛИ НУЛОЙ ДАТЫ ТАБЛИЦЫ
                Object ОшибкаТекущегоМетода;
                try {
                    String Adress_String =null;
                    Adress_String = PUBLIC_CONTENT.ПубличныйАдресGlassFish + АдресЗагрузки; /////"dsu1.glassfish/update_android_dsu1/output-metadata.json";

                    Log.d(this.getClass().getName(), "Adress_String " + Adress_String);

                    ////
                    Adress_String = Adress_String.replace(" ", "%20");
                    ///
                    Log.d(this.getClass().getName(), " Adress_String " +Adress_String);





                    URL Adress = null;
                    Adress = new URL(Adress_String);
                    ПодключениеИнтернетДляОтправкиНаСервер[0] = (HttpURLConnection) (Adress).openConnection();/////САМ ФАЙЛ JSON C ДАННЫМИ
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestProperty("Content-Type","application/json");
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestProperty("Accept-Encoding", "gzip,deflate,sdch");
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestProperty("Connection", "Keep-Alive");
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestProperty("Accept-Language", "ru-RU");
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setRequestMethod("GET"); ///GET //ПРОВЕРЯЕМ ЕСЛИ ПОДКЛЮЧЕНИЕ К СЕВРЛЕТУ НА СЕРВЕР ВЫБРАСЫВАЕМ
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setReadTimeout(15000); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ(30000);
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setConnectTimeout(1000);//todo САМ ПОТОК ДАННЫХ(1000);
                    ПодключениеИнтернетДляОтправкиНаСервер[0].setUseCaches(true);
                    //////////

                    ПодключениеИнтернетДляОтправкиНаСервер[0].connect(); /////////////ТОЛЬКО СОЕДИНЕНИЕ
                    ПодключениеИнтернетДляОтправкиНаСервер[0].getResponseCode();///ВАЖНАЯ КОМАНДА  СТУЧИТЬСЯ В СЕРВЛЕТ ECLIPSE СТУЧИМСЯ ВТОРОЙ РАЗ ЧТОБЫ ПОЛУЧИТЬ УЖЕ САМ JSON
                    ПодключениеИнтернетДляОтправкиНаСервер[0].getContent(); ////РЕАЛЬНОЕ ПОЛУЧЕНИЕ ДАННЫХ С ИНТРЕНЕТА

                    ///




                    ////TODO И ЕСЛИ ПРИШЕЛ ОТ СЕРВЕРА ОТВЕТ ПОЛОЖИТЕЛЬНО ТО ТОГДА ЗАПУСКАМ ПРОЧТЕНИЯ ПОТОКА ПРИШЕДШЕГО С СЕРВЕРА
                    if (ПодключениеИнтернетДляОтправкиНаСервер[0].getResponseCode() == 200) {
                        //TODO шифровани
                        Log.d(this.getClass().getName(), "  ПолитикаРасшифровки  " +PUBLIC_CONTENT. ПолитикаРасшифровки);


                        int lenghtOfFile = ПодключениеИнтернетДляОтправкиНаСервер[0].getContentLength();

                        //////тест шифрование
                        InputStream ПришелФайлAPKОбновление= ПодключениеИнтернетДляОтправкиНаСервер[0].getInputStream();
                        ///// todo получаем данные с сервера
                        //GZIPInputStream GZIPПотокОтСЕРВЕРА = new GZIPInputStream(ПодключениеИнтернетДляОтправкиНаСервер[0].getInputStream(),Deflater.BEST_COMPRESSION);
                        BufferedReader РидерОтСервераМетодаGET = new BufferedReader(new InputStreamReader(ПришелФайлAPKОбновление, StandardCharsets.UTF_8));

                        ////размеры буферов
                 /*       8192


                        32768

                        8192
                        */

                        int РазмерБуфера =8192;////РидерОтСервераМетодаGET.toString().toCharArray().length*3; /////     8192;

                        int ФлагНекончильсяЛиПотокДанных=0;

                        char[] СамБУфер = new char[РазмерБуфера];


                        // TODO: 02.06.2021

                        do {
                            ФлагНекончильсяЛиПотокДанных = РидерОтСервераМетодаGET.read(СамБУфер);
                            if (ФлагНекончильсяЛиПотокДанных < 0) {
                                break;
                            }

                            // TODO: 02.06.2021 заполения


                            БуферПолученнниеJOSNФайла.append(СамБУфер, 0, ФлагНекончильсяЛиПотокДанных);

                        } while (true);


                        /////////TODO метод анализа версии


                        String СодержимоеИзПришедшихТаблицДляКлиентаdd;

                        int СодержимоеИзПришедшихТабл = БуферПолученнниеJOSNФайла.lastIndexOf("versionCode");
                        int СодержимоеИзПришедшихТабл2 = БуферПолученнниеJOSNФайла.indexOf("versionName");

                        if (СодержимоеИзПришедшихТабл >= 0 && СодержимоеИзПришедшихТабл2 >= 0) {

                            СодержимоеИзПришедшихТаблицДляКлиентаdd = БуферПолученнниеJOSNФайла.substring(СодержимоеИзПришедшихТабл, СодержимоеИзПришедшихТабл2);
                            ///
                            System.out.println("   СодержимоеИзПришедшихТаблицДляКлиентаdd  " + СодержимоеИзПришедшихТаблицДляКлиентаdd);

                            ПолученнаяВерсияПОДЛяОбновления = Integer.parseInt(СодержимоеИзПришедшихТаблицДляКлиентаdd.replaceAll("[^0-9]", ""));


///todo РЕЗУЛЬТАТ ВЕРСИИ ЛОКАЛЬНОЙ JSOON*//*



                        }



                        /////НАЗВАНИЕ ПОТОКА
                        Log.i(this.getClass().getName(), " БуферПолученнниеJOSNФайла"+ БуферПолученнниеJOSNФайла.toString()
                                + " ПолученнаяВерсияПОДЛяОбновления " +ПолученнаяВерсияПОДЛяОбновления);
                        /////togo закрывает приходящие потоки от сервера
                        ///TODO закрываем метод получение данных
                        РидерОтСервераМетодаGET.close();
                        ПришелФайлAPKОбновление.close();




                        ////TODO нет ответа от сервер или поток нулевой
                    }else{
                        Log.i(this.getClass().getName(), "ПОТОК ПРИШЕЛ НУЛОВОЙ ОТ СЕРВЕРА  " +ПодключениеИнтернетДляОтправкиНаСервер[0].getInputStream().available());
                    }



                } catch (IOException ex) {
                    ex.printStackTrace();
                    ///метод запись ошибок в таблицу
                    ОшибкаТекущегоМетода = ex.toString();

                    if(!ex.toString().equals("java.io.EOFException")){


                        Log.e(MODEL_synchronized.class.getName(), "Ошибка " + ОшибкаТекущегоМетода + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber()+ " ОшибкаТекущегоМетода " +ОшибкаТекущегоМетода.toString());
                        new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(ex.toString(), MODEL_synchronized.class.getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                    }


                }


                return ПолученнаяВерсияПОДЛяОбновления;
            }

        });////



        //// todo get ASYNtASK
        return     (Integer) futureВерсияJSON.get();

    }








    ////TODO ДАННЫЙ МЕТОД ВЫЧИСЛЯЕТ НУЖНО ЛИ ЗАПОЛЯНТЬ ВЫХОДНИЕ ДНИ БУКВОЙ Б
    ContentValues МетодВычисляемВыходныеДниПриСозданииНовогоТабеляАвтоРЕжим(@NonNull Context КонтекстДляРежимаИнтрента ,@NonNull Integer Год,  @NonNull Integer Месяц){

        ContentValues РезультатВычисленияВыходныхДней =new ContentValues();

        try {


// create a Calendar for the 1st of the required month


            Calendar calendar = Calendar.getInstance(new Locale("rus"));

            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, Месяц-1);
            calendar.set(Calendar.YEAR, Год);


            int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
            int day;
            for ( day = 1; day <= daysInMonth; day++) {

                calendar.set(Calendar.DAY_OF_MONTH, day);
                int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
                if (dayOfWeek==Calendar.SUNDAY || dayOfWeek==Calendar.SATURDAY) {


                    System.out.println( "выходные дни при созадни тбалея полльзователь разрешмил авторежим" +day);

                    String ОбьединяемДеньсЦифровдЛЯвСТАВКИ="d"+String.valueOf(day);

                    РезультатВычисленияВыходныхДней.put(ОбьединяемДеньсЦифровдЛЯвСТАВКИ,"В");

                }
            }
// stop when we reach the start of the next month



            Log.d(this.getClass().getName(), "   РезультатВычисленияВыходныхДней  "+  РезультатВычисленияВыходныхДней.valueSet()+ " day " +day);





            ///поймать ошибку
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///////
        }

        return  РезультатВычисленияВыходныхДней;
    }






    ////TODO КОТОТРЫЙ УЗНАЕТ ИЗ БАЗЫ КАКОЙ РЕЖИМ РАБОТЫ ИНТРЕНТА WIFI AND MOBILE
    String МетодПолучениеНазваниеТабеляНаОснованииСФО(Context КонтекстДляРежимаИнтрента ,Integer ТекущееСФО) throws InterruptedException {
        //
        ССылкаНаСозданнуюБазу = this.getWritableDatabase();
        /////
        CompletionService completionServiceПолучениеНАзваниеТабеля=new ExecutorCompletionService<String>(Executors.newSingleThreadExecutor());
        ////
        completionServiceПолучениеНАзваниеТабеля.submit(new Callable<String>() {
            @Override
            public String call() throws Exception {
                String ПолученоеНазваниеТабеляНаОснованииСФО=null;

              Cursor Курсор_ЗагружаетНазваниеТабеляНАОснованииСФО = null;
                try {
                    Курсор_ЗагружаетНазваниеТабеляНАОснованииСФО =  new MODEL_synchronized(КонтекстДляРежимаИнтрента).КурсорУниверсальныйДляБазыДанных("cfo", new String[]
                                    {"name"}, "id=?",
                            new String[]{String.valueOf(ТекущееСФО)}, null, null,"date_update DESC", "1");///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                    //////
                    if (Курсор_ЗагружаетНазваниеТабеляНАОснованииСФО.getCount()>0) {
                        ////
                        Курсор_ЗагружаетНазваниеТабеляНАОснованииСФО.moveToFirst();
                        //
                       ПолученоеНазваниеТабеляНаОснованииСФО=Курсор_ЗагружаетНазваниеТабеляНАОснованииСФО.getString(0).trim();

                        Log.d(this.getClass().getName()," ПолученоеНазваниеТабеляНаОснованииСФО  "+ПолученоеНазваниеТабеляНаОснованииСФО);

                    }

                    ///поймать ошибку
                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    ///////
                }
                return ПолученоеНазваниеТабеляНаОснованииСФО;
            }
        });

        ///
        Future<String> futureПолученоеНазваниеТабеля=    completionServiceПолучениеНАзваниеТабеля.poll(1,TimeUnit.MINUTES);
        //
        String ПолученоеНазваниеТабеля=null;
        try {
            ПолученоеНазваниеТабеля=futureПолученоеНазваниеТабеля.get();
            ////
            if(futureПолученоеНазваниеТабеля.isDone()) {

                futureПолученоеНазваниеТабеля.cancel(false);

            }
            ///поймать ошибку
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new  КлассВставкиОшибок(contextСозданиеБАзы).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///////
        }


        return  ПолученоеНазваниеТабеля;
    }






    // TODO: 15.06.2021 метод вычислчет дни недели  в потоке для отправки и принятии d1,d2,d3

    boolean  МетодКоторыйВычисляетЕслиДНИвПотоке (String ПараметрИмяТаблицыОтАндройдаPostВнутриДляПоиска ,JSONObject БуферСтолбикиДляВставкиВнутриВнутриДляПосика ){



        boolean ЕслиТакойДень = false;
        ////
        StringBuffer БУферИзJSONВБУФЕРАНАЛИЗА=new StringBuffer(БуферСтолбикиДляВставкиВнутриВнутриДляПосика.toString());

        ArrayList<String> АрайЛистДниТабеля=new ArrayList<String>(Arrays.asList("d1","d2","d3","d4","d5","d6","d7","d8","d9","d10","d11","d12","d13","d14"
                ,"d15","d16","d17","d18","d19","d20","d21","d22","d23","d24","d25","d26","d27","d28","d29","d30","d31"));

        if (ПараметрИмяТаблицыОтАндройдаPostВнутриДляПоиска.equalsIgnoreCase("tabels")) {
            //////////
            String ЗначенияИБуфераДляПосикаДней = БУферИзJSONВБУФЕРАНАЛИЗА.toString();


            // TODO: 15.06.2021

            for (String КлючИзАрайЛиста : АрайЛистДниТабеля) {

                System.out.println(КлючИзАрайЛиста);

                //
                ЕслиТакойДень = ЗначенияИБуфераДляПосикаДней.contains(КлючИзАрайЛиста);
                ///TODO ЕСЛИ СТРАБОТАЛО ТО ВЫХОДИМ ИЗ ЦИКЛА
                if (ЕслиТакойДень == true) {

                    System.out.println("   ЕслиТакойДень " + ЕслиТакойДень);
                    /////////////
                    break;

                }


            }


        }
        return ЕслиТакойДень;
    }



















}
