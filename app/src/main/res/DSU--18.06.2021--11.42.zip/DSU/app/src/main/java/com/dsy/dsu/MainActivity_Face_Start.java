package com.dsy.dsu;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static com.dsy.dsu.PUBLIC_CONTENT.ССылкаНаСозданнуюБазу;

//import static com.dsy.dsu.PUBLIC_CONTENT.ПУбличныйИмяТаблицыОтАндройда;
//import static com.dsy.dsu.PUBLIC_CONTENT.ИменаТаблицыОтАндройда;

public class MainActivity_Face_Start extends AppCompatActivity {
    protected   ProgressBar ПрогрессБарНаFace;
 ///   protected  TextView TextViewПрогрессБарНаFace ;


    Context КонтекстДляFAceapp;


    static   int ПубличныйI=0;

    final long[] ФиналПолучаемРазницуМеждуДатами = {0};

    //




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
try{

/*
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);*/



        КонтекстДляFAceapp=this;
        ////todo запрещяет поворот экрана

        ////
        ((Activity) КонтекстДляFAceapp) .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        //////todo настрока экрана
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        getSupportActionBar().setHomeButtonEnabled(false);

        getSupportActionBar().setDisplayHomeAsUpEnabled(false);

        getSupportActionBar().setHomeAsUpIndicator(null);
        //////todo  конец настрока экрана

        ///////


        setContentView(R.layout.activity_main__face);

        /////TODO помпонеты
      ///  TextViewПрогрессБарНаFace= (TextView) findViewById(R.id.textViewПрогрессБарНаFace);


        ПрогрессБарНаFace =(ProgressBar)  findViewById(R.id.progressBarFace); ////програссбар при аунтификации при входе в системму
        ///TODO попытка открыть экран как full screan

       // ССылкаНаСозданнуюБазу = new CREATE_DATABASE(this).ССылкаНаСозданнуюБазу;//ссылка на схему базы данных;//ссылка на схему базы данных

        getSupportActionBar().hide(); ///скрывать тул бар


      /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);



        ((Activity) КонтекстДляFAceapp) .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);








    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }

    }


















    @Override
    protected void onStart() {
        super.onStart();
        try{

            МетодСозданиеПрограссБара();////ЗАПУСКАЕМ МЕТОД ОПРЕДЕЛЕНИЯ ЗАХОДИЛ ЛИ ПОЛЬЗОВАТЕЛЬ В БАЗУ НЕДЕЛЮ НАЗАД ИЛИ СТАРШЕ И ПЛЮС ПРОГРЕССБАР

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }

    @Override
    protected void onStop() {
        super.onStop();


    }


/////////////////ЗАПУСКАЕМ ПРОГРЕСС БАР


    private void МетодСозданиеПрограссБара() throws ExecutionException, InterruptedException {
        int[] ИндексПрогрессБара = {0};
        try {

            ///TODO Создаем Пул потоков Собственого
            //////TODO организация работы потоков на данном активити
            ////цикл для круглаво ПРОГРЕСС БАРА
            Handler HandlerДляПоказаПользователюЗагрузки = new Handler();
            ///
          ///  TextViewПрогрессБарНаFace.setText(String.valueOf(0) + " % ");
            new Thread(new Runnable() {



                public void run() {

                    //////TODO код в потоке




                    for (ИндексПрогрессБара[0]=ПубличныйI;ИндексПрогрессБара[0] <= 100;ИндексПрогрессБара[0]=ИндексПрогрессБара[0]+5) {
                        ///
                        Log.d(this.getClass().getName(), "  ИндексПрогрессБара верхий" + ИндексПрогрессБара[0]);
                        try {
                            TimeUnit.MILLISECONDS.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        /////TODO присваиваем наверх факсическое значение идущего цикла
                        ПубличныйI=ИндексПрогрессБара[0];
                        ////
                        HandlerДляПоказаПользователюЗагрузки.post(new Runnable() {
                            @Override
                            public void run() {
                                ////////////
                                ПрогрессБарНаFace.setProgress(ИндексПрогрессБара[0]);
                              //  TextViewПрогрессБарНаFace.setVisibility(View.VISIBLE);
                                ПрогрессБарНаFace.setVisibility(View.VISIBLE);// по умолчанию прогресс бар делаем не видеым
                                HandlerДляПоказаПользователюЗагрузки.sendEmptyMessage(ИндексПрогрессБара[0]);
                                ////TODO само значение процентов
                              //  TextViewПрогрессБарНаFace.setText(String.valueOf(ИндексПрогрессБара[0]) + " % ");
                                ////TODO СИНХРОНИЗАЦИЯ ДАННЫ
                                //TODO
                                ////--- ТУТ СТРАРТУЕТ НАЧАЛО ОБМЕНА МЕЖДУ АНДРОЙДОМ И СЕРВЕРОМ ( СИНХРОНИЗАЦИЯ ДАННЫХ  )
                                Log.d(this.getClass().getName(), "  ИндексПрогрессБара нижний" + ИндексПрогрессБара[0]);
                            }});




                        ////TODO ПОСЛЕ ВСЕГО ПРОГРАСС БАРА ВЫХОДИМ ИЗ ПРИЛОЖЕНИЯ
                        if (ИндексПрогрессБара[0]>=100) {
                            Log.d(this.getClass().getName(), "МетодПроыеркиАунтификацииНа7Дней");

                            try {
                                Log.d(this.getClass().getName(), "ФиналПолучаемРазницуМеждуДатами[0] " +ФиналПолучаемРазницуМеждуДатами[0]);


                                //TODO КОД КОГДА ПОЛЬЗОВАТЕЛЬ ВСЕ РАБОТАЕТ
                                МетодОпределениеКогдаПоследнийРазЗаходилПользователь();////ЗАПУСКАЕМ


                                //TODO ПЕРВАЯ ЧАСТЬ  СИХРОНИЗАЦИИ  ПОЛУЧАЕМ ID
                                МетодЗаполенениеПубличногоIDПриРаботеОфлайн();



                                ///////TODO ПОСЛЕ ОПРЕДЕЛЯ КОГДА СОТРУДНИКА ЗАХОДИЛ ИДЕТ НА ДВА ПУТИ ПОЛЬЗОВАТЛЬ ПОДТРВЕРЖАЕТ СОВЕ ИМЯ И ПАРОЛЬИ ИЛИ МЫ СРРАЗУ ЗАРПУСКАМ ПРОГРАММУ
                                МетодВизуальногоПодтвержденияКогдаКтоВходит(ФиналПолучаемРазницуМеждуДатами[0] );
                                ////


                                //TODO ВЫХОДИМ
                                break; // ИЗ FOR ДО 100%

                            } catch (Exception e) {
                                e.printStackTrace();
                                ///метод запись ошибок в таблицу
                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                            }

                        }



                    }//TODO END FOR

                    ///TODO КОМАНДЫ ПОСЛЕ HANDLER
                    ////
                    HandlerДляПоказаПользователюЗагрузки.postDelayed(null, 0);
                    HandlerДляПоказаПользователюЗагрузки.removeCallbacksAndMessages(null);
                    ///TODO после показа пользвоателю процесса загрцузки делаем паузу

                    ///TODO тест

                }
                //////todo
            }).start();
            ///
            /////TODO   конец комадны после Handler




            ////TODO  КОНЕЦ КОД ДВА В ОДНОМ ДЛЯ ЗАМЕНЫ ASYNTASKОВ


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }







    /////// МЕТОД КОГДА ЗАХОДИЛ ПОСЛЬДНИЙ РАЗ ПОЛЬЗОВАТЛЬ
    private void  МетодОпределениеКогдаПоследнийРазЗаходилПользователь() throws ExecutionException, InterruptedException {

        ///TODO ЗАПУСКАЕМ  ПуллПамяти

        final Cursor[] Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели = {null};

        ExecutorService ПуулПамяти = Executors.newCachedThreadPool(); //

        ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными
        Future<Object> результатИмеипароль=     ПуулПамяти.submit(new Callable<Object>() {
            public Object call() {
                System.out.println("Another thread was executed");
                try {
/////САМ КОД КОТОРЫЙ ОПРЕДЕЛЯЕТ КОГДА ЧЕЛОВЕК ПОСЛЕДНИЙ РВЗ ЗАЗХОДИЛ
                    ФиналПолучаемРазницуМеждуДатами[0] = 0;
                    System.out.println("КАКАЯ ТАБЛИЦА КОНКРЕТНАЯ ПОЛУЧИТ JSON ::::   " + "SuccessLogin");


                    Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели[0]=null;
                        ///////////
                        Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели[0] = new MODEL_synchronized(getApplication()).КурсорУниверсальныйДляБазыДанных( "SuccessLogin", new String[]
                                {"date_update"},null,new String[] { },null,null,null,"1" );////SELECT date_update  FROM SuccessLogin  WHERE id=?", "1"


                        ///ДАТА ПОСЛЕДНЕЙ АУНТИФИКАЦИИ ПОЛЬЗОВАТЕЛЯ
                        if (Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели[0].getCount() > 0) {/////ПРОВЕРЯЕМ ЕСЛИ ПО ДАННОМУ ID UUID ЗАПОЛНЕ ЛИ ОН
                            Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели[0].moveToFirst();
                            String ПолеСуществетЛиДата = Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели[0].getColumnName(0);

                            ///////
                            if (ПолеСуществетЛиДата.trim().equalsIgnoreCase("date_update")) {
                                String СамаПолученнаяДатаИзТАлблицыВерсияДанных = Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели[0].getString(0);
                                Log.d(this.getClass().getName(), "  ПолеСуществетЛиДата  " +ПолеСуществетЛиДата + "      СамаПолученнаяДатаИзТАлблицыВерсияДанных  " +СамаПолученнаяДатаИзТАлблицыВерсияДанных);
                                if (СамаПолученнаяДатаИзТАлблицыВерсияДанных != null) { //еслия дата в базе андройд вооще существет то начинаем сравниея ,если нет по не стравниваем и точно идем на ауттификацию приложения



                                    Date ДатаПолученнаяИзТаблицыВерсияДанныхАндройдаДляПроверкиПользователя=null;

                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                       ДатаПолученнаяИзТаблицыВерсияДанныхАндройдаДляПроверкиПользователя =
                                               new SimpleDateFormat("yyyy-MM-dd", new Locale("ru")).parse(СамаПолученнаяДатаИзТАлблицыВерсияДанных);

                                    }else {

                                      ДатаПолученнаяИзТаблицыВерсияДанныхАндройдаДляПроверкиПользователя =
                                              new java.text.SimpleDateFormat("yyyy-MM-dd", new Locale("ru")).parse(СамаПолученнаяДатаИзТАлблицыВерсияДанных);


                                    }

                                    Log.d(this.getClass().getName()," ДатаПолученнаяИзТаблицыВерсияДанныхАндройдаДляПроверкиПользователя " +ДатаПолученнаяИзТаблицыВерсияДанныхАндройдаДляПроверкиПользователя.toString());


                                    /////Дата (сегодня) с которй нужно сравнить полученную дату из базы андройда
                                    Date ДатаСегодня = Calendar.getInstance().getTime();
                                    DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd", new Locale("ru"));//"yyyy-MM-dd'T'HH:mm:ss'Z'
                                    String ДатСегоднявВидеТекста = dateFormat.format(ДатаСегодня);



                                    Date ДатаСегодняДляПроверки =null;

                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                                       ДатаСегодняДляПроверки = new SimpleDateFormat("yyyy-MM-dd", new Locale("ru")).parse(ДатСегоднявВидеТекста);

                                    }else {

                                      ДатаСегодняДляПроверки = new java.text.SimpleDateFormat("yyyy-MM-dd", new Locale("ru")).parse(ДатСегоднявВидеТекста);


                                    }

                                    Log.d(this.getClass().getName()," ДатаВерсииДанныхНаSqlServer " +ДатаСегодняДляПроверки.toString());




                                    ////само сравнивание дат на 7 дней назад
                                    long ОтнимаемОтОднойДатыОтДатыСегодня = ДатаСегодняДляПроверки.getTime() - ДатаПолученнаяИзТаблицыВерсияДанныхАндройдаДляПроверкиПользователя.getTime(); //локальное сравнение дата из базы андройда и дат сегодня
                                   ///////////
                                    ФиналПолучаемРазницуМеждуДатами[0] = Integer.parseInt("" + (TimeUnit.DAYS.convert(ОтнимаемОтОднойДатыОтДатыСегодня, TimeUnit.MILLISECONDS)));
                                   /////////////
                                    Log.d(this.getClass().getName(), " ДатаПолученнаяИзТаблицыВерсияДанныхАндройдаДляПроверкиПользователя " + ДатаПолученнаяИзТаблицыВерсияДанныхАндройдаДляПроверкиПользователя +
                                            " ДатаСегодняДляПроверки " + ДатаСегодняДляПроверки
                                            + " Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели.getCount() " + Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели[0].getCount() +
                                            "  ФиналПолучаемРазницуМеждуДатами : " + ФиналПолучаемРазницуМеждуДатами[0]);
                                    //// конец само сравнивание дат на 7 дней назад
                                } else {
                                    Log.d(this.getClass().getName(), " Сотрдник не захол никогда в программу   в таблице SuccessLogin  пообще отсуттвует дата NULL СамаПолученнаяДатаИзТАлблицыВерсияДанных " + ССылкаНаСозданнуюБазу.getVersion());
                                } } }
                } catch (NumberFormatException | ParseException | ExecutionException | InterruptedException | TimeoutException e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }finally {
                    МетодВытаскиемДанныеИзКурсораДляАунтификацииМенне7Дней(ФиналПолучаемРазницуМеждуДатами[0]);
                    //////
                    Курсор_ДляОпрелеленияЗаходилЛиПользовательДольшеНедели[0].close();
                }

                //////
                return null;
            }


        });

        //TODO ЗАПУСКАЕМ ФУТУРЕ

        результатИмеипароль.get();


        if (результатИмеипароль.isDone()) {

            ПуулПамяти.shutdown();
            результатИмеипароль.cancel(false);

        }


    }


    //todo ВЫТАСКИВАЕМ ДАННЫЕ ДЛЯ АУНТИФИКАЦИИ МЕНЕЕ 7 ДНЕЙ

    private void МетодВытаскиемДанныеИзКурсораДляАунтификацииМенне7Дней( long ФиналПолучаемРазницуМеждуДатами ) {/////МЕТОД ПОЛУЧЕНИЕ ИЗ БАЗЫ ИМЯ И ПАРОЛЬ ДЛЯ АУНТИФИКАЦИИ МЕНЕЕ 7 ДНЕЙ
        try {
            Cursor Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней=null;




            //////


                //Cursor Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней = ССылкаНаСозданнуюБазу.rawQuery("SELECT id,success_users,success_login   FROM SuccessLogin  WHERE id=?", new String[]{"1"});
                Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней  =
                        new MODEL_synchronized(getApplication()).КурсорУниверсальныйДляБазыДанных("SuccessLogin",
                                new String[] {"id,success_users,success_login"},null,new String[] {} ,null,null,null,"1" );///"SELECT id,success_users,success_login   FROM SuccessLogin  WHERE id=?", "1"
                ///////////////////////х( "SuccessLogin", "date_update","id","=","1",null,null,null,null );
                if (Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней.getCount() > 0) {/////ПРОВЕРЯЕМ ЕСЛИ ПО ДАННОМУ ID UUID ЗАПОЛНЕ ЛИ ОН
                    ///
                    Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней.moveToFirst();

                    /////
                    PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета = Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней.getString(1);
                    PUBLIC_CONTENT. ПубличноеПарольДлСервлета = Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней.getString(2);
                    Log.d(this.getClass().getName(), " Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней  " + Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней.getCount() +
                            " ПубличноеИмяПользовательДлСервлета " + PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета +
                            "  ПубличноеПарольДлСервлета " + PUBLIC_CONTENT.ПубличноеПарольДлСервлета);
                }


            Курсор_ДляПолучениеИМяИПарольДЛяПодключениеКСерверуБолееСемиДней.close();

            /////////////////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }finally {

          /*  ///////TODO ПОСЛЕ ОПРЕДЕЛЯ КОГДА СОТРУДНИКА ЗАХОДИЛ ИДЕТ НА ДВА ПУТИ ПОЛЬЗОВАТЛЬ ПОДТРВЕРЖАЕТ СОВЕ ИМЯ И ПАРОЛЬИ ИЛИ МЫ СРРАЗУ ЗАРПУСКАМ ПРОГРАММУ
            МетодВизуальногоПодтвержденияКогдаКтоВходит(ФиналПолучаемРазницуМеждуДатами );
            ////*/

        }
    }



    ///////todo ФИНАЛЬНЫЙ МЕТОД КТО ВХОДИЛ ДО 7 ДНЕЙ ИЛИ ПОСЫЛАЕМ НА АУНТИФИКАЦИЮ
    private void МетодВизуальногоПодтвержденияКогдаКтоВходит(long ФиналПолучаемРазницуМеждуДатами ) {
        // Toast.makeText(getApplicationContext(), "Конец Загрузки", Toast.LENGTH_SHORT).show();
        Log.d(this.getClass().getName(), " ПубличноеИмяПользовательДлСервлета "+PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета+" ПубличноеПарольДлСервлета " +PUBLIC_CONTENT.ПубличноеПарольДлСервлета+
                " ФиналПолучаемРазницуМеждуДатами " +ФиналПолучаемРазницуМеждуДатами);

// todo ПРОВЕРЯЕМ РЕЗУЛЬТАТ ПРОВЕРКИ НА ДАТУ КОГДА ПОСЛДЕНИЙ РАЗ ЗАХОДИЛ ПОЛЬЗОВАТЕЛЬ В ПРОГАММУ ЕСЛИ МЕНЕЕ НЕДЕЛИ НАЗАД ТО НЕ  ПРОВОДИМ АУТНИФИКАЦИЮ ( ИМЯ И ПАРОЛЬ НА СЕРВРЕР)
        if ((long)  ФиналПолучаемРазницуМеждуДатами <7  && PUBLIC_CONTENT. ПубличноеИмяПользовательДлСервлета!=null && PUBLIC_CONTENT. ПубличноеПарольДлСервлета!=null) { //ЕСЛИ МЕНЬШЕ СЕМИ ИЛИ РАВНО ТО НЕ оригинально <7
            // ПРОВОДИМ АУНТИФИКАЦИЮ //// if ((long) o<=7) {   ЦИФРА 7 ПОКАЗЫВАЕТ ОГРАНИЧЕНИЯ ЧТО ДЕЛАТЬ ПРОХОДИТИ АУНТИФИКАЦИЮ


/////TODO запускам СРАЗУ СИНХРНИЗАЦИЮ НЕ ПЕРВЫЙ ЗАПУСК ПРИЛДОЖЕНИЯ
            /////TODO запускам ПРОВЕРКУ ПОЛЬЗОВАТЕЛЯ И ПАРОЛЬ  ДЛЯ ВХОДА В СИСТЕМУ



            /////данные с потока
            /////TODO ЗАПУСКАМ ОБНОЛВЕНИЕ ДАННЫХ С СЕРВЕРА ПЕРЕРД ЗАПУСКОМ ПРИЛОЖЕНИЯ ВСЕ ПРИЛОЖЕНИЯ ДСУ-1
            Intent Интент_ЗапускаетFaceApp=new Intent();
            Интент_ЗапускаетFaceApp.setClass(this,  MainActivity_Sinfrozisaziy_Prograssbar.class); //MainActivity_Sinfrozisaziy_Prograssbar //MainActivity_FACE_APP
            ////
            Интент_ЗапускаетFaceApp.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_FROM_BACKGROUND);//////FLAG_ACTIVITY_SINGLE_TOP

            Интент_ЗапускаетFaceApp.setAction(Intent.ACTION_SCREEN_OFF);
            Интент_ЗапускаетFaceApp.setAction(Intent.ACTION_SCREEN_ON);
            Интент_ЗапускаетFaceApp.setAction(Intent.ACTION_BOOT_COMPLETED);
            Интент_ЗапускаетFaceApp.setAction(Intent.ACTION_REBOOT );
            Интент_ЗапускаетFaceApp.setAction(Intent.ACTION_LOCKED_BOOT_COMPLETED);
            Интент_ЗапускаетFaceApp.setAction(Intent.ACTION_SCREEN_OFF);


            ////


            startActivity(Интент_ЗапускаетFaceApp);
            ////TODO ДАННАЯ КОМАНДА ПЕРЕКРЫВАЕТ НЕ ЗАПУСКАЕМОЕ АКТИВТИ А АКТИВТИ КОТОРЕ ЕГО ЗАПУСТИЛО
            finishAffinity();









///todo КОГДА ПЕРВЫЙ ЗАПУСК ПРОГРАММЫ ИЛИ ПОЛЬЗОВАТЕЛЬ СНАЧАЛА АУНТИФТИКАЦИЯ  И ЕСЛИ ОНА УСПЕШНО ТО ТОГДА САМО ПРИЛОЖЕНИЕ
        }else{////ПРОВОДИМ АУНТИФИКАЦИЮ ПОЛЬЗОВАТЕЛЯ


/////TODO запускам ПРОВЕРКУ ПОЛЬЗОВАТЕЛЯ И ПАРОЛЬ  ДЛЯ ВХОДА В СИСТЕМУ  ПЕРВЫЙ ВХОД
            ///TODO принудительно устанвливаем редим работы синхронизации




            //// TODO ЗАПУСКАЕМ СНАЧАЛА АУНТИФКАУИЮ И ЕСЛИ УСПЕШНО ЗАПУСКАМ ДАННЫЕ   -----ЭТО ПЕРВЫЙ ЗАПУСК ПРИЛОЖЕНИЯ
            Intent Интент_ЗапускПроверкиАунтификацииЕслиПользоваьельЗаходилДавновПрограмму=new Intent();

            Интент_ЗапускПроверкиАунтификацииЕслиПользоваьельЗаходилДавновПрограмму.setClass(getApplication(), MainActivity_Tabels_Users_And_Passwords.class);/////

            Интент_ЗапускПроверкиАунтификацииЕслиПользоваьельЗаходилДавновПрограмму.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_FROM_BACKGROUND);///
            // ТУТ СЕМЬ ДНЕЙ И БОЛЕЕ КЛИЕНТ АУНТАФИЦИРОВАЛЬСЯ НАДО ПОВТОРОНО ПРОВЕРНИТЬ КЛИЕНТА
            startActivity(Интент_ЗапускПроверкиАунтификацииЕслиПользоваьельЗаходилДавновПрограмму);
            //////
            finishAffinity();

        }
    }

















/////TODO НУДЖНЫЙ метод начало получение ID С Сервера Для ДОЛЬНЕЙШЕГО ЗАПУСКА СИНХРОНИЗАЦИИИ  ПУБЛИЧНЫЙ ID ОТ СЕРВЕРА

    String МетодЗаполенениеПубличногоIDПриРаботеОфлайн() {
        try{
            //TODO ЕСЛИ ПУБЛИЧНОГО ID  НЕТ
            Log.d(this.getClass().getName(), " ПубличноеIDПолученныйИзСервлетаДляUUID " + PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID);
            //
            if (PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID==null) {
                ////
                final Cursor[] Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн = {null};

                ///TODO ЗАПУСКАЕМ  ПуллПамяти
                ///TODO ЗАПУСКАЕМ  ПуллПамяти

                ExecutorService ПуулПамяти = Executors.newCachedThreadPool(); //
                ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными
         Future<?> futureпулмапяти=   ПуулПамяти.submit(new Runnable() {
                    public void run() {
                        System.out.println("Another thread was executed");
                        try{
                            //Cursor Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн = new MODEL_synchronized(this).КурсорУниверсальныйДляБазыДанных("SuccessLogin", new String[]
                            Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн[0] = new MODEL_synchronized(getApplication()).КурсорУниверсальныйДляБазыДанных("SuccessLogin", new String[]
                                            {"id"}, null,
                                    null, null, null, null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                            ////
                        } catch (Exception e) {
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                            ////// начало запись в файл
                        }
                    }});

                //TODO ЗАПУСКАЕМ ФУТУРЕ

                futureпулмапяти.get();

                if (futureпулмапяти.isDone()) {
                    ////
                    ПуулПамяти.shutdown();
                    ////
                    futureпулмапяти.cancel(false);
                }


                //////////

                Log.d(this.getClass().getName(), " Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн.getCount() " + Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн[0].getCount());
                /////TODO
                if (Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн[0].getCount() > 0) {
                    Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн[0].moveToFirst();
                    do {
                        String СамоЗначениеIDПриработаетОфлайн = Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн[0].getString(0);
                        Log.d(this.getClass().getName(), " СамоЗначениеIDПриработаетОфлайн " + СамоЗначениеIDПриработаетОфлайн);
                        //
                        PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID = СамоЗначениеIDПриработаетОфлайн;
                        Log.d(this.getClass().getName(), " ПубличноеIDПолученныйИзСервлетаДляUUID  " + PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID);
                    } while (Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн[0].moveToNext());
///todo
                    ///todo удаляем из памяти асинтаск

                    Курсор_ВытаскиваемЗначениеПубличногоIDкогдаРабатаемОфлайн[0].close();
                }
            }

        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID;
    }
















}


