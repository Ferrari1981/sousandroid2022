package com.dsy.dsu;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.annotation.UiThread;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.ListFragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionService;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;

import static com.dsy.dsu.PUBLIC_CONTENT.ССылкаНаСозданнуюБазу;
import static java.util.Locale.setDefault;

public class MainActivity_History_Tabels extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {




    protected Spinner СпинерВыборДату;/////спинеры для создание табеляСпинерТабельДепратамент
    String ПолученноеЗначениеИзСпинераДата; ///результат полученный из спенров
    String КакойКонтекст;

    protected ScrollView ScrollНаАктивтиСозданныхТабелей;

    protected LinearLayout LinearLayoutСозданныхТабелей;
    protected LinearLayout LinearLayoutДляЛинии;
 protected  ProgressDialog progressDialogДляУдаления;
    boolean РежимыПросмотраДанныхЭкрана;
    protected EditText ПрослойкаМеждуТабелей;
    //protected  TextView ТекстСообщениеЧТоТабеляЕщеНеСозданны;
    static Configuration config;
    String ПослеСозданиеовгоТабеляГОд= "";
    String ПослеСозданиеовгоТабеляМЕсяц= "";
    String ПослеСозданиеовгоТабеляВместеГодИМесяц= "";
    String ПолученноеЗначениеИзТолькоСпинераДата= "";
    /////static
    static  String  ПослеСозданияНовогоТабеляЕгоUUID;
    static  String   ПослеСозданияНовогоТабеляЕгоПолноеНазвание= "";
    static  String ПубличноеИмяКнопкиТабеля;
    ///
static  String ПолученныйПоследнийМесяцДляСортировкиЕгоВСпиноре;
    ////
    View.OnLongClickListener СлушательУдаланиеСамогоТабеля;
    /////TODO СОЗДАННЫЕ КНОПКИ НАЗВАНИЯ ТАБЕЛЕЙ
    Button ТабелявВидеКнопок=null;

    //TODO полученые месяц и год для создаени нового табеля
    String ПолученныйГодДляНовогоТабеля= "";
    String ФинальнаяМЕсяцДляНовогоТабеля= "";
    String   ПравильныйВозвратИзДруговоАктивтиBACK;
 //   String ЦифровоеИмяНовгоТабеля;

    //////
    //String[]    МассивДляВыбораВСпинерДата = {ГлавнаяДатаИВремяОперацийСБазойДанных(), "Выберите Дату Табеля" ,""};/////ДАННЫЙ МАССИВ БУДЕТ ЗАПОЛНЯТЬ СПИНЕР РАЗДЕЛ
    LinkedList<String> МассивДляВыбораВСпинерДата = new LinkedList<>(); //////АКАРЛИСТ ДЛЯ ПОЛУЧЕНЫЙ НОВЫХ ДАТ
    ////
    int МЕсяцВвидеЦифрыДляКурсора;


    int ГОДВвидеЦифрыДляКурсора;

    int ЦифровоеИмяНовгоТабеля;

 Context КонтекстИсторииВсехТабелейВыбранных;

    static Context  КонтекстИсторииВсехТабелейВыбранныхВнешний;

    String  МесяцТабеляФиналИзВсехСотрудниковВТАбеле;

    String ГодТабеляФиналИзВсехСотрудниковВТАбел;

    /////////////////////////////////////////////////////////////
    Button    КнопкаНазадВсеТабеля;


    List СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником;


    Long ПолученнаяUUIDНазванияОрганизации;

TextView textViewКоличествоТабелей;



    int ПолучеаемЦифруСФО;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        try{

        super.onCreate(savedInstanceState);

        КонтекстИсторииВсехТабелейВыбранных=this;
        КонтекстИсторииВсехТабелейВыбранныхВнешний=this;

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        ////todo запрещяет поворот экрана



        /////todo ориентация строго портрет

        setContentView(R.layout.activity_main__historytabely);

        getSupportActionBar().hide(); ///скрывать тул бар
        /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        //getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION  );


        /////
        ScrollНаАктивтиСозданныхТабелей = (ScrollView) findViewById(R.id.ScrollViewСамТабеля); /////КНОПКА ТАБЕЛЬНОГО УЧЕТА

        LinearLayoutСозданныхТабелей = (LinearLayout) findViewById(R.id.ГлавныйКонтейнерТабель); /////КНОПКА ТАБЕЛЬНОГО УЧЕТА


        //todo кнопка назад
        КнопкаНазадВсеТабеля= findViewById(R.id.КонопкаНазадСтрелкаВсеТабеля);



        textViewКоличествоТабелей= findViewById(R.id.textViewКоличествоТабелей);








        //////todo  конец настрока экрана
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);


        // Locale locale = Locale.ROOT;
        Locale locale = new Locale("rus");
        setDefault(locale );
        config =
                getBaseContext().getResources().getConfiguration();
        config.setLocale(locale);
        createConfigurationContext(config);

/////////////// //TODO пришли два значения месяц и год после успешного создание ТАБЕЛЯ

        //TODO МЕТОД ПОЛУЧЕНИЕ ДАННЫХ ДЛЯ ДАННОГО АКВТИВИ
        МетодПолучениеДанныхДляДаногоАктивтиИсторияТАбеля();







        ///////// todo Круглая Кнопка
        FloatingActionButton КруглаяКнопкаСозданиеНовогоТабеля = findViewById(R.id.КруглаяКнопкаСамТабель);//////КНОПКА СОЗДАНИЕ НОВГО ТАБЕЛЯ ИЗ ИСТОРИИ ВТОРОЙ ШАГ СОЗДАНИЯ ТАБЕЛЯ СНАЧАЛА ИСТРОИЯ ПОТОМ НА БАЗЕ ЕГО СОЗЗДАНИЕ
        /////КЛИК ПО КНОПКЕ

        ///
        КруглаяКнопкаСозданиеНовогоТабеля.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO СОЗДАНИЕ НОВОГО ТАБЕЛЯ


            if (PUBLIC_CONTENT.Отладка==true) {
                    СообщениеСпрашиваемПользователяЧтоОнТОчноХочетьСоздатьНовыйТабель("Табеля", "Создать новый Табель ?."+"\n", true);
                } else {

                    Log.d(this.getClass().getName()," создание нового сотрудника " );


                    ///TODO создание нового ТАБЕЛЯ
                    МетодСозданиеДиалогаКалендаряДаты();////ЗПАСУКАЕМ МЕТОД КОГДА НАДО ВЫБРВТЬ ДАТУ С КАЛЕНДАРКА

                }


            }

        });


        /////

        //todo метод возврата к предыдущему активти
        ////
        КнопкаНазадВсеТабеля.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                try{

                Log.d(this.getClass().getName(), " кликнем для созданни новго сотрдника при нажатии  ");
                ///todo код которыц возврящет предыдущий актвитики кнопка back
                Intent Интент_BackВозвращаемАктивти = new Intent();
                Интент_BackВозвращаемАктивти.setClass(getApplication(), MainActivity_FACE_APP.class); // Т
                ////todo запускаем активти
                Интент_BackВозвращаемАктивти.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                ////

                startActivity( Интент_BackВозвращаемАктивти);
                ////
               finish();



            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }

                return false;
            }
        });





    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
    }



    }
























    void МетодПолучениеДанныхДляДаногоАктивтиИсторияТАбеля() {
        ////////

        try{
        Intent Интент_ПослеУспешноСозданогоНовогоТабеляПередаемСюдаЦифруМесяцаИЦифруГода = getIntent();
        ////////
        ПослеСозданиеовгоТабеляГОд= Интент_ПослеУспешноСозданогоНовогоТабеляПередаемСюдаЦифруМесяцаИЦифруГода.getStringExtra("ГодВырезалиИзБуфераТабель");
        ///
        ПослеСозданиеовгоТабеляМЕсяц= Интент_ПослеУспешноСозданогоНовогоТабеляПередаемСюдаЦифруМесяцаИЦифруГода.getStringExtra("МесяцВырезалиИзБуфераТабель");
        ////
        ПослеСозданиеовгоТабеляВместеГодИМесяц= Интент_ПослеУспешноСозданогоНовогоТабеляПередаемСюдаЦифруМесяцаИЦифруГода.getStringExtra("ПолученноеТекущееЗначениеСпинераДата");
        ////
        ПослеСозданияНовогоТабеляЕгоUUID= Интент_ПослеУспешноСозданогоНовогоТабеляПередаемСюдаЦифруМесяцаИЦифруГода.getStringExtra("СгенерированныйUUIDДляНовогоТабеля");
        /////
        ПослеСозданияНовогоТабеляЕгоПолноеНазвание= Интент_ПослеУспешноСозданогоНовогоТабеляПередаемСюдаЦифруМесяцаИЦифруГода.getStringExtra("СгенерированныйНазваниеНовогоТабеля");
/////////
        ПравильныйВозвратИзДруговоАктивтиBACK= Интент_ПослеУспешноСозданогоНовогоТабеляПередаемСюдаЦифруМесяцаИЦифруГода.getStringExtra("ДепартаментТабеляПослеПодбораBACK");


    // ЦифровоеИмяНовгоТабеля= Интент_ПослеУспешноСозданогоНовогоТабеляПередаемСюдаЦифруМесяцаИЦифруГода.getStringExtra("ЦифровоеИмяНовгоТабеля");
        /////
        Log.d(this.getClass().getName(), " ПослеСозданиеовгоТабеляГОд "+ПослеСозданиеовгоТабеляГОд+ " ПослеСозданиеовгоТабеляГОд " +ПослеСозданиеовгоТабеляГОд +
                " ПослеСозданиеовгоТабеляВместеГодИМесяц " +ПослеСозданиеовгоТабеляВместеГодИМесяц + "    ПравильныйВозвратИзДруговоАктивтиBACK " +  ПравильныйВозвратИзДруговоАктивтиBACK);



    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }









    @Override
    protected void onStop() {
        super.onStop();
try{
        //////TODO  данный код срабатывает когда произошда ошивка в базе

        if(ССылкаНаСозданнуюБазу.isOpen()) {
            if (ССылкаНаСозданнуюБазу.inTransaction()) {
                ССылкаНаСозданнуюБазу.endTransaction();
            }
        }



    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
    }

    }












    @Override
    protected void onStart() {
        super.onStart();



        ///TODO попытка открыть экран как full screan
        ////////ЗАПОЛНЯЕМ АРАЙЛИСТ
        try {

            ///todo метод для удаления табеля
            МетодДляУдалениеТабеляЕслиВнемНетСотрудников();
            //////
            //////

            ////todo заполение спинера
            МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля();////метод вызаваем все созжданные ТАБЕДЯ ИЗ БАПЗЫ И ДАЛЕЕ ИХ ЗАПИСЫВАЕМ В ОБМЕН
            ////todo заполение спинера
            //////

            //TODO метод праивльно возврящет дату в спиноре  на первоночальнуюс последней
            МетодВозвратаПравильногоДатыВСпиноре();



            МетодСозданиеСпинераДляДатыНаАктивитиСозданиеИВыборТабеля();

            //
            //////



        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }






    //todo метод удаления табля из проекта если внем нет сотрудников
    private void МетодДляУдалениеТабеляЕслиВнемНетСотрудников() {
        ///todo третий обработчки нажатия
///TODO  удаление ОБРАБОТКА КЛИКА ПО ФИО
        СлушательУдаланиеСамогоТабеля = new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                try{
                    ////todo
                    //МыУжеВКодеУденияСотрудника=true;
                    TextView UUIDУдаляемогоТабеля=(TextView) v;
                    Log.d(this.getClass().getName(), " UUIDУдаляемогоТабеля " +UUIDУдаляемогоТабеля.getTag());
                    ///Toast.makeText(getApplication(), " Удаление Самого Табеля  " +v.getTag(), Toast.LENGTH_SHORT).show();
                    String UUIDУдаляемогоТабеляКАкТекст= (String) UUIDУдаляемогоТабеля.getTag();
                    int НазваниеУдаляемогоТАбеля=(int) UUIDУдаляемогоТабеля.getId();
                    int НазваниеУдаляемогоТАбеляВЦифровомФормате=(int) UUIDУдаляемогоТабеля.getId();
                    ///
                    String ПолноеНазваниеУдалмемогоТабелья= (String ) UUIDУдаляемогоТабеля.getText();
                    ////
                    Log.d(this.getClass().getName(), " НазваниеУдаляемогоТАбеля " +НазваниеУдаляемогоТАбеля+
                            "НазваниеУдаляемогоТАбеляВЦифровомФормате "+НазваниеУдаляемогоТАбеляВЦифровомФормате+ПолноеНазваниеУдалмемогоТабелья);




////todo метод придупрежнает что будет процесс даленис самого табеля
                if (PUBLIC_CONTENT.Отладка==true) {
                        //////
                        СообщениеПредпреждаетОВыбореУдалениеСамогоТабеля("Оповещение",  "Вы выбрали функцию удаление"+"\n"
                                        +"Табеля: " +ПолноеНазваниеУдалмемогоТабелья+"\n" + "(Выбор Да/Нет на следующем диалогом окне).", "nametabel_typename",
                                UUIDУдаляемогоТабеляКАкТекст,НазваниеУдаляемогоТАбеля,НазваниеУдаляемогоТАбеляВЦифровомФормате);
                        //  +"Табеля: " +НазваниеУдаляемогоТАбеля+"\n" + "(Выбор Да/Нет на следующем диалогом окне).", "uuid", UUIDУдаляемогоТабеляКАкТекст,НазваниеУдаляемогоТАбеля,НазваниеУдаляемогоТАбеляВЦифровомФормате);
                    } else {

                        /////todo сообщением передохим вв удаления табеля
                        МетодУдалениеТАбеляСообщениеПередЭтим(UUIDУдаляемогоТабеляКАкТекст,
                                UUIDУдаляемогоТабеляКАкТекст,
                                НазваниеУдаляемогоТАбеля,
                                НазваниеУдаляемогоТАбеляВЦифровомФормате,
                                ПолноеНазваниеУдалмемогоТабелья);

                    }







/*/////TODO КОД КОТОРЫЙ КОТОРЫ УДАЛЯЮТ СОТРУДНИКА ИЗ ТАБЕЛЯ
                    СообщениеПредпреждаетОВыбореУдалениеСотрудникаИзТабеля("Оповещение",  "Вы выбрали функцию удаление сотрудника: "+"\n" +ФИОДляУдаление.getText() +
                            " из Табеля."+"\n"+"(Выбор Да/Нет на следующем диалогом окне).", "uuid",(String) v.getTag(), (String) ФИОДляУдаление.getText());*/
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                            + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
                           new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }
                return false;
            }
        };


    }
///todo конецслушателя long для уделанеи самого табеля

    ///todo сообщение
    @UiThread
    void СообщениеПредпреждаетОВыбореУдалениеСамогоТабеля(String ШабкаДиалога,  String СообщениеДиалога,
                                                          String СамИндификаторUUID, String СамUUIDТабеля,int НазваниеУдаляемогоТАбеля,int НазваниеУдаляемогоТАбеляВЦифровомФормате) {

        Log.d(this.getClass().getName(), "  ФИНАЛ создание нового сотрудника ");
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
//////сам вид
        final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                .setTitle(ШабкаДиалога)
                .setMessage(СообщениеДиалога)
                .setPositiveButton("ОК", null)
                .setIcon(R.drawable.icon_dsu1_tabel_info)
                .show();
/////////кнопка
        final Button MessageBoxUpdateСоздатьТабель = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
        MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
            ///MessageBoxUpdate метод CLICK для DIALOBOX
            @Override
            public void onClick(View v) {
                //удаляем с экрана Диалог
                alertDialog.dismiss();
                Log.d(this.getClass().getName(), "  ФИНАЛ создание нового сотрудника ");

                /////todo сообщением передохим вв удаления табеля
                try {
                    МетодУдалениеТАбеляСообщениеПередЭтим(СамUUIDТабеля, СамИндификаторUUID, НазваниеУдаляемогоТАбеля, НазваниеУдаляемогоТАбеляВЦифровомФормате,null);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


            }
        });
    }








    void МетодУдалениеТАбеляСообщениеПередЭтим(String СамUUIDТабеля, String СамИндификаторUUID, int НазваниеУдаляемогоТАбеля,
                                               int НазваниеУдаляемогоТАбеляВЦифровомФормате,
                                             String  ПолноеНазваниеУдалмемогоТабелья) throws InterruptedException



    {
        Long СамUUIDТабеляКакLONG= Long.valueOf(СамUUIDТабеля);

        try{


        final String[] ФлагВыясняемПроведенныйТабельИлиНет = {null};
        final Cursor[] Курсор_ИщемПроведенЛиТАбельИлиНЕт = {null};

        ExecutorService executorServiceПроведенИЛИнет=Executors.newSingleThreadExecutor();
       Future futureПроведениИлИНЕт= executorServiceПроведенИЛИнет.submit(new Runnable() {
            @Override
            public void run() {



        try {
            Курсор_ИщемПроведенЛиТАбельИлиНЕт[0] =
                    new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("tabels",
                            new String[]{"*"}, " uuid=?", new String[]{СамИндификаторUUID}, null, null, "date_update", "1");//
            ////////
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                    + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        /////////
        if(Курсор_ИщемПроведенЛиТАбельИлиНЕт[0].getCount()>0){
            Курсор_ИщемПроведенЛиТАбельИлиНЕт[0].moveToFirst();
            ////
            Log.d(this.getClass().getName(), " Курсор_ИщемПУбличныйIDКогдаегоНетВстатике " + Курсор_ИщемПроведенЛиТАбельИлиНЕт[0].getCount());

int ИндексКурсор_ИщемПУбличныйIDКогдаегоНетВстатике= Курсор_ИщемПроведенЛиТАбельИлиНЕт[0].getColumnIndex("status_carried_out");
         ФлагВыясняемПроведенныйТабельИлиНет[0] = Курсор_ИщемПроведенЛиТАбельИлиНЕт[0].getString(ИндексКурсор_ИщемПУбличныйIDКогдаегоНетВстатике);

        }

            }
        });
        //

        try {
            futureПроведениИлИНЕт.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        if (futureПроведениИлИНЕт.isDone()){
            executorServiceПроведенИЛИнет.shutdown();
            futureПроведениИлИНЕт.cancel(false);







                ///todo
                СообщениеВыборУдлалянияТабеляИзБазы("Удаление табеля","Удалить выбранный табель ?: "+"\n"+"\n"
                                +ПолноеНазваниеУдалмемогоТабелья+"." , СамИндификаторUUID,
                        СамUUIDТабеляКакLONG,НазваниеУдаляемогоТАбеля,НазваниеУдаляемогоТАбеляВЦифровомФормате) ;




        }

    } catch (Exception e) {
        e.printStackTrace();
        Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }


    }
//todo  конеч сообщение предупреждения удлаения табеля






    ///todo сообщение
    @UiThread
    protected void СообщениеВыборУдлалянияТабеляИзБазы(String ШабкаДиалога,  String СообщениеДиалога,  String ИндификаторUUID,
                                                       Long СамоЗначениеUUID,int НазваниеУдаляемогоТАбеля, int НазваниеУдаляемогоТАбеляВЦифровомФормате) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
        try {
//////сам вид
            final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                    .setTitle(ШабкаДиалога)
                    .setMessage(СообщениеДиалога)
                    .setPositiveButton("Да", null)
                    .setNegativeButton("Нет", null)
                    .setIcon(R.drawable.icon_dsu1_delete_customer)
                    .show();
/////////кнопка
            final Button MessageBoxУдалениеСотрудникаИзТабеля = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            MessageBoxУдалениеСотрудникаИзТабеля .setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog.dismiss();
                    Log.d(this.getClass().getName(), "  ФИНАЛ создание нового сотрудника " + "ИндификаторUUID " +ИндификаторUUID+ " СамоЗначениеUUID " + СамоЗначениеUUID+"  "+ПолученноеЗначениеИзСпинераДата);

//////todo
                    if (СамоЗначениеUUID>0) {



                        МетодУдалениеСамогоТабеля(ИндификаторUUID,СамоЗначениеUUID,НазваниеУдаляемогоТАбеля,ПолученноеЗначениеИзСпинераДата,НазваниеУдаляемогоТАбеляВЦифровомФормате); //// TODO передаеюм UUID для Удалание



                    }

                }
            });

            /////////кнопка
            final Button MessageBoxУдалениеСотрудникаИзТабеляОтмена = alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            MessageBoxУдалениеСотрудникаИзТабеляОтмена.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog.dismiss();
                }
            });


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }


    //todo метод удаление сотрудника из табеля
    private void МетодУдалениеСамогоТабеля(String ДляУдалениеUUID,Long СамоЗначениеUUID,int НазваниеУдаляемогоТАбеля , String ПолученноеЗначениеИзСпинераДата, int НазваниеУдаляемогоТАбеляВЦифровомФормате) {

        StringBuffer ПрисутстуетСотрудникВУдаляемомоТабеле=new StringBuffer();

        final Cursor[] Курсор_КоторыйПроверяетПУстойЛиТабеля = {null};
        try{
            Log.d(this.getClass().getName()," СамоЗначениеUUID "+СамоЗначениеUUID+ " ДляУдалениеUUID " +ДляУдалениеUUID);

            /////todo код курсор выясняеть нет вполе fio сотрудник короче если в табеле нет ни одного сотрудника
            long РезультатУдалениеСамогоТАбеля = 0;


            Log.d(this.getClass().getName()," НазваниеУдаляемогоТАбеля"+ НазваниеУдаляемогоТАбеля);

            progressDialogДляУдаления = new ProgressDialog(this);
            progressDialogДляУдаления.setTitle("Удаления Табеля");
            progressDialogДляУдаления.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialogДляУдаления.setProgress(0);
            progressDialogДляУдаления.setCanceledOnTouchOutside(false);
            progressDialogДляУдаления.setMessage("");
            progressDialogДляУдаления.show();
            ////




            ExecutorService executorServiceУдаленияТабеля= Executors.newCachedThreadPool();
            //   ForkJoinPool   executorService=new ForkJoinPool(Runtime.getRuntime().availableProcessors());
          executorServiceУдаленияТабеля.submit(new Runnable() {
                @Override
                public void run() {

                    try {
                        // TODO: 11.06.2021 метод который удялет
                        МетодУдалениеТабеляПриУсловииЧтоНетСотрудниковВнем(ДляУдалениеUUID,
                                СамоЗначениеUUID, НазваниеУдаляемогоТАбеля, ПрисутстуетСотрудникВУдаляемомоТабеле,
                                Курсор_КоторыйПроверяетПУстойЛиТабеля,НазваниеУдаляемогоТАбеляВЦифровомФормате);

///


//TODO удаление ТАБЕЛЯ ПРИУСЛОВИИ ЧТО В ТАБЕЛЕ НЕТ СОТРУДНИКОВ
                        executorServiceУдаленияТабеля.shutdown();


                        /////
                        MainActivity_History_Tabels.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // TODO: 11.06.2021 после успешного удаления данных вызываем данные

                                progressDialogДляУдаления.setIndeterminate(false);
                                progressDialogДляУдаления.setCancelable(true);
                                progressDialogДляУдаления.dismiss();
                                ///

                                onStart();
                            }
                        });



                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }

                }});
//TODO удаление ТАБЕЛЯ ПРИУСЛОВИИ ЧТО В ТАБЕЛЕ НЕТ СОТРУДНИКОВ
          //  futurПутойИлинет.get();









        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }









    private void МетодУдалениеТабеляПриУсловииЧтоНетСотрудниковВнем(String ДляУдалениеUUID, Long СамоЗначениеUUID, int НазваниеУдаляемогоТАбеля,
                                                                    StringBuffer присутстуетСотрудникВУдаляемомоТабеле, Cursor[] курсор_КоторыйПроверяетПУстойЛиТабеля, int НазваниеУдаляемогоТАбеляВЦифровомФормате)
            throws ExecutionException, InterruptedException, TimeoutException, BrokenBarrierException {
        long РезультатУдалениеСамогоТАбеля = 0;
      ///  Log.d(this.getClass().getName()," Курсор_КоторыйПроверяетПУстойЛиТабеля.getCount() "+ курсор_КоторыйПроверяетПУстойЛиТабеля[0].getCount());
        String СодержимоеКурсора = null;
        String СодержимоеКурсораНазваниеТабеля = null;
        //todo если данныз нет то не удаляем Табеля удаляем если нет не одного сотрудника в нутир табеля



            Log.d(this.getClass().getName(), " СодержимоеКурсораНазваниеТабеля       " + СодержимоеКурсораНазваниеТабеля);



        Cursor  Курсор_ДляУдалениеТАБЕЛЯИщемГодМесяцСФОЧерезUUID=null;
        //////
        Курсор_ДляУдалениеТАБЕЛЯИщемГодМесяцСФОЧерезUUID = new MODEL_synchronized(this).
                КурсорУниверсальныйБазыДанных("SELECT cfo,month_tabels,year_tabels FROM tabels WHERE uuid="+СамоЗначениеUUID+" ;");
//////////////////////////////


        if(Курсор_ДляУдалениеТАБЕЛЯИщемГодМесяцСФОЧерезUUID.getCount()>0){
            //
            Курсор_ДляУдалениеТАБЕЛЯИщемГодМесяцСФОЧерезUUID.moveToFirst();
            /////
            Log.d(this.getClass().getName(), "  Курсор_ДляУдалениеТАБЕЛЯИщемГодМесяцСФОЧерезUUID "+Курсор_ДляУдалениеТАБЕЛЯИщемГодМесяцСФОЧерезUUID.getCount());


            int СФоДляУдлания=Курсор_ДляУдалениеТАБЕЛЯИщемГодМесяцСФОЧерезUUID.getInt(0);
            /////
            int МесяцДляУдлания=Курсор_ДляУдалениеТАБЕЛЯИщемГодМесяцСФОЧерезUUID.getInt(1);
            /////
            int ГОдДляУдлания=Курсор_ДляУдалениеТАБЕЛЯИщемГодМесяцСФОЧерезUUID.getInt(2);
            /////




            Cursor  Курсор_ДляУдалениеТАБЕЛЯИщемТОлькоUUID=null;

            //////
            Курсор_ДляУдалениеТАБЕЛЯИщемТОлькоUUID = new MODEL_synchronized(this).
                    КурсорУниверсальныйБазыДанных("SELECT uuid FROM tabels WHERE cfo="+СФоДляУдлания+" AND month_tabels="+МесяцДляУдлания+" AND year_tabels="+ГОдДляУдлания+"   ;");

            if(Курсор_ДляУдалениеТАБЕЛЯИщемТОлькоUUID.getCount()>0) {
                //
                Курсор_ДляУдалениеТАБЕЛЯИщемТОлькоUUID.moveToFirst();


                СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником=Collections.synchronizedList(new LinkedList());


            СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником.clear();
            //todo
            do{

                Long UUIDДляУдаленияПолученный=Курсор_ДляУдалениеТАБЕЛЯИщемТОлькоUUID.getLong(0);

              СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником.add(UUIDДляУдаленияПолученный);





            }while (Курсор_ДляУдалениеТАБЕЛЯИщемТОлькоUUID.moveToNext());

                Log.d(this.getClass().getName(), "  СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником "+СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником.toArray());


            }

        }


        /////
        MainActivity_History_Tabels.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // TODO: 11.06.2021 после успешного удаления данных вызываем данные

                progressDialogДляУдаления.setMax(СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником.size());

            }
        });






///todo команда которая удаляет выбранный табель


        ListIterator<Integer> ЗначениИзЛинкЛиста = СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником.listIterator();
        //

    ReentrantLock reentrantLockУдаленияТабеля=new ReentrantLock();

        //////////УДАЛЕНИЕ ТАБЕЛЯ
        while (ЗначениИзЛинкЛиста.hasNext()) {
//

            try {
                ////
                reentrantLockУдаленияТабеля.lockInterruptibly();


                reentrantLockУдаленияТабеля.newCondition().await(100, TimeUnit.MILLISECONDS);


                ////////////////

                Object СамоЗначениеUUIDИзЛинЛиста = ЗначениИзЛинкЛиста.next();

                //////
                Log.d(this.getClass().getName(), " СамоЗначениеUUIDИзЛинЛиста " + СамоЗначениеUUIDИзЛинЛиста.toString());


                /////TODO КОД ПРИ ОБНОВЛЯЕМ ПРИ ТАБЕЛЯ (ВАРИАНТ ВАРИАНТ УДЯЛЯЕМ А НИЖЕ ПРОСТО ОБНОВЛЯЕМ КОЛОКУ И ВПИСЫВАЕМ уДАЛЕННЫЕ)
                РезультатУдалениеСамогоТАбеля = new MODEL_synchronized(getApplicationContext()).УдалениеТолькоПустогоТабеляЧерезКонтейнерУниверсальная("tabels", "uuid",
                        Long.valueOf(String.valueOf(СамоЗначениеUUIDИзЛинЛиста)));
                //todo очищаем память
///
                // TODO: 14.06.2021 прогресс бар для удаления


                Log.d(this.getClass().getName(), " РезультатУдалениеСотрудникаИзТаблея " + РезультатУдалениеСамогоТАбеля);


                /////
                if (РезультатУдалениеСамогоТАбеля>0) {
                    MainActivity_History_Tabels.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // TODO: 11.06.2021 после успешного удаления данных вызываем данные
                            ///
                            //progressDialogДляУдаления.setMessage(String.valueOf(ЗначениИзЛинкЛиста.nextIndex())+"...("+String.valueOf(progressDialogДляУдаления.getMax()+")"));

                            ///
                            progressDialogДляУдаления.setProgress(ЗначениИзЛинкЛиста.nextIndex());


                        }
                    });
                }


            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            } finally {
                //

                reentrantLockУдаленияТабеля.unlock();
            }

            ////


        }}






            ///TODO СООБЩЕНИЕ О РЕЗУЛЬТАТОВ







































    ///todo  конец метода удаления третий обработчки нажатия
    ///////МЕТОД СОЗДАННИЕ СПИНЕРА

    ///todo сообщение
    @UiThread
    protected void СообщениеПослеУдаленияСотрудникаИзТабеля(String ШабкаДиалога, String СообщениеДиалога, boolean Статус , Long СамоЗначениеUUID,String ДляУдалениеUUID,int НазваниеУдаляемогоТАбеляВЦифровомФормате) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
//////сам вид
        int Значек;
        if (Статус){
            Значек  =R.drawable.icon_dsu1_tabel_info;
        }else{
            Значек  =R.drawable.icon_dsu1_delete_customer;///
        }
        final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                .setTitle(ШабкаДиалога)
                .setMessage(СообщениеДиалога)
                .setPositiveButton("Удалить", null)
                .setNegativeButton("Нет", null)
                .setIcon(Значек)
                .show();
/////////кнопка
        final Button MessageBoxUpdateСоздатьТабель = alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
            ///MessageBoxUpdate метод CLICK для DIALOBOX

            @Override
            public void onClick(View v) {
                //удаляем с экрана Диалог
                alertDialog.dismiss();
                Log.d(this.getClass().getName(), "  ФИНАЛ после удалание сотрудуника ");

                //TODO  второе действие заполенние контентом  в табеля в TableLyзаполения табеля из базы через элемент TableLauy
                //todo код послеу успешного удаления табеля
                //todo
            }
        });
        /////////////


        final Button MessageBoxUpdateСоздатьТабельВсеравноУдлаитьВместеССотрудникамиТабель = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
        MessageBoxUpdateСоздатьТабельВсеравноУдлаитьВместеССотрудникамиТабель.setOnClickListener(new View.OnClickListener() {
            ///MessageBoxUpdate метод CLICK для DIALOBOX

            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                //удаляем с экрана Диалог
                alertDialog.dismiss();
                Log.d(this.getClass().getName(), "  ФИНАЛ после удалание сотрудуника ");

////

                ///
                try {
                    МетодУдалениеВсехСотрудниковВТАбеле(СамоЗначениеUUID,ДляУдалениеUUID, НазваниеУдаляемогоТАбеляВЦифровомФормате);

                    ///todo команда которая удаляет выбранный табель
///todo команда которая удаляет выбранный табель




                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                           new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

                try {

                    ///todo метод для удаления табеля
                   /* МетодДляУдалениеТабеляЕслиВнемНетСотрудников();
                    //////
                    //////

                    ////todo заполение спинера
                    МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля();////метод вызаваем все созжданные ТАБЕДЯ ИЗ БАПЗЫ И ДАЛЕЕ ИХ ЗАПИСЫВАЕМ В ОБМЕН
                    ////todo заполение спинера
                    //////


                    МетодСозданиеСпинераДляДатыНаАктивитиСозданиеИВыборТабеля();*/

                    //
                    onStart();
                    //////

                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

                //TODO  второе действие заполенние контентом  в табеля в TableLyзаполения табеля из базы через элемент TableLauy
                //todo код послеу успешного удаления табеля
                //todo
            }
        });
        /////////////





    }






    private void МетодУдалениеВсехСотрудниковВТАбеле(Long СамоЗначениеUUID,String ДляУдалениеUUID, int НазваниеУдаляемогоТАбеляВЦифровомФормате) throws ExecutionException, InterruptedException, TimeoutException {

        final long[] РезультатУдалениеВсехСотрудниковСамогоТАбеля = {0};



        /////TODO Дополнительно делаем ФИО поле НУЛЛ
/*
        ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();
        ССылкаНаСозданнуюБазу.execSQL("UPDATE tabels SET  fio= NULL WHERE fio=-1");
        ССылкаНаСозданнуюБазу.execSQL("UPDATE fio SET  uuid= NULL WHERE uuid=-1");
        ССылкаНаСозданнуюБазу.setTransactionSuccessful();
        ССылкаНаСозданнуюБазу.endTransaction();
*/








        try{
            ExecutorService executorService=Executors.newCachedThreadPool();
     Future future=       executorService.submit(new Runnable() {
                @Override
                public void run() {


                  Object СамоЗначениеUUIDДляУдаланиевсехСотрудников = null;



                    // TODO: 18.03.2021  если есть содружники
                    if(СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником.size()>0){



                  for(int i=0;i<СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником.size();i++){


                    СамоЗначениеUUIDДляУдаланиевсехСотрудников=  СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником.get(i);

                    String  СамоЗначениеUUIDДляУдаланиевсехСотрудниковФинал=СамоЗначениеUUIDДляУдаланиевсехСотрудников.toString();

                    System.out.println(СамоЗначениеUUIDДляУдаланиевсехСотрудников.toString());



                      ///////
                      int ГодДляУдаления = 0;
                      int МесяцДляУдаления=0;


                      try {
                          Cursor       Курсор_ДляУдаленияПолучаемМесяцИгод = new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("tabels",
                                  new String[]{"month_tabels", "year_tabels"}, "uuid= ?", new String[]{String.valueOf(СамоЗначениеUUID)}, null, null, null, null);

             if(Курсор_ДляУдаленияПолучаемМесяцИгод.getCount()>0){

                 Курсор_ДляУдаленияПолучаемМесяцИгод.moveToFirst();
                 //////
                 int ИндексМесяцДляУдаления=Курсор_ДляУдаленияПолучаемМесяцИгод.getColumnIndex("month_tabels")  ;
                 ///////
                 МесяцДляУдаления=Курсор_ДляУдаленияПолучаемМесяцИгод.getInt(ИндексМесяцДляУдаления);
                 //////
                int  ИндексГодДляУдаления=Курсор_ДляУдаленияПолучаемМесяцИгод.getColumnIndex("year_tabels")  ;
                 ///////
                 ГодДляУдаления=Курсор_ДляУдаленияПолучаемМесяцИгод.getInt(ИндексГодДляУдаления);



             }



                          ///
                      } catch (Exception e) {///////ошибки
                          e.printStackTrace();
                          ///метод запись ошибок в таблицу
                          Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e.toString() + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                  " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                          new  КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                                  Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                          //

                      }

                      ReentrantLock reentrantLock=new ReentrantLock();
                      reentrantLock.lock();
                    ///////
                    try {
                        reentrantLock.newCondition().await(200,TimeUnit.MILLISECONDS);
                        ////
                 /*       РезультатУдалениеВсехСотрудниковСамогоТАбеля[0] = new MODEL_synchronized(КонтекстИсторииВсехТабелейВыбранных).
                                УдалениеТолькоПустогоТабеляЧерезКонтейнерУниверсальная("tabels", "cfo", СамоЗначениеUUIDДляУдаланиевсехСотрудниковФинал);

                        System.out.println( "РезультатУдалениеВсехСотрудниковСамогоТАбеля "  + РезультатУдалениеВсехСотрудниковСамогоТАбеля[0]);
                        //
*/


                       /* РезультатУдалениеВсехСотрудниковСамогоТАбеля[0] = new MODEL_synchronized(getApplication()).
                                УдалениеТолькоПустогоТабеляЧерезКонтейнерУниверсальная("tabels", "nametabel_typename",
                                        String.valueOf(НазваниеУдаляемогоТАбеляВЦифровомФормате));

                        System.out.println( "РезультатУдалениеВсехСотрудниковСамогоТАбеля "  + РезультатУдалениеВсехСотрудниковСамогоТАбеля[0]);*/



                    } catch (Exception e) {///////ошибки
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e.toString() + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new  КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        //

                    }finally {
                        reentrantLock.unlock();
                    }
                    //todo очищаем память



                        System.out.println("СамоЗначениеUUIDДляУдаланиевсехСотрудников " +СамоЗначениеUUIDДляУдаланиевсехСотрудников);
                    }/////TODO конец while




                    }






                }





            });
     //
            future.get();

            if (future.isDone()){

                //  ССылкаНаСозданнуюБазу.close();

            if (PUBLIC_CONTENT.Отладка==true) {
                    СообщениеПослеУдаленияСамогоТАбеля("Оповещение Табеля", "Успешное удалание Табеля"
                            +"\n"+" (с сотрудниками): "
                            +СодержимоеКурсораUUIDТабеляПриУдалениеиТАбеляилиВместеССотрудником.size(), true,НазваниеУдаляемогоТАбеляВЦифровомФормате);
                } else {


                    try {

                        ///todo метод для удаления табеля
                       /* МетодДляУдалениеТабеляЕслиВнемНетСотрудников();
                        //////
                        //////

                        ////todo заполение спинера
                        МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля();////метод вызаваем все созжданные ТАБЕДЯ ИЗ БАПЗЫ И ДАЛЕЕ ИХ ЗАПИСЫВАЕМ В ОБМЕН
                        ////todo заполение спинера
                        //////


                        МетодСозданиеСпинераДляДатыНаАктивитиСозданиеИВыборТабеля();*/
                        executorService.shutdown();
                        future.cancel(false);

                        onStart();

                        //
                        ScrollНаАктивтиСозданныхТабелей.invalidate();
                        ScrollНаАктивтиСозданныхТабелей.requestLayout();

                        //////

                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }

                }


            }












        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }
////todo конец фильаного сообщения о удалени самого табеля

































    ///todo сообщение
    @UiThread
    protected void СообщениеПослеУдаленияСамогоТАбеля(String ШабкаДиалога,  String СообщениеДиалога,boolean Статус, int НазваниеУдаляемогоТАбеляВЦифровомФормате) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ


//////сам вид
        int Значек;
        if (Статус){
            Значек  =R.drawable.icon_dsu1_tabel_info;
        }else{
            Значек  =R.drawable.icon_dsu1_delete_customer;
        }
        final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                .setTitle(ШабкаДиалога)
                .setMessage(СообщениеДиалога)
                .setPositiveButton("ОК", null)
                .setIcon(Значек)
                .show();
/////////кнопка
        final Button MessageBoxUpdateСоздатьТабель = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
        MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
            ///MessageBoxUpdate метод CLICK для DIALOBOX

            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                //удаляем с экрана Диалог
                alertDialog.dismiss();
                Log.d(this.getClass().getName(), "  ФИНАЛ после удалание сотрудуника ");
                //////// todo если успешно удаление табеля то запускаем сообщение
                if (Статус) {

                    ///TODO попытка открыть экран как full screan
                    ////////ЗАПОЛНЯЕМ АРАЙЛИСТ
                    ////////ЗАПОЛНЯЕМ АРАЙЛИСТ
                    try {

                        ///todo метод для удаления табеля
                /*        МетодДляУдалениеТабеляЕслиВнемНетСотрудников();
                        //////
                        //////

                        ////todo заполение спинера
                        МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля();////метод вызаваем все созжданные ТАБЕДЯ ИЗ БАПЗЫ И ДАЛЕЕ ИХ ЗАПИСЫВАЕМ В ОБМЕН
                        ////todo заполение спинера
                        //////


                        МетодСозданиеСпинераДляДатыНаАктивитиСозданиеИВыборТабеля();*/


                        onStart();

                        //
                        ScrollНаАктивтиСозданныхТабелей.invalidate();

                        //////

                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }
                }

                //TODO  второе действие заполенние контентом  в табеля в TableLyзаполения табеля из базы через элемент TableLauy
                //todo код послеу успешного удаления табеля
                //todo
            }
        });
    }
////todo конец фильаного сообщения о удалени самого табеля

























    private void МетодСозданиеСпинераДляДатыНаАктивитиСозданиеИВыборТабеля() {
        try {

            ////TODO сортируем дату на ПОСЛЕДНКЮ

            final Cursor[] Курсор_ВЫводимМаксимальнуюДатуДляСпинера = {null};
            /////
            //int ПОложениевЛинкЛисте=0;

            try {
                Курсор_ВЫводимМаксимальнуюДатуДляСпинера[0] =        МетодКоторыйПоказываетМаксимальнуюДатуИзмененияДляСпинера();
                ////


                if ( Курсор_ВЫводимМаксимальнуюДатуДляСпинера[0].getCount()>0){
                    /////
                    Курсор_ВЫводимМаксимальнуюДатуДляСпинера[0].moveToFirst();


                    CountDownLatch countDownLatch=new CountDownLatch(1);

                    ////TODO МЕТОД ПРЕОБРАЗОВАНИЕ ЦИФРА В НАЗВАНИЕ МЕСЯЦА ДЛЯ ЕГО СРАВНЕНИЯ
                   // String ПолученныйПоследнийМесяцДляСортировкиЕгоВСпиноре=      МетодДляПреоразванияЦифрыВНазванияМесяца(Курсор_ВЫводимМаксимальнуюДатуДляСпинера[0]);


                    Log.d(this.getClass().getName(), " " + ПолученныйПоследнийМесяцДляСортировкиЕгоВСпиноре);
                    ///




                    ListIterator<String> iterator = МассивДляВыбораВСпинерДата.listIterator();

                    // Iterating the list in forward direction
                    System.out.println("LinkedList elements:");
                    while(iterator.hasNext()){



                        String ИщемМесяцАЛинкЛисте=        iterator.next();

                        int ПОложениевЛинкЛисте=iterator.nextIndex()-1;

                        Log.d(this.getClass().getName(), " ИщемМесяцАЛинкЛисте  " +ИщемМесяцАЛинкЛисте
                                + " ПолученныйПоследнийМесяцДляСортировкиЕгоВСпиноре " +ПолученныйПоследнийМесяцДляСортировкиЕгоВСпиноре);

            /*            if (ИщемМесяцАЛинкЛисте.equalsIgnoreCase(ПолученныйПоследнийМесяцДляСортировкиЕгоВСпиноре)){

                            Log.d(this.getClass().getName(), "  ПОложениевЛинкЛисте " +   ПОложениевЛинкЛисте);

                            countDownLatch.countDown();

                            Collections.swap(МассивДляВыбораВСпинерДата,0,  ПОложениевЛинкЛисте);
                            /////
                            ПолученныйПоследнийМесяцДляСортировкиЕгоВСпиноре=null;
                            countDownLatch.await();
                            break;


                        }*/


                    }//todo end loop




                }///TODO END IF


                /////
            } catch (Exception e) {
                e.printStackTrace();
///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            }







//////ТРЕТИЙ СПИНЕР ДАТА
            СпинерВыборДату=(Spinner) findViewById(R.id.СпинерТабельМесяцИсториииТабелей);


// Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
            ArrayAdapter<String> АдаптерДляСпинераДата = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, МассивДляВыбораВСпинерДата);
            // Определяем разметку для использования при выборе элемента
            АдаптерДляСпинераДата.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);



            // Применяем адаптер к элементу spinner
            СпинерВыборДату.setAdapter(АдаптерДляСпинераДата);
            ////что быврали





////////РЕЖИМ ПОЛНОГО  ЭКРАНА слушатели экрана табеля

            /////Метод не выбара а Клика

            СпинерВыборДату.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    //////TODO линия снизу самих табелей ЦВЕТ
                    ((TextView) parent.getChildAt(0)).setBackgroundResource(R.drawable.textlines_tabel_row_color_green);
                    ((TextView) parent.getChildAt(0)).setTextSize(16);
                    ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    ((TextView) parent.getChildAt(0)).setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    ((TextView) parent.getChildAt(0)).setTypeface(((TextView) parent.getChildAt(0)).getTypeface(), Typeface.BOLD);//////ВЫДЕЛЕМ ЖИРНЫМ ЦВЕТОМ ДАТЫ
                    //
                    // TODO: 16.05.2021

                   //// ((TextView) parent.getChildAt(0)).setText(((TextView) parent.getChildAt(0)).getText()+String.valueOf("  ("+СпинерВыборДату.getCount()+")"));

                    КакойКонтекст= String.valueOf(((TextView) parent.getChildAt(0)).getText()); /////ОПРЕДЕЛЯЕМ ТЕКУЩЕЕ ЗНАЧЕНИЕ ВНУТИРИ СПЕНИРА
                    //////меняем цвет спинера
                    // СпинерВыборДату.setTooltipText("Дата месяца");
                    ПолученныйПоследнийМесяцДляСортировкиЕгоВСпиноре=КакойКонтекст;
                    //////конец второго лушателя спинера



                    ////todo данные два значения приходят только просле содание воговто табеля из другово актвити ПРИНИМАЕМ РЕШЕНИЕ ВСТВЛЕМ НОВУЮ ДАТУ ИЛИ НЕТ
                    /////////ПРИНИМАЕМ РЕШЕНИЕ СОЗДАННЫЙ ИЛИ НЕТ ПРИШЛА ДАТА ОТ ДРУГОВО АКТИВТИ ИЛИ НЕТ
                    if (ПослеСозданиеовгоТабеляГОд!=null && ПослеСозданиеовгоТабеляМЕсяц!=null){////заполянеться если новыйтабель создан и на при запуске встать на попределнный табель
                        /////ПОКАЗЫАМ ДАТУ ПРИ ЗАПУСКЕ АКТИВТИ ИСТОРИЯ ТАБЕЛЯ  ДАННАЯ ДАТА ПОЛУЧЕНА ПРИШЛА ОТ ДРУГОВО АКТИВТИ ПОСЛЕ УСПЕШНОЙ ВСТВКИ НОВГО ТАБЕЛЯ
                        ((TextView) parent.getChildAt(0)).setText(ПослеСозданиеовгоТабеляВместеГодИМесяц);//// ЗАПИСЫВАЕМ ЗНАЧЕНИЕ В СПИПЕР
                        ////
                        ПослеСозданиеовгоТабеляГОд=null;
                        ПослеСозданиеовгоТабеляМЕсяц=null;




                    }

                    ПолученноеЗначениеИзСпинераДата= "";
                    ПолученноеЗначениеИзСпинераДата = (String) ((TextView) parent.getChildAt(0)).getText(); //ПОЛУЧАЕМ ЗНАЧЕНИЕ
                    Log.d(this.getClass().getName(), " ((TextView) parent.getChildAt(0)).getText()  " + ((TextView) parent.getChildAt(0)).getText());





                    /////////// todo КОНЕЦ СОЗДАНИЕ КОМПОНЕТА КАЛЕНДАРЬ
                    if (ПолученноеЗначениеИзСпинераДата.length()>0) {
                        ///////future
                        try{
                            МетодаСозданиеТабеляИзБазы(); /////МЕТОД ЗАГРУЗКИ СОЗДАННЫХ ТАБЕЛЕЙ ИЗ БАЗЫ
                        } catch (Exception e) {
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        }

                    }
                    /////
///////// ТУТ МЫ НИЧИНАЕМ СОЗДАВАТЬ НОВЫЙ МЕСЯЦ АВГУСТ , СЕНТЯБРЬ ОКТЯБРЬ

                }


                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    Log.d(this.getClass().getName(), " ПолученноеЗначениеИзСпинераДата  " + ПолученноеЗначениеИзСпинераДата);
                }

            });




//поймать ошибку всего классаIOException | MyException e    NumberFormatException
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

        /////МЕТОД ЗАГРУКЗИ КОЛИЧЕСТВО ТАБЕЛЕЙ ИЗ БАЗЫ\




    }


    ////TODO Метод Преоразует цифру в  названия месяца
    private String МетодДляПреоразванияЦифрыВНазванияМесяца(Cursor Курсор_ВЫводимМаксимальнуюДатуДляСпинера) {
        String  МаксимальнаяМесяцДляСпинера;
        String МаксимальнаяГодДляСпинера;
        String  МаксимальнаяНазваниеДляСпинера;
        String ПолученыеМесяцНеОбработанный = null;
        try{


            МаксимальнаяМесяцДляСпинера =Курсор_ВЫводимМаксимальнуюДатуДляСпинера.getString(0);
            //
            Log.i(this.getClass().getName(), "МаксимальнаяМесяцДляСпинера[0] " +   МаксимальнаяМесяцДляСпинера);

            МаксимальнаяГодДляСпинера =Курсор_ВЫводимМаксимальнуюДатуДляСпинера.getString(1);
            //
            Log.i(this.getClass().getName(), "МаксимальнаяГодДляСпинера[0] " + МаксимальнаяГодДляСпинера);

            МаксимальнаяНазваниеДляСпинера=Курсор_ВЫводимМаксимальнуюДатуДляСпинера.getString(2);
            //
            Log.i(this.getClass().getName(), " МаксимальнаяНазваниеДляСпинера[0] " + МаксимальнаяНазваниеДляСпинера);



            ///TODO из цифры в НАзвание




                /*            Locale ee=Locale.forLanguageTag("ru");
                            Calendar cal=Calendar.getInstance();
                            cal.set(Calendar.MONTH,Integer.parseInt(МаксимальнаяМесяцДляСпинера));
                            String s=cal.getDisplayName(Calendar.MONTH,Calendar.LONG_FORMAT,new Locale("rus"));
*/





            DateFormat df = new SimpleDateFormat("MM/yyyy");
            Date date = df.parse(МаксимальнаяМесяцДляСпинера+"/"+МаксимальнаяГодДляСпинера);
            System.out.println(date); // Sat Jan 02 00:00:00 GMT 2010




                /*    SimpleDateFormat f = new SimpleDateFormat("MMM", new Locale("ru"));
                    SimpleDateFormat f1 = new SimpleDateFormat("LLL", new Locale("ru"));
                    SimpleDateFormat f2 = new SimpleDateFormat("MMMM", new Locale("ru"));*/
            SimpleDateFormat ПреобразованиеЦифраВНАзваниемесяца = new SimpleDateFormat("LLLL  yyyy", new Locale("ru"));

            ПолученыеМесяцНеОбработанный=  ПреобразованиеЦифраВНАзваниемесяца.format(date);
            System.out.println(ПолученыеМесяцНеОбработанный);

            ПолученыеМесяцНеОбработанный=(ПолученыеМесяцНеОбработанный.substring(0,1).toUpperCase()+
                    ПолученыеМесяцНеОбработанный.substring(1).toLowerCase());

            Log.i(this.getClass().getName(), " ПолученыеМесяцНеОбработанный " + ПолученыеМесяцНеОбработанный);










            //поймать ошибку всего классаIOException | MyException e    NumberFormatException
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return ПолученыеМесяцНеОбработанный;
    }


////////НАЧАЛО МЕТОД СОЗДАНИЕ ТАБЕЛЯ


    private void МетодаСозданиеТабеляИзБазы() throws InterruptedException, ExecutionException, TimeoutException, ParseException {
        final Cursor[] Курсор_КоторыйЗагружаетГотовыеТабеля = {null};





        Cursor  Курсор_КоторыйЗагружаетГотовыеТабеляВнутриМаксимальнаяДата=null;


        //

        final String[] МесяцМаскимальнаяДатавТабеляхПоМесецям = {null};
        ////todo ДАННЫЙ КУРСОР ДЛЯ ПОКАЗА НОВГО ТАБЕЛЯ
        try{

            //// todo ЗАПОЛЕНИЯ ТАБЕЛЯ ИЗ БАЗЫ ДАННЫХ
            if (ПолученноеЗначениеИзСпинераДата != null ) {
                try{
                    //////метод которы из текста которйц было арпдчьадена дата обраьно преобразует в дату для проверки
                    LinearLayoutСозданныхТабелей.removeAllViews();

                } catch (Exception e) {
                 /*   e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());*/
                }

                Log.d(this.getClass().getName(), " код загружает все созданные табеля из базы " + КакойКонтекст);
                //////TODO преобразовыываем оборатно из названиея месяц в цифру
                МЕсяцВвидеЦифрыДляКурсора= МетодПолучениниеКурсораМЕсяцДата(ПолученноеЗначениеИзСпинераДата);
                ////
                ГОДВвидеЦифрыДляКурсора=МетодПолучениниеКурсораГОДДата(ПолученноеЗначениеИзСпинераДата);
                /////
                Log.d(this.getClass().getName(), " МЕсяцВвидеЦифрыДляКурсора " + МЕсяцВвидеЦифрыДляКурсора +
                        "  ГОДВвидеЦифрыДляКурсора " + ГОДВвидеЦифрыДляКурсора);

                ///TODO СЮДА ЗАХОДИМ ТОЛЬКО КОГДА НОВЫЙ ТАБЕЛЬ


//TODO данный курсор работает когда не новый а старый простмартиваем ТАбель(создаенный ранее)

//////todo загружаем табеоля в начале  ЗАГРУЖАЕМ В СПИНЕР ДАТЫ А НЕ А ТАБЕЛЯ  ДАННЫЕ ДЛЯ СПИПЕР



                try {


                    ///TODO ГЛАВНЫЙ КУРСОР ЗАГРУЗКИ САМИХ ТАБЕЛЕЙ НА АКТИВТИИ
                    if ( МЕсяцВвидеЦифрыДляКурсора>0 && ГОДВвидеЦифрыДляКурсора>0 ) {
                        //////////
                        Log.d(this.getClass().getName(), "ПолученнаяUUIDНазванияОрганизации "+ ПолученнаяUUIDНазванияОрганизации
                                + " PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID " +PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID
                                + " МЕсяцВвидеЦифрыДляКурсора " +МЕсяцВвидеЦифрыДляКурсора
                                + " ГОДВвидеЦифрыДляКурсора  "+ ГОДВвидеЦифрыДляКурсора);




                        String    НазваниеТабеля;

                        try{

                            final      int  finalМЕсяцВвидеЦифрыДляКурсора=МЕсяцВвидеЦифрыДляКурсора;

                            final      int  finalГОДВвидеЦифрыДляКурсора=ГОДВвидеЦифрыДляКурсора;


                         /////////////////////


                            CompletionService completionServiceгружаетГотовыеТабеля=new ExecutorCompletionService(Executors.newSingleThreadExecutor());
                            //////
                            completionServiceгружаетГотовыеТабеля
                                    .submit(new Callable<Object>() {
                                @Override
                                public Object call() {
                                    Курсор_КоторыйЗагружаетГотовыеТабеля[0]=null;

                                    //TODO ГЛАВНЫЙ КУРСОР ЗАГРУЗКИ САМИХ ТАБЕЛЕЙ НА АКТИВТИИ"nametabel"
                                    try {
                                        Курсор_КоторыйЗагружаетГотовыеТабеля[0] = new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("tabels", new String[]{"*"},
                                                " month_tabels=? AND year_tabels=? AND status_send!=? " +
                                                        "AND month_tabels IS NOT NULL  AND year_tabels IS NOT NULL",
                                                new String[]{String.valueOf(finalМЕсяцВвидеЦифрыДляКурсора),
                                                        String.valueOf(finalГОДВвидеЦифрыДляКурсора), "Удаленная"},
                                                "cfo", null, "date_update DESC", null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                                        ///////
//




                                    } catch (Exception e) {
                                        e.fillInStackTrace();
                                        ///метод запись ошибок в таблицу
                                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    }
                                    //////todo работающий NULL в query
                                    Log.d(this.getClass().getName(), " Курсор_КоторыйЗагружаетГотовыеТабеля.getCount() " +    Курсор_КоторыйЗагружаетГотовыеТабеля[0].getCount());
                                    ////todo получаем значение ищем
                                    ///



                                    Cursor Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДата=null;
                            //TODO ГЛАВНЫЙ КУРСОР ЗАГРУЗКИ САМИХ ТАБЕЛЕЙ НА АКТИВТИИ"nametabel"
                                    try {
                                        Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДата = МетодКоторыйПоказываетМаксимальнуюДатуИзменения(ПолученнаяUUIDНазванияОрганизации);
                                    } catch (ExecutionException e) {
                                        e.printStackTrace();
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }


                                    if (Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДата.getCount()>0) {
                                Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДата.moveToFirst();


                                String   МаскимальнаяДатавТабеляхПоМесецям = Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДата.getString(0);



//                  МаскимальнаяДатавТабеляхПоМесецямДляСравнение = new android.icu.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(МаскимальнаяДатавТабеляхПоМесецям);//

                                Log.d(this.getClass().getName(), " МаскимальнаяДатавТабеляхПоМесецям  " +    МаскимальнаяДатавТабеляхПоМесецям
                                        + " МесяцМаскимальнаяДатавТабеляхПоМесецям  " + МесяцМаскимальнаяДатавТабеляхПоМесецям[0]);

                            }else{
                                МесяцМаскимальнаяДатавТабеляхПоМесецям[0] ="";
                            }



                                    /////TODO курсор для нахождения даты максимальной

                                    return  null;
                                }
                            });
                            //////
                      Future<?> futureагружаетГотовыеТабеля=      completionServiceгружаетГотовыеТабеля.take();




                          if(futureагружаетГотовыеТабеля.isDone()){
                              Log.d(this.getClass().getName(), "ЗАГРУЗИЛИ ДАННЫЕ НА АКТИВТИ ИСТОРИЯ ТАБЕЛЯЕЙ ");



                              if ( Курсор_КоторыйЗагружаетГотовыеТабеля[0]!=null) {
                                  if (   Курсор_КоторыйЗагружаетГотовыеТабеля[0].getCount()>0) {


                                         textViewКоличествоТабелей.setText(" ("+СпинерВыборДату.getCount()+" м) "+ " ("+ String.valueOf(Курсор_КоторыйЗагружаетГотовыеТабеля[0].getCount())+" т)")  ;
                                     } else {
                                         textViewКоличествоТабелей.setText("("+"0"+")");
                                     }
                              }else{

                                  textViewКоличествоТабелей.setText("("+"0"+")");
                              }


                              ////
                              futureагружаетГотовыеТабеля.cancel(false);

                          }




                            //TODO закрываем курсор с максимальной датой
                           // Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДата.close();

                        } catch (Exception e) {
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        }








            /*    ///TODO ГЛАВНЫЙ КУРСОР ЗАГРУЗКИ САМИХ ТАБЕЛЕЙ НА АКТИВТИИ
                Курсор_КоторыйЗагружаетГотовыеТабеля = new MODEL_synchronized(this).КурсорУниверсальныйДляБазыДанных("viewtabel", new String[]{"*"},
                        "user_update= ? AND  month_tabels=? AND year_tabels=? AND name IS NOT NULL",
                        new String[]{ПубличноеIDПолученныйИзСервлетаДляUUID, String.valueOf(МЕсяцВвидеЦифрыДляКурсора),
                                String.valueOf(ГОДВвидеЦифрыДляКурсора)}, "nametabel", null, "date_update desc", null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере*/
                    }else{
                        if (ПолученнаяUUIDНазванияОрганизации==0){
                            МетодКогдаДанныхСамихТабелйНет();
                            //Toast.makeText(getApplicationContext(), "Не выбрана организация (в настройках выберети ОРГАНИЗАЦИЮ и зайтите еще раз)", Toast.LENGTH_LONG).show();
                        }
                    }
                    //поймать ошибку всего классаIOException | MyException e    NumberFormatException
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                           new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////
                /////// обнуляем
                ///
                String[] НазваниеТабеля = {""};
                String[] ДатаТабеляИзБАзы = {""};


                ////todo ЗАГРУЖАЕМ КУРСОР ПОЛУЧЕННЫЙ С ГОТОВЫМИ ТАБЕЛЯ ЗА КОНКЕРТНЫЙ МЕСЯЦ
                if (Курсор_КоторыйЗагружаетГотовыеТабеля[0]!=null) {/////ЕСЛИ ЕСТЬХОТЯБЫ ОДИН ТАБЕЛЬ
                    Log.d(this.getClass().getName(), " Курсор_КоторыйЗагружаетГотовыеТабеля " + Курсор_КоторыйЗагружаетГотовыеТабеля[0].getCount());
                }

                if (Курсор_КоторыйЗагружаетГотовыеТабеля[0].getCount() > 0) {/////ЕСЛИ ЕСТЬХОТЯБЫ ОДИН ТАБЕЛЬ

                    Log.d(this.getClass().getName(), " Курсор_КоторыйЗагружаетГотовыеТабеля " + Курсор_КоторыйЗагружаетГотовыеТабеля[0].getCount());

                    ////TODO СТАВИМ КУРСОР НА НУЖНУЮ ПОЗИЦИЮ
                    Курсор_КоторыйЗагружаетГотовыеТабеля[0].moveToFirst();
                    Log.d(this.getClass().getName(), " Курсор_КоторыйЗагружаетГотовыеТабеля " + Курсор_КоторыйЗагружаетГотовыеТабеля[0].getCount());
                    ///TODO




                    final int[] ИндексДляСозданныхОбьектовНаАктивитиТАбель = {0};

                    ///todo удалчем элемены перед новой вставкой обтьектов на активти


                    try{

                        //
                        LinearLayoutСозданныхТабелей.removeAllViews();/////удалем данные с актиывти
                        LinearLayoutСозданныхТабелей.invalidate();



                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
               /* Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());*/
                    }






                    ////// todo заргужаем название табелеей ЦИКЛ загружаем на активти  УЖЕ СОЗДАННЫЕ ТАБЕЛЯ И ВИД ИХ ДЕЛАЕМ КАК КНОПКА
                    do {
                        Log.d(this.getClass().getName(), " Количество Строчек В табеле " + Курсор_КоторыйЗагружаетГотовыеТабеля[0].getCount() + " Количество столбиков в табеле " +
                                Курсор_КоторыйЗагружаетГотовыеТабеля[0].getColumnCount());
                        //////
                        /* TimeUnit.MILLISECONDS.sleep(30);*/


                        ////TODO электронне прдставлени имени табеля
                        int ИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ= Курсор_КоторыйЗагружаетГотовыеТабеля[0].getColumnIndex("cfo");
                        ////


                        // TODO: 10.06.2021
                  ПолучеаемЦифруСФО=0;

                        ///
                       ПолучеаемЦифруСФО= Курсор_КоторыйЗагружаетГотовыеТабеля[0].getInt(ИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ);


                        Log.d(this.getClass().getName()," ИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ  "+ИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ+" ПолучеаемЦифруСФО " +ПолучеаемЦифруСФО);


                        НазваниеТабеля[0] =        new  MODEL_synchronized(КонтекстИсторииВсехТабелейВыбранных).     МетодПолучениеНазваниеТабеляНаОснованииСФО(КонтекстИсторииВсехТабелейВыбранных,ПолучеаемЦифруСФО);
                        ///;


                        Log.d(this.getClass().getName(),"  НазваниеТабеля[0]   "+ НазваниеТабеля[0] );


                        try {
                            МесяцМаскимальнаяДатавТабеляхПоМесецям[0] =     new  MODEL_synchronized(КонтекстИсторииВсехТабелейВыбранных).
                                    МетодПолучениеНазваниеТабеляНаОснованииСФО(КонтекстИсторииВсехТабелейВыбранных,ПолучеаемЦифруСФО);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        ///;








                  //      НазваниеТабеля[0] = Курсор_КоторыйЗагружаетГотовыеТабеля[0].getString(ИндексНазваниеТабеля);

                        int ИндексДата= Курсор_КоторыйЗагружаетГотовыеТабеля[0].getColumnIndex("date_update");

                        ДатаТабеляИзБАзы[0] = Курсор_КоторыйЗагружаетГотовыеТабеля[0].getString(ИндексДата);
                        //todo перерводим в дату для СРАВНЕНИЯ

                        //TODO статус табеля
/*
                        int ИндексСтатусаТабеляПроведенИлиНет= Курсор_КоторыйЗагружаетГотовыеТабеля[0].getColumnIndex("status_carried_out");

                        int   СамСтатусАтбеля = Курсор_КоторыйЗагружаетГотовыеТабеля[0].getInt(ИндексСтатусаТабеляПроведенИлиНет)*/;

                        Integer   СамСтатусАтбеля =     МетодВЫчиляемСтатусТабеляПроведенИлиНет(МЕсяцВвидеЦифрыДляКурсора,ГОДВвидеЦифрыДляКурсора,ПолучеаемЦифруСФО);







//                        Date МаскимальнаяДатавТабеляхПоМесецямДляСравнениеВЦикле = new android.icu.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru")).parse(ДатаТабеляИзБАзы[0]);


                        Log.d(this.getClass().getName(), " НазваниеТабеля " + НазваниеТабеля[0] + " ДатаТабеляИзБАзы " + ДатаТабеляИзБАзы[0] + " СамСтатусАтбеля " +СамСтатусАтбеля);
                        ///////// TODO добаляем кнопки
                        ТабелявВидеКнопок = new Button(this);////СОЗДАЕМ НОВЫЕ КНОПКИ НА АКТИВТИ
                        //////
                       // ТабелявВидеКнопок.setId(ИндексДляСозданныхОбьектовНаАктивитиТАбель[0]);
                        ///TODO определяем для созданого табеля его UUID для последющей работы
                        ///todo не посредственно для табеля
                        int ИндексГдеНаходитьсяUUIDВТАБЕЛЕ= Курсор_КоторыйЗагружаетГотовыеТабеля[0].getColumnIndex("uuid");
                        ////
                        String НепостредственоеЗначениеUUIDСозданогоТАбеля = "";
                        ///////
                        if (ИндексГдеНаходитьсяUUIDВТАБЕЛЕ>=0){
                            НепостредственоеЗначениеUUIDСозданогоТАбеля = Курсор_КоторыйЗагружаетГотовыеТабеля[0].getString(ИндексГдеНаходитьсяUUIDВТАБЕЛЕ).trim();
                        }

                        ////TODO электронне прдставлени имени табеля
                        ИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ= Курсор_КоторыйЗагружаетГотовыеТабеля[0].getColumnIndex("cfo");
                        ////
                        int НепостредственоеЗначениеИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ = 0;


                        ///////TODO вычисляем
                        if (ИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ>=0){
                            НепостредственоеЗначениеИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ = Курсор_КоторыйЗагружаетГотовыеТабеля[0].getInt(ИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ);

                            ЦифровоеИмяНовгоТабеля=НепостредственоеЗначениеИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ;
                        }




                        ////todo когда данные в табелй есть  САМИ ДАННЫЕ ТАБЕЛЕЙ ЗАГРУЖАЮТЬСЯ
                        //ТабелявВидеКнопок.setHint(НепостредственоеЗначениеИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ);
                        ТабелявВидеКнопок.setTag(НепостредственоеЗначениеUUIDСозданогоТАбеля);
                        ТабелявВидеКнопок.setId(НепостредственоеЗначениеИндексГдеНаходитьсяЭлектронноеИмяВТАБЕЛЕ);
                        ТабелявВидеКнопок.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                        ТабелявВидеКнопок.setMinLines(8);
                        ТабелявВидеКнопок.setTextSize(13);
                        ТабелявВидеКнопок.setHintTextColor(Color.RED);
                        ТабелявВидеКнопок.setText(НазваниеТабеля[0]);
                        ТабелявВидеКнопок.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                        ТабелявВидеКнопок.setTextColor(Color.BLACK);
                        ТабелявВидеКнопок.setHintTextColor(Color.RED);

                        /////


    //TODO добвлем галочку
                        Log.d(this.getClass().getName(), " СамСтатусАтбеля "+СамСтатусАтбеля);
                        ///
if (СамСтатусАтбеля>0){ ///"пр"

    Drawable icon = getResources().getDrawable(R.mipmap.icon_dsu1_tabels_provedennye);
    icon.setBounds(0, 2, 100, 100);
  //  ТабелявВидеКнопок.setPadding (0,0, 0, 150);
    ТабелявВидеКнопок.setCompoundDrawables(icon, null, null, null);

}



                        ////
                   ТабелявВидеКнопок.setBackground(getApplication().getResources().getDrawable(R.drawable.textlines_tabel_row_color_green_mini));
                        //////ДОБАЯЛЕМ СТРОЧКУ

//////todo сЛУШАТЕЛЬ ДЛЯ УДАЛЕНИЯ ТАБЕЛЯ
                        ТабелявВидеКнопок.setOnLongClickListener(СлушательУдаланиеСамогоТабеля);

                        // TODO ТУТ ДАННЫЙ КОД СРАБАТЫВАЕТ ПОСЛЕ ТОГО КАК МЫ СОЗДАЛИ НОВЫЙ ТАБЕЛЬ И КНОПКА С НОВЫМ НАЗВАНИЕМ ТОЖЕ СОЗДААЛСЬ И МЫ ПО НЕЙ ПЕРЕХОДИМ НА НОВЫЙ ТАБЕЛЯ КЛИКНУТ ПО КНОПКЕ ТАБЕЛЬ

                        ////// todo КЛИК ПО КНОПКАМ --СОЗДАННЫМ НОВЫЕ ТАБЕЛЯ   //////КЛИК ПО КНОПКАМ --СОЗДАННЫМ НОВЫЕ ТАБЕЛЯ
                        //////КЛИК ПО КНОПКАМ --СОЗДАННЫМ НОВЫЕ ТАБЕЛЯ   //////КЛИК ПО КНОПКАМ --СОЗДАННЫМ НОВЫЕ ТАБЕЛЯ








                        ////////


// TODO: 18.03.2021 ЗАПУСКАЕТ КОД ПРОСТО КЛИКА ПО ТАБЕЛЮ ЧТО БЫ ЗАЙТИ ВО ВНУТЬ
                        ////////
                        ТабелявВидеКнопок.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

/////TODO одинатрный клик для загрузки в этот табель всех сотрудников
                        МетодЗапускаетТачОднократныйДляЗагрузкиВтабельСотрудников((Button) v);


                                КонтекстИсторииВсехТабелейВыбранныхВнешний=null;

                            }


                            ////////////////////////TODO event




                            ////////











                            /////TODO метод запуска кода при однократорм нажатии просто загузка сотрудников табель
                            private void МетодЗапускаетТачОднократныйДляЗагрузкиВтабельСотрудников(Button v) {
                                try{
                                    // TODO ДАННЫЙ КОД УЩУСЕТВЛЯЕТ ЗАПУСК СОЗДАНОГО ТАБЕЛЯ НОВОГО ЗАХОДИМ ПРАМЯ В НЕГО
                                    //////СПИНЕРА
                                    //  Toast.makeText(getApplicationContext(), "Тест на Клик по Табелю  MainActivity_CreateTableTHREE.class !!! "  , Toast.LENGTH_SHORT).show();
                                    /////СОБИТИЕ ПРИ НАЖАТИИ НА КОНРКУ СОЗДАННОГО ТАБЕЛЯ
                                    //Intent ИнтентЗапускаемСуществующийТабель=new Intent(MainActivity_History_Tabels.this,MainActivity_CreateTableTHREE.class);//getApplicationContext()
                                    // Intent ИнтентЗапускаемСуществующийТабель=new Intent(MainActivity_History_Tabels.this,MainActivity_Single_Tabely.class);//getApplicationContext()
                                    Intent ИнтентЗапускаемСуществующийТабель=new Intent(MainActivity_History_Tabels.this, MainActivity_Employees_Tabely.class);//getApplicationContext()

                                    ////todo сами данные для ПЕРЕДАЧИ

                                    String ПередаемСозданнуюДатуНовогоТабеля = (String) ((TextView) СпинерВыборДату.getChildAt(0)).getText();///дата нового табеля
                                    ///////todo ВЫТАСКИЕВАЕМ НАЗВАНИЕ ТАБЕЛЯ
                                    Button ИзКнопкиПолучаемНазваниеТабеля = v;
                                    String ПередаемСозданнуюНазваниеТабеля = ИзКнопкиПолучаемНазваниеТабеля.getText().toString();
                                    Log.d(this.getClass().getName(), " ПередаемСозданнуюНазваниеТабеля  " +ПередаемСозданнуюНазваниеТабеля);
                                    ///////todo ВЫТАСКИЕВАЕМ НАЗВАНИЕ ТАБЕЛЯ
                                    Button ИзКнопкиПолучаемUUIDТабеля = v;
                                    Object ПередаваемыйИзКнопкиПолучаемUUIDТабеля = ИзКнопкиПолучаемНазваниеТабеля.getTag();
                                    Log.d(this.getClass().getName(), " ПередаваемыйИзКнопкиПолучаемUUIDТабеля  " +ПередаваемыйИзКнопкиПолучаемUUIDТабеля);
                                    ПубличноеИмяКнопкиТабеля=  ТабелявВидеКнопок.getText().toString();
                                    ///////



                                    Button ИзКнопкиПолучаемЦифровоеИмяТабеля = v;
                                    Object ПередаваемыйИзКнопкиПолучаемЦифровоеИмяТабеля = ИзКнопкиПолучаемНазваниеТабеля.getId();
                                    PUBLIC_CONTENT.ЦифровоеИмяНовгоТабеля= ПередаваемыйИзКнопкиПолучаемЦифровоеИмяТабеля.toString();
                                    Log.d(this.getClass().getName(), " ЦифровоеИмяНовгоТабеля  " +PUBLIC_CONTENT.ЦифровоеИмяНовгоТабеля);



                                    ///////
                                    int ПоискФлеша = ПередаемСозданнуюНазваниеТабеля.indexOf("\n") + 1;
                                    StringBuffer БуферДляПоискаФлешаДляГотовогоТабеля = new StringBuffer(ПередаемСозданнуюНазваниеТабеля);
                                    String ПередаемДепартаментФинал = БуферДляПоискаФлешаДляГотовогоТабеля.substring(ПоискФлеша, БуферДляПоискаФлешаДляГотовогоТабеля.length());
                                    ////
                                    Log.d(this.getClass().getName(), " ПередаемСозданнуюДатуНовогоТабеля " + ПередаемСозданнуюДатуНовогоТабеля +
                                            "  ПередаемСозданнуюДепартаментНовогоТабеля " + ПередаемСозданнуюНазваниеТабеля +
                                            " ПередаемДепартаментФинал  " +ПередаемДепартаментФинал + " ТабелявВидеКнопок.getTag().toString() " );

                                    ////
                                    Log.d(this.getClass().getName(), " МассивДляВыбораВСпинерДата.get(1) " + МассивДляВыбораВСпинерДата.get(0));
                                    ///

                                    МесяцТабеляФиналИзВсехСотрудниковВТАбеле  =МассивДляВыбораВСпинерДата.get(0);

                                    /////////todo отпраялем данные значения на активти где все сотрудникаи вконкретном табеле
                                    ИнтентЗапускаемСуществующийТабель.putExtra("ПередаемСозданнуюДатуНовогоТабеля", String.valueOf(ПередаемСозданнуюДатуНовогоТабеля));

                                    ИнтентЗапускаемСуществующийТабель.putExtra("ПередаемДепартаментФинал", ПередаемДепартаментФинал);

                                    ИнтентЗапускаемСуществующийТабель.putExtra("ПолноеНазваниеТабеляФинал", ПередаемСозданнуюНазваниеТабеля);

                                    ИнтентЗапускаемСуществующийТабель.putExtra("ПередаваемыйИзКнопкиПолучаемUUIDТабеля", String.valueOf(ПередаваемыйИзКнопкиПолучаемUUIDТабеля));



                                    ИнтентЗапускаемСуществующийТабель.putExtra("МесяцТабеляФиналИзВсехСотрудниковВТАбеле", String.valueOf( МесяцТабеляФиналИзВсехСотрудниковВТАбеле));



                                    ИнтентЗапускаемСуществующийТабель.putExtra("ГодТабеляФиналИзВсехСотрудниковВТАбеле", String.valueOf( ГОДВвидеЦифрыДляКурсора));


                                    ИнтентЗапускаемСуществующийТабель.putExtra("ЦифровоеИмяНовгоТабеля", String.valueOf( PUBLIC_CONTENT.ЦифровоеИмяНовгоТабеля));



                                    ИнтентЗапускаемСуществующийТабель.putExtra("ПолученнаяUUIDНазванияОрганизации",ПолученнаяUUIDНазванияОрганизации);


                                    ИнтентЗапускаемСуществующийТабель.putExtra("ЦифровоеИмяНовгоТабеля",ЦифровоеИмяНовгоТабеля);






                                    ////



                                    /////запускаем активти
                                    startActivity(ИнтентЗапускаемСуществующийТабель);
                                    /////
                                    ////
                                  ///  finish();



                                    /////////
                                } catch (Exception e) {
                                    //  Block of code to handle errors
                                    e.printStackTrace();
                                    ///метод запись ошибок в таблицу
                                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                           new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                            Thread.currentThread().getStackTrace()[2].getLineNumber());

                                }
                            }
                        });


                        ///todo клик по табелби преход на сотрудников
                        /////
/////



                        //////

                        if (  МесяцМаскимальнаяДатавТабеляхПоМесецям[0].trim().equals(НазваниеТабеля[0].trim())) {




                            LinearLayoutСозданныхТабелей.addView(ТабелявВидеКнопок, 0); /////СОЗДАЕМ НАКШИ КНОПКИ ВНУРИ СКРОЛБАР




                        }else{
                            //TODO  ОЧИЩАЕМ ПАМТЬ




                            ////////унопки распологаем внутири скролбара
                            LinearLayoutСозданныхТабелей.addView(ТабелявВидеКнопок, ИндексДляСозданныхОбьектовНаАктивитиТАбель[0]); /////СОЗДАЕМ НАКШИ КНОПКИ ВНУРИ СКРОЛБАР




                        }
                        ИндексДляСозданныхОбьектовНаАктивитиТАбель[0]++;///увеличиваем


                        ////ТУТ НАПИСАН  КОД КОТОРЫЙ ЗАПУСКАЕТ САМ ТАБЕЛЬ ПРИ НАЖАТИИ НА СОЗДАННЫЕ КНОПКА-ТАБЕЛЬ



                        /////todo ЦИКЛ ЗАГРУЗКИ ТОЛЬКО НАЗВАНИЙ ТАБЕЛЯ
                    } while (Курсор_КоторыйЗагружаетГотовыеТабеля[0].moveToNext());
                    /////toto ПОСЛЕ ВСТАВКИ ДАННЫХ ПЕРЕОПРЕДЕЛЯЕМ ВНЕГНИЙ ВИДЖ



                   // TextView) parent.getChildAt(0)).getText()+String.valueOf("  ("+СпинерВыборДату.getCount()+")")




///todo  когда в табеле нет сотрудников ПУСТОЙ ТАБЕЛЬ
                }else{
                    МетодКогдаДанныхСамихТабелйНет();
                }

                ////TODO ПОСЛЕ ЗАПОЛЕНЕИЯ ТАБЕЛЯ В АКТИВИТИ
                LinearLayoutСозданныхТабелей.invalidate();
                ScrollНаАктивтиСозданныхТабелей.invalidate();
                ScrollНаАктивтиСозданныхТабелей.fullScroll(View.FOCUS_UP);

            }

            ///TODO удалем из памяти курсор
            Курсор_КоторыйЗагружаетГотовыеТабеля[0].close();


            ///КОНЕЦ ЗАПОЛЕНИЯ ТАБЕЛЯ ИЗ ДАННЫХ
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }


    // TODO: 17.06.2021 вычиляем статус табеля

    private int МетодВЫчиляемСтатусТабеляПроведенИлиНет(int finalМЕсяцВвидеЦифрыДляКурсора ,int finalГОДВвидеЦифрыДляКурсора ,int ПолучеаемЦифруСФО ) {
//
        Integer ПолученныйСтатусТабеля=0;
   try{

       final Cursor[] Курсор_КоторыйЗагружаетСтатусТабеля = {null};


CompletionService<Integer> completionServiceСтатцусТабеля=new ExecutorCompletionService<Integer>(Executors.newSingleThreadExecutor());
///
       completionServiceСтатцусТабеля.submit(new Callable() {
           @Override
           public Integer call() throws Exception {

               Integer ПолученныйСтатусВнутри = null;
               /////////////
               Курсор_КоторыйЗагружаетСтатусТабеля[0]=null;
               /////////////
       Курсор_КоторыйЗагружаетСтатусТабеля[0] = new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("viewtabel", new String[]{"status_carried_out"},
               " month_tabels=? AND year_tabels=?  AND cfo=?  AND status_send!=? " +
                       "AND status_carried_out IS NOT NULL",
               new String[]{String.valueOf(finalМЕсяцВвидеЦифрыДляКурсора),
                       String.valueOf(finalГОДВвидеЦифрыДляКурсора), String.valueOf(ПолучеаемЦифруСФО), "Удаленная"},
               "cfo", null, "date_update DESC", null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
       ///////
               if( Курсор_КоторыйЗагружаетСтатусТабеля[0].getCount()>0){
                   ////
                   Курсор_КоторыйЗагружаетСтатусТабеля[0].moveToNext();
                   ///
               ПолученныйСтатусВнутри=Курсор_КоторыйЗагружаетСтатусТабеля[0].getInt(0);
               }else{
                   ПолученныйСтатусВнутри=0;
               }


//
               return ПолученныйСтатусВнутри;
           }
       });
       ////
     Future<Integer>  futureПолученныйСтатусТабеля=   completionServiceСтатцусТабеля.take();
     //
       ПолученныйСтатусТабеля=    futureПолученныйСтатусТабеля.get();
       //
       if(futureПолученныйСтатусТабеля.isDone()){
           ///
           futureПолученныйСтатусТабеля.cancel(false);
       }


        ///КОНЕЦ ЗАПОЛЕНИЯ ТАБЕЛЯ ИЗ ДАННЫХ
    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
   return ПолученныйСтатусТабеля;
    }












    //////TODO вычисляем максимальную дату для LISTVIEW

    Cursor МетодКоторыйПоказываетМаксимальнуюДатуИзменения(Long полученнаяUUIDНазванияОрганизации) throws ExecutionException, InterruptedException {
        final Cursor[] Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДата = {null};
        ///
        ExecutorService executorService= Executors.newCachedThreadPool();
        //   ForkJoinPool   executorService=new ForkJoinPool(Runtime.getRuntime().availableProcessors());
        Future futureВсеТабеля=   executorService.submit(new Runnable() {
            @Override
            public void run() {
                try{

                    Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДата[0] = new MODEL_synchronized(КонтекстИсторииВсехТабелейВыбранных).КурсорУниверсальныйДляБазыДанных("tabels",
                            new String[]{"date_update"},
                            " month_tabels=? AND year_tabels=? AND status_send!=?  AND date_update = (SELECT MAX(date_update) FROM tabels)",
                            new String[]{ String.valueOf(МЕсяцВвидеЦифрыДляКурсора),
                                    String.valueOf(ГОДВвидеЦифрыДляКурсора), "Удаленная",}, null, null, "date_update DESC", null);
///////

///////
                } catch (Exception e) {
                    e.printStackTrace();
///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

            }});
        ////
        futureВсеТабеля.get();
        if(futureВсеТабеля.isDone()){
            executorService.shutdown();
        }
        return Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДата[0];
    }

//////






    //////TODO вычисляем максимальную дату для СПИНЕРА ДЛЯ ВАДАПТЕРА AAARYADAPTER

    Cursor МетодКоторыйПоказываетМаксимальнуюДатуИзмененияДляСпинера() throws ExecutionException, InterruptedException {
        final Cursor[] Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДатаДляСпинера = {null};
        ///
        ExecutorService executorService= Executors.newCachedThreadPool();
        //   ForkJoinPool   executorService=new ForkJoinPool(Runtime.getRuntime().availableProcessors());
        Future futureВсеТабеля=   executorService.submit(new Runnable() {
            @Override
            public void run() {
                try{

                    Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДатаДляСпинера[0] = new MODEL_synchronized(КонтекстИсторииВсехТабелейВыбранных).КурсорУниверсальныйДляБазыДанных("tabels", new String[]
                                    {"month_tabels,year_tabels"},
                            "status_send!=?  AND date_update = (SELECT MAX(date_update) FROM tabels)",
                            new String[]{ "Удаленная"}, null, null, "date_update DESC", null);
///////

///////
                } catch (Exception e) {
                    e.printStackTrace();
///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

            }});
        ////
        futureВсеТабеля.get();
        if(futureВсеТабеля.isDone()){
            executorService.shutdown();
        }
        return Курсор_КоторыйЗагружаетГотовыеТабеляМаксимальнаяДатаДляСпинера[0];
    }
















    private void МетодКогдаДанныхСамихТабелйНет() {
        try{
            ТабелявВидеКнопок = new Button(this);////СОЗДАЕМ НОВЫЕ КНОПКИ НА АКТИВТИ
            ТабелявВидеКнопок.setTag(" * В данном месяце нет табеля * ");
            ТабелявВидеКнопок.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
            ТабелявВидеКнопок.setMinLines(10);
            ТабелявВидеКнопок.setTextSize(14);
            ТабелявВидеКнопок.setText("*В этом месяце нет Табеля  " +"(создайте).*");
            ТабелявВидеКнопок.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
            ТабелявВидеКнопок.setTextColor(Color.RED);
            ТабелявВидеКнопок.setHintTextColor(Color.RED);
            ////
            ТабелявВидеКнопок.setBackground(this.getResources().getDrawable(R.drawable.textlines_tabel_row));
            //////ДОБАЯЛЕМ СТРОЧКУ
////////унопки распологаем внутири скролбар
            ((Activity) КонтекстИсторииВсехТабелейВыбранных).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ////////унопки распологаем внутири скролбара
                    LinearLayoutСозданныхТабелей.addView(ТабелявВидеКнопок); /////СОЗДАЕМ НАКШИ КНОПКИ ВНУРИ СКРОЛБАРА
                }});

            ///////
        } catch (Exception e) {
            e.printStackTrace();
///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }


    /////МЕТОД СОЗДАНИЕ ДАТЫ И КАЛЕНДАРЯ
    /////МЕТОД СОЗДАНИЕ ДАТЫ И КАЛЕНДАРЯ
    /////МЕТОД СОЗДАНИЕ ДАТЫ И КАЛЕНДАРЯ
    /////МЕТОД СОЗДАНИЕ ДАТЫ И КАЛЕНДАРЯ

    private void МетодСозданиеДиалогаКалендаряДаты() {///////метод создание календяря даты
/////TODO тут визуализикуеться КАЛЕНДАРЬ
        DatePickerDialog ДатаДляКалендаря=new DatePickerDialog(this,this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        // ДатаДляКалендаря.setTitle("Календарь");
        ДатаДляКалендаря.show();
    }




    //////////
//TODO метод который и создает календарь после нажатие на кнопку ОК

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String МесяцИзКолендаря = String.valueOf(month + 1);////ТЕКУЩИЙ МЕСЯЦ ИЗ КАЛЕНДАРЯ
        if (МесяцИзКолендаря.length() == 2) {
            ПолученноеЗначениеИзСпинераДата = dayOfMonth + "-" + МесяцИзКолендаря + "-" + year;////ДАННОЕ ЗНАЧЕНИЕ ПЕРЕДАЕМ НА ВСЕ ПРОГРАММУ В ДАЛЬНЕЙШЕМ
            Log.d(this.getClass().getName(), " ПолученноеЗначениеИзСпинераДата" + ПолученноеЗначениеИзСпинераДата);
        } else {
            ПолученноеЗначениеИзСпинераДата = dayOfMonth + "-" + "0" + МесяцИзКолендаря + "-" + year;////ДАННОЕ ЗНАЧЕНИЕ ПЕРЕДАЕМ НА ВСЕ ПРОГРАММУ В ДАЛЬНЕЙШЕМ
            Log.d(this.getClass().getName(), " ПолученноеЗначениеИзСпинераДата" + ПолученноеЗначениеИзСпинераДата);
        }

        Date ПрасингДаты = new Date();
        try {



            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                ПрасингДаты = new android.icu.text.SimpleDateFormat("dd-MM-yyyy", new Locale("ru")).parse(ПолученноеЗначениеИзСпинераДата);

            }else {

                ПрасингДаты = new java.text.SimpleDateFormat("dd-MM-yyyy", new Locale("ru")).parse(ПолученноеЗначениеИзСпинераДата);


            }
            Log.d(this.getClass().getName()," ПрасингДаты " +ПрасингДаты.toString());





        } catch (ParseException e) {
            e.printStackTrace();
        }
        ///////получаем значение месца на руском через метод дата
        ПолученноеЗначениеИзТолькоСпинераДата = МетодПереводаНазваниеМесяцаСАнглискогоНаРУсский(ПрасингДаты);
        Log.e(this.getClass().getName(), " ПолученноеЗначениеИзТолькоСпинераДата " + ПолученноеЗначениеИзТолькоСпинераДата);
        /////вАЖНО ЗАПИСЫВАЕМ ОБРАТНО В СПИНЕР НА РАБОЧИЙ СТОЛ АКТИВТИ НАПРИМЕР НОВЫЙ МЕСЯЦ  ОКТЯБРЬ 2020 ГОДА НАПРИМЕР
        Log.e(this.getClass().getName(),"  ПолученноеЗначениеИзСпинераДата" + ПолученноеЗначениеИзСпинераДата);


/////////////ТУТ КРУТИМ ВЕСЬ КУРСОР  И ПЫТАЕМСЯ НАЙТИ ЗНАЧЕНИЕ ВНЕМ  И ПО РЕЗУЛЬТАТ ЗАПОЛЯЕМ ЕГО В STRINGBUGGER
        ////TODO ТУТ МЫ КРУТИМ ВЕСЬ СПИНЕР В КОТРЫЙ ИЗ БАЗЫ ЗАГРУЗИЛОСЬ ВСЕ СОЗДАННЫЕ МЕСЯЦА ИМЫ ПРОВЕРЕМ ЕЛСИ ТАКОМ МЕСЯЦ ЕЩН ИЛИ НЕТ
        StringBuffer ИщемУжеСозданныйМЕсяц=new StringBuffer();
        for (int ИндексСуществуюЩимМесяц=0;ИндексСуществуюЩимМесяц<СпинерВыборДату.getCount();ИндексСуществуюЩимМесяц++){
            ////todo ДА ПРОСТО ЗАПОЛЯНЕМ БУФЕР УЖЕ СОЗДАННЫМИ МЕСЯЦАМИ В СПИНЕРЕ
            ИщемУжеСозданныйМЕсяц.append(СпинерВыборДату.getItemAtPosition(ИндексСуществуюЩимМесяц).toString()).append("\n");
            Log.d(this.getClass().getName()," ИщемУжеСозданныйМЕсяц " +ИщемУжеСозданныйМЕсяц.toString()+"\n");

        }


        ///// todo ТУТ ВСТАВЛЯЕМ ММЕСЯЦА УКТОРГНО НЕТ ЕШЕ
        try {
            МетодВставкиНовогоМесяцавТабельКоторогоНет(ИщемУжеСозданныйМЕсяц);
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }
////TODO СОЗДАНИЯ КАЛЕНДАРЯ С ПОЛУЧЕННЫМИ УЖЕ ДАННЫМИ
    private void МетодВставкиНовогоМесяцавТабельКоторогоНет(StringBuffer ищемУжеСозданныйМЕсяц) throws ParseException {
        ///////ПРОВЕРКА НЕ ВЫБРАЛИ ЛИ МЫ МЕСЯЦ КОТОРЫЙ УЖЕ СУЩЕТСВУЕТ
        Log.d(this.getClass().getName()," ПолученноеЗначениеИзТолькоСпинераДата " +ПолученноеЗначениеИзТолькоСпинераДата);
        StringBuffer МЕсяцСЗакглавнойБуквы =new StringBuffer(ПолученноеЗначениеИзТолькоСпинераДата.toLowerCase());
        ПолученноеЗначениеИзТолькоСпинераДата= МЕсяцСЗакглавнойБуквы.substring(0, 1).toUpperCase() + МЕсяцСЗакглавнойБуквы .substring(1).toLowerCase();
        Log.d(this.getClass().getName()," МЕсяцСЗакглавнойБуквы " +ПолученноеЗначениеИзТолькоСпинераДата);
        ///проверяем не тот же самый месяц выбран был ///ЕСЛИ ВЕРНУЛ -1 ТО ТАКОГО МЕСЯЦА ЕЩЕ НЕТ И НАДО ЕГО СОЗДАТЬ

        //TODO ВАЖНО ОПРЕДЕЛЯЕМ ВСТАЛЯТЬ ИЛИ НЕ ВСТАЛЯТЬ МЕСЯЦ ЕСЛИ НИЖЕ В IF ВЕРНУЛАСЬ ЦИФРА -1 ТО ТАКОГО МЕСЯЦА НЕТ И НАДО ВСТАЛЯТЬ,
        // TODO ЕСЛИ ПРИШЛА ПОЛОЖИТЕЛЕЛЬАЯ ЦИФРА ТО ТАКОЙ МЕСЯЦ УЖЕ ЕСТЬ НЕ НАДО ВСТАЛЯТЬ


        ////ЗАПОЛЕНИЕ СПИНЕРА ТОЛЬКО ЕСЛИ ТАКОГО МЕСЯЦА ЕЩЕ НЕТ
        //////ВАЖГНО ЗАПОЛЕНИЕ СПИНЕРА СДЕСЬ КА КТЕКС ДОБАВЛЕНИЕ МЕСЯЦА , СЕНТЯБРЬ ОКТЯБРЬ НОЯБРЬ


            ////////
            ContentValues АдаптерВставкаНовогоМЕсяцаИзКалендаря = new ContentValues();////контрейнер для нового табеля
            ////////заполение контейнера данными новго табеля
            // /TODO перердаваемые три згначение в следующее активти // -- ФинальнаяМЕсяцДляНовогоТабеля // ПолученныйГодДляНовогоТабеля // -ПолученноеЗначениеИзТолькоСпинераДата
            ///TODO вставляемый контент
            int ДляВставкиНовогоМесяцаНазвание = МетодПолучениниеНовогоМесяцДляЗАписивОднуКолонку(ФинальнаяМЕсяцДляНовогоТабеля);
////
            int ДляВставкиНовогоГодНазвание = МетодПолучениниеНовыйГодДляЗАписивОднуКолонку(ПолученныйГодДляНовогоТабеля);

///TODO  заполянем контейнер новыми данными новый месяц и новый год
      /*          АдаптерВставкаНовогоМЕсяцаИзКалендаря.put("month_tabels",ДляВставкиНовогоМесяцаНазвание);
                АдаптерВставкаНовогоМЕсяцаИзКалендаря.put("year_tabels",ДляВставкиНовогоГодНазвание  );
                АдаптерВставкаНовогоМЕсяцаИзКалендаря.put("date_update",ГлавнаяДатаИВремяДляТабеля() );

////
                Log.d(this.getClass().getName()," ДляВставкиНовогоМесяцаНазвание " +ДляВставкиНовогоМесяцаНазвание+ " ДляВставкиНовогоГодНазвание " +ДляВставкиНовогоГодНазвание);
                //////
                long РезультатВставкиНовогоМесяцаСозданогоИзКалендаря= 0;
                try {
                  РезультатВставкиНовогоМесяцаСозданогоИзКалендаря = new MODEL_synchronized(getApplication()).ВставкаДанныхЧерезКонтейнерУниверсальная("tabels",
                            АдаптерВставкаНовогоМЕсяцаИзКалендаря,"tabels","",true);

                   ///ОЧИСТКА ПАМЯТИ
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (TimeoutException e) {
                    e.printStackTrace();
                }*/
            /// после вствки в базу обнуляем контейнер данные от сервера

            ///todo ПОКАЗЫВАЕМ ЧТО ПРОШЛАУ СПЕШНО ОПЕРВЦИЯ
            PUBLIC_CONTENT.КоличествоУспешныхВставки++;////ПРИ УСПЕШНОЙ ВСТАВКИ ДАННЫХ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+

            //TODO тут КОД НАЧИНАЕТ РАБОТЬ КОГДА УКАЗАННЫЙ МЕСЯЦ УЖЕ СТЬ И МЫ В КАЛЕНДАРИ ВЫБРАЛИ МЕСЯЦ КОТОРФЙ УЖЕ ЕСТЬ И ЕГО СОЗДАВАТЬ НЕ НАДО И МЫ СРАЗУ ПЕРЕХОДИМ НА СОЗАЛНИЕ ЕЩЕ ОДНОГО ТАБЕЛЕЯ НА МЕСЯЦ


            ////ПОСЛЕ ВССТАВКИ ЗАПУСКАЕМ АКТИВТИ ЧТОБЫ ПЕРЕЙТИ НА СОЗАННУЮ




            ///TODO  ПОСЛЕ ВСТАКИ ПЕРЕХОДИМ НА АКТИВТИ С ВЫБОРО И СОЗДАНИЕМ САМОГО ТАБЕЛЯ НОВОГО
            Intent Интент_ЗапускСозданиеНовогоТабельногоУчетавТаблицуИстория = new Intent();
            Интент_ЗапускСозданиеНовогоТабельногоУчетавТаблицуИстория.setClass(getApplicationContext(), MainActivity_New_Tabely.class); // ТУТ ЗАПВСКАЕТЬСЯ ВЫБОР ПРИЛОЖЕНИЯ
            // КОТОРЫЕ ЕСТЬ FACE APP НА ДАННЫЙ МОМЕТНТ РАЗРАБОТНАО ТАБЕЛЬНЫЙ УЧЁТ
            Интент_ЗапускСозданиеНовогоТабельногоУчетавТаблицуИстория.putExtra("ПолученноеЗначениеИзСпинераДата", ПолученноеЗначениеИзТолькоСпинераДата);
            Интент_ЗапускСозданиеНовогоТабельногоУчетавТаблицуИстория.putExtra("ПолученныйГодДляНовогоТабеля", String.valueOf(ДляВставкиНовогоГодНазвание));
            Интент_ЗапускСозданиеНовогоТабельногоУчетавТаблицуИстория.putExtra("ФинальнаяМЕсяцДляНовогоТабеля", String.valueOf(ДляВставкиНовогоМесяцаНазвание));
            ////
            // /TODO перердаваемые три згначение в следующее активти // -- ФинальнаяМЕсяцДляНовогоТабеля // ПолученныйГодДляНовогоТабеля // -ПолученноеЗначениеИзТолькоСпинераДата
            Log.d(this.getClass().getName(), "  ПолученноеЗначениеИзТолькоСпинераДата " + ПолученноеЗначениеИзТолькоСпинераДата +
                    " ПолученныйГодДляНовогоТабеля " + ПолученныйГодДляНовогоТабеля
                    + " ФинальнаяМЕсяцДляНовогоТабеля " + ФинальнаяМЕсяцДляНовогоТабеля);
            ///TODO ПОСЛЕ ОТПРОВКИ ДАННЫХ ЧИСТИМ ПЕРЕМЕНЕЫ

            ////
        Интент_ЗапускСозданиеНовогоТабельногоУчетавТаблицуИстория.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(Интент_ЗапускСозданиеНовогоТабельногоУчетавТаблицуИстория);

            ////
          // finish();

            // ВЫБОРА ИЛИ СОЗДАНИЕ МАКЕТА ТАБЕЛЯ СПРАВИШАЕМ НУЖНА ЛИ СОЗДАТЬ ТАБЕЛЬ НА ЛРУГОМ АКТТИВИТИ
            //////спрашиваем пользователя хочел ли он создать табель
            ////СООБЩЕНИЕ ИЗ ИТОРИИИ ТАБЛЕЙ ОТПРАВЛЯЕМ СООБЩЕНЕИ И ЗНАЧЕНИЕ В ДУГОЕ АКТИВТИ О СОЗДАНИЮ НОВОГО ТАБЕЛЯ И ПЛЮС ТУТ ПЕРЕДАЕМ ПОЛУЧЕННОЕ ЗНАЧЕНИЕ НОВОГО МЕСЯЦ
            // finish();
            ///TODO очищаем память
            АдаптерВставкаНовогоМЕсяцаИзКалендаря.clear();//
            ПолученныйГодДляНовогоТабеля = "";
            ФинальнаяМЕсяцДляНовогоТабеля = "";
        }






    //TODO метод получени месяа для записи в одну колонку

    private int  МетодПолучениниеМесяцДляЗАписивОднуКолонку(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println( " " + ДатаКоторуюНадоПеревестиИзТекставЦифру + " " +ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatмесяц = new SimpleDateFormat("LLLL  yyyy");
        Date date = formatмесяц .parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        Calendar calendar2 = new GregorianCalendar();
        calendar.setTime(date );
        int month = calendar.get(Calendar.MONTH) + 1;
        return   month;
    }

    //TODO метод получени месяа для записи в одну колонку

    private int  МетодПолучениниеГОдДляЗАписивОднуКолонку(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println( "ДатаКоторуюНадоПеревестиИзТекставЦифру " +ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatгод = new SimpleDateFormat("LLLL  yyyy");
        Date date = formatгод.parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        return   year ;
    }

////TODO МЕТОД ТОЛЬКО ДЛЯ ВСТВКИ НОВОГО МЕСЯЦА и ГОД НОВЫЙ

















    private int  МетодПолучениниеНовогоМесяцДляЗАписивОднуКолонку(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println( " " + ДатаКоторуюНадоПеревестиИзТекставЦифру + " " +ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatмесяц = new SimpleDateFormat("LLLL");
        Date date = formatмесяц .parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        int month = calendar.get(Calendar.MONTH) + 1;
        return   month;
    }

    private int  МетодПолучениниеНовыйГодДляЗАписивОднуКолонку(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println( "ДатаКоторуюНадоПеревестиИзТекставЦифру " +ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatгод = new SimpleDateFormat("yyyy");
        Date date = formatгод.parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        Calendar calendar2 = new GregorianCalendar();
        calendar.setTime(date );
        int year = calendar.get(Calendar.YEAR);
        return   year ;
    }





    //TODO метод получени года для записи в одну колонку

    private String МетодПолучениниеГодаДляЗАписивОднуКолонку(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {

        int ИщемЕслиПробелВДате=ДатаКоторуюНадоПеревестиИзТекставЦифру.indexOf(" ");
        StringBuffer ИщемГод=new StringBuffer(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        String Год=  ИщемГод.substring(ИщемЕслиПробелВДате,ИщемГод.length());
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy", new Locale("ru"));
        Date date = formatter.parse(Год);
        System.out.println(date);
        System.out.println(formatter.format(date));
        return   Год;
    }



    //TODO метод получени года для записи в одну колонку






    //////TODO МЕТОД ПЕРВЫЙ ПРИ ПРОСМОТРЕ КАКЕИ ТАБЕЛЯ ВООБЩЕ ЕСТЬ
    private void МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля() throws InterruptedException, ExecutionException, TimeoutException, ParseException {

        try{





// TODO вытасиваем даные из базы чтобы ЗАполнить спирер готовыми табелями Датами НАПРИМЕР ОКТЯРЬ 2020  ДЕКАБРЬ 2019

Cursor Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля=null;

            Future<Cursor> futureКурсор_ЗагружаетАрайдистЗначенийНовогоТИабеля=   Executors.newCachedThreadPool().submit(new Callable<Cursor>() {
                @Override
                public Cursor call() throws Exception {


                    Cursor       Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеляВнутри=null;

//////////TODO
                  Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеляВнутри = new MODEL_synchronized(КонтекстИсторииВсехТабелейВыбранных).
                            МетодЗагружаетЗначенияНовгоСотрудника( КонтекстИсторииВсехТабелейВыбранных);

//
                    //// МесяцМаскимальнаяДатавТабеляхПоМесецям

               return Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеляВнутри;
                }
            });
            Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля=     futureКурсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.get();

            if (futureКурсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.isDone()){
                futureКурсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.cancel(false);
            }





            // TODO: 16.05.2021 запоеления данных

            String ЗначениеДляЗаполенияСпинера= "";
            int   IDДляЗаполенияСпинера;


            if (Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля!=null) {
////////
                МетодЗаполенияТабелямиАктивти(Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля);


                ///////////////todo закрываем курсор для заполения данными АКайлиста ЗАКРЫВАЕМ
                Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.close();
            }







            ///
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }





    private void МетодЗаполенияТабелямиАктивти(Cursor курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля) throws ExecutionException, InterruptedException, ParseException {
        if ( курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.getCount()>0) {/////ЗАГРУЖАЕМ ДАННЫЕ ИЗ ТАБЛИЦЫ CFO ДЛЯ СПИНЕРА И СОЗДАНИЯ ТАБЕЛЯ
            //TODO ЧТО В КУРСОРЕ
            Log.d(this.getClass().getName()," Курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.getCount() " + курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.getCount());
            ///TODO очищаем арайлист
            //МассивДляВыбораВСпинерДата.clear();
            курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.moveToFirst();

            //////TODO ЗАПОЛЯЕМ СПИНЕР ЧЕРЕЗ АРАЙЛИСТ ПОСЛЕДНИМИ ДАТАМИ

            МассивДляВыбораВСпинерДата.clear();





            ////первый элемент в спинре

            do{
                ///


                ///////вытаскиваем данные из базы столбкик ЗАПОЛЕНИЕ ХЕША

                String     ЗнаениеИзБазыНовыеТабеляМесяц = курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.getString(0).trim();

                String     ЗнаениеИзБазыНовыеТабеляГод = курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.getString(1).trim();

               // String     ЗнаениеИзБазыНовыеТабеляНазваниеТабеля = курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.getString(2).trim();
                String     ЗнаениеИзБазыНовыеТабеляНазваниеТабеля ;

                int ИндексСФО=курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.getColumnIndex("cfo");

                int     ЗнаениеИзБазыНовыеТабеляIDСфо = курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.getInt(ИндексСФО);

// TODO: 10.06.2021



                ПолученнаяUUIDНазванияОрганизации=0l;

                ПолученнаяUUIDНазванияОрганизации=Long.parseLong(String.valueOf(ЗнаениеИзБазыНовыеТабеляIDСфо));

                Log.d(this.getClass().getName()," ЗнаениеИзБазыНовыеТабеляМесяц " +ЗнаениеИзБазыНовыеТабеляМесяц +"  ЗнаениеИзБазыНовыеТабеляГод " +ЗнаениеИзБазыНовыеТабеляГод
                        +" ЗнаениеИзБазыНовыеТабеляIDСфо" +ЗнаениеИзБазыНовыеТабеляIDСфо + " ПолученнаяUUIDНазванияОрганизации " +ПолученнаяUUIDНазванияОрганизации);



Future<String> futureПолучениеНазванниеТабеляЧерезIdСФО=Executors.newCachedThreadPool().submit(new Callable<String>() {
    @Override
    public String call() throws Exception {

        String ЗнаениеИзБазыНовыеТабеляНазваниеТабеляВнутри=null;
                // TODO: 19.05.2021 если нет названеи Табеля то выислчем его пото ID сфо


 try {

       Cursor Курсор_ВычисляемНазваниеТАбеляПоIDсфо = new MODEL_synchronized(КонтекстИсторииВсехТабелейВыбранных).
               КурсорУниверсальныйБазыДанных("SELECT name FROM cfo WHERE id='"+ЗнаениеИзБазыНовыеТабеляIDСфо+"' LIMIT 1");

if (Курсор_ВычисляемНазваниеТАбеляПоIDсфо.getCount()>0){
    ///
    Курсор_ВычисляемНазваниеТАбеляПоIDсфо.moveToFirst();
    ////
 ЗнаениеИзБазыНовыеТабеляНазваниеТабеляВнутри=  Курсор_ВычисляемНазваниеТАбеляПоIDсфо.getString(0);
}


       /////
   } catch (Exception e) {///////ошибки
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу

                    Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new  КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

        return ЗнаениеИзБазыНовыеТабеляНазваниеТабеляВнутри.trim();
    }
});
////

                ЗнаениеИзБазыНовыеТабеляНазваниеТабеля=futureПолучениеНазванниеТабеляЧерезIdСФО.get();////

                //////
                if (futureПолучениеНазванниеТабеляЧерезIdСФО.isDone()){
                    futureПолучениеНазванниеТабеляЧерезIdСФО.cancel(false);
                }



                Log.d(this.getClass().getName()," ЗнаениеИзБазыНовыеТабеляНазваниеТабеля " +ЗнаениеИзБазыНовыеТабеляНазваниеТабеля);

















                ////todo ПРЕОБРАЗОВАЫВЕМ ЦИФРВЫ В ДАТУ ВВИДЕТ ТЕКСТА ИБЛЬ АВГУСТ 2020 2021
                SimpleDateFormat ПереводимЦифруВТЕкстМЕсяца = new SimpleDateFormat("mm", new Locale("rus") );
                Date ДатаДляПолученияМесяцаСловом = ПереводимЦифруВТЕкстМЕсяца.parse(ЗнаениеИзБазыНовыеТабеляМесяц);
                String ПреобразованоеИмяМесяца= ПереводимЦифруВТЕкстМЕсяца.format( ДатаДляПолученияМесяцаСловом );
                Log.d(this.getClass().getName()," ПреобразованоеИмяМесяца " +ПреобразованоеИмяМесяца);


                ////////////////
                SimpleDateFormat formatмесяц = new SimpleDateFormat("MMyyyy", new Locale("ru"));
                Date date = formatмесяц.parse(ПреобразованоеИмяМесяца+ЗнаениеИзБазыНовыеТабеляГод);
                Calendar calendar = Calendar.getInstance(new Locale("ru"));
                calendar.setTime(date);
                System.out.println(calendar.get(Calendar.YEAR));
                System.out.println(calendar.get(Calendar.MONTH)+1);
                System.out.println(calendar.get(Calendar.DAY_OF_MONTH));
                System.out.println(new SimpleDateFormat("LLLL").format(calendar.getTime()));
                ПреобразованоеИмяМесяца=new SimpleDateFormat("LLLL").format(calendar.getTime());


                StringBuffer stringBuffer=new StringBuffer(ПреобразованоеИмяМесяца);

                ПреобразованоеИмяМесяца=stringBuffer.substring(0,1).toUpperCase()+stringBuffer.substring(1,stringBuffer.length()).toLowerCase();

                //String месяцОбрантноТекстДляКурсора=   МетодПолучениеДатыИзЦифраВТекстДляКурсора(ЗнаениеИзБазыНовыеТабеляМесяц);
                String ФиналВставкаМЕсяцаИгода = "";
                ////TODO ПОКАЗЫВВАЕТ ПОЛЬЗОВАТЛЕЛЮ МЕСЯЦ И ГОДВ ВИДЕ СЛОВ ИЗ ЦИФРЫ 11 МЕНЯЕ НА НОЯБРЬ 2020 НАПРИМЕР
                ФиналВставкаМЕсяцаИгода=ПреобразованоеИмяМесяца+ "  "+ЗнаениеИзБазыНовыеТабеляГод;
                Log.d(this.getClass().getName()," ФиналВставкаМЕсяцаИгода "+ФиналВставкаМЕсяцаИгода);






                ///todo ТОЛЬКО ДЛЯ ПРОСМОТРА ДАННЫХ ПОЛЬЗОВТЕЛЯ ЗАГРУАЕТЬСЯ ИЗ БАЗЫ
                МассивДляВыбораВСпинерДата.add(ФиналВставкаМЕсяцаИгода);

                Log.d(this.getClass().getName(),"  МассивДляВыбораВСпинерДата " + МассивДляВыбораВСпинерДата.toString() +"  МассивДляВыбораВСпинерДата " +МассивДляВыбораВСпинерДата.size());
                ////////
            }while (курсор_ЗагружаетАрайдистЗначенийНовогоТИабеля.moveToNext());
            //todO УДАЛЕМ КУРСОР

/*

            //TODO метод праивльно возврящет дату в спиноре  на первоночальнуюс последней
            МетодВозвратаПравильногоДатыВСпиноре();*/






            ////todo данный ко дпрказывает что на текущего польоватлея пока нет не обного табеля
        }else{
            ////todo данный ко дпрказывает что на текущего польоватлея пока нет не обного табеля
            LinearLayoutСозданныхТабелей.removeAllViews();
            ТабелявВидеКнопок = new Button(this);////СОЗДАЕМ НОВЫЕ КНОПКИ НА АКТИВТИ
            ТабелявВидеКнопок.setTag(" * Табелей Нет (создайте)* ");
            ТабелявВидеКнопок.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            ТабелявВидеКнопок.setLines(12);
            ТабелявВидеКнопок.setTextSize(15);
            ТабелявВидеКнопок.setText("*В этом месяце нет Табеля  " +"(создайте).*");
            ТабелявВидеКнопок.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
            ТабелявВидеКнопок.setTextColor(Color.RED);
            ТабелявВидеКнопок.setHintTextColor(Color.RED);

            ////
            ТабелявВидеКнопок.setBackground(this.getResources().getDrawable(R.drawable.textlines_tabel_row));



////////унопки распологаем внутири скролбара
            LinearLayoutСозданныхТабелей.addView(ТабелявВидеКнопок); /////СОЗДАЕМ НАКШИ КНОПКИ ВНУРИ СКРОЛБАРА






        }
    }


    private void МетодВозвратаПравильногоДатыВСпиноре() {
        try{


            Log.d(this.getClass().getName()," ПравильныйВозвратИзДруговоАктивтиBACK "+ПравильныйВозвратИзДруговоАктивтиBACK +"\n");

            //TODO для првавильного востсзвтра делаем дополнительнй параметр ДВА ВИДА ЗАГРУЗЩКИ ПЕРВОНОЧАЛЬНЫЙ И ВОЗВРАТ ИЗ BACK
            if ( ПравильныйВозвратИзДруговоАктивтиBACK!=null) {
                Log.d(this.getClass().getName()," МассивДляВыбораВСпинерДата.size() "+МассивДляВыбораВСпинерДата.size());


                Log.d(this.getClass().getName()," МассивДляВыбораВСпинерДата "+МассивДляВыбораВСпинерДата +"\n");


                int ИщемСвойМесяцПорядок=МассивДляВыбораВСпинерДата.indexOf(ПравильныйВозвратИзДруговоАктивтиBACK);


                /////TODo данной командой ставим месяц котроый наш всегда в начало Арайлиста
                Collections.swap(МассивДляВыбораВСпинерДата,0,ИщемСвойМесяцПорядок);


                Log.d(this.getClass().getName()," МассивДляВыбораВСпинерДата "+МассивДляВыбораВСпинерДата +"\n");

                ///TODO возврат из другой активти
   /*         int РазмерАрайЛиста=МассивДляВыбораВСпинерДата.size();
            МассивДляВыбораВСпинерДата.ensureCapacity(РазмерАрайЛиста);
            for ( int  i = 0; i < РазмерАрайЛиста; i++) {
                Log.d(this.getClass().getName()," МассивДляВыбораВСпинерДата.get(i) "+МассивДляВыбораВСпинерДата.get(i));
                String ИщемСвойМесяцНулевой=МассивДляВыбораВСпинерДата.get(0);
                String ИщемСвойМесяц=МассивДляВыбораВСпинерДата.get(i);
                if (ИщемСвойМесяц.equalsIgnoreCase(ПравильныйВозвратИзДруговоАктивтиBACK)) {
                    //int ИщемСвойМесяцПорядок=МассивДляВыбораВСпинерДата.indexOf(ИщемСвойМесяц);
                    МассивДляВыбораВСпинерДата.set(0,МассивДляВыбораВСпинерДата.get(i));
                    МассивДляВыбораВСпинерДата.set(i,ИщемСвойМесяцНулевой);
                    //МассивДляВыбораВСпинерДата.remove(i);
                    break;
                }
            }*/
                Log.d(this.getClass().getName()," МассивДляВыбораВСпинерДата.toString() "+МассивДляВыбораВСпинерДата.toString());

                //TODO нормальные режим загрузки ДАты спипернар
            }
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }
    //TODO метод получени месяа для записи в одну колонку




    ////СООБЩЕНИЕ ИЗ ИТОРИИИ ТАБЛЕЙ ОТПРАВЛЯЕМ СООБЩЕНЕИ И ЗНАЧЕНИЕ В ДУГОЕ АКТИВТИ О СОЗДАНИЮ НОВОГО ТАБЕЛЯ






    ////ВТОРАЯ ФУНКЦИЯ  ДАТЫ НА РУСКИЙ ЯЗЫК МЕСЯЦ
    //функция получающая время операции

    public String МетодПереводаНазваниеМесяцаСАнглискогоНаРУсский(Date ПрасингДаты) {
        SimpleDateFormat sdfmt = null;
        SimpleDateFormat sdfmtГод = null;
        String ДатаДляСпинераИМеняемАнглискиеНаРУскиеНазваниеМесяцев;
        String ФинальнаяДатаДЛяОпределенияНовыйЭтоМесяцИлиНЕт;
        sdfmt = new SimpleDateFormat("LLLL", new Locale("ru"));
        ФинальнаяМЕсяцДляНовогоТабеля=sdfmt.format(ПрасингДаты);
        Log.d(this.getClass().getName(),"  ФинальнаяМЕсяцДляНовогоТабеля  "+ ФинальнаяМЕсяцДляНовогоТабеля);

        ///////МЕНЯЕМ АГЛИСКИЕ НА РУСКОЕ НАЗВАНИЕМЕСЯЦА
        ДатаДляСпинераИМеняемАнглискиеНаРУскиеНазваниеМесяцев=sdfmt.format(ПрасингДаты);////ПЕРВОНОЧАЛЬНОЕ ВИД МЕСЯЦ НА АНГЛИСКОМ
        ДатаДляСпинераИМеняемАнглискиеНаРУскиеНазваниеМесяцев= ДатаДляСпинераИМеняемАнглискиеНаРУскиеНазваниеМесяцев;
        Log.d(this.getClass().getName(),"  ДатаДляСпинераИМеняемАнглискиеНаРУскиеНазваниеМесяцев  "+ДатаДляСпинераИМеняемАнглискиеНаРУскиеНазваниеМесяцев);
        ///////Добалявем год
        sdfmtГод = new SimpleDateFormat("yyyy", new Locale("ru"));
        ПолученныйГодДляНовогоТабеля=sdfmtГод.format(ПрасингДаты);
        System.out.println("  операции время :  " + sdfmtГод.format(ПрасингДаты));
        ФинальнаяДатаДЛяОпределенияНовыйЭтоМесяцИлиНЕт=ФинальнаяМЕсяцДляНовогоТабеля+"  "+ПолученныйГодДляНовогоТабеля;
        System.out.println("  ФинальнаяДатаДЛяОпределенияНовыйЭтоМесяцИлиНЕт  " + ФинальнаяДатаДЛяОпределенияНовыйЭтоМесяцИлиНЕт);
////////свич пробегаеться по названиям месяцев и перерделываем их с аглиского на русский
        return  ФинальнаяДатаДЛяОпределенияНовыйЭтоМесяцИлиНЕт;
    }



    //TODO метод получени месяа для записи в одну колонку ОБРАБОТКА ДАТЫ ДЛЯ КУРСОРА НЕ НОВЫЕ ДАННЫЕ А УЖЕ СУЩЕТСВУЮЩИЕ--МЕСЯЦ

    private int  МетодПолучениниеКурсораМЕсяцДата(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        String[] ДелимМЕсяцИгод =ДатаКоторуюНадоПеревестиИзТекставЦифру.split(" ");
        System.out.println( " " + ДелимМЕсяцИгод [0]);
        SimpleDateFormat formatмесяц = new SimpleDateFormat("LLLL  yyyy", new Locale("ru"));
        Date date = formatмесяц.parse(ДатаКоторуюНадоПеревестиИзТекставЦифру.trim());
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        System.out.println(calendar.get(Calendar.YEAR));
        System.out.println(calendar.get(Calendar.MONTH)+1);
        System.out.println(calendar.get(Calendar.DAY_OF_MONTH));
        System.out.println(new SimpleDateFormat("MMMM").format(calendar.getTime()));
        return   calendar.get(Calendar.MONTH)+1;
    }
    //TODO метод получени месяа для записи в одну колонку ОБРАБОТКА ДАТЫ ДЛЯ КУРСОРА НЕ НОВЫЕ ДАННЫЕ А УЖЕ СУЩЕТСВУЮЩИЕ--ГОД
    private int  МетодПолучениниеКурсораГОДДата(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        String[] ДелимМЕсяцИгод =ДатаКоторуюНадоПеревестиИзТекставЦифру.split(" ");
        System.out.println( " " + ДелимМЕсяцИгод [1]);
        SimpleDateFormat formatгод = new SimpleDateFormat("LLLL  yyyy");
        Date date = formatгод.parse(ДатаКоторуюНадоПеревестиИзТекставЦифру.trim());
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        System.out.println(calendar.get(Calendar.YEAR));
        System.out.println(calendar.get(Calendar.MONTH)+1);
        System.out.println(calendar.get(Calendar.DAY_OF_MONTH));
        System.out.println(new SimpleDateFormat("yyyy").format(calendar.getTime()));
        return   calendar.get(Calendar.YEAR);
    }
    //TODO  конец метод получени месяа для записи в одну колонку ОБРАБОТКА ДАТЫ ДЛЯ КУРСОРА НЕ НОВЫЕ ДАННЫЕ А УЖЕ СУЩЕТСВУЮЩИЕ--МЕСЯЦ




    ////МетодПолучение Мак Адреса
    private void МетодПолучениеMAcАдреса() {
        WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = manager.getConnectionInfo();
        PUBLIC_CONTENT.МакАдресТелефона = info.getMacAddress();
        Log.d(this.getClass().getName(), "  МакАдресТелефона " +   PUBLIC_CONTENT.МакАдресТелефона );
    }
    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ


    public String ГлавнаяДатаИВремяДляТабеля() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);
    }

    ///todo сообщение на активти создание новго сотрудника спрашиваем нужно ли создать
    @UiThread
    protected void СообщениеСпрашиваемПользователяЧтоОнТОчноХочетьСоздатьНовыйТабель(String ШабкаДиалога, final String СообщениеДиалога, boolean статус) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
        try{
//////сам вид
            final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                    .setTitle(ШабкаДиалога)
                    .setMessage(СообщениеДиалога)
                    .setPositiveButton("Да", null)
                    .setNegativeButton("Нет", null)
                    .setIcon(R.drawable.icon_dsu1_new_tabel1)
                    .show();
/////////кнопка
            final Button MessageBoxUpdateСоздатьТабель = alertDialog .getButton(AlertDialog.BUTTON_POSITIVE);
            MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog .dismiss();
                    Log.d(this.getClass().getName()," создание нового сотрудника " );


                    ///TODO создание нового ТАБЕЛЯ
                    МетодСозданиеДиалогаКалендаряДаты();////ЗПАСУКАЕМ МЕТОД КОГДА НАДО ВЫБРВТЬ ДАТУ С КАЛЕНДАРКА


                }
            });

/////////кнопка
            final Button MessageBoxUpdateЗАкрытьСозданиеТабеля = alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            MessageBoxUpdateЗАкрытьСозданиеТабеля.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog .dismiss();
///запуск метода обновления через DIALOGBOX
                }
            });
            /////
            //TODO шаблоны



        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }























}