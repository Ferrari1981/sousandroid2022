package com.dsy.dsu;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.annotation.UiThread;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;

import javax.crypto.NoSuchPaddingException;

import static com.dsy.dsu.PUBLIC_CONTENT.ССылкаНаСозданнуюБазу;
import static java.util.Calendar.getInstance;

public class MainActivity_New_Cusomers extends AppCompatActivity implements DatePickerDialog.OnDateSetListener  {
    ////todo переменные для новго сотрдуника при создание на  активтик
    protected Button КнопкаСозданиеНовогоСотрудника;
    protected EditText ЗначениеФИОСозданиеСотрудника, ЗначениеДеньРожденияСозданиеСотрудника, ЗначениеСНИЛССозданиеСотрудника;
    ///todo переменные для табеля
    String НазваниеТабеляВКоторомИНадоСоздатьНовогоСотрудника;
    String UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника;
    String НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника;
    String ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника;
    Configuration config;
    String ПубличноеИМяТабеля;
    String УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель;
    //String ЦифровоеИмяНовгоТабеля;
    String ПолноеИмяТабеляПослеСозданиеНовогоСотрудника;
    String UUIDСтарыйСамогоСозданогоТабелявКоторыйИнужноВставлятьНовгоСотрудника = "";
    String НовоеЗначениеUUIDДляОбновлениеТабеляКоторыйУжеСозданБЫл = "";
    String МесяцТабеляФинал = "";
    String UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя = "";
    String ДепартаментТабеляФинал = "";
    Long UUIDДанныйПришелПослеВЫбораУжеСуществующегоСотрудника;
    protected Button КнопкаНазад;
    int ЦифровоеИмяНовгоТабеля;
    long    Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИОФИНАЛ;
   static  Context КонтекстДляАктивтиСозданиеНовогоСотрудника;

    protected Spinner СпинерВыборОрганизацииПриСозданииНовогоСотрудника;/////спинеры для создание табеля

        String ПолученноеТекущееЗначениеСпинераОрганизация;

    long РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыФИО;

    int Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИО;

    int ГодПриВставкеНовогоСотрудника = 0;

    ////////
    ContentValues АдаптерДляСозданиеНовогоСотрудаТАблицаТабель;////контрейнер для нового табеля

    ContentValues АдаптерДляСозданиеНовогоСотрудаТАблицаФИО;////контрейнер для нового табеля



    int МЕсяцПриВставкеНовогоСотрудника = 0;












    @Override
    protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main_create_new_customers);
        //TODO  ОЧИЩАЕМ ПАМТЬ
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);



        /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);


        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
     //   getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION  );


        getSupportActionBar().hide(); ///скрывать тул бар
        /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext

        КонтекстДляАктивтиСозданиеНовогоСотрудника=this;

        КнопкаСозданиеНовогоСотрудника = findViewById(R.id.КнопкаСозданиеНовогоТабеля);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
        /////
        Log.d(this.getClass().getName(), "   ");
        // Locale locale = Locale.ROOT;
        Locale locale = new Locale("rus");
        Locale.setDefault(locale);
        config =
                getBaseContext().getResources().getConfiguration();
        config.setLocale(locale);
        createConfigurationContext(config);
        ///TODO разное

////TODO ИНИЗАЛИЗАУМЯ ОБЬЕКТОВ НА АКТИВИТИ
        ЗначениеФИОСозданиеСотрудника = findViewById(R.id.ЗначениеЦФОПриСозданииНовогоТабеля);
        ЗначениеДеньРожденияСозданиеСотрудника = findViewById(R.id.ЗначениеДепартаментаПриСоздаенииНовогоТабеля);
        ЗначениеСНИЛССозданиеСотрудника = findViewById(R.id.ЗначениеДатаСоздаваемогоТабеля);
        ЗначениеСНИЛССозданиеСотрудника = findViewById(R.id.ЗначениеДатаСоздаваемогоТабеля);
        //todo кнопка назад
        КнопкаНазад= findViewById(R.id.imageViewСтрелкаНазадНовыйСотрудник);


                СпинерВыборОрганизацииПриСозданииНовогоСотрудника= findViewById(R.id.значениеИзСпинераОрганизацияДляНовогоСотрудника);


        //todo пришили данные из преедедущего активти с названием табеля сСАМО ИМЯ И ЕГО UUID
        МетодПриемКонтентаОтДругихАктивти();



        МетодСозданиеСпинеровОрганизации();



//todo настройки


    }




    private void МетодСозданиеСпинеровОрганизации() {

        try{


            // TODO: 24.03.2021 ЕслиВубличногоНЕтТоНАходим ЕГо
            ArrayList<String> ЛистДляАдаптераСпинерОрганизация = new ArrayList<>();

            Cursor    Курсор_ИщемВсеОрганизации=null;
            try {
                Курсор_ИщемВсеОрганизации =
                        new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("organization",
                                new String[]{"*"}, " name IS NOT NULL", null, null, null, null, null);//
                if(Курсор_ИщемВсеОрганизации.getCount()>0){
                    Курсор_ИщемВсеОрганизации.moveToFirst();

                 ЛистДляАдаптераСпинерОрганизация.add("") ;

                    do{




                        Log.d(this.getClass().getName(), " Курсор_ИщемПУбличныйIDКогдаегоНетВстатике " + Курсор_ИщемВсеОрганизации.getCount());



                        int ПолощениеСамаОрганизация=Курсор_ИщемВсеОрганизации.getColumnIndex("name");

                        String          СамаОрганизация =Курсор_ИщемВсеОрганизации.getString(ПолощениеСамаОрганизация);


                        Log.d(this.getClass().getName(), "  СамаОрганизация" +  СамаОрганизация);



                        ЛистДляАдаптераСпинерОрганизация.add(СамаОрганизация) ;



                    } while (Курсор_ИщемВсеОрганизации.moveToNext());
                    ////







                }

                Курсор_ИщемВсеОрганизации.close();

            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (TimeoutException e) {
                e.printStackTrace();
            }















// Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
        ArrayAdapter<String> АдаптерДляСпинераОрганизация = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_activated_1,
                ЛистДляАдаптераСпинерОрганизация);
        // Определяем разметку для использования при выборе элемента
        АдаптерДляСпинераОрганизация.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        СпинерВыборОрганизацииПриСозданииНовогоСотрудника.setAdapter(АдаптерДляСпинераОрганизация);

        //
        СпинерВыборОрганизацииПриСозданииНовогоСотрудника.setHorizontalScrollBarEnabled(true);
        ////что быврали
        СпинерВыборОрганизацииПриСозданииНовогоСотрудника.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //////СПИНЕР ДЕПАРТАМЕНТ
                if (position>0) {///ставим ограничкния если выбрано не 0 позиция то запонимаеним

                    ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    ((TextView) parent.getChildAt(0)).setTextSize(16);
                    ((TextView) parent.getChildAt(0)).setLines(5);
                    ((TextView) parent.getChildAt(0)).setTypeface(Typeface.DEFAULT_BOLD);
                    ((TextView) parent.getChildAt(0)).setHint("Выберете Организацию");
                    ((TextView) parent.getChildAt(0)).setHintTextColor(Color.parseColor("#675757"));
                    ((TextView) parent.getChildAt(0)).setBackgroundResource(R.drawable.textlines);
                    ((TextView) parent.getChildAt(0)).setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);

                    ПолученноеТекущееЗначениеСпинераОрганизация = parent.getItemAtPosition(position).toString();

                    Log.d(this.getClass().getName(), "ПолученноеТекущееЗначениеСпинераОрганизация " + ПолученноеТекущееЗначениеСпинераОрганизация);
                        /*Toast toast = Toast.makeText(getApplicationContext(),
                                "Ваш выбор Раздел : " + ПолученноеЗначениеИзСпинераРаздел + " " + position, Toast.LENGTH_SHORT);
                        toast.show();*/

                }else if (position==0){
                    ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    ((TextView) parent.getChildAt(0)).setBackgroundResource(R.drawable.textlines);
                    ((TextView) parent.getChildAt(0)).setTextSize(16);
                    ((TextView) parent.getChildAt(0)).setLines(5);
                    ((TextView) parent.getChildAt(0)).setTypeface(Typeface.DEFAULT_BOLD);
                    ((TextView) parent.getChildAt(0)).setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    ((TextView) parent.getChildAt(0)).setHint("Выберете Организацию");
                    ((TextView) parent.getChildAt(0)).setHintTextColor(Color.parseColor("#675757"));
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();

        //////TODO  данный код срабатывает когда произошда ошивка в базе

        if(ССылкаНаСозданнуюБазу.isOpen()){
            if(ССылкаНаСозданнуюБазу.inTransaction()){
                ССылкаНаСозданнуюБазу.endTransaction();
            }
            //ССылкаНаСозданнуюБазу.close();
        }

    }






    @Override
    protected void onPause() {
        super.onPause();
        try {

          ///  МетодЗапускаЛокальнойСинхронизации();
            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }









































    protected void МетодПриемКонтентаОтДругихАктивти() {
        ///////////
        Intent ИнтентПришелДепаартаментТабеля = getIntent();
        ///TODO ИМЯ ТАБЕЛЯ
        НазваниеТабеляВКоторомИНадоСоздатьНовогоСотрудника = ИнтентПришелДепаартаментТабеля.getStringExtra("ДепартаментТабеляФинал");
        Log.d(this.getClass().getName(), " ДепартаментТабеляФинал :  " + НазваниеТабеляВКоторомИНадоСоздатьНовогоСотрудника);
        //TODO UUID ТАБЕЛЯ
        UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника = ИнтентПришелДепаартаментТабеля.getStringExtra("UUIDТабеляФинал");
        Log.d(this.getClass().getName(), " UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника :  " + UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника);
        //TODO имя самого месяца например июль 2020  ТАБЕЛЯ'
        НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника = ИнтентПришелДепаартаментТабеля.getStringExtra("МесяцТабеляФинал");
        Log.d(this.getClass().getName(), " НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника:  " + НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника);
/////////////
//TODO имя ПЕРЕД СОЗЖДАНИЕ НОВОГО СОТРУДНИКА ПЕРЕРДАЕМ ИМЯ ДЕПАРТЕМЕНТА
        ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника = ИнтентПришелДепаартаментТабеля.getStringExtra("ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника");
        Log.d(this.getClass().getName(), " НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника:  " + ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника);
//////
        ПубличноеИМяТабеля = ИнтентПришелДепаартаментТабеля.getStringExtra("СгенерированныйНазваниеНовогоТабеля");
        Log.d(this.getClass().getName(), " ПубличноеИМяТабеля  " + ПубличноеИМяТабеля);


        if( UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника==null){
            UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника= ИнтентПришелДепаартаментТабеля.getStringExtra("UUIDТабеляПослеУспешногоСозданиеСотрудника");
            Log.d(this.getClass().getName(), " UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника :  " + UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника);

        }


        //todo код работает после  подбора уже существующего сотрудника
        if (UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника == null) {
            UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника = UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя;
        }


        if (new MainActivity_New_Tabely().СгенерированныйUUIDДляНовогоТабеля == null) {
            УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель = UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника.trim();

            ////todo когда ТАБЕЛЬ ТОЛЬКО СДЕЛАЛИ ИЗ ПЕРМЕНОЙ ЧИТАЕМ
        } else {
            УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель = new MainActivity_New_Tabely().СгенерированныйUUIDДляНовогоТабеля.trim();
        }

        /////
        ///TODO цифровоеимя табеля
        Intent Интент_ПришлиДанныеДляПосикаУжеСуществующегоСотрудникаДляСозданияТабеля = getIntent();
        if (ЦифровоеИмяНовгоТабеля==0) {
            ЦифровоеИмяНовгоТабеля = Интент_ПришлиДанныеДляПосикаУжеСуществующегоСотрудникаДляСозданияТабеля.getIntExtra("ЦифровоеИмяНовгоТабеля",0);
        }

        if (ПолноеИмяТабеляПослеСозданиеНовогоСотрудника==null) {
            ПолноеИмяТабеляПослеСозданиеНовогоСотрудника= ИнтентПришелДепаартаментТабеля.getStringExtra("ПолноеИмяТабеляПослеСозданиеНовогоСотрудника");
        }


        Log.d(this.getClass().getName(), " ЦифровоеИмяНовгоТабеля :  " + ЦифровоеИмяНовгоТабеля+ " ПолноеИмяТабеляПослеСозданиеНовогоСотрудника " +ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);
    }





    @Override
    protected void onStart() {
        super.onStart();


 Future futureНовыйСотрудник=       Executors.newCachedThreadPool().submit(new Callable<Object>() {
            @Override
            public Object call() {


        try{
            /////
        МетодСозданиеНовогоСотрудникаДляТабелясКнопки();
        /////
        МетодПолучениеДатыРожденияЧерезКалендарь();
        ////
        МетодВозврещениеНаПредыдущуюАктивтиBACK();

////




        ///
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        ///////
    }

        return  null;
            }
        });
        try {
   Object РезультатНовыйСотрудник=         futureНовыйСотрудник.get();
   //
            if(futureНовыйСотрудник.isDone()){
                //
                futureНовыйСотрудник.cancel(false);
            }

        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        /////




    }

///todo метод который возврящаем с текущего активити на предыдущий
///todo метод получение ДАТЫ РОЖДЕНИЯ ИЗ  КАЛЕНЛАРЯ
private void МетодВозврещениеНаПредыдущуюАктивтиBACK() {
    КнопкаНазад.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Log.d(this.getClass().getName(), " кликнем для созданни новго сотрдника при нажатии  ");
            ///todo код которыц возврящет предыдущий актвитики кнопка back
            //TODO ПОСЛЕ УСПЕШНОЙ СОЗДАНИЕ НОВОГО СОТРУДНИКА ПЕРЕХОДИМ В ТАБЕЛЯ

            МетодПослеУспешнгоСозданиеНовгоСотрудникаПереходимВТабеля();
            //////

        }
    });
}





///todo метод получение ДАТЫ РОЖДЕНИЯ ИЗ  КАЛЕНЛАРЯ
    private void МетодПолучениеДатыРожденияЧерезКалендарь() {
        ЗначениеДеньРожденияСозданиеСотрудника.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(this.getClass().getName(), " кликнем для созданни новго сотрдника при нажатии  ");
                МетодВытаскиваемИзКалендаряДиалогаКалендаряДаты();
            }
        });
    }
    ///поймать ошибку
    private void МетодВытаскиваемИзКалендаряДиалогаКалендаряДаты() {///////метод создание календяря даты
/////TODO тут визуализикуеться КАЛЕНДАРЬ
        DatePickerDialog ДатаДляКалендаря=new DatePickerDialog(this, (DatePickerDialog.OnDateSetListener) this,
                GregorianCalendar.getInstance().get(Calendar.YEAR),
                GregorianCalendar.getInstance().get(Calendar.MONTH),
                GregorianCalendar.getInstance().get(Calendar.DAY_OF_MONTH));
        ДатаДляКалендаря.setIcon(R.drawable.icon_dsu1_new_customer7 );
        ДатаДляКалендаря.show();
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        StringBuffer БуферПолученаяДатаРожденияСотрудника=new StringBuffer();
        //todo make offset
        switch (month){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
                month=month+1;
                break;
                /////todo яныварь
            case 0:
                month=month+1;
                break;
        }
//todo выравниваем длину месяца
        String МесяцФинал=String.valueOf(month);
        if (МесяцФинал.length()==1) {
            МесяцФинал = "0" + МесяцФинал;
        }
        ////todo  выравниваем длину день
        String ДеньФинал=String.valueOf(dayOfMonth);
        if (ДеньФинал.length()==1) {
            ДеньФинал = "0" + ДеньФинал;
        }
        БуферПолученаяДатаРожденияСотрудника.append(ДеньФинал).append(".").append(МесяцФинал).append(".").append(year);
        Log.d(this.getClass().getName(), " stringBuffer  "+ БуферПолученаяДатаРожденияСотрудника.toString());
        //TODO ЗАПОЛНЯЕМ
        ЗначениеДеньРожденияСозданиеСотрудника.setText(БуферПолученаяДатаРожденияСотрудника.toString());
    }







    ///todo данный метод начальный для создание нового сотрудника с кнопки
    private void МетодСозданиеНовогоСотрудникаДляТабелясКнопки() {
        try {
            ///TODO НАЧИНАЕМ СОЗДАВАТЬ НОВОГО СОТРУДУНИКА ЕСЛИ ПРИШИЛИ НАЗВАНИЕ ТАБЕЛЯ И ЕГО UUID


            ////todo кнопка по нажатию на которуюи создеться табель

            КнопкаСозданиеНовогоСотрудника.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(this.getClass().getName(), " ЗначениеФИОСозданиеСотрудника  "+ ЗначениеФИОСозданиеСотрудника+
                            " ЗначениеДеньРожденияСозданиеСотрудника  " + ЗначениеДеньРожденияСозданиеСотрудника +
                            " ЗначениеСНИЛССозданиеСотрудника  " +ЗначениеСНИЛССозданиеСотрудника);



                    int ТекущаяПозицияСпинерВыборОрганизацииПриСозданииНовогоСотрудника=СпинерВыборОрганизацииПриСозданииНовогоСотрудника.getSelectedItemPosition();

                    ПолученноеТекущееЗначениеСпинераОрганизация=( СпинерВыборОрганизацииПриСозданииНовогоСотрудника.getItemAtPosition(ТекущаяПозицияСпинерВыборОрганизацииПриСозданииНовогоСотрудника).toString());


                    // TODO: 25.03.2021 создание контеенер для будщем вставки нового струдника сюда 
                    АдаптерДляСозданиеНовогоСотрудаТАблицаТабель = new ContentValues();////контрейнер для нового табеля

              АдаптерДляСозданиеНовогоСотрудаТАблицаФИО = new ContentValues();////контрейнер для нового табеля

                    
                    
                    
                    

/////TODO перед созданием определяем не пустые ли значения
                    if (ЗначениеФИОСозданиеСотрудника.length() > 4
                            && ЗначениеДеньРожденияСозданиеСотрудника.length() > 4
                            && ЗначениеСНИЛССозданиеСотрудника.length() > 10 &&
                            ТекущаяПозицияСпинерВыборОрганизацииПриСозданииНовогоСотрудника!=0 &&
                            СпинерВыборОрганизацииПриСозданииНовогоСотрудника.getItemAtPosition(ТекущаяПозицияСпинерВыборОрганизацииПриСозданииНовогоСотрудника).toString()!=null &&
                            СпинерВыборОрганизацииПриСозданииНовогоСотрудника.getItemAtPosition(ТекущаяПозицияСпинерВыборОрганизацииПриСозданииНовогоСотрудника).toString()!="") {


                        // TODO: 25.03.2021 начинаем заполнятьконтейнеры информацией

                        АдаптерДляСозданиеНовогоСотрудаТАблицаФИО.put("name",ЗначениеФИОСозданиеСотрудника.getText().toString());
                        //
                        АдаптерДляСозданиеНовогоСотрудаТАблицаФИО.put("BirthDate",ЗначениеДеньРожденияСозданиеСотрудника.getText().toString());
                        ///
                        АдаптерДляСозданиеНовогоСотрудаТАблицаФИО.put("snils",ЗначениеСНИЛССозданиеСотрудника.getText().toString());






















                        ////////todo  ВСЕ ПОЛЯ ЗАПОЛЕНЫ НА ААКТИВТИ СОЗДАНИЕ СОТРУДНИКА И ПЕРЕХОДМ НА САМО СОЗДАНИЕ СОТРУДНИКА
                    if (PUBLIC_CONTENT.Отладка==true) {
                            СообщениеКотороеСпрашиваетТочноЛиНужноСоздатьНовогоСотрудника("Новый сотрудник", "Создать нового сотрудника ?", true);
                        } else {

                            try{
                                ///TODO создание нового сотрудника
                                МетодСозданиеНовогоСотрудникаДЛяСуществуещегоТабеля();


                                ///
                            } catch (Exception e) {
                                e.printStackTrace();
                                ///метод запись ошибок в таблицу
                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                            }

                        }


                    } else {




                        Toast aa = Toast.makeText(getApplicationContext(), "OPEN",Toast.LENGTH_SHORT);
                        ImageView cc = new ImageView(getApplicationContext());
                        cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_error);//icon_dsu1_synchronisazia_dsu1_success
                        aa.setView(cc);
                        aa.show();
                        Toast.makeText(getApplicationContext(), "Вы не заполнили ФИО/Дата рождения/СНИЛС/Организацию"
                                +"\n"+" (заполните и повторите попытку).", Toast.LENGTH_SHORT).show();

                    }



                }
            });

            ///поймать ошибку
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(this).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///////
        }
    }


    ///todo сообщение на активти создание новго сотрудника спрашиваем нужно ли создать
    @UiThread
    protected void СообщениеКотороеСпрашиваетТочноЛиНужноСоздатьНовогоСотрудника(String ШабкаДиалога, final String СообщениеДиалога, boolean статус) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
        try {
//////сам вид
            final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                    .setTitle(ШабкаДиалога)
                    .setMessage(СообщениеДиалога)
                    .setPositiveButton("Да", null)
                    .setNegativeButton("Нет", null)
                    .setIcon(R.drawable.icon_dsu1_new_customer7)
                    .show();
/////////кнопка
            final Button MessageBoxUpdateСоздатьТабель = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog.dismiss();
                    Log.d(this.getClass().getName(), " создание нового сотрудника ");

/////TODO ОСНОВНОЙ МЕТОД ЗАПУСКА СОЗДАНИЕ НОВОГО СОТРУДНИКА В ПОТОКЕ
  try{
                    ///TODO создание нового сотрудника
                    МетодСозданиеНовогоСотрудникаДЛяСуществуещегоТабеля();


                    ///
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }
                    ///////////

                }
            });

/////////кнопка
            final Button MessageBoxUpdateЗАкрытьСозданиеТабеля = alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            MessageBoxUpdateЗАкрытьСозданиеТабеля.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog.dismiss();
///запуск метода обновления через DIALOGBOX
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }







    //TODO метод записи нового сотрудника в базу
    private void МетодСозданиеНовогоСотрудникаДЛяСуществуещегоТабеля() throws InterruptedException {


        Log.d(this.getClass().getName(), " МетодСозданиеНовогоСотрудникаДЛяСуществуещегоТабеля() ");


        ExecutorService executorService= Executors.newSingleThreadExecutor();
        ///
        CountDownLatch countDownLatchНовыйСотрудник=new CountDownLatch(1);
    Future futureВставкаНовогоСотрудника= executorService.submit(new Runnable() {
            @Override
            public void run() {



        try {




                ///todo перед СОЗДАНИЕ/ДОБАЛВЕНИМ НОВГО СОТРУДНИКА ОПЕРДЕЛЯЕМ UUID ЧИТАЕМ ЕГО ИЗ ТАБЛИЦЫ НА КОНКТЕРНЫЙ ТЕКУЩИЙ ТАБЕЛЬ ИЛИ ТАБЕЛЬ ТОЛЬКО СДЕЛАЛИ И UUID СЧИТЫВАЕМ С ПЕРЕМЕННОЙ
                ///todo ДАННОЕ ЗНАЧЕНИЕ НУЖНО УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель ТОЛЬКО ДЛЯ ОБНОЛВЕНИЕ ЗАПИСИ ЧТОБЫ ПОНЯТЬ В UPDATE КАКУЮ СТОРЧКУ ОБНОВЕЯТЬ
                long UUIDTabelзначениеСамогоПустогоТабеляБезСотрудников = 0;
                /////TODO ТАБЕЛЬ УЖЕ СУЩЕСТВАОЛАЛ И МЫ ЧИТАЕМ UUID  ТАБЕЛЯ ИЗ БАЗЫ

                //todo  из текста в цифру UUID ---ВНИМАНИЕ ЭТО СТАРЫЙ UUID СУЩЕСТВУЮЩЕГО ТАБЕЛЯ

                UUIDTabelзначениеСамогоПустогоТабеляБезСотрудников = Long.parseLong(УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель);

                Log.d(this.getClass().getName(), "  УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель " + УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель
                        + " new MainActivity_New_Tabely().СгенерированныйUUIDДляНовогоТабеля   "  + UUIDTabelзначениеСамогоПустогоТабеляБезСотрудников);


/////TODO ГЕНЕРИРУЕМ НОВЫЙ UUID ДЛЯ ТАБЕЛЯ ПРИ СОЗДАНИИ НОВОГО СОТРУДНИКА ТУТ НОВЫЙ UUID ТОЛЬКО СОЗДАННЫЙ

                /////
                UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника = String.valueOf(МетодГенерацииUUID());

                Log.d(this.getClass().getName(), " UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника    " + UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника);


            АдаптерДляСозданиеНовогоСотрудаТАблицаФИО.put("uuid",UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника);

            Log.d(this.getClass().getName(), " UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника " + UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника);





            // TODO: 25.03.2021 вписываем сгенерированный UUID для таблицы ФИО в таблицу Табеля

            АдаптерДляСозданиеНовогоСотрудаТАблицаТабель.put("fio",UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника);






            ////


/////TODO ГЕНЕРИРУЕМ НОВЫЙ UUID ДЛЯ ТАБЕЛЯ ПРИ СОЗДАНИИ НОВОГО СОТРУДНИКА
            /////
            UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника = String.valueOf(МетодГенерацииUUID());

            АдаптерДляСозданиеНовогоСотрудаТАблицаТабель.put("uuid",UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника);



            Log.d(this.getClass().getName(), " UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника " + UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника);



            String ДатаПРиСозданииНовогоСотрудника=null;


             ДатаПРиСозданииНовогоСотрудника = ГлавнаяДатаИВремяДляТабеля();

                Log.d(this.getClass().getName(), " ДатаПРиСозданииНовогоСотрудника" + ДатаПРиСозданииНовогоСотрудника);

            АдаптерДляСозданиеНовогоСотрудаТАблицаФИО.put("date_update",ДатаПРиСозданииНовогоСотрудника);




         ДатаПРиСозданииНовогоСотрудника = ГлавнаяДатаИВремяДляТабеля();

            Log.d(this.getClass().getName(), " ДатаПРиСозданииНовогоСотрудника" + ДатаПРиСозданииНовогоСотрудника);


            АдаптерДляСозданиеНовогоСотрудаТАблицаТабель.put("date_update",ДатаПРиСозданииНовогоСотрудника);


















                ////todo месяц и год нового сотрудника
          МЕсяцПриВставкеНовогоСотрудника = 0;
            try {
                МЕсяцПриВставкеНовогоСотрудника = МетодПолучениниеМесяцПриСозданииНовогоСОтрудника(НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника);
            } catch (ParseException parseException) {
                parseException.printStackTrace();
            }


            Log.d(this.getClass().getName(), " МЕсяцПриВставкеНовогоСотрудника" + МЕсяцПриВставкеНовогоСотрудника);


            АдаптерДляСозданиеНовогоСотрудаТАблицаТабель.put("month_tabels",МЕсяцПриВставкеНовогоСотрудника);




            ////////
     ГодПриВставкеНовогоСотрудника = 0;
            try {
                ГодПриВставкеНовогоСотрудника = МетодПолучениниеГОдПриСозданииНовогоСОтрудника(НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника);
            } catch (ParseException parseException) {
                parseException.printStackTrace();
            }





            Log.d(this.getClass().getName(), " ГодПриВставкеНовогоСотрудника" + ГодПриВставкеНовогоСотрудника);


            АдаптерДляСозданиеНовогоСотрудаТАблицаТабель.put("year_tabels",ГодПриВставкеНовогоСотрудника);














                    if (ЦифровоеИмяНовгоТабеля>0) {

                        АдаптерДляСозданиеНовогоСотрудаТАблицаТабель.put("cfo",ЦифровоеИмяНовгоТабеля);







                    // TODO: 25.03.2021 текущая оргниазция дтя аьдицы ФИО








                    АдаптерДляСозданиеНовогоСотрудаТАблицаФИО.put("current_organization","1");


                    // TODO: 25.03.2021 заполяем  user_update



                    // TODO: 24.03.2021 ЕслиВубличногоНЕтТоНАходим ЕГо
                    final int[] ПолученныйID = {0};


                    Cursor Курсор_ИщемПУбличныйIDКогдаегоНетВстатике = null;
                    try {
                        Курсор_ИщемПУбличныйIDКогдаегоНетВстатике =
                                new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("SuccessLogin",
                                        new String[]{"id"}, " id IS NOT NULL", null, null, null, null, null);//
                        if (Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount() > 0) {
                            Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.moveToFirst();
                            ////
                            Log.d(this.getClass().getName(), " Курсор_ИщемПУбличныйIDКогдаегоНетВстатике " + Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount());

                            ПолученныйID[0] = Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getInt(0);


                        }


                        Log.d(this.getClass().getName(), "   ПолученныйID[0] " + ПолученныйID[0]);
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (TimeoutException e) {
                        e.printStackTrace();
                    }


                    PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID = String.valueOf(ПолученныйID[0]);


                    Log.d(this.getClass().getName(), "  PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID" + PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID);


                    if (ПолученныйID[0] > 0) {
                        АдаптерДляСозданиеНовогоСотрудаТАблицаФИО.put("user_update", ПолученныйID[0]);

                        АдаптерДляСозданиеНовогоСотрудаТАблицаТабель .put("user_update", ПолученныйID[0]);


                    }





///////TODO САМ ВЫЗОВ МЕТОДА ОБНОВЛЕНИЕ ЛОКАЛЬНОГО-------СКОПИРОВАН КОД ИЗ УДАЕННОГО МЕТОДА








                    // TODO: 25.03.2021 получеам текущую организацию
                    // TODO: 24.03.2021 ЕслиВубличногоНЕтТоНАходим ЕГо
                    final int[] ТекущуюОрганизацию = {0};


                    final Cursor[] Курсор_ИщемТекущуюОрганизациюКоторуюВыбраСОтрудник = {null};








                    АдаптерДляСозданиеНовогоСотрудаТАблицаТабель .put("status_send",  " " );






                    Log.d(this.getClass().getName(),"ТекущуюОрганизацию[0] " + ТекущуюОрганизацию[0] );
















                    //// TODO КОНЕЦ СамаВставка нового сотрудника в новый табель
                }else{
                    Log.e(this.getClass().getName(), " нет данных из предцдуещго табеля");
                }



//TODO ОКОНЧИАЕМ ВСТАВКУ ДАННЫХ


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


            }



    });
        ///
        try {
            countDownLatchНовыйСотрудник.countDown();
            //////
            futureВставкаНовогоСотрудника.get();
            ////
            countDownLatchНовыйСотрудник.await();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        if (       futureВставкаНовогоСотрудника.isDone()) {

            executorService.shutdown();
            futureВставкаНовогоСотрудника.cancel(false);


            МетодПослеЗаполненияКотейнеровНепосредвственнаСамаывставкаНовогоСотрудникавТабель();



            // TODO: 25.03.2021 код после вставки

            if (     Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИОФИНАЛ > 0) {
                Log.d(this.getClass().getName(), " успешная вставка новго сотрудника " + РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыФИО);
                PUBLIC_CONTENT.КоличествоУспешныхВставки++;

                ///TODO ЕСЛИ УСЕШНО ВСТАВЛА ТАДЛИЦА ФИО ТО НАЧИТАЕМ ОБРАБОАТЫВАТЬ ТАЮЛИЦУ ТАБЕЛЬ




                ////todo после успешной встаки новго сотрудкниа и обнуляем общий с ним и uuid  табеля по которому они оба связанны
                //new MainActivity_New_Tabely().СгенерированныйUUIDДляНовогоТабеля = new String();
                //////Удаляем из памяти Асинтаск
                ///TODO сообщаем ЧТО НОВЫЙ СОТРУДНИК УСПЕШНО СОЩДАН
                ((Activity) КонтекстДляАктивтиСозданиеНовогоСотрудника).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast aa = Toast.makeText(КонтекстДляАктивтиСозданиеНовогоСотрудника, "OPEN", Toast.LENGTH_SHORT);
                        ImageView cc = new ImageView(КонтекстДляАктивтиСозданиеНовогоСотрудника);
                        //  cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_success);//icon_dsu1_synchronisazia_dsu1_success
                        aa.setView(cc);
                        aa.show();


                        ///TODO сообщаем об успешном создаении данных
                        if (PUBLIC_CONTENT.Отладка == true) {
                            СообщениеСообщаетОСоздаенииНовогоСотрудника("Табель", "Успешное создание нового сотрудника (помещены в текущий Табель :)" +
                                    ЗначениеФИОСозданиеСотрудника.getText().toString(), true);
                        } else {

                            PUBLIC_CONTENT.КоличествоУспешныхОбновлений = 0;
                            ///////
                            PUBLIC_CONTENT.КоличествоУспешныхВставки = 0;


                            //todo обнуляем ПОСЛЕ ВСТАВКИ НОВГО СОТРУДНИКА

                            ЗначениеФИОСозданиеСотрудника = null;
                            ЗначениеДеньРожденияСозданиеСотрудника = null;
                            ЗначениеСНИЛССозданиеСотрудника = null;








///TODO метод запуска формы после вставки
                            //TODO ПОСЛЕ УСПЕШНОЙ СОЗДАНИЕ НОВОГО СОТРУДНИКА ПЕРЕХОДИМ В ТАБЕЛЯ

                            МетодПослеУспешнгоСозданиеНовгоСотрудникаПереходимВТабеля();
                            //////

                        }


                    }
                });






                ///////////////////////////todo не был создан сотрудник за за ТОГО ЧТО НЕ БЫЛА ВИБРАНА ОРГАНИЗЦИЯ В НАСТРОЙКАХ
            } else {


                ///TODO сообщаем ЧТО НОВЫЙ СОТРУДНИК НЕ БЫЛ СОЗДАН
                ((Activity)КонтекстДляАктивтиСозданиеНовогоСотрудника).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast aa = Toast.makeText(getApplicationContext(), "OPEN", Toast.LENGTH_SHORT);
                        ImageView cc = new ImageView(getApplicationContext());
                        cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_error);//icon_dsu1_synchronisazia_dsu1_success
                        aa.setView(cc);
                        aa.show();

                        СообщениеСообщаетОСоздаенииНовогоСотрудника("Табель", "Не был создан сотрудник (ошибка)", false);

                    }

                });


            }



        }
        ////////

        //////

        //////////



    }

























    // TODO: 26.03.2021 финальная вствка данных новго сотружника

    protected void МетодПослеЗаполненияКотейнеровНепосредвственнаСамаывставкаНовогоСотрудникавТабель() {


        try{

ReentrantLock reentrantLockвставкановгосотрудника=new ReentrantLock();
        ///TODO  КОНЕЦ сами данные таблица FIO только при вставке данных и ТОЛЬКО

        ///todo САМА ВСТВКА ТАБЛИЦА ФИО
        long      РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыФИО = 0;
        try {

            reentrantLockвставкановгосотрудника.lockInterruptibly();
            //
            reentrantLockвставкановгосотрудника.newCondition().await(100,TimeUnit.MILLISECONDS);

            // TODO: 25.03.2021 вставка фио
            РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыФИО = new MODEL_synchronized(getApplicationContext()).
                    ВставкаДанныхЧерезКонтейнерТолькоПриСозданииНовогоСотрудникаУниверсальная("fio",
                            АдаптерДляСозданиеНовогоСотрудаТАблицаФИО, "fio", "", true);




        } catch (ExecutionException executionException) {
            executionException.printStackTrace();
        } catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        } catch (TimeoutException timeoutException) {
            timeoutException.printStackTrace();

        }

        // TODO: 25.03.2021 успешное вставка в таблицу ФИО




            // TODO: 22.04.2021  srart JOBschedele
            Log.d(this.getClass().getName(), "РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыФИО "+РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыФИО);


        if (РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыФИО>0) {
            ///////
            //todo ВО ВРЕМЯ СИНХРОНИЗХАЦИИ В ФОНЕ ИЗМЕНЯЕМ ДАТЫ ТАБЛИЦ ТОЛЬКО ПО ТАБЛИЦАМ КОГДА ИДЕМ
            long   Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИО = 0;
            try {
                Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИО = new MODEL_synchronized(getApplicationContext()).
                        МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных("fio", new Date());
            } catch (ExecutionException executionException) {
                executionException.printStackTrace();
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }

            //////////////////////////////////
            Log.d(this.getClass().getName(), "Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИО  " + Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИО);


            // TODO: 25.03.2021 вставка таблицы ТАБЕЛЬ ПОСЛЕ ТАБЛИЦЫ ФИО































            ///todo САМА ВСТВКА ТАБЛИЦА ФИО
            long      РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыТабель= 0;
            try {


                // TODO: 25.03.2021 вставка табель
                РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыТабель = new MODEL_synchronized(getApplicationContext()).
                        ВставкаДанныхЧерезКонтейнерТолькоПриСозданииНовогоСотрудникаУниверсальная("tabels",
                                АдаптерДляСозданиеНовогоСотрудаТАблицаТабель, "tabels", "", true);
            } catch (ExecutionException executionException) {
                executionException.printStackTrace();
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            } catch (TimeoutException timeoutException) {
                timeoutException.printStackTrace();

            }


            // TODO: 22.04.2021  srart JOBschedele
            Log.d(this.getClass().getName(), "РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыТабель "+РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыТабель);




            if (РезультатВставкиНовогоТабеляЧерезКонтрейнерТаблицыТабель>0) {
                //todo ВО ВРЕМЯ СИНХРОНИЗХАЦИИ В ФОНЕ ИЗМЕНЯЕМ ДАТЫ ТАБЛИЦ ТОЛЬКО ПО ТАБЛИЦАМ КОГДА ИДЕМ
                long   Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыТабель = 0;
                ////
                Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИОФИНАЛ=0;
                try {
                    Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИОФИНАЛ = new MODEL_synchronized(getApplicationContext()).
                            МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных("tabels", new Date());
                } catch (ExecutionException executionException) {
                    executionException.printStackTrace();
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
            }




        }


        АдаптерДляСозданиеНовогоСотрудаТАблицаТабель.clear();

        АдаптерДляСозданиеНовогоСотрудаТАблицаФИО.clear();










            // TODO: 24.05.2021 ТРЕТИЙ КОД ЕСЛИ ПОЛЬЗОВАТЕЛЬ ЗАХОДТЕ АВТОМАТИЧЕСКОЙ УСВТУКУ В ВЫХОДЫНЕ ДНИ

            // TODO: 24.05.2021 КОД ДЛЯ АВТОМАТИЧЕСКОГО ВЫСТАВЛЕНИЯ ВЫХОДНЫХ ДНЕЙ В ТАБЕЛЬ
            String РезультатКакойРежимЗаписанвБазеВЫходныеДни =  new MODEL_synchronized(getApplicationContext()).
                    МетодПолучениеЗначенияРежимаРаботыИнтернетаWifiИлиInternet(getApplicationContext() ,"SuccessLogin","mode_weekend");

            Log.d(this.getClass().getName()," РезультатКакойРежимЗаписанвБазеВЫходныеДни " + РезультатКакойРежимЗаписанвБазеВЫходныеДни);



            // TODO: 24.05.2021 КОД ДЛЯ АВТОМАТИЧЕСКОГО ВЫСТАВЛЕНИЯ ВЫХОДНЫХ ДНЕЙ В ТАБЕЛЬ

            if (РезультатКакойРежимЗаписанвБазеВЫходныеДни.contentEquals("Включить")) {
                ////
                // TODO: 24.05.2021 вычисляем дни
                ContentValues КонтрейнерДляВставкиВВыходныеДниМЕткиВыходные=             new MODEL_synchronized(getApplicationContext()). МетодВычисляемВыходныеДниПриСозданииНовогоТабеляАвтоРЕжим(getApplicationContext(),
                        ГодПриВставкеНовогоСотрудника,МЕсяцПриВставкеНовогоСотрудника);


                // TODO: 24.05.2021 сама вставка  выходних дней




                ///todo САМА ВСТВКА ТАБЛИЦА ФИО
                long      РезультатВставкиВЫходнихДнейЧерезКонтрейнерТаблицыТабель= 0;
                try {


                    // TODO: 25.03.2021 вставка табель
                    РезультатВставкиВЫходнихДнейЧерезКонтрейнерТаблицыТабель  = new MODEL_synchronized(getApplicationContext()).ЛокальногоОбновлениеДанныхЧерезКонтейнерУниверсальная("tabels",
                            КонтрейнерДляВставкиВВыходныеДниМЕткиВыходные,
                            UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника,
                          "uuid");

                    //////
                } catch (ExecutionException executionException) {
                    executionException.printStackTrace();
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }


                if (РезультатВставкиВЫходнихДнейЧерезКонтрейнерТаблицыТабель>0) {
                    //todo ВО ВРЕМЯ СИНХРОНИЗХАЦИИ В ФОНЕ ИЗМЕНЯЕМ ДАТЫ ТАБЛИЦ ТОЛЬКО ПО ТАБЛИЦАМ КОГДА ИДЕМ
                    long   Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыТабель = 0;
                    ////
                    Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИОФИНАЛ=0;
                    try {
                        Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИОФИНАЛ = new MODEL_synchronized(getApplicationContext()).
                                МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных("tabels", new Date());
                    } catch (ExecutionException executionException) {
                        executionException.printStackTrace();
                    } catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }finally {
                        reentrantLockвставкановгосотрудника.unlock();
                    }
                }


                // TODO: 22.04.2021  srart JOBschedele
                Log.d(this.getClass().getName(), "Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИОФИНАЛ "+Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицыФИОФИНАЛ);



                КонтрейнерДляВставкиВВыходныеДниМЕткиВыходные.clear();

                UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника=null;


            }






















        } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }


























/////TODO ДАННЫЙ МЕТОД ОПРЕДЕЛЯЕТ ЧТОБЫ МЫ БУДЕМ ДЕЛАТЬ ВСТАВЛЯТЬ НОВОГО СОТРУДНИКА КАК НОВОГО ИЛИ В БАЗЕ УЖЕ ЕСТЬ ХОТЬ ОДНА ЗАПИСЬ И ЭТО БУДЕТ НЕ ПЕРВЫЙ СОТРУДНИКА В ДАННОМ ТАБЕЛЕ


    private String МетодКоторыйОпределетЧТоБУдемДелатьОбновлятьИлиВставлятьНовгСОтрудника()
            throws ExecutionException, InterruptedException, TimeoutException {
        Cursor Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем=null;

         Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем =
                МетодПроверяетПустойЛиТабельПервыйЗапускТабеляЧтоДелатьОбновлятьИлиВставлять();

        if (Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем.getCount() > 0) { //TODO ЕСЛИ ДАННЫЙ UUID НЕ ПУСТОЙ ЭТО ЗНАЧИТ ЧТО ЭТОТ ТАБЕЛЬ УЖЕ СУЩЕТСВЕТ И НАМ НАДО ОБНОВИТЬ
            ////TODO ТАБЕЛЬ УЖЕ ЕСТЬ И МЫ ЕГО ОБНОЫЛЕНИЯ ПубличноеИмяНовогоТабеля
            Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем.moveToFirst();
            Log.d(this.getClass().getName(), " Курсор_ПонятьМыВставляемВПУстойТабельСотрудникаИЛиОбновлеемЕго.getString(1) " +
                    Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем.getString(0));
            НовоеЗначениеUUIDДляОбновлениеТабеляКоторыйУжеСозданБЫл =
                    Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем.getString(0);
            ////TODO ИЩЕМ СТРАЙ UUID САМОГО ТАБЕЛЯ КОТОРЫЙ УЖЕ СОЗДАН
            //todo close cursor
            Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем.close();
        }
        return НовоеЗначениеUUIDДляОбновлениеТабеляКоторыйУжеСозданБЫл;
    }












    @NotNull
    private Cursor МетодПроверяетПустойЛиТабельПервыйЗапускТабеляЧтоДелатьОбновлятьИлиВставлять() throws ExecutionException, InterruptedException, TimeoutException {
        //todo табель еще есть м ыв уже сущетсвещющеуй табель не всталяем  а обнолвяем
////TODO КУРСОР ПРОВЕЯЕТ ПЕРВЫЙ ЭТО ЗАПУСК ИЛИ НЕТ
        Cursor Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем =
                new MODEL_synchronized(this).КурсорУниверсальныйДляБазыДанных("tabels",
                        new String[]{"fio"}, "uuid=?", new String[]{УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель}, null, null, null, null);//"SuccessLogin", "date_update","id=","1",null,null,null,null
        ///TODO УДАЛЕМ ПАМЯТЬ
       
//todo определяем есть uuid в строчке или нет
        Log.d(this.getClass().getName(), "Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем " +
                Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем.getCount());
        /////s
        return Курсор_КоторыйПроверяетЭтоПустаяЯчейкаUUIDЕслиПустоеНоЭтоНовыйТабельБезСотрудниковиМыНеВставляемАОбновлем;
    }




    ////////todo































    //TODO ПОСЛЕ УСПЕШНОЙ СОЗДАНИЕ НОВОГО СОТРУДНИКА ВОЗВРАЩАЕМСЯ ОБРАТНО В ТАБЕЛЬ КУДА ДОБАВЛЯЛИ СОТРУЛНИКА


    private void МетодПослеУспешнгоСозданиеНовгоСотрудникаПереходимВТабеля() {
        try{

  TimeUnit.MILLISECONDS.sleep(200);

        Intent ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника = new Intent();
            //   Интент_ПослеПодбораДействуещегоСотрудникаОтпраляемЕгоДляВставки.putExtra("UUIDТабеляПослеПодбораУниверсальный", UUIDТабеляФинал);
            //todo запускаем активти после успешно создданого сотрудка
            ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.setClass(this, MainActivity_Employees_Tabely.class); // ТУТ ЗАПВСКАЕТЬСЯ ВЫБОР ПРИЛОЖЕНИЯ КОТОРЫЕ ЕСТЬ FACE APP НА ДАННЫЙ МОМЕТНТ РАЗРАБОТНАО ТАБЕЛЬНЫЙ УЧЁТ
            //////

        ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("НазваниеТабеляВКоторомИНадоСоздатьНовогоСотрудника",   ПолноеИмяТабеляПослеСозданиеНовогоСотрудника );
            ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("ПолноеИмяТабеляПослеСозданиеНовогоСотрудника",   ПолноеИмяТабеляПослеСозданиеНовогоСотрудника );
        ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника", УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель);
        ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника", НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника);
        ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника",  ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);
        ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель",
                УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель);
        ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("UUIDТабеляПослеПодбораУниверсальный",
                УниверсальныйUUIDДляСОзданиеНовогоСотрудникаНаКонкретныйТабель);
        ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("UUIDТабеляКнопкаBACKУниверсальный",
                UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника);
        ///todo ПОЛНОЕ ИМЯ ТАБЕЛЯ
        ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("ПолноеИмяТабеляПослеСозданиеНовогоСотрудника", ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);


            ///TODO цифровоеимя табеля
            ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.putExtra("ЦифровоеИмяНовгоТабеля", ЦифровоеИмяНовгоТабеля);





            ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);


        startActivity(ИнтентФиналПослеУспешногоСозданиеНовгоСотрудника);
        ////
  // finish();


    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }





    ///todo сообщение на активти создание новго сотрудника спрашиваем нужно ли создать
    @UiThread
    protected void СообщениеСообщаетОСоздаенииНовогоСотрудника(String ШабкаДиалога, final String СообщениеДиалога, boolean статус) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
        int ФлагЗнака;
        if (статус) {
            ФлагЗнака = R.drawable.icon_dsu1_new_customer_success;
        } else {
            ФлагЗнака = R.drawable.icon_dsu1_new_customer_error;
        }

        try {
//////сам вид
            final AlertDialog alertDialog = new MaterialAlertDialogBuilder(КонтекстДляАктивтиСозданиеНовогоСотрудника)
                    .setTitle(ШабкаДиалога)
                    .setMessage(СообщениеДиалога)
                    .setPositiveButton("ОК", null)
                    .setIcon(ФлагЗнака)
                    .show();
/////////кнопка
            final Button MessageBoxUpdateСоздатьТабель = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog.dismiss();
                    Log.d(this.getClass().getName(), "  ФИНАЛ создание нового сотрудника ");

                    if (статус) {
                        ///todo после как мы либо создали новогосо остружника или обновли его в табел то обнуляем
                        PUBLIC_CONTENT.КоличествоУспешныхОбновлений = 0;
                        ///////
                        PUBLIC_CONTENT.  КоличествоУспешныхВставки = 0;


                        //todo обнуляем ПОСЛЕ ВСТАВКИ НОВГО СОТРУДНИКА

                        ЗначениеФИОСозданиеСотрудника=null;
                        ЗначениеДеньРожденияСозданиеСотрудника=null;
                        ЗначениеСНИЛССозданиеСотрудника=null;

///TODO метод запуска формы после вставки
                        //TODO ПОСЛЕ УСПЕШНОЙ СОЗДАНИЕ НОВОГО СОТРУДНИКА ПЕРЕХОДИМ В ТАБЕЛЯ

                        МетодПослеУспешнгоСозданиеНовгоСотрудникаПереходимВТабеля();
                        //////


                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }


    /////////todo проверика подключение к wi fi
    ///////// TODO ПРОВЕРЯЕТ ЕСЛИ ПОДКЛЧБЕНИ В ИНТРЕНТУ
    protected boolean УниверсальнайМетодПроверкиПодключениекWIFI() throws ExecutionException, InterruptedException {
        Context context=this;
        AsyncTask AsyncTaskУнивермальныйДляОбмена = new AsyncTask() {
            boolean РезультатПрозвонаСокетом = false;

            @Override
            protected Object doInBackground(Object[] objects) {
                System.out.println("УниверсальнайМетодПроверкиПодключениекWIFI ");
                try {
                    /////todo код ping ip
                    //  InetAddress addr=null;
                    // addr= InetAddress.getByName("www.google.com");
                    //Log.d(MODEL_synchronized.class.getName() ," addr.getHostAddress() "+  addr.getHostAddress());
                    //   if (addr.getHostAddress().length()>0){
                    //   }

                    ///todo вьторой вариант прозвона

                    /////todo код ping ip второйвариант
                    /////todo код ping ip второйвариант
                    try {

                        Socket socket = new Socket();
                        SocketAddress socketAddress = new InetSocketAddress("80.66.149.58", 8888); //"http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet"; //"216.58.212.131"
                        socket.connect(socketAddress, 500);
                        РезультатПрозвонаСокетом = true;
                        PUBLIC_CONTENT.ПубличныйАдресGlassFish = "http://80.66.149.58:8888/"; //http://80.66.149.58:8888 //8181 ///РЕЖИМ НАСТОЯЩИЕ РАБОТЫ ПРИЛОЖЕНИЯ
                        Log.d(MODEL_synchronized.class.getName()," PUBLIC_CONTENT.ПубличныйАдресGlassFish " + PUBLIC_CONTENT.ПубличныйАдресGlassFish);
                        ///TODO определяем какой вид подкобченеи mobile and wifi

                    }catch (IOException e){
                        РезультатПрозвонаСокетом = false;
                        ////TODO ВТОРАЯ ПРОВЕРКА
                       try {
                            if(РезультатПрозвонаСокетом == false) {
                                HttpURLConnection ПодключениеИнтернетДляОтправкиНаСервер=null;

                                /////
                                String    Adress_String="http://192.168.254.63:8081/dsu1.glassfish/DSU1JsonServlet";
                                ///
                                Adress_String = Adress_String.replace(" ", "%20");


                                URL Adress = null;
                                Adress = new URL(Adress_String);

                                ПодключениеИнтернетДляОтправкиНаСервер = (HttpURLConnection) (Adress).openConnection();/////САМ ФАЙЛ JSON C ДАННЫМИ
                                ПодключениеИнтернетДляОтправкиНаСервер.setReadTimeout(15000); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ(1000);
                                ПодключениеИнтернетДляОтправкиНаСервер.setConnectTimeout(1000);//todo САМ ПОТОК ДАННЫХ(1000);
                                ПодключениеИнтернетДляОтправкиНаСервер.setUseCaches(true);


                                ПодключениеИнтернетДляОтправкиНаСервер.connect();
                                РезультатПрозвонаСокетом = true;


                               /* Socket socket = new Socket();
                                SocketAddress socketAddress = new InetSocketAddress("192.168.254.63", 8080);
                                socket.connect(socketAddress, 500);
                                РезультатПрозвонаСокетом = true;*/
                                PUBLIC_CONTENT.ПубличныйАдресGlassFish = "http://192.168.254.63:8081/";//PUBLIC_CONTENT.ПубличныйАдресGlassFish = "http://192.168.254.63:8080/"; //http://80.66.149.58:8888 //8181 ///РЕЖИМ НАСТОЯЩИЕ РАБОТЫ ПРИЛОЖЕНИЯ
                                Log.d(MODEL_synchronized.class.getName(), " PUBLIC_CONTENT.ПубличныйАдресGlassFish " + PUBLIC_CONTENT.ПубличныйАдресGlassFish);
                                ///TODO определяем какой вид подкобченеи mobile and wifi
                                //МетодОпределяемКакойТипПодключение();
                            }
                        }catch (IOException ex) {
                            РезультатПрозвонаСокетом = false;
                            ///////todo вторая проверка
                        }
                    }



                } catch (Exception e) {///////ошибки
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                          new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }
                return РезультатПрозвонаСокетом;

            }

            //todo метод опреденлеине какой ти плдкоючени я wifi and mobile
            private boolean МетодОпределяемКакойТипПодключение() {

                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                if (wifiInfo != null && wifiInfo.isConnected()) {
                    Log.e(MODEL_synchronized.class.getName(), " подключние к интренту через wifi");
                    return true;
                }
                wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                if (wifiInfo != null && wifiInfo.isConnected()) {
                    Log.e(MODEL_synchronized.class.getName(), " подключние к интренту через mobile");
                    return true;
                }
                wifiInfo = cm.getActiveNetworkInfo();
                if (wifiInfo != null && wifiInfo.isConnected()) {
                    Log.e(MODEL_synchronized.class.getName(), " подключние к интренту через " + wifiInfo.getTypeName());
                    return true;
                }
                return false;
            }

            protected void onCancelled() {
                super.onCancelled();
                // Log.d(this.getClass().getName(), " Принудительный Выход из AsyTask --Вставка Ошибки" );
            }
        };
        AsyncTaskУнивермальныйДляОбмена.execute();
        return (boolean) AsyncTaskУнивермальныйДляОбмена.get();
    }



    // TODO ГЕНЕРАЦИЯ UUID ВВИДЕ ЦИФРЫ
    public String МетодГенерацииUUID() {
        String UUID = "";
        try {
            // TODO ГЕНЕРАЦИЯ UUID ВВИДЕ ЦИФРЫ
            //"yyyyMMddHHmmssSSS" //"EEEEE MMMMM yyyy HH:mm:ss.SSSSSSZ"
            Date Дата = getInstance().getTime();
           // DateFormat dateFormat = new SimpleDateFormat("yyyyddMMHHmmssSS", new Locale("ru"));
            DateFormat dateFormat = new SimpleDateFormat("yyddMMHHmmssS", new Locale("ru"));
            //dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
            dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
            String СгенерированоДатаДляUUIDШагПервый=dateFormat.format(Дата);
            Long СгенерированоДатаВТипеLong=Long.parseLong(СгенерированоДатаДляUUIDШагПервый);
            //todo гененируем если есть публичный id
            if (PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID!=null) {
                UUID = PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID + СгенерированоДатаВТипеLong;// Integer.parseInt(UUIDФинал.trim());
                Log.i(this.getClass().getName(), " UUID " + UUID);
            }
            //todo обнуляем
            СгенерированоДатаВТипеLong=null;
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return UUID;
    }
    //TODO метод получени месяа для записи в одну колонку

    private int МетодПолучениниеМесяцПриСозданииНовогоСОтрудника(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println(" " + ДатаКоторуюНадоПеревестиИзТекставЦифру + " " + ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatмесяц = new SimpleDateFormat("LLLL  yyyy", new Locale("ru"));
       // formatмесяц.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
        formatмесяц.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Date date = formatмесяц.parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = getInstance(new Locale("ru"));
        calendar.setTime(date);
        Calendar calendar2 = new GregorianCalendar();
        calendar.setTime(date);
        int month = 0;
        if (ДатаКоторуюНадоПеревестиИзТекставЦифру.matches("(.*)Январь(.*)")) {
            month = calendar.get(Calendar.MONTH) +1;
        } else
            month = calendar.get(Calendar.MONTH) + 1;
        return month;
    }

    //TODO метод получени месяа для записи в одну колонку

    private int МетодПолучениниеГОдПриСозданииНовогоСОтрудника(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println("ДатаКоторуюНадоПеревестиИзТекставЦифру " + ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatгод = new SimpleDateFormat("LLLL  yyyy", new Locale("ru"));
       // formatгод.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
        formatгод.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Date date = formatгод.parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = getInstance(new Locale("ru"));
        calendar.setTime(date);
        int year= 0;
        if (ДатаКоторуюНадоПеревестиИзТекставЦифру.matches("(.*)Январь(.*)")) {
            year = calendar.get(Calendar.YEAR);
        } else
            year = calendar.get(Calendar.YEAR);
        return year;
    }
    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
    public String ГлавнаяДатаИВремяОперацийСБазойДанных() {
        Date Дата = getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        //dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);
    }
    public String ГлавнаяДатаИВремяДляТабеля() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
       // dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);

    }







    }