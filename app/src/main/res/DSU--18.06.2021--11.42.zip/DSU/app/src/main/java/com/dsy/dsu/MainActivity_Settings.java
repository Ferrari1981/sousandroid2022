package com.dsy.dsu;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.loader.content.AsyncTaskLoader;

import org.jetbrains.annotations.NotNull;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

import static com.dsy.dsu.PUBLIC_CONTENT.ССылкаНаСозданнуюБазу;


//вывод данных на Автивити
public class MainActivity_Settings extends AppCompatActivity {

    ///////CОЗДАЕМ ОБЬЕКТ ASYNCTASK ПОТОК ДЛЯ ANDROID I
    ///create ProgressBar
    LinkedHashMap<String, String> ХэшДанныеИзБазыДляЗАполенияСпинеровыОрганизация = new LinkedHashMap<String, String>();



    protected Spinner СпинерВыборОрганизации;
    ///////CОЗДАЕМ ОБЬЕКТ ASYNCTASK ПОТОК ДЛЯ ANDROID I

    Cursor Курсор_СамиДанные_Logins=null;

    private int ЕстьСтроки;

Button  imageViewСтрелкаВнутриНастроек,КнопкаСохранениеОрганизации;

Spinner СпинерДляСозданииОрганизации;

    Switch СвичДляWIFI ,switchАвтоЗаполенияВТАбелеВыходных;

Context КонтекстWIFI;


    static Context   КонтекстWIFIВнешний;

TextView textViewИмяПрограммы;
TextView textViewВерсияПрограммы;
TextView textViewТекущийПользователь;
    TextView textViewВремяПоследнееСинхронизации;
;

    int ПубличныйIDДляорганизацции=0;
    String ДатаДляОбновлениеОргназации;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            Log.d(this.getClass().getName(), "Запущен.... метод  onCreate в классе MainActivity_Settings  ; ");

                super.onCreate(savedInstanceState);

            setContentView(R.layout.activity_main_wifi);

            getSupportActionBar().hide(); ///скрывать тул бар

            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            ///


            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

            getSupportActionBar().hide(); ///скрывать тул бар

            КонтекстWIFI=this;
            /////

            КонтекстWIFIВнешний=this;

          ///  ССылкаНаСозданнуюБазу = new CREATE_DATABASE(this).ССылкаНаСозданнуюБазу;//ссылка на схему базы данных;//ссылка на схему базы данных


            //////todo настрока экрана
          //  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION  );


            //////todo  конец настрока экрана
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);


            imageViewСтрелкаВнутриНастроек = (Button) findViewById(R.id.imageViewСтрелкаВнутриНастроек);

          //  КнопкаСохранениеОрганизации= (Button) findViewById(R.id.КнопкаСохранениеОрганизации);

            СпинерДляСозданииОрганизации= (Spinner) findViewById(R.id.СпинерДляСозданииОрганизации);


            // TODO: 24.05.2021 сфичи



            СвичДляWIFI= (Switch) findViewById(R.id.switchWIFI);


            switchАвтоЗаполенияВТАбелеВыходных= (Switch) findViewById(R.id.switchАвтоЗаполенияВТАбелеВыходных);




            textViewВерсияПрограммы=(TextView) findViewById(R.id.textViewВерсияПрограммы);

                 /*   textViewИмяПрограммы=(TextView) findViewById(R.id.textViewИмяПрограммы);
            //   textViewИмяПрограммы.setText("Имя."+String.valueOf(BuildConfig.VERSION_NAME));*/

            textViewВерсияПрограммы.setText("Версия."+ BuildConfig.VERSION_CODE);

            Log.d(this.getClass().getName(), "  textViewВерсияПрограммы " + textViewВерсияПрограммы.getText());





            textViewТекущийПользователь  =(TextView) findViewById(R.id.textViewТекущийПользователь);



            String ПолученыйТекущееИмяПользователя=new MODEL_synchronized(getApplicationContext()).МетодПолучениеИмяСистемыДляСменыПользователя(getApplicationContext());


            Log.d(this.getClass().getName(), "  ПолученыйТекущееИмяПользователя  "+ПолученыйТекущееИмяПользователя);

            textViewТекущийПользователь.setText("Пользователь: "+ПолученыйТекущееИмяПользователя.toUpperCase());

                    ////


            // TODO: 02.06.2021 время последней синхронизации TextView

            textViewВремяПоследнееСинхронизации =(TextView) findViewById(R.id.textViewВремяПоследнееСинхронизации);
            
            
            













                    //////////todowifi
                    try {
                        МетодСозданиеКодBACK();
                        ///
                        ///
                        МетодОбработкиСвичаДляWIFI();

                        //////
                        МетодОбработкиСвичаАвтоматическогоДобавлениямМеткуВыходныхДней();
                        
                        
                        
                        методВычисляетПоследнуюДатуСинхронищацииССервром();
                        


        //
     ////   МетодСозданиеСпинераОрганизации();
        //////




                        ///////
                    } catch (Exception e) {
                        //  Block of code to handle errors
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }

                    ///МетодСохранениеВыбраннойОрганизации();


            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    } // конец    protected void onCreate(Bundle savedInstanceState)














    // TODO: 02.06.2021 метод которыу вычислет и заполянет ДАТУПОСЛЕДНЕЙ СИНХРОНИЗАЦИИ С СЕРВЕРОМ

    private void методВычисляетПоследнуюДатуСинхронищацииССервром() {


 try{


     CompletionService<String> completionServiceПолучениеПоследнейДатыСинхорониазции=new ExecutorCompletionService<String>(Executors.newSingleThreadExecutor());


     completionServiceПолучениеПоследнейДатыСинхорониазции.submit(new Callable<String>() {
         @Override
         public String call() throws Exception {

  String ПоследнаяДата=null;
  ///
   Cursor  Курсор_ВытаскиваемПоследнуюДатуСинхрониазииССерором=
             new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client",
                     new String[]{"versionserveraandroid"}, "versionserveraandroid  = (SELECT MAX(versionserveraandroid) FROM MODIFITATION_Client)  AND versionserveraandroid IS NOT NULL", null, null, null, null, null);//


             ////
            if ( Курсор_ВытаскиваемПоследнуюДатуСинхрониазииССерором.getCount()>0) {
                /////
                Курсор_ВытаскиваемПоследнуюДатуСинхрониазииССерором.moveToFirst();////
                //////
                ПоследнаяДата  =Курсор_ВытаскиваемПоследнуюДатуСинхрониазииССерором.getString(0);

                Log.d(this.getClass().getName(), "ПоследнаяДата"+ПоследнаяДата);
             }

             return ПоследнаяДата;
         }
     });
     ///////




  Future<String> futureДатаПоследнаяяСинхрониазции=   completionServiceПолучениеПоследнейДатыСинхорониазции.take();
  /////

     String ДатаПоследнаяяСинхрониазции=futureДатаПоследнаяяСинхрониазции.get();
     ///
     if(futureДатаПоследнаяяСинхрониазции.isDone()){

         futureДатаПоследнаяяСинхрониазции.cancel(false);
     }








     if (ДатаПоследнаяяСинхрониазции!=null) {
         ///////////
         textViewВремяПоследнееСинхронизации.setText("Успешный обмен : "+ДатаПоследнаяяСинхрониазции);
     }


     ///////
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }


    
    
    






    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @Override
    protected void onDestroy() {
        super.onDestroy();




        if(ССылкаНаСозданнуюБазу.isOpen()){
            if(ССылкаНаСозданнуюБазу.inTransaction()){
                ССылкаНаСозданнуюБазу.endTransaction();
            }
           // ССылкаНаСозданнуюБазу.close();
        }

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e(this.getClass().getName(), "onRestart() " );
        try {
            TimeUnit.MILLISECONDS.sleep(30);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }










































    private void МетодОбработкиСвичаДляWIFI() throws InterruptedException {
        try{
        //TODO флажек WIFI MObile /// =  МетодПолучениеЗначенияРежимаРаботыИнтернетаWifiИлиInternet(КонтекстКоторыйДляСинхронизации);
            final String[] РезультатКакойРежимРаботыИнтренета = new String[1];


                    РезультатКакойРежимРаботыИнтренета[0] =  new MODEL_synchronized(getApplicationContext()).
                            МетодПолучениеЗначенияРежимаРаботыИнтернетаWifiИлиInternet(getApplicationContext(),"SuccessLogin","mode_connection");




        Log.d(this.getClass().getName(), " РезультатКакойРежимРаботыИнтренета : "+ РезультатКакойРежимРаботыИнтренета[0]);
        ////
            final Toast[] aa = new Toast[1];
            final ImageView[] cc = new ImageView[1];
            MainActivity_Settings.this.runOnUiThread(new Runnable() {
                                                     @Override
                                                     public void run() {
                                                          aa[0] = Toast.makeText(getBaseContext(), "OPEN", Toast.LENGTH_SHORT);
                                                         cc[0] = new ImageView(getBaseContext());
                                                     }});
        //////////TODO КАК РЕЖИМ РАБОТЫ ИНТРЕНТА И  ПЕРЕОПРЕДЕЛЯЕМ ВИЗУАЛЬНО
        switch (РезультатКакойРежимРаботыИнтренета[0]){
            case"Mobile":
                this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        СвичДляWIFI.setChecked(true);
                        СвичДляWIFI.setText("Оба Mobile/Wifi");
                      //  cc[0].setImageResource(R.drawable.icon_dsu1_for_dont_wifi);
                        aa[0].setView(cc[0]);
                        aa[0].show();

                    }
                });
                break;


                ///TODO WIFI ТОЛЬКО
            case"WIFI":
                this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                СвичДляWIFI.setChecked(false);
                СвичДляWIFI.setText("Только WIFI");
             //   cc[0].setImageResource(R.drawable.icon_dsu1_for__wifi);
                aa[0].setView(cc[0]);
                aa[0].show();
                    }
                });
                break;

        }


//////todo при нНАЖАТИИ  НА КНОПКУ СОХРАНИТЬ НАСТРОЙКИ ЗАПИСЫВАЕТ ОРГАНИЗАЦИЮ В БАЗУ

        СвичДляWIFI.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //////TODO ЕСЛИ РЕЖИМ TRUE  MOBILE ВПИСЫВАЕМ КАК В БАЗУ MOBILE
                if (isChecked) {
                    // The toggle is enabled mobile
             new MODEL_synchronized(getApplicationContext()).МетодКоторыйЗаписываемВыбранныйРежимИнтрернетаWifiИлиMobile("Mobile", getApplicationContext()
                     ,"SuccessLogin","mode_connection" );

                    ///TODO принудительно устанвливаем редим работы синхронизации
                    MainActivity_Settings.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            СвичДляWIFI.setText("Оба Mobile/Wifi");
                            Toast aa = Toast.makeText(getBaseContext(), "OPEN", Toast.LENGTH_SHORT);
                            ImageView cc = new ImageView(getBaseContext());
                            cc.setImageResource(R.drawable.icon_dsu1_for_dont_wifi);
                            aa.setView(cc);
                            aa.show();
                        }});



                    //////TODO ЕСЛИ РЕЖИМ TRUE  MOBILE ВПИСЫВАЕМ КАК В БАЗУ ТОЛЬКО WIFI
                } else {
                    // The toggle is disabled
                    new MODEL_synchronized(getApplicationContext()).МетодКоторыйЗаписываемВыбранныйРежимИнтрернетаWifiИлиMobile("WIFI", getApplicationContext()
                            ,"SuccessLogin","mode_connection" );

                    ///TODO принудительно устанвливаем редим работы синхронизации
                    MainActivity_Settings.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            СвичДляWIFI.setText("Только Wifi");
                            Toast aa = Toast.makeText(getBaseContext(), "OPEN", Toast.LENGTH_SHORT);
                            ImageView cc = new ImageView(getBaseContext());
                            cc.setImageResource(R.drawable.icon_dsu1_for__wifi);
                            aa.setView(cc);
                            aa.show();
                        }});
                }
            }
        });
    } catch (Exception e) {
        e.printStackTrace();
///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка : " + e + " Метод : " + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  : " + Thread.currentThread().getStackTrace()[2].getLineNumber());
               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

    }
    }







    // TODO: 24.05.2021 ВТОРОЙ СВИЧ ПЕРЕКЛЮЧАТЕЛЬ КОТОРЫЙ РАЗРЕШЕТ РЕЖИМ АВТОМАТИЧЕСГКО ЗАПИСИ бОЛЬНИЧНОГОВ НОВЫЙ ТАБЕЛЬ
    
    

    private void МетодОбработкиСвичаАвтоматическогоДобавлениямМеткуВыходныхДней() throws InterruptedException {
        try{
            //TODO флажек WIFI MObile /// =  МетодПолучениеЗначенияРежимаРаботыИнтернетаWifiИлиInternet(КонтекстКоторыйДляСинхронизации);
          String РезультатКакойРежимЗаписанвБазеВЫходныеДни = new String();


            РезультатКакойРежимЗаписанвБазеВЫходныеДни =  new MODEL_synchronized(getApplicationContext()).
                    МетодПолучениеЗначенияРежимаРаботыИнтернетаWifiИлиInternet(getApplicationContext() ,"SuccessLogin","mode_weekend");




            Log.d(this.getClass().getName(), " РезультатКакойРежимЗаписанвБазеВЫходныеДни : "+ РезультатКакойРежимЗаписанвБазеВЫходныеДни);
            ////
            final Toast[] aa = new Toast[1];
            final ImageView[] cc = new ImageView[1];
            MainActivity_Settings.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    aa[0] = Toast.makeText(getBaseContext(), "OPEN", Toast.LENGTH_SHORT);
                    cc[0] = new ImageView(getBaseContext());
                }});


            //////////TODO КАК РЕЖИМ РАБОТЫ ИНТРЕНТА И  ПЕРЕОПРЕДЕЛЯЕМ ВИЗУАЛЬНО
            switch (РезультатКакойРежимЗаписанвБазеВЫходныеДни){
                case"Включить":
                    this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            switchАвтоЗаполенияВТАбелеВыходных.setChecked(true);
                            switchАвтоЗаполенияВТАбелеВыходных.setText("Вкл (Выходные)");
                            //  cc[0].setImageResource(R.drawable.icon_dsu1_for_dont_wifi);
                            aa[0].setView(cc[0]);
                            aa[0].show();

                        }
                    });
                    break;


                ///TODO WIFI ТОЛЬКО
                case"Выключить":
                    this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            switchАвтоЗаполенияВТАбелеВыходных.setChecked(false);
                            switchАвтоЗаполенияВТАбелеВыходных.setText("Выкл (Выходные)");
                            //   cc[0].setImageResource(R.drawable.icon_dsu1_for__wifi);
                            aa[0].setView(cc[0]);
                            aa[0].show();
                        }
                    });
                    break;

            }


//////todo при нНАЖАТИИ  НА КНОПКУ СОХРАНИТЬ НАСТРОЙКИ ЗАПИСЫВАЕТ ОРГАНИЗАЦИЮ В БАЗУ

            switchАвтоЗаполенияВТАбелеВыходных.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    //////TODO ЕСЛИ РЕЖИМ TRUE  MOBILE ВПИСЫВАЕМ КАК В БАЗУ MOBILE
                    if (isChecked) {
                        // The toggle is enabled mobile
                        new MODEL_synchronized(getApplicationContext()).МетодКоторыйЗаписываемВыбранныйРежимИнтрернетаWifiИлиMobile("Включить", getApplicationContext()
                                ,"SuccessLogin","mode_weekend");

                        ///TODO принудительно устанвливаем редим работы синхронизации
                        MainActivity_Settings.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                switchАвтоЗаполенияВТАбелеВыходных.setText("Вкл (Выходные)");
                                Toast aa = Toast.makeText(getBaseContext(), "OPEN", Toast.LENGTH_SHORT);
                                ImageView cc = new ImageView(getBaseContext());
                                cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_success);
                                aa.setView(cc);
                                aa.show();
                            }});



                        //////TODO ЕСЛИ РЕЖИМ TRUE  MOBILE ВПИСЫВАЕМ КАК В БАЗУ ТОЛЬКО WIFI
                    } else {
                        // The toggle is disabled
                        new MODEL_synchronized(getApplicationContext()).МетодКоторыйЗаписываемВыбранныйРежимИнтрернетаWifiИлиMobile("Выключить", getApplicationContext()
                                ,"SuccessLogin","mode_weekend");

                        ///TODO принудительно устанвливаем редим работы синхронизации
                        MainActivity_Settings.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                switchАвтоЗаполенияВТАбелеВыходных.setText("Выкл (Выходные)");
                                Toast aa = Toast.makeText(getBaseContext(), "OPEN", Toast.LENGTH_SHORT);
                                ImageView cc = new ImageView(getBaseContext());
                                cc.setImageResource(R.drawable.icon_dsu1_off_swihc_bolyny_error);
                                aa.setView(cc);
                                aa.show();
                            }});
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка : " + e + " Метод : " + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  : " + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

        }
    }



















//todo СОХРАНЕНИЕ ВЫБРАНОЙ ОРГАНИЗАЦИИ


            private int МетодЗаписиПолученойОрганизацииВТАблицу(String ПолученоеНазваниеИзСпинераДляХэша) {
                final long[] РезультатВставкиНовогоСотрудникарезКонтрейнер = {0};
        try {


            Object ПолученныйUUIDИзХэшаОрганизации = null;
            for (Map.Entry<String, String> ХэшПосикаОрганизация : ХэшДанныеИзБазыДляЗАполенияСпинеровыОрганизация.entrySet()) {
                if (ХэшПосикаОрганизация .getValue().trim().equalsIgnoreCase(ПолученоеНазваниеИзСпинераДляХэша)) {
                    Log.d(this.getClass().getName(), "ХэшПосикаСоздаваемогоТабеля.getKey() " + ХэшПосикаОрганизация .getKey()
                            + " ХэшПосикаСоздаваемогоТабеля.getValue() "+ ХэшПосикаОрганизация .getValue());
                    //////финальное значение от сфо
                    ПолученныйUUIDИзХэшаОрганизации =ХэшПосикаОрганизация.getKey();

                    int ПолученныйUUIDИзХэшаОрганизацииФинал=Integer.parseInt(ПолученныйUUIDИзХэшаОрганизации.toString());


                    /////todo записываем получени UUID
                    if ( ПолученныйUUIDИзХэшаОрганизацииФинал>0) {
                        final ContentValues[] АдаптерВставкиВыбраноеОрганизации = {new ContentValues()};

                        CountDownLatch countDownLatch=new CountDownLatch(3);
ReentrantLock reentrantLock=new ReentrantLock();

                        ExecutorService executorServiceUpdateOrganizatio=Executors.newSingleThreadExecutor();
                   Future futureupdateor=     executorServiceUpdateOrganizatio.submit(new Runnable() {
                            @Override
                            public void run() {
                                reentrantLock.lock();
                                countDownLatch.countDown();

                         АдаптерВставкиВыбраноеОрганизации[0] = МетодЗаполенияДаннымиПриВставкеОрганизации(ПолученныйUUIDИзХэшаОрганизацииФинал);









                        try{

///TODO ВСТАВКА НОВГО ТАБЕЛЯ В ТАБЛИЦУ
                            countDownLatch.countDown();
                        РезультатВставкиНовогоСотрудникарезКонтрейнер[0] = new MODEL_synchronized(getApplicationContext()).
                                ВставкаДанныхЧерезКонтейнерОрганизацияДляТекущегоСотрудникаУниверсальная("settings_tabels",
                                        АдаптерВставкиВыбраноеОрганизации[0], "settings_tabels", "", true,ПубличныйIDДляорганизацции,ДатаДляОбновлениеОргназации);

                        Log.d(this.getClass().getName(), " РезультатВставкиНовогоСотрудникарезКонтрейнер " + РезультатВставкиНовогоСотрудникарезКонтрейнер[0]);




                                                              } catch (Exception e) {
                                                                  e.printStackTrace();
                                                                  ///метод запись ошибок в таблицу
                                                                  Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                                                          " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                                                  new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                                                          Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                                              }finally {
                            reentrantLock.unlock();
                        }




                                Log.d(this.getClass().getName(), "записали названиеорганизацуии в базу " + new Date()  +
                                        "               РезультатВставкиНовогоСотрудникарезКонтрейнер[0] "+              РезультатВставкиНовогоСотрудникарезКонтрейнер[0]);





                            }
                        });

                        countDownLatch.countDown();
//
                        futureupdateor.get();
                        if (futureupdateor.isDone()) {
                            executorServiceUpdateOrganizatio.shutdown();
                        }

                        countDownLatch.await();



                        // TODO: 19.03.2021 конец вставки организаии
                        Toast aa = Toast.makeText(getBaseContext(), "OPEN", Toast.LENGTH_SHORT);
                        ImageView cc = new ImageView(getBaseContext());
                        /////TODO РЕЗУЛЬТАТ ВСТАВКИ ОРГАНИЗАЦИИ НА АКТИЫТИ НАСТРОЙКИ
                        if (  РезультатВставкиНовогоСотрудникарезКонтрейнер[0] >0){
                            //      cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_success);//icon_dsu1_synchronisazia_dsu1_success
                        }else{
                            cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_error);//icon_dsu1_synchronisazia_dsu1_success
                            Toast.makeText(getApplicationContext(), "ошибка организация не записалась !!!" , Toast.LENGTH_LONG).show();

                            ////
                            aa.setView(cc);
                            aa.show();
                        }



                        ////////////////////
/////TODO результат вставки организации в систему

                    }
                    ///TODO как заполнили сразу выходим
                    break;
                }
            }
            ////TODO если не пустой



        } catch (Exception e) {
                //  Block of code to handle errors
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///////
            }
return (int) РезультатВставкиНовогоСотрудникарезКонтрейнер[0];
    }

    @NotNull
    private ContentValues МетодЗаполенияДаннымиПриВставкеОрганизации(int полученныйUUIDИзХэшаОрганизацииФинал) {
        ContentValues АдаптерВставкиВыбраноеОрганизации = new ContentValues();////контрейнер для нового табеля
        //TODO вставка в контейнер
        АдаптерВставкиВыбраноеОрганизации.put("organizations", String.valueOf(полученныйUUIDИзХэшаОрганизацииФинал));


// TODO: 28.03.2021 id search puvlic

        Cursor Курсор_ИщемПУбличныйIDКогдаегоНетВстатике=null;
        ПубличныйIDДляорганизацции=0;
        try {
            Курсор_ИщемПУбличныйIDКогдаегоНетВстатике =
                    new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("SuccessLogin",
                            new String[]{"id"}, " id IS NOT NULL", null, null, null, "date_update", "1");//
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (TimeoutException e) {
            e.printStackTrace();
        }
        /////////
        if(Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount()>0){
            Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.moveToFirst();
            ////
            Log.d(this.getClass().getName(), " Курсор_ИщемПУбличныйIDКогдаегоНетВстатике " + Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount());

            ПубличныйIDДляорганизацции =Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getInt(0);



        }


        Log.d(this.getClass().getName(), "   ПубличныйIDДляорганизацции" +
                ПубличныйIDДляорганизацции);


        АдаптерВставкиВыбраноеОрганизации.put("user_update", String.valueOf(ПубличныйIDДляорганизацции));


        // TODO: 20.04.2021 определяем ели UUID или нет
        Cursor     Курсор_УзнаемЕслиUUIDВТАблицеОрганизация=null;
        try {
                 Курсор_УзнаемЕслиUUIDВТАблицеОрганизация =
                         new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("settings_tabels",
                                 new String[]{"uuid"}, "user_update=?", new String[]{String.valueOf(ПубличныйIDДляорганизацции)}, null, null, "date_update", "1");//
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (TimeoutException e) {
            e.printStackTrace();
        }
        int UUIDдлянастроуки = 0;

if (Курсор_УзнаемЕслиUUIDВТАблицеОрганизация!=null){
    if (Курсор_УзнаемЕслиUUIDВТАблицеОрганизация.getCount()>0){
        Курсор_УзнаемЕслиUUIDВТАблицеОрганизация.moveToFirst();
        int IndexUUID=Курсор_УзнаемЕслиUUIDВТАблицеОрганизация.getColumnIndex("uuid");

        UUIDдлянастроуки=Курсор_УзнаемЕслиUUIDВТАблицеОрганизация.getInt(IndexUUID);


        if(UUIDдлянастроуки==0){
            Random random=new Random();
            UUIDдлянастроуки=random.nextInt(100000);
        }

    }else{
        Random random=new Random();
        UUIDдлянастроуки=random.nextInt(100000);
    }
}

        ///






       АдаптерВставкиВыбраноеОрганизации.put("uuid", UUIDдлянастроуки);


        // TODO: 28.03.2021 date for update orgazition
        ДатаДляОбновлениеОргназации=null;

        ДатаДляОбновлениеОргназации=            ГлавнаяДатаИВремяОперацийСБазойДанных();






        АдаптерВставкиВыбраноеОрганизации.put("date_update", ДатаДляОбновлениеОргназации);
        return АдаптерВставкиВыбраноеОрганизации;
    }









/*

    ///todo сообщение
    @UiThread
    protected void   СообщениеСообщаетЗаписиОрганизацииДляТекущегоСотрудника(String ШабкаДиалога,  String СообщениеДиалога,
                                                               boolean статус ) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
        int ФлагЗнака;
        if (статус) {
            ФлагЗнака = R.drawable.icon_dsu1_new_customer_success;//icon_dsu1_new_customer7
        } else {
            ФлагЗнака = R.drawable.icon_dsu1_new_customer_error;
        }

        try {
//////сам вид
            final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                    .setTitle(ШабкаДиалога)
                    .setMessage(СообщениеДиалога)
                    .setPositiveButton("ОК", null)
                    .setIcon(ФлагЗнака)
                    .show();
/////////кнопка
            final Button MessageBoxUpdateСоздатьТабель = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog.dismiss();
                    Log.d(this.getClass().getName(), "  ФИНАЛ создание нового сотрудника ");

                    if (статус) {
                        //TODO после успешной вставки нового сотрудника  в табель обнуляем переменные
///TODO метод запуска формы после вставки
                        ///todo ПОСЛЕ ЦИКЛА ОБНУЛЯЕМ ХЭШ
                        //МетодаКоторыйПослеУспешнойВставкиЗапускаетТАбельсНовымСотрудниковм();

                        ///todo код которыц возврящет предыдущий актвитики кнопка back
                        Intent ИнтентВозврящемсяНазад = new Intent();
                        ИнтентВозврящемсяНазад .setClass(getApplication(),  MainActivity_FACE_APP.class); // ТУТ ЗАПВСКАЕТЬСЯ ВЫБОР ПРИЛОЖЕНИЯ КОТОРЫЕ ЕСТЬ FACE APP НА ДАННЫЙ МОМЕТНТ РАЗРАБОТНАО ТАБЕЛЬНЫЙ УЧЁТ
                        ИнтентВозврящемсяНазад.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(ИнтентВозврящемсяНазад);
                       finishAffinity();

                    }
                }


            });

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }
*/







    /////todo метод создание BACK
    private void МетодСозданиеКодBACK() {


        imageViewСтрелкаВнутриНастроек.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(this.getClass().getName(), " кликнем для созданни новго сотрдника при нажатии  ");
                ///todo код которыц возврящет предыдущий актвитики кнопка back
                Intent ИнтентВозврящемсяНазад = new Intent();
                ИнтентВозврящемсяНазад .setClass(getApplication(),  MainActivity_FACE_APP.class); // ТУТ ЗАПВСКАЕТЬСЯ ВЫБОР ПРИЛОЖЕНИЯ КОТОРЫЕ ЕСТЬ FACE APP НА ДАННЫЙ МОМЕТНТ РАЗРАБОТНАО ТАБЕЛЬНЫЙ УЧЁТ
                ИнтентВозврящемсяНазад.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(ИнтентВозврящемсяНазад);
                //////
                //////TODO  данный код срабатывает когда произошда ошивка в базе
                КонтекстWIFIВнешний=null;
                Log.d(this.getClass().getName(), " кликнем для созданни новго сотрдника при нажатии  ");
            }

        });


    }















    private void МетодСозданиеСпинераОрганизации() {
        try{

            ArrayList ДанныеДляЗаполенияОрганизациивАдаптер=МетодЗаполненияНазваниеОрганизации("organization","name,id");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ДанныеДляЗаполенияОрганизациивАдаптер = (ArrayList) ДанныеДляЗаполенияОрганизациивАдаптер.stream().distinct().collect(Collectors.toList());
            }


            ArrayAdapter<String> АдаптерДляСпинераОрганизации = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_activated_1,
                ДанныеДляЗаполенияОрганизациивАдаптер );

        АдаптерДляСпинераОрганизации.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);



        // Применяем адаптер к элементу spinner
        СпинерДляСозданииОрганизации.setAdapter(АдаптерДляСпинераОрганизации);

            СпинерДляСозданииОрганизации.setHorizontalScrollBarEnabled(true);


        ///
        СпинерДляСозданииОрганизации.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {



                ////todo когда пользователь выбрал из спинера значение
                if (position>0) {///ставим ограничкния если выбрано не 0 позиция то запонимаеним
                    ///////////
             String       ПолученноеЗначениеИзСпинераОрганизации=parent.getItemAtPosition(position).toString();
                    ////СПИНЕР ЦФО
                    ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    ((TextView) parent.getChildAt(0)).setBackgroundResource(R.drawable.textlines);
                    ((TextView) parent.getChildAt(0)).setTextSize(20);
                    ((TextView) parent.getChildAt(0)).setLines(1);
                    ((TextView) parent.getChildAt(0)).setTypeface(Typeface.DEFAULT_BOLD);
                    ((TextView) parent.getChildAt(0)).setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    ((TextView) parent.getChildAt(0)).setHintTextColor(Color.parseColor("#00ACC1"));
                    Log.e(this.getClass().getName(), " СпинерВыборЦФО.getCount() " +СпинерДляСозданииОрганизации.getCount());

                    ////TODO Выбраная Организация Записываем название оргнаизации   В БАЗУ ЧТОБЫ ПРИ ПОВТОРНОМ ВХОДЕ ОРГАНИЗАЦИЮ УЖЕ СТОЯЛА
                    Log.d(this.getClass().getName(), " ((TextView) parent.getChildAt(0))  " +((TextView) parent.getChildAt(0)).getText());

                    ////////TODO если выбрана какая то огранизациия то мы ее и записываем
                    if (((TextView) parent.getChildAt(0)).getText().length()>0){

                        МетодЗаписиВбАзуОрганизацииТекущейИзаписьегоВСамСпинерДЛяВизуализацииВыбранойОрганизации(parent);


                    }


                    ////////////////
//                                                               Toast toast = Toast.makeText(getApplicationContext(),
//                                                                         "((TextView) parent.getChildAt(0)).getText() : " + ((TextView) parent.getChildAt(0)).getText() + " " + position, Toast.LENGTH_SHORT);
//                                                                 toast.show();
                }else if (position==0) {
                    ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    ((TextView) parent.getChildAt(0)).setBackgroundResource(R.drawable.textlines);
                    ((TextView) parent.getChildAt(0)).setTextSize(20);
                    ((TextView) parent.getChildAt(0)).setLines(1);
                    ((TextView) parent.getChildAt(0)).setTypeface(Typeface.DEFAULT_BOLD);
                    ((TextView) parent.getChildAt(0)).setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    ((TextView) parent.getChildAt(0)).setHint("Выбирете Организацию");
                    ((TextView) parent.getChildAt(0)).setHintTextColor(Color.parseColor("#00ACC1"));


                    ///TODO записть в базу название организации при нулевой позиции в спиноре
                    if (((TextView) parent.getChildAt(0)).getText().length()>0){

                       // МетодЗаписиВбАзуОрганизацииТекущейИзаписьегоВСамСпинерДЛяВизуализацииВыбранойОрганизации(parent);


                    }



                }



                ///
            }

            protected void МетодЗаписиВбАзуОрганизацииТекущейИзаписьегоВСамСпинерДЛяВизуализацииВыбранойОрганизации(AdapterView<?> parent) {
                final Long[] РезультатВставкиГотовойОрганизации = {0L};

                ////////todo записываем выбраную оргниазцаию





                /////TODO ЕСЛИ ОРГАНИЗАЦИЯ ДОБАВЛИСЬ ПОКАЗЫВАЕМ ЭТО ПОЛЬЗОВАТЕЛЮ
                Toast aa = Toast.makeText(getApplicationContext(), "OPEN",Toast.LENGTH_SHORT);
                ImageView cc = new ImageView(getApplicationContext());


                final int[] РезультатВставкиНовогоUUIIDОрганизации = {0};

                ///
                Log.d(this.getClass().getName(), " РезультатВставкиГотовойОрганизации  " + РезультатВставкиГотовойОрганизации[0]);


                int ТекущаяПозицияСпинераЦФО=СпинерДляСозданииОрганизации.getSelectedItemPosition();
                //TODO еСЛИ чтО ВЫБРАЛИ ТО НАЧИНАЕМ ВСТАВЛЯТЬ
                Log.d(this.getClass().getName(), " кликнем для созданни новго сотрдника при нажатии  " + СпинерДляСозданииОрганизации.getItemAtPosition(ТекущаяПозицияСпинераЦФО).toString());


              String СодержимоеСпинераНазваниеОрганизации=СпинерДляСозданииОрганизации.getItemAtPosition(ТекущаяПозицияСпинераЦФО).toString();



                if (СодержимоеСпинераНазваниеОрганизации !=null ) {
                    Log.d(this.getClass().getName()," СпинерДляСозданииОрганизации  " +СодержимоеСпинераНазваниеОрганизации
                            + " ТекущаяПозицияСпинераЦФО " +ТекущаяПозицияСпинераЦФО);





                           /* ///todo устанвливаем организацию КОТОРУЮ ВЫБРАЛ ПОЛЬЗОВАТЕЛЬ
                            РезультатВставкиГотовойОрганизации[0] =      new MODEL_synchronized(getApplicationContext()).
                                    МетодКоторыйЗаписываемВыбраннуюОргназациювБазуЧтобыПотомЕеНеБывырать(((TextView) parent.getChildAt(0)),getApplicationContext());

*/





                         ///   РезультатВставкиНовогоUUIIDОрганизации[0] =       МетодЗаписиПолученойОрганизацииВТАблицу(СодержимоеСпинераНазваниеОрганизации);












                }else{
////todo сообщаем пользователю что он не выбрал ничего сфо и/или департметем
                    Toast.makeText(getApplicationContext(), "Выбор организации" + " Вы не выбрали организацию (пропробуйте еще раз)" , Toast.LENGTH_LONG).show();
                }





            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        ///поймать ошибку
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new КлассВставкиОшибок(this).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        ///////
    }
    }









    //// TODO МЕТОД ЗАПОЛЕНИЯ ДАННЫМИ ИЗ БАЗЫ В СПИНЕР НАЗВАНИЯ ОРГАНИЗАЦИЙ
    ArrayList<String> МетодЗаполненияНазваниеОрганизации(String ИмяТаблицыДляСпинера, String СтолбикДляЗагурзкиВСпинер) {
        ///
        Log.d(this.getClass().getName()," МетодЗаполениеяСпинераДаннымиИзБазы() ");

        final Cursor[] asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля = {null};
        /////
        ArrayList<String> АрайЛИстДанныеИзБазыДляЗАполенияСпинеровы= new ArrayList <String>(); ////ГЛАВНЫЙ СПИСОК ТАБЛИЦ ДЛЯ  ОБМЕНАМИ ДАННЫМИ ИЗ НЕГО БУДЕТ БРАТЬСЯ СПИСКО ТАБЛИЦ

        try{
/////todo КОД ЗАПОЛЕНЕИЯ ДАННЫМИ В СПИНЕР ЦФО ДЕПАРТАМЕНТ МЕСЯЦ

            ExecutorService executorService=Executors.newCachedThreadPool();
        Future futureорганизаци=   executorService.submit(new Runnable() {
                @Override
                public void run() {
                    try {
                        asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0] =  new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных(ИмяТаблицыДляСпинера, new String[]
                                        {СтолбикДляЗагурзкиВСпинер}, null,
                                null, null, null,null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере



                        ///поймать ошибку
                    } catch (Exception e) {
                        //  Block of code to handle errors
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ///////
                    }

                }
            });
            ////
            futureорганизаци.get();

if (futureорганизаци.isDone()){
    Log.d(this.getClass().getName(), " asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].getCount() " +  asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].getCount());
///
    if (executorService.isTerminated()) {
        ////
        МетодЗаполенияАктивтиНастройки(asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля, АрайЛИстДанныеИзБазыДляЗАполенияСпинеровы);
    }
    executorService.shutdown();
}
            ///поймать ошибку
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(this).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///////
        }
////ВОЗВРЯЩАЕМ  МетодЗаполненияДляТабеляСпинераДаннымиИзБазы
        return АрайЛИстДанныеИзБазыДляЗАполенияСпинеровы;
    }









    private void МетодЗаполенияАктивтиНастройки(Cursor[] asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля, ArrayList<String> арайЛИстДанныеИзБазыДляЗАполенияСпинеровы) {

        ReentrantLock reentrantLock=new ReentrantLock();
        try{
        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
        /////
        String ЗначениеДляЗаполенияСпинера= "";

////////
        if ( asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].getCount()>0) {/////ЗАГРУЖАЕМ ДАННЫЕ ИЗ ТАБЛИЦЫ CFO ДЛЯ СПИНЕРА И СОЗДАНИЯ ТАБЕЛЯ
            /////
            asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].moveToFirst();

            Log.d(this.getClass().getName(), " asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля " + asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].getCount());

            ////TODO ДАННЫЕ ПЕРВЫМ СТАВИТЬСЯ ПЕРЕД ВСЕМ МАСИВОМ ЗНАЧЕНИЯ
            арайЛИстДанныеИзБазыДляЗАполенияСпинеровы.add("") ;
            //TODO
            ХэшДанныеИзБазыДляЗАполенияСпинеровыОрганизация.clear();





            ////сам цикл заполения спинеров
          do{

              /////
              reentrantLock.lock();
                ///////вытаскиваем данные из базы столбкик ЗАПОЛЕНИЕ ХЕША
                //TODO UUID  ВСЛУЧАЕ ЕЛСИ ID ПУСТОЙ ТО ЗАПОЛЯЕМ ПОЛЯ UUID

                    int ИндексДляСохранениеОрганизацииUUID= asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].getColumnIndex("id");

          Long СамДляСохранениеОрганизацииUUID = asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].getLong(ИндексДляСохранениеОрганизацииUUID);

              int ИндексДляСохранениеОрганизацииИмени= asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].getColumnIndex("name");

              ЗначениеДляЗаполенияСпинера  = asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].getString(ИндексДляСохранениеОрганизацииИмени);

                Log.d(this.getClass().getName(), " СамДляСохранениеОрганизацииUUID " + СамДляСохранениеОрганизацииUUID +" ЗначениеДляЗаполенияСпинера "  +ЗначениеДляЗаполенияСпинера);

//////TODO САМО ЗАПОЛНЕНИЕ НАЗВАНИЕМ ОРГАНИЗАЦИИ В AERRAYLIST  И HASPMAP
                if (СамДляСохранениеОрганизацииUUID>0 && ЗначениеДляЗаполенияСпинера!=null) {
///ЗАПОЛЯНЕМ ААРАЛИСТ
                    ////// todo для ЗАПОЛЕНИЕ АРАЙЛИСТА ЗАПОЛЕНИЕ ПЕРВОЕ И ВАЖНОЕ АРАЛИЛСИАТ
                    арайЛИстДанныеИзБазыДляЗАполенияСпинеровы.add(ЗначениеДляЗаполенияСпинера); /////ЗАПОЛЯНЕМ АРАЙЛИСТА ДЛЯ ОТОБРАЖЕНИЯ НАЗВАНИЕ ТАБЕЛЯ В АКТИВТИ
///ЗАПОЛЯНЕМ ХЭ
                    ////// TODO ДЛЯ ЗАПОЛЕНИЯ ХЭШМАПА ЗАПОЛЕЯНИМ ХЭШМАП ВЗАВИСИМОСТИ ОТ НАЗВАНИЯ ТАБЛИЦЫ
                    ХэшДанныеИзБазыДляЗАполенияСпинеровыОрганизация.put(String.valueOf(СамДляСохранениеОрганизацииUUID), ЗначениеДляЗаполенияСпинера);////ЗАПОЛЯЕМ  ДОПОЛНИТЕЛЬНО  ХЭШМАП ДЛЯ РАБОТЫ ВСТМВКИ В БАЗУ ДОПОЛНИТЕЛЬНО
             //TODO ПОСЛЕ УСТАВКИ  ДЕЛАЕМ NULL
                    СамДляСохранениеОрганизацииUUID=0l ;
                    ЗначениеДляЗаполенияСпинера=null;

                }






            }while (asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].moveToNext());

            Log.d(this.getClass().getName(), "  АрайЛИстДанныеИзБазыДляЗАполенияСпинеровы.size()  " + арайЛИстДанныеИзБазыДляЗАполенияСпинеровы.size()
                    + "  ХэшДанныеИзБазыДляЗАполенияСпинеровыОрганизация.size() " +ХэшДанныеИзБазыДляЗАполенияСпинеровыОрганизация.size());
            asyncTaskLoaderЗагружаетДанныеПриСозданииТабеля[0].close();


            ///todo Метод который узнает какой ВыбранаОрганизация самим пользователь СОРТИРУЕМ ЕГО ПО ЦИФРЕ 1 КТО ВЫБРАЛ ТОГО И СТАВИМ

            МетодКоторыйСортируетАрайЛистПоУсловияКакаяОрганизацияУжеВыбрана(арайЛИстДанныеИзБазыДляЗАполенияСпинеровы);


        }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }finally {
            reentrantLock.unlock();
        }
    }


    private void МетодКоторыйСортируетАрайЛистПоУсловияКакаяОрганизацияУжеВыбрана(ArrayList<String> арайЛИстДанныеИзБазыДляЗАполенияСпинеровы) {

        final Cursor[] asyncTaskLoaderИщемВыбраннуюОрганизацию = {null};
        try{


//todo ИЩЕМ САМУ ОРГАНИЗАЦИИ

            ExecutorService executorService=Executors.newCachedThreadPool();
            executorService.execute(new Runnable() {
                @Override
                public void run() {

                    try {
                        ////TODO ИЩЕМ ОРГАНИЗАЦИЮ КОТРОУЮ ВЫБРАЛ СОТРУДНИК УЖЕ ЗАХОДИЛ И ВЫБРАЛ НА АКТИВТИ цифра один ставитсья всегда каторую выбрали
                        asyncTaskLoaderИщемВыбраннуюОрганизацию[0] =  new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("organization", new String[]
                                {"name","chosen_organization"}, "chosen_organization=?",new String[] {"1"}, null, null,null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере



                        ///поймать ошибку
                    } catch (Exception e) {
                        //  Block of code to handle errors
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ///////
                    }


                }
            });
            ///
            executorService.shutdown();
            executorService.awaitTermination(1,TimeUnit.MINUTES);











        ///TODO САМА СОРТИРОВКА ПО ЦИФРЕ 1 НУ КТО ВЫБРАЛ ОРГАНИЗАЦИЮ ТОГО ПЕРВОГО И СТАВИМ
        if (asyncTaskLoaderИщемВыбраннуюОрганизацию[0].getCount()>0) {
            /////
            Log.d(this.getClass().getName(), "  asyncTaskLoaderИщемВыбраннуюОрганизацию.getCount()  " + asyncTaskLoaderИщемВыбраннуюОрганизацию[0].getCount());

            ////
            asyncTaskLoaderИщемВыбраннуюОрганизацию[0].moveToFirst();
            String ОрганизацияРанееВыбранаяСотрудником = asyncTaskLoaderИщемВыбраннуюОрганизацию[0].getString(0);
            String НомерОрганизацияРанееВыбранаяСотрудником= asyncTaskLoaderИщемВыбраннуюОрганизацию[0].getString(1);


            /////TODO СОБВСТВЕННО СОРТИРУЕМ ПО НАЙДЕНОМУ КЛЮЧУ

        int ИщемСвойМесяцПорядок= арайЛИстДанныеИзБазыДляЗАполенияСпинеровы.indexOf(ОрганизацияРанееВыбранаяСотрудником);
        /////TODo данной командой ставим месяц котроый наш всегда в начало Арайлиста SORT()
        Collections.swap(арайЛИстДанныеИзБазыДляЗАполенияСпинеровы,0,ИщемСвойМесяцПорядок);
        Log.d(this.getClass().getName(), "  АрайЛИстДанныеИзБазыДляЗАполенияСпинеровы  " + арайЛИстДанныеИзБазыДляЗАполенияСпинеровы.toString());
        ////TODO попытка удили предыдущего места ЛИШНЕЕ МЕСТО КОТОРЕ ОСВОБОДИЛОСЬ ПОСЛЕ КАК МЫ СОРТИРОВАЛИ
            арайЛИстДанныеИзБазыДляЗАполенияСпинеровы.remove( ИщемСвойМесяцПорядок);
        }




            //TODO КУРСОР ЗАКРЫВАЕМ
            asyncTaskLoaderИщемВыбраннуюОрганизацию[0].close();

    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new КлассВставкиОшибок(this).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        ///////
    }
    }



    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
    public String ГлавнаяДатаИВремяОперацийСБазойДанных() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        //  dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);
    }


}/// конец  public class MainActivity_New_Tabely extends AppCompatActivity

