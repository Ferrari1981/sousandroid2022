package com.dsy.dsu;


import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.inputmethodservice.KeyboardView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.loader.content.AsyncTaskLoader;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener;

import org.json.JSONException;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.LongSupplier;
import java.util.stream.LongStream;

import javax.crypto.NoSuchPaddingException;

import static com.dsy.dsu.CREATE_DATABASE.ССылкаНаСозданнуюБазу;


public class MainActivity_Single_Tabely extends AppCompatActivity  {

    // TODO данные переменные обьявляються на самом активти ТАБЕЛЬ
    // TODO данные переменные обьявляються на самом активти ТАБЕЛЬ
    // TODO данные переменные обьявляються на самом активти ТАБЕЛЬ
    // TODO данные переменные обьявляються на самом активти ТАБЕЛЬ
    // TODO данные переменные обьявляються на самом активти ТАБЕЛЬ

    protected Spinner СпинерТАбельМЕсяцФинал;/////спинеры для создание табеля
    protected Spinner СпинерТАбельДепартаментФинал;/////спинеры для создание табеля
    protected ScrollView ScrollСамогоТабеля;
    boolean РежимыПросмотраДанныхЭкрана;
    protected LinearLayout ГлавныйКонтейнерТабель; ////главный linelayuout

    protected ConstraintLayout ГлавныйВерхнийКонтейнер;

protected ProgressDialog progressDialogДляУдаления;
 protected    String ФИОДляТабеляНаАктивти;

    private  int ОбщееКоличествоСОтрудниковДляСкролаПотабелю=0;

    private ImageButton imageButtonДвижениеПоСотрудникамВТАбеле,imageButtonНазадПоСотрудникамВТАбеле;


    private  String  МесяцТабеляФинал;
    Configuration config;
    ArrayList<String> МассивДляВыбораСпинераДаты= new ArrayList<>(); //////АКАРЛИСТ ДЛЯ ПОЛУЧЕНЫЙ НОВЫХ ДАТ
    ArrayList<String> МассивДляВыбораВСпинерДепартамент= new ArrayList<>(); //////АКАРЛИСТ ДЛЯ ПОЛУЧЕНЫЙ НОВЫХ ДАТ
    String КонтентСпинераНаАктивтиТабель= "";

    private static String ИмяТабеляФинал= "";

    private static  String  ДепартаментТабеляФинал= "";

    private static String UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя;

    TextView НазваниеДанныхВТабелеДниНедели;
    TextView НазваниеДанныхВТабелеСНИЛС;
    TextView НазваниеДанныхВТабелеФИО;
    String РежимРаботыСинхронизации="WIFI";
    ///TODO важно здесь созадються самиданные который и отпобрабються в ТАБЕЛЕ
    //////TODO ОБРАБОТКА САМИХ ДАННЫХ И УСТАНОВКА КЛИКА
    // EditText[] СамиДанныеТабеля= new EditText[31];
    EditText СамиДанныеТабеля;

    int ПосикДня;
    String НазваниеСтолбикаДляЛобкальногоОбноления= "";
    String НазваниеТабеля= "";
    String НазваниеЗагруженногТАбеля= "";
    int    СтаттусТабеля= 0;
    ////
    String ДробимДляТабеляГод,ДробимДляТебеляМесяц;
    /////TODO записываем в двухм мерный массив данные из табеля
    protected  View КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла;
    LinkedHashMap< Integer,String> ХЭШНазваниеДнейНедели = new LinkedHashMap<>();

    String СамиДанныеКурсораДляДней;

  int ТекущееПоложенияВТабелеДляСкрола;




    String МесяцДляЗагрузкиТабелей= "";
    String ГодДляЗагрузкиТабелей= "";
    String ПубличноеIDЗагрузкиТабелей= "";


    int МЕсяцДляКурсораТабелей;
    //TODO месяц и год для куросара
    int ГодДляКурсораТабелей;
    protected Button КнопкаНазад;
    protected Button КнопкаЛеваяПередвиженияПоДанным;
    protected Button КнопкаПраваяПередвиженияПоДанным;
    TextView ОбщееКоличествоВТабелеСотудников;



    int КоличествоДнейвЗагружаемойМесяце;
    boolean МыУжеВКодеУденияСотрудника=false;
    String ЛимитСоСмещениемДанных= "";
    int ИндексДвижениеТабеляСкролл=0;
    int ИндексДвижениеТабеляКнопки=0;
    String ОбщееКоличествоЛюдейВТабелеТекущем;
    HashMap<String,Long> ХэшЛовимUUIDIDНазваниеСтолбика        =new HashMap<>();;
    String ПолучениеЗначениеДоИзменения;
    String СамоЗначениеЯчейкиТабеля;

    final Cursor[] Курсор_ЗагружаемТабеляСозданный = {null};


    GridLayout GridLayoutВнутриСамТабель;
    ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными
    ///TODO компонеты табеля
    // TODO сам ТАБЕЛЬ активити

    Context КонтекстОдногоСотрудикаВТабеле;

    static Context КонтекстОдногоСотрудикаВТабелеВнешний;


    static Context КонтекстОдногоСотрудикаВТабелеДляСинхронизации;


    private static   int IDЧьиДанныеДляСотрудников;

    private static   String  ГодТабеляПослеПодбораУниверсальный;
    //////
    private int ЦифровоеИмяНовгоТабеля;

private int МЕсяцДляКурсораТабелейДЛяПермещения;


    TextView СловоТабель;

protected HorizontalScrollView HorizontalScrollViewВТабелеОдинСотрудник;

/*
private GestureDetector gestureDetectorКлассДляЖестов;





*/

// TODO: 06.05.2021
   // private SlidrInterface slidrInterface;
    // TODO: 06.05.2021 Переменные для свайпа

    private static  String НазваниеТабеляПослеУспешногоСозданиеСотрудника= "";

    private static String    UUIDТабеляПослеУспешногоСозданиеСотрудника= "";
    ////////
    private    Long UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников=0l;

    private static  String НазваниеТабеляПришелПослеСоздангоНового= "";

    private static  String  ДепартаментПришелПослеСоздангоНового= "";
    ///после успешной вставки сотрудника
 protected    String ПолноеИмяТабеляПослеСозданиеНовогоСотрудника;



    private static String ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки;
    private static   String UUIDТабеляКнопкаBACKУниверсальный= "";











    /////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try{

            super.onCreate(savedInstanceState);
            ////todo запрещает поворот экрана

            //     getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION  );
            //////todo настрока экрана
        /*    getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);*/
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);







            //////todo  конец настрока экрана
            /////todo данная настрока запрещает поврот экрана

            /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);


            // TODO: 24.05.2021 ВЫБОР КАКОЙ АКТИВТИ МАКЕТ ЗАГРУЗАТЬ НА САМСУНГ И НЕ НА САМСУНГ 

            if (Build.BRAND.toString().contains("Samsung") ||Build.BRAND.toString().contains("Galaxy")
                    || Build.BRAND.toString().contains("samsung") ||Build.BRAND.toString().contains("galaxy") ) {
                setContentView(R.layout.activity_main__tabel_four_colums_samsung);
            } else {
                setContentView(R.layout.activity_main__tabel_four_colums);
            }
            ////TODO ПЕРЕРДАЕМ КОНТЕКТ АКТИВИТИ ДЛЯ СИНХРОНИЗАЦИИ




            КонтекстОдногоСотрудикаВТабеле=this;

            КонтекстОдногоСотрудикаВТабелеВнешний=this;
            КонтекстОдногоСотрудикаВТабелеДляСинхронизации=this;


            // TODO: 06.05.2021 для ловли свайпов









            ((Activity) КонтекстОдногоСотрудикаВТабеле) .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            getSupportActionBar().hide(); ///скрывать тул бар

            /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
            ///TODO попытка открыть экран как full screan
            Log.d(this.getClass().getName(), "  onCreate(Bundle savedInstanceState)   MainActivity_Single_Tabely  ");
            // Locale locale = Locale.ROOT;
            ///todo данная код перерводи все актвивти на русский язык каленларь итд
            Locale locale = new Locale("rus");
            Locale.setDefault(locale);
            config =
                    getBaseContext().getResources().getConfiguration();
            config.setLocale(locale);
            createConfigurationContext(config);

//////





            КонтекстОдногоСотрудикаВТабеле=this;



            ///////
            /////







            ((Activity) КонтекстОдногоСотрудикаВТабеле) .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);

            ///TODO разное
            СпинерТАбельМЕсяцФинал = (Spinner) findViewById(R.id.СпинерТабельМесяц);


            СпинерТАбельДепартаментФинал = (Spinner) findViewById(R.id.СпинерТабельДепратамент);
            /////TODO КОМПОНЕТЫ ТАБЕЛЯ
            ///TODO главный контйренр табеля
            ГлавныйКонтейнерТабель = (LinearLayout) findViewById(R.id.ГлавныйКонтейнерТабель);

            ГлавныйКонтейнерТабель.removeAllViewsInLayout();

            /////TODO Скоролл Вид
            ScrollСамогоТабеля=(ScrollView) findViewById(R.id.ScrollViewСамТабеля);
            ///TODO на данной КНОПКЕ МЫ МОЖЕМ ДОБАВИТЬ СОТРУДНИКА К ТАБЕЛЮ ИЛИ СОЗДАТЬ НОВОГО СОТРУДНИКА









            /////////Круглая Кнопка

            ГлавныйВерхнийКонтейнер=(ConstraintLayout) findViewById(R.id.ГлавныйВерхнийКонтейнер);








            КнопкаЛеваяПередвиженияПоДанным=(Button) findViewById(R.id.imageViewВСамомТабелеЛеваяСтрелка);
            КнопкаПраваяПередвиженияПоДанным=(Button) findViewById(R.id.imageViewВСамомТабелеТабельПраваяСтрелка);
            ОбщееКоличествоВТабелеСотудников=(TextView) findViewById(R.id.textViewJОбщееКоличествоСотрудниковВТабеле);


            // TODO: 28.04.2021 кнопки вперед назад
            imageButtonДвижениеПоСотрудникамВТАбеле=(ImageButton) findViewById(R.id.imageButtonДвижениеПоСотрудникамВТАбеле);
            ////////
            imageButtonНазадПоСотрудникамВТАбеле=(ImageButton) findViewById(R.id.imageButtonНазадПоСотрудникамВТАбеле);








            ////
            ОбщееКоличествоВТабелеСотудников.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);

            ОбщееКоличествоВТабелеСотудников.setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);

            ОбщееКоличествоВТабелеСотудников.setPaintFlags( (ОбщееКоличествоВТабелеСотудников.getPaintFlags() | Paint.FAKE_BOLD_TEXT_FLAG));
///

            СловоТабель=(TextView) findViewById(R.id.textView3СловоТабель);


            СловоТабель.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);


            // СОЗДАНИЯ ТАБЕЛЯ СНАЧАЛА ИСТРОИЯ ПОТОМ НА БАЗЕ ЕГО СОЗЗДАНИЕ
            //////todo limit offset смеещние и огорничения загрузки данных
            ЛимитСоСмещениемДанных="0";
            ///todo создаем новый потоки елси он первый future

//todo кнопка назад
            КнопкаНазад=(Button) findViewById(R.id.imageViewСтрелкаВнутриТабеля);


            ///TODO ДАННЫЙ МЕТОД ЗАПУСКАЕТ СИНХРОНИЗАИЮ В ФОНОВОМ ПОТОКЕ БЕЗ ВИЗУАЛЬНОЙ ЧАСТИ ПОЛЬЗОВАТЛЮ НИЧЕГО НЕ ПОКАЗЫВАЕТ ДвижокОбменаДаннымиОфлайнсОнлайном, когда приложение уходит с перерднего края
            ///////TODO ТУТ ЗАПУСКАЕМ СИНХРОНИЗАЦИЮ В  ФОНЕ КОТОРАЯ НАХОДИТЬСЯ ЗАПУСКАЮЩИЙ МЕТОД В АКТИВИТИ  MainActivity_Single_Tabely() СОТРУДНИКИ






            ///gestureDetector=new GestureDetectorCompat(this,this);

//////
// TODO: 06.05.2021
            //slidrInterface= Slidr.attach(this);


        //    ГлавныйКонтейнерТабель.setOnTouchListener(this);




        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }














    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(this.getClass().getName(), "onRestart() " );


    }


    @Override
    protected void onStop() {
        super.onStop();
////TODO после как прошла СИНХРОНИЗАЦИЯ В ФОНЕ  ПЕЕРРИСОВЫВАЕМ КОМПОНЕТЫ РОБОЧЕГО СТОЛА
////TODO после как прошла СИНХРОНИЗАЦИЯ В ФОНЕ  ПЕЕРРИСОВЫВАЕМ КОМПОНЕТЫ РОБОЧЕГО СТОЛА

        //////TODO  данный код срабатывает когда произошда ошивка в базе

        ////////////////////
        if(ССылкаНаСозданнуюБазу.isOpen()) {
            if (ССылкаНаСозданнуюБазу.inTransaction()) {
                ССылкаНаСозданнуюБазу.endTransaction();
            }
            ///  ССылкаНаСозданнуюБазу.close();
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();











    }












    @Override
    protected void onStart() {
        super.onStart();
        Log.d(this.getClass().getName(), " onStart() " );
        ///TODO СОЗДАЕНИЕ ТАБЕЛЯ НА АКТИВИТИ

        try{
//TODO #0
            //TODO #1
            МетодПришлиПараметрыОтДругихАктивитиДляРаботыТабеля();
            //TODO #2
            МетодПриНАжатииНаКнопкуBACK();

            try{
            //TODO #4
            МетолСозданиеТабеляФинал(ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);//запускаем метод создание табеля

            /////////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }
            try{
            //TODO #5
            МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля(МесяцТабеляФинал,ТекущееПоложенияВТабелеДляСкрола);   ////раньше стояло 0




            /////////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }




////

            try{
            ///TODO запускаем метод ПОСЛЕ УСПЕШНОЙ ГЕНЕРАЦИИ ТАБЕЛЯ

            МетодПослеУспешнойГенерацииТабеля();

            /////////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }



            try{


                МетодОбработкиСвайповНаЭкране();



            /////////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }


// TODO: 24.05.2021 метод отработки поднятие клавиатуры


            МетодОтработкиПоднятияКлавиатуры();








            /////////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }

    }


// TODO: 24.05.2021  метд обоработки поднятия и апускания клавиатуры

    private void МетодОтработкиПоднятияКлавиатуры() {

    try{


        KeyboardVisibilityEvent.setEventListener(this, new KeyboardVisibilityEventListener() {
            @Override
            public void onVisibilityChanged(boolean isOpen) {
                ///
                if (isOpen) {
                  /*  Toast.makeText(getApplicationContext(),
                            " Клавиатур поднялась !!!!!!! "    , Toast.LENGTH_SHORT).show();
*/



                    ///////

                    Log.d(this.getClass().getName(), " ПолноеИмяТабеляПослеСозданиеНовогоСотрудника "+ПолноеИмяТабеляПослеСозданиеНовогоСотрудника+"\n"+
                            " ФИОДляТабеляНаАктивти " +ФИОДляТабеляНаАктивти);





                    МетолСозданиеТабеляФинал(ФИОДляТабеляНаАктивти);



                }else{
                    /*Toast.makeText(getApplicationContext(),
                            " Клавиатур опусталась  "    , Toast.LENGTH_SHORT).show();*/




                    ///////

                    Log.d(this.getClass().getName(), " ПолноеИмяТабеляПослеСозданиеНовогоСотрудника "+ПолноеИмяТабеляПослеСозданиеНовогоСотрудника+"\n"+
                            " ФИОДляТабеляНаАктивти " +ФИОДляТабеляНаАктивти);

                    МетолСозданиеТабеляФинал(ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);


                }

            }
        });




        /////////
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());

    }

}














    // TODO: 28.04.2021 обработка свайпов
    private void МетодОбработкиСвайповНаЭкране() {
        try{

// TODO: 30.04.2021 обрабаотывает TOCUCH   создание свайпов

///
            Log.d(this.getClass().getName(), "   setOnTouchListenera ");



            ScrollСамогоТабеля.setOnTouchListener(new OnTouchListener() {


                // TODO: 07.05.2021 Точу

                final float[] downy = {0l};
                //

                final float[] downx = {0l};


                Long  getDownTime=0l;
                Long  getEventTime=0l;

    @Override
    public boolean onTouch(View v, MotionEvent event) {

        Log.d(this.getClass().getName(),"Свайп просто сфайп");

        if (downy[0] ==0l) {
            downy[0] = event.getY();
        }

        ////
        if (downx[0]==0l){
            downx[0]=event.getX();

        }


        if (getDownTime==0) {
            getDownTime = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
        }


        float     upy,upx;

        float deltaY,deltax;

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: // нажатие
                Log.d(this.getClass().getName(),"Movement occurred outside bounds " +
                        "of current screen element ACTION_DOWN");



                break;
            case MotionEvent.ACTION_MOVE: // движение
                Log.d(this.getClass().getName(),"Movement occurred outside bounds " +
                        "of current screen element ACTION_MOVE");
                break;
            case MotionEvent.ACTION_UP: // отпускание
            case MotionEvent.ACTION_CANCEL:
                Log.d(this.getClass().getName(),"Movement occurred outside bounds " +
                        "of current screen element ACTION_UP ACTION_CANCEL ");


                upy=event.getY();
                deltaY=upy- downy[0];
                //////
                upx=event.getX();
                deltax=upx-downx[0];

                // TODO: 07.05.2021  формула
                final int MIN_DISTANCEY=50;
                ////
                final int MIN_DISTANCEX=50;

                getEventTime = TimeUnit.MILLISECONDS.toSeconds( System.currentTimeMillis());


                float duration = getEventTime - getDownTime;

           StringBuffer БуферФиналВремениПрошлло=      new StringBuffer(String.valueOf(duration));
           /////
           int ФиналСколькоПрошллоВремени=     Integer.parseInt(БуферФиналВремениПрошлло.substring(0,1));
                // TODO: 19.05.2021 конец прокрутки

                int КонецПрокрутки=      v.getBottom();
                int НачалоПрокрутки=      v.getTop();

                View lastChild = ScrollСамогоТабеля.getChildAt(ScrollСамогоТабеля.getChildCount() - 1);
                int bottom = lastChild.getBottom() + ScrollСамогоТабеля.getPaddingBottom();
                int sy = ScrollСамогоТабеля.getScrollY();
                int sh = ScrollСамогоТабеля.getHeight();
                int delta = bottom - (sy + sh);


                // TODO: 08.05.2021  Y

                if (Math.abs(deltaY) > MIN_DISTANCEY ) {
                    if (deltaY > 0 && delta>10) {

                        МетодСвайпВпередПоДАнным();
                        //
                        downy[0]=0;



                    }else if  ( deltaY<0 && delta==0) {
                        ///TODO плюс время



                        МетодСвайпНазаПоДанным();

                        ////
                        downy[0]=0;
                        //////////////
                        // TODO: 07.05.2021  обработка горизонта X
                    }
                    /////

                    // TODO: 09.05.2021  при успешном срабоатывании true
                    return true;



                }else {

                    // TODO: 07.05.2021  обработка горизонта X

            /*        if (Math.abs(deltax)>MIN_DISTANCEX){
                        if(deltax>0){
                            // TODO: 07.05.2021 вперед по дпнным
                            МетодСвайпВпередПоДАнным();
                            //
                            downx[0]=0;
                        }else if(deltax<0){
                            // TODO: 07.05.2021 движение назад
                            МетодСвайпНазаПоДанным();
                            //
                            downx[0]=0;
                        }
                        // TODO: 09.05.2021  при успешном срабоатывании true
                        return true;

                    }*/


                }

                // TODO: 19.05.2021 обнуялем
                getDownTime=0l;

                break;
        }

        return false;
    }




});































            // TODO: 29.04.2021 код обработки кнопок для перемещения по табелям
            Handler handler=new Handler();
            /////
            imageButtonДвижениеПоСотрудникамВТАбеле .setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // TODO: 28.04.2021 Запускаем Загрузку Следуюзегосотрудника в табель МИНУС


                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            ///////
                            imageButtonДвижениеПоСотрудникамВТАбеле.setBackgroundColor(Color.parseColor("#D87093"));

                        }
                    },50);
                    /////////////////////

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            imageButtonДвижениеПоСотрудникамВТАбеле.setBackgroundColor(Color.parseColor("#F5FFFA"));

                            ///todo вырвиваем индексы
                            if (ТекущееПоложенияВТабелеДляСкрола == ОбщееКоличествоСОтрудниковДляСкролаПотабелю) {
                                ТекущееПоложенияВТабелеДляСкрола=0;
                                // ТекущееПоложенияВТабелеДляСкрола=  Курсор_ЗагружаемТабеляСозданный[0].getPosition();

                            }


                            if (ТекущееПоложенияВТабелеДляСкрола>0) {
                                ТекущееПоложенияВТабелеДляСкрола--;


                            }
                            if (ТекущееПоложенияВТабелеДляСкрола==1) {
                                ТекущееПоложенияВТабелеДляСкрола--;


                            }


                            // TODO: 28.04.2021


                            //TODO #5
                            МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля(МесяцТабеляФинал,ТекущееПоложенияВТабелеДляСкрола);

                            ///TODO запускаем метод ПОСЛЕ УСПЕШНОЙ ГЕНЕРАЦИИ ТАБЕЛЯ

                            МетодПослеУспешнойГенерацииТабеля();



                        }
                    },100);




                }///ScrollСамогоТабеля  ///ГлавныйКонтейнерТабель






            });

            // TODO: 28.04.2021

            // TODO: 28.04.2021 Запускаем Загрузку Следуюзегосотрудника  Увеличения в табель ПЛЮС

            imageButtonНазадПоСотрудникамВТАбеле .setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    /////

                    Handler handler=new Handler();
                    // TODO: 28.04.2021 Запускаем Загрузку Следуюзегосотрудника в табель МИНУС

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            imageButtonНазадПоСотрудникамВТАбеле.setBackgroundColor(Color.parseColor("#D87093"));
                        }
                    },50);

/////////////////////////////

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            imageButtonНазадПоСотрудникамВТАбеле.setBackgroundColor(Color.parseColor("#F5FFFA"));




                            if (ТекущееПоложенияВТабелеДляСкрола < ОбщееКоличествоСОтрудниковДляСкролаПотабелю) {
                                ТекущееПоложенияВТабелеДляСкрола++;


                            }
                            ///////////////////////

                            if (ТекущееПоложенияВТабелеДляСкрола <= ОбщееКоличествоСОтрудниковДляСкролаПотабелю) {

                                //TODO #5
                                МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля(МесяцТабеляФинал, ТекущееПоложенияВТабелеДляСкрола);

                                ///TODO запускаем метод ПОСЛЕ УСПЕШНОЙ ГЕНЕРАЦИИ ТАБЕЛЯ

                                МетодПослеУспешнойГенерацииТабеля();


                            }

                            // TODO: 28.04.2021 ПЕРЕД ПЕРЕДВИЖЕНЕИМ ПРОВЕРЯЕМ ЕСЛИ ЗНАЧЕНИЯ РАВНЫ ТО ОБНУЛЯЕМ ИНДЕКС ПЕРЕМЕЖЕНИЯ












                        }
                        // TODO: 28.04.2021




                    },100);




                }

            });



            /////////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }
    }




















    private void МетодПришлиПараметрыОтДругихАктивитиДляРаботыТабеля() {
        try {
            Intent ИнтентПришелМЕсяцТабеля = getIntent();
            if (МесяцТабеляФинал==null) {
                МесяцТабеляФинал = ИнтентПришелМЕсяцТабеля.getStringExtra("ПередаемСозданнуюДатуНовогоТабеля");
            }

            Log.d(this.getClass().getName(), " МесяцТабеляФинал :" + МесяцТабеляФинал);

            /////
            Intent ИнтентПришелИмяТабеля = getIntent();
            ИмяТабеляФинал = ИнтентПришелМЕсяцТабеля.getStringExtra("ПередаемСозданнуюНазваниеТабеля");
            Log.d(this.getClass().getName(), " ИмяТабеляФинал :" + ИмяТабеляФинал);
            /////
            Intent ИнтентПришелДепаартаментТабеля = getIntent();
            ДепартаментТабеляФинал = ИнтентПришелМЕсяцТабеля.getStringExtra("ПередаемДепартаментФинал");
            Log.d(this.getClass().getName(), " ДепартаментТабеляФинал :" + ДепартаментТабеляФинал);
            ////
            Intent ИнтентПришелПолноеИмяТабеля = getIntent();

            if (ПолноеИмяТабеляПослеСозданиеНовогоСотрудника==null) {
                ПолноеИмяТабеляПослеСозданиеНовогоСотрудника = ИнтентПришелМЕсяцТабеля.getStringExtra("ПолноеНазваниеТабеляФинал");
                Log.d(this.getClass().getName(), " ПолноеИмяТабеляПослеСозданиеНовогоСотрудника " + ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);
                ////
            }


            ///TODO ПОЛНОЕ НАЗВАНИЕ ТАБЕЛЯ ПОСЛЕ УСПЕШНОЙ СОЗДАНОГО СОТРУДНИКА И ПЕРЕДВЕМ СЮДА ЕГО ИМЯ ТАБЕЛЯ ПОЛНОЕ
            Intent ИнтентПришелПолноеИмяТабеляПослеУспешнойВставки = getIntent();
            ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки = ИнтентПришелПолноеИмяТабеляПослеУспешнойВставки.getStringExtra("ПолноеИмяТабеляПослеСозданиеНовогоСотрудника");
            Log.d(this.getClass().getName(), " ПолноеИмяТабеляПослеСозданиеНовогоСотрудника " + ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки);


            Intent ИнтентПришелUUIDНазванияТабеля = getIntent();
            String ПроверкаUUIDТабеляФинал = ИнтентПришелUUIDНазванияТабеля.getStringExtra("ПередаваемыйИзКнопкиПолучаемUUIDТабеля");
            /////
            ////todo если не пришел uuid запускаем его с дгурим uuid

            UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя = ИнтентПришелUUIDНазванияТабеля.getStringExtra("ПередаваемыйИзКнопкиПолучаемUUIDТабеля");
            Log.d(this.getClass().getName(), "UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя" + UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя);

            ////
            Intent ИнтентПришелПослеСоздангоНовогоСотрудникаНазваниеТабеля = getIntent();
            НазваниеТабеляПослеУспешногоСозданиеСотрудника = ИнтентПришелПослеСоздангоНовогоСотрудникаНазваниеТабеля.getStringExtra("НазваниеТабеляВКоторомИНадоСоздатьНовогоСотрудника");
            Log.d(this.getClass().getName(), " НазваниеТабеляПослеУспешногоСозданиеСотрудника " + НазваниеТабеляПослеУспешногоСозданиеСотрудника);
            ////
            Intent ИнтентПришелПослеСоздангоНовогоСотрудникаUUID = getIntent();
            UUIDТабеляПослеУспешногоСозданиеСотрудника = ИнтентПришелПослеСоздангоНовогоСотрудникаUUID.getStringExtra("UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника");
            Log.d(this.getClass().getName(), " UUIDТабеляФинал:" + UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя);
            ////
            Intent ИнтентПришелПослеСоздангоНовогоНазваниеТабеля = getIntent();
            НазваниеТабеляПришелПослеСоздангоНового = ИнтентПришелПослеСоздангоНовогоСотрудникаUUID.getStringExtra("НазваниеМесяцаТабеляВКоторомИНадоСоздатьНовогоСотрудника");
            Log.d(this.getClass().getName(), " НазваниеТабеляПришелПослеСоздангоНового  " + НазваниеТабеляПришелПослеСоздангоНового);
            ////
            ////
            Intent ИнтентПришелПослеСоздангоНовогоДепартамент = getIntent();
            ДепартаментПришелПослеСоздангоНового = ИнтентПришелПослеСоздангоНовогоДепартамент.getStringExtra("ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника");
            Log.d(this.getClass().getName(), "  ДепартаментПришелПослеСоздангоНового   " + ДепартаментПришелПослеСоздангоНового);
            ////
            Intent ИнтентПришелПослеUUIDТабеляПослеПодбораУниверсальный = getIntent();
            String UUIDТабеляПослеПодбораУниверсальный = ИнтентПришелПослеСоздангоНовогоДепартамент.getStringExtra("UUIDТабеляПослеПодбораУниверсальный");
            Log.d(this.getClass().getName(), "  ДепартаментПришелПослеСоздангоНового   " + ДепартаментПришелПослеСоздангоНового);
            ////

            Intent ИнтентПришелПослеГОДТабеляПослеПодбораУниверсальный = getIntent();
            ГодТабеляПослеПодбораУниверсальный = ИнтентПришелПослеСоздангоНовогоДепартамент.getStringExtra("ГодДляЗагрузкиТабелей");
            Log.d(this.getClass().getName(), " ГодТабеляПослеПодбораУниверсальный  " + ГодТабеляПослеПодбораУниверсальный);


            ///todo значения из Всех Сотрудников Табеля
            Intent ИнтентПришелПослеИзВсехСотрудниов = getIntent();
            if(ПолноеИмяТабеляПослеСозданиеНовогоСотрудника==null) {

                ПолноеИмяТабеляПослеСозданиеНовогоСотрудника = ИнтентПришелПослеИзВсехСотрудниов.getStringExtra("ДепартаментТабеляИзВсехСотрудниковВТАбеле");//ДепартаментПришелПослеСоздангоНового
                Log.d(this.getClass().getName(), "  ДепартаментПришелПослеСоздангоНового   " + ДепартаментПришелПослеСоздангоНового);
                ////
            }
            Intent ИнтентПришелПослеИзВсехСотрудниовUUID = getIntent();

            if (UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников==0l) {
                UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников = ИнтентПришелПослеИзВсехСотрудниовUUID.getLongExtra("UUIDТабеляФиналПослеВыбораИзВсехСотрудниковВТАбеле", 0);
            }

            Log.d(this.getClass().getName(), "  UUIDТабеляПослеУспешногоСозданиеСотрудника   " + UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников);
            ////

            ///todo значения из Всех Сотрудников Табеля
            Intent ИнтентПришелПослеИзВсехСотрудниовМесяц = getIntent();
            if (МесяцТабеляФинал==null) {
                МесяцТабеляФинал = ИнтентПришелПослеИзВсехСотрудниовМесяц.getStringExtra("МесяцТабеляФиналИзВсехСотрудниковВТАбеле");
            }
            Log.d(this.getClass().getName(), "  МесяцТабеляФинал  " + МесяцТабеляФинал);
            ////
            ///todo значения из Всех Сотрудников Табеля







            ///todo значения из Всех конец  Сотрудников Табеля

            //TODO  ДАННЫЙ КОД ПРОВЕРЯЕТ ЕЛСИ ЭТО ТАБЕЛЬ ЗАГРУЖАЕТЬСЯ ПОСЛЕ СОЗДАНИЕ НОВОГО СОТРУДНИКА ,,, ТО ПЕРЕПРИСВАЕМВАЕМ ЕГО ОТ ДРУГОЙ ПЕРЕРМЕНОЙ КОТОРАЯ
            // ЗАПОЛЯНЕТЬСЯ ПОСЛЕ УСПЕГШНОЙ СОЗДАННОЙ НАЗВАЕНИ МЕМСЯЦА

            if ( UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя==null){
                UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя= UUIDТабеляПослеПодбораУниверсальный;
            }

            if (МесяцТабеляФинал==null){
                МесяцТабеляФинал=НазваниеТабеляПришелПослеСоздангоНового;
            }
            //todo департамент
            if (ДепартаментТабеляФинал==null ){
                ДепартаментТабеляФинал=ДепартаментПришелПослеСоздангоНового;
            }
            if (ПолноеИмяТабеляПослеСозданиеНовогоСотрудника ==null){
                ПолноеИмяТабеляПослеСозданиеНовогоСотрудника = ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки ;
            }

            //todo после добавление сотрудник асуществуещего ---- ТУТ ПОСЛЕ КАК ТЫ ДОБАВИЛИ УЖЕ СУЩЕСТВУЮЩИХ СОТРУДНИКОВ В ТАБЕЛЬ
            Intent ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника = getIntent();
            ////////
            if (МесяцТабеляФинал==null) {
                МесяцТабеляФинал = ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.getStringExtra("МесяцТабеляПослеПодбора");
                Log.d(this.getClass().getName(), "  МесяцТабеляФинал " + МесяцТабеляФинал);
                ////
                if (ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки==null) {
                    ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки = ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.
                            getStringExtra("ПолноеНазваниеЗагруженногТАбеляПослеПодбора");
                    Log.d(this.getClass().getName(), " ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки " + ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки);
                }
                ///////
                if (ДепартаментПришелПослеСоздангоНового==null) {
                    ДепартаментПришелПослеСоздангоНового = ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.getStringExtra("ДепартаментТабеляПослеПодбора");
                    Log.d(this.getClass().getName(), "  ДепартаментПришелПослеСоздангоНового   " + ДепартаментПришелПослеСоздангоНового);
                }
                ////
                if ( UUIDТабеляПослеУспешногоСозданиеСотрудника ==null) {
                    UUIDТабеляПослеУспешногоСозданиеСотрудника = ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.getStringExtra("UUIDТабеляПослеПодбораУниверсальный");
                    Log.d(this.getClass().getName(), "  UUIDТабеляПослеУспешногоСозданиеСотрудника  " + UUIDТабеляПослеУспешногоСозданиеСотрудника);
                }
                if ( UUIDТабеляПослеУспешногоСозданиеСотрудника ==null) {
                    UUIDТабеляПослеУспешногоСозданиеСотрудника = ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.getStringExtra("UUIDТабеляПослеПодбора");
                    Log.d(this.getClass().getName(), "  UUIDТабеляПослеУспешногоСозданиеСотрудника  " + UUIDТабеляПослеУспешногоСозданиеСотрудника);
                }
                if ( UUIDТабеляПослеУспешногоСозданиеСотрудника ==null) {
                    UUIDТабеляПослеУспешногоСозданиеСотрудника = ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.getStringExtra("UUIDТабеляФиналПослеВыбораИзВсехСотрудниковВТАбеле");
                    Log.d(this.getClass().getName(), "  UUIDТабеляПослеУспешногоСозданиеСотрудника  " + UUIDТабеляПослеУспешногоСозданиеСотрудника);
                }

                if (ПолноеИмяТабеляПослеСозданиеНовогоСотрудника==null) {
                    ПолноеИмяТабеляПослеСозданиеНовогоСотрудника= ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.
                            getStringExtra("ПолноеНазваниеЗагруженногТАбеляПослеПодбора");
                    Log.d(this.getClass().getName(), " ПолноеИмяТабеляПослеСозданиеНовогоСотрудника " + ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);
                }
///todo если имя табеля пустое полслен созадени нового сотрудника по присваемое ему имя от дургой переменой
                Log.d(this.getClass().getName(), "   МесяцТабеляФинал  " + МесяцТабеляФинал +
                        "    ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки   " + ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки+
                        "  ДепартаментПришелПослеСоздангоНового " + ДепартаментПришелПослеСоздангоНового + "  UUIDТабеляПослеУспешногоСозданиеСотрудника  "
                        + UUIDТабеляПослеУспешногоСозданиеСотрудника );
            }

            if (UUIDТабеляПослеУспешногоСозданиеСотрудника==null){
                UUIDТабеляПослеУспешногоСозданиеСотрудника=UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя;
            }
            Log.d(this.getClass().getName(), "  UUIDТабеляПослеУспешногоСозданиеСотрудника  " + UUIDТабеляПослеУспешногоСозданиеСотрудника);
////TODO UUID ПОСЛЕ ВСТАВКИ НОВГО СОТРУДНИКА


////todo ДАНЫЕ ДДАНЫЕ ПРИХОДЯТ КОГДА МЫ НА ПРДЫДУЩЕМ КВТИВАИТИ СОЗДАНИЕ НОВОГО СОТРУДНИКА ИЛИ ВЫБОР ИЗ УЖЕ СУЩЕСТВУЮЩИХ

            ///////////
            if(UUIDТабеляКнопкаBACKУниверсальный!=null) {
                if (UUIDТабеляКнопкаBACKУниверсальный.length() < 1) {
                    UUIDТабеляКнопкаBACKУниверсальный = ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.getStringExtra("UUIDТабеляКнопкаBACKУниверсальный");
                    Log.d(this.getClass().getName(), "  UUIDТабеляКнопкаBACKУниверсальный  " + UUIDТабеляКнопкаBACKУниверсальный);
                }

            }

            ///////////
            if(ПолноеИмяТабеляПослеСозданиеНовогоСотрудника==null){
                ПолноеИмяТабеляПослеСозданиеНовогоСотрудника = ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.getStringExtra("ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника");
                Log.d(this.getClass().getName(), "  ПолноеИмяТабеляПослеСозданиеНовогоСотрудника " +ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);
            }

//////todo ПРИШЛО НА SINGLE TANEL ПО СОТРУДНИКУ
            IDЧьиДанныеДляСотрудников = ИнтентПришелПослеДобавлениеУжеСуществуюещегоСотрудника.getIntExtra("IDЧьиДанныеДляСотрудников",0);
            Log.d(this.getClass().getName(), "  IDЧьиДанныеДляСотрудников  " +IDЧьиДанныеДляСотрудников);








            //////todo дополнтельные данные которые нужно перебросить далеее в другие актвити и ДАЛЕЕ МЕТКА ТАБЕЛЯ
            Intent Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее = getIntent();

            if(МесяцТабеляФинал==null) {
                МесяцТабеляФинал = Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getStringExtra("ПередаемСозданнуюДатуНовогоТабеля");
            }

            if( ДепартаментПришелПослеСоздангоНового==null) {

                ДепартаментПришелПослеСоздангоНового = Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getStringExtra("ПередаемДепартаментФинал");
            }
            if(ДепартаментПришелПослеСоздангоНового==null) {
                ДепартаментПришелПослеСоздангоНового = Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getStringExtra("ПолноеНазваниеТабеляФинал");
            }
            if (UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя ==null ) {
                UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя = Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getStringExtra(("ПередаваемыйИзКнопкиПолучаемUUIDТабеля"));

            }



                UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников=Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getLongExtra("UUIDТабеляПослеПодбораУниверсальный",0l);



            Log.d(this.getClass().getName(), " UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников  "+UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников);


            /////TODO ЕСЛИ НЕ НАШЛИ ДРУГ ДРУГА

            if (ГодТабеляПослеПодбораУниверсальный == null){
                ГодТабеляПослеПодбораУниверсальный = Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getStringExtra("ГодТабеляФиналИзВсехСотрудниковВТАбеле");
            }


            ///TODO цифровоеимя табеля
            if ( PUBLIC_CONTENT.ЦифровоеИмяНовгоТабеля==null) {
                PUBLIC_CONTENT.ЦифровоеИмяНовгоТабеля = Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getStringExtra("ЦифровоеИмяНовгоТабеля");
            }


            if (ЦифровоеИмяНовгоТабеля==0) {
                ЦифровоеИмяНовгоТабеля= Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getIntExtra("ЦифровоеИмяНовгоТабеля",0);
            }


            //////todo  RКОНЕЦ дополнтельные данные которые нужно перебросить далеее в другие актвити и ДАЛЕЕ МЕТКА ТАБЕЛЯ
            if (ЦифровоеИмяНовгоТабеля==0) {
                ЦифровоеИмяНовгоТабеля= Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getIntExtra("ЦифровоеИмяНовгоТабеляБольШИеБуквыАктивти",0);
            }


// TODO: 29.04.2021 getiD


            if (ТекущееПоложенияВТабелеДляСкрола==0) {
                ТекущееПоложенияВТабелеДляСкрола = Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getIntExtra("setIDСамогоТабеляВКотромМыНаходились", 0);
            }

          /*  if (ТекущееПоложенияВТабелеДляСкрола==0) {
                ТекущееПоложенияВТабелеДляСкрола= Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getIntExtra("ИндификаторПередвиженияПоТабелюСвайпы",0);
            }*/


            Log.d(this.getClass().getName(), " Конец Получение Данных " +  PUBLIC_CONTENT.ЦифровоеИмяНовгоТабеля+ "  PUBLIC_CONTENT.ЦифровоеИмяНовгоТабеля "+
                    " ЦифровоеИмяНовгоТабеля " +ЦифровоеИмяНовгоТабеля + "   ТекущееПоложенияВТабелеДляСкрола " +  ТекущееПоложенияВТабелеДляСкрола);







                МЕсяцДляКурсораТабелейДЛяПермещения = Интент_ДополнительныеПришлиДанныеКоторыеНужноПроброситьДалее.getIntExtra("МЕсяцДляКурсораТабелей", 0);















        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }






    //todo метод возврата к предыдущему активти
    private void МетодПриНАжатииНаКнопкуBACK() {
        try {


            ///////

            КнопкаНазад.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    МетодЗапускаетСотрудниковПослеУспешногоУдалениеСотрудника();
                    ////
                    ///finishAffinity();

                }


            });
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


    }








    //TODO хдесь мы запускаем метод создание и обработка самого табеля
    private void МетолСозданиеТабеляФинал( @NonNull  String ВнутрениеЗначениеСФОилиПриСменеФИОсотрудника) {
        try{
            ////////todo заполняем спинер первый дата табеля
            //   МассивДляВыбораСпинераДаты.clear();///TODO ОЧИЩАЕМ ЫВРХИЙ СПИНЕР
            /////////TODO ЗАПОЛНЯЕМ
            МассивДляВыбораСпинераДаты.clear();
            МассивДляВыбораСпинераДаты=new ArrayList<>();
            МассивДляВыбораСпинераДаты.add(МесяцТабеляФинал);
            Log.d(this.getClass().getName(), " МассивДляВыбораВСпинерТабельФинал " +МассивДляВыбораСпинераДаты.toString());
            // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
            /////
            ArrayAdapter<String> АдаптерДляСпинераТабельФинал = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_activated_1, МассивДляВыбораСпинераДаты);
            // Определяем разметку для использования при выборе элемента
            АдаптерДляСпинераТабельФинал.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            /////



            // Применяем адаптер к элементу spinner
            СпинерТАбельМЕсяцФинал.setAdapter(АдаптерДляСпинераТабельФинал);
            ////TODO вненшний вид табеля




            СпинерТАбельМЕсяцФинал.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    //////меняем цвет спинера
                    try {
                        for (int i=0;i<СпинерТАбельМЕсяцФинал.getCount();i++) {
                            ////
                            ((TextView) parent.getChildAt(0)).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);//Typeface boldTypeface = Typeface.defaultFromStyle(Typeface.BOLD);
                            ((TextView) parent.getChildAt(0)).setPaintFlags( ((TextView) parent.getChildAt(0)).getPaintFlags() | Paint.FAKE_BOLD_TEXT_FLAG);
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                            ((TextView) parent.getChildAt(0)).setBackgroundResource(R.drawable.textlines_tabel);
                            ((TextView) parent.getChildAt(0)).setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                            ((TextView) parent.getChildAt(0)).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
                            //////
                            //////todo полученое выбраное ЗНАЧЕНИЕ ИЗ СПИНЕРПА ПЕРЕДАЕМ ДАЛЬШЕ
                            КонтентСпинераНаАктивтиТабель= String.valueOf(((TextView) parent.getChildAt(0)).getText()); /////ОПРЕДЕЛЯЕМ ТЕКУЩЕЕ ЗНАЧЕНИЕ ВНУТИРИ СПЕНИРА
                            Log.d(this.getClass().getName(), " КонтентСпинераНаАктивтиТабель  " +КонтентСпинераНаАктивтиТабель);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }

                    ////что быврали
//поймать ошибку всего классаIOException | MyException e    NumberFormatException
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    Log.e(this.getClass().getName(), " ПолученноеЗначениеИзСпинераДата  " );
                }
            });




            ////////todo заполняем спинер второй  департамент табеля
            //     МассивДляВыбораВСпинерДепартамент.clear();//TODO ОЧИАЩЕМ СПИНЕР С НАЗВАНИЕМ ТАБЕЛЯ
            МассивДляВыбораВСпинерДепартамент.clear();
            МассивДляВыбораВСпинерДепартамент=new ArrayList<>();
            ///
            МассивДляВыбораВСпинерДепартамент.add( ВнутрениеЗначениеСФОилиПриСменеФИОсотрудника );
            Log.d(this.getClass().getName(), " МассивДляВыбораВСпинерТабельФинал " +МассивДляВыбораВСпинерДепартамент.toString());
            // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
            ArrayAdapter<String> АдаптерДляСпинераТабельФиналДепартамент = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_activated_1,МассивДляВыбораВСпинерДепартамент);
            // Определяем разметку для использования при выборе элемента
            АдаптерДляСпинераТабельФинал.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            /////


            // Применяем адаптер к элементу spinner
            СпинерТАбельДепартаментФинал.setAdapter(АдаптерДляСпинераТабельФиналДепартамент);



            ////TODO вненшний вид табеля
            СпинерТАбельДепартаментФинал.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    //////меняем цвет спинера
                    try {
                        for (int i=0;i<СпинерТАбельДепартаментФинал.getCount();i++) {
                            ///////ВЫДЕЛЕМ ЖИРНЫМ ЦВЕТОМ ДАТЫ((TextView) parent.getChildAt(0)).setTextColor(Color.parseColor("#708090"));

                            ((TextView) parent.getChildAt(0)).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);//Typeface boldTypeface = Typeface.defaultFromStyle(Typeface.BOLD);
                            ((TextView) parent.getChildAt(0)).setPaintFlags( ((TextView) parent.getChildAt(0)).getPaintFlags() | Paint.FAKE_BOLD_TEXT_FLAG);
                            ((TextView) parent.getChildAt(0)).setBackgroundResource(R.drawable.textlines_tabel);
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                            ((TextView) parent.getChildAt(0)).setGravity(Gravity.CENTER_VERTICAL |Gravity.CENTER_HORIZONTAL);
                            ((TextView) parent.getChildAt(0)).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
                            //////
                            КонтентСпинераНаАктивтиТабель= String.valueOf(((TextView) parent.getChildAt(0)).getText()); /////ОПРЕДЕЛЯЕМ ТЕКУЩЕЕ ЗНАЧЕНИЕ ВНУТИРИ СПЕНИРА
                            Log.d(this.getClass().getName(), " КонтентСпинераНаАктивтиТабель  " +КонтентСпинераНаАктивтиТабель);



                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }

                    ////
                    //

                    СпинерТАбельДепартаментФинал.setClickable(false);
                    СпинерТАбельДепартаментФинал.setFocusable(false);

                    ////что быврали
//поймать ошибку всего классаIOException | MyException e    NumberFormatException
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    Log.e(this.getClass().getName(), " ПолученноеЗначениеИзСпинераДата  " );
                }
            });


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }






    //TODO заполения табеля из базы через элемент TableLauy

    private void МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля(String  МесяцТабеляФинал ,int ЕслиСмещениеВдАнныхДляСкрола) {
        //////


        final Cursor[] Курсор_ЗагружаемТабеляСозданныйТОлькоОбшееКоличество = {null};



        try{
            ///TODO курсор который поттягиваемд данные избазы табель
            Log.d(this.getClass().getName(), " МесяцТабеляФинал " + МесяцТабеляФинал);


////TODO КУРСОР ЗАГРУЖАЕТ НА АКТИВИТИ ДАННЫЕ УЖЕ СУЩЕТСТУЕЮЩЕИ ДАННЫЕ НА ТАБЕЛЬ
            МесяцДляЗагрузкиТабелей= String.valueOf(МетодПоказатьМесяцДляЗАписивОднуКолонку(МесяцТабеляФинал));

            ГодДляЗагрузкиТабелей= String.valueOf(МетодПоказатьГодДляЗАписивОднуКолонку(МесяцТабеляФинал));

            ПубличноеIDЗагрузкиТабелей= PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID;


            ///todo условие загрузка действуещнго табеля или тот ЖЕ ТАБЕЛЬ ,,,НО ПОСЛЕ СОЗДАНИЯ НА ЭТОТ ТАБЕЛЬ СОТРУДНИКА ДОПОЛНИТЕЛЬНОГО И ДЕЛАЕМ УСЛОВИЕ
            //TODO месяц и год для куросара
            МЕсяцДляКурсораТабелей=МетодПолучениниеМесяцДляКурсора( МесяцТабеляФинал);
            //TODO месяц и год для куросара
            ГодДляКурсораТабелей=МетодПолучениниеГодДляКурсора( МесяцТабеляФинал);
            //////
            Log.d(this.getClass().getName()," МЕсяцДляКурсораТабелей "+МЕсяцДляКурсораТабелей+" ГодДляКурсораТабелей " +ГодДляКурсораТабелей +
                    " UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников " +UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников+" МЕсяцДляКурсораТабелейДЛяПермещения " +МЕсяцДляКурсораТабелейДЛяПермещения);
////todo загружем созданные табеля из базы после успешного добавления нового сотрдуника
            ////TODO ЕСДИ ДАННЫХ НЕТ НЕ И НЕЧЕГО НАЧИНАТЬ ВЫБОРКУ ДАННЫХ ИЗ БАЗЫЫ ДепартаментТабеляФинал

            if (МЕсяцДляКурсораТабелейДЛяПермещения==0) {
                МЕсяцДляКурсораТабелейДЛяПермещения=МЕсяцДляКурсораТабелей;
            }


///TODO СЮДА ЗАХОДИМ ПРОСТО БЕЗ СОЗДАНИЕ НОВОГО ЗАГРУЖАЕТ УЖЕ СОЗДАННОЕ ТАБЕЛЯ В БАЗЕ "status_send", "Удаленная"
            CountDownLatch countDownLatchПриМеремещенииПоДАнным=new CountDownLatch(2);

         Future futureПолучениеДанныхВТАбелеСотрудникаКонкретного=Executors.newSingleThreadExecutor().submit(new Callable<Object>() {
             @Override
             public Object call() throws Exception {




                    try{



                        // TODO: 28.04.2021 получение
                        // TODO: 28.04.2021 получение
                        // TODO: 28.04.2021  общее количкство сотрдников
                        Курсор_ЗагружаемТабеляСозданныйТОлькоОбшееКоличество[0]=null;
                        ////////////
                        Курсор_ЗагружаемТабеляСозданныйТОлькоОбшееКоличество[0] =
                                new MODEL_synchronized(getApplicationContext()).МетодЗагружетУжеготовыеТабеляДляСкролаПОТабелюТолькоКоличествоСТорочек(КонтекстОдногоСотрудикаВТабеле,
                                        ЦифровоеИмяНовгоТабеля,МЕсяцДляКурсораТабелейДЛяПермещения, ГодДляКурсораТабелей);




                        ////////
                        ОбщееКоличествоСОтрудниковДляСкролаПотабелю=0;
                        ///////////////////////////

                        if (   Курсор_ЗагружаемТабеляСозданныйТОлькоОбшееКоличество[0].getCount()>0) {
                            Курсор_ЗагружаемТабеляСозданныйТОлькоОбшееКоличество[0].moveToFirst();

                            ОбщееКоличествоСОтрудниковДляСкролаПотабелю=     Курсор_ЗагружаемТабеляСозданныйТОлькоОбшееКоличество[0].getCount();


                            ///
                            Log.d(this.getClass().getName(), "ОбщееКоличествоСОтрудниковДляСкролаПотабелю " + ОбщееКоличествоСОтрудниковДляСкролаПотабелю);

                            countDownLatchПриМеремещенииПоДАнным.countDown();

                        }


///TODO метод загружет уже готовые табеля на АКТИВТИ
                        if (ЕслиСмещениеВдАнныхДляСкрола>=1 && UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников>0l) {
                            // TODO: 28.04.2021 движение назад


                            // TODO: 07.05.2021 получение UUID дл я струдника из тпбелья




                            // TODO: 07.05.2021



                                Курсор_ЗагружаемТабеляСозданный[0]=null;

                                ////////////////////
                                Курсор_ЗагружаемТабеляСозданный[0] = new MODEL_synchronized(getApplicationContext()).МетодЗагружетУжеготовыеТабеля(КонтекстОдногоСотрудикаВТабеле,
                                        UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников,МЕсяцДляКурсораТабелейДЛяПермещения, ГодДляКурсораТабелей);



                                Курсор_ЗагружаемТабеляСозданный[0].moveToFirst();


                                ///TODO ЗАПУСКАЕМ  ПуллПамяти


                                int ixx=Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("name");

                                String ФИОСледующий=     Курсор_ЗагружаемТабеляСозданный[0].getString(ixx);


                                int ПозицияДанныхВАТбеле=         Курсор_ЗагружаемТабеляСозданный[0].getPosition();


                                ///
                                Log.d(getApplicationContext().getClass().getName(), "ФИОСледующий " + "--" +ФИОСледующий+
                                        " ПозицияДанныхВАТбеле " +ПозицияДанныхВАТбеле);/////






// TODO: 28.04.2021 вперед
/////////////////////////
                        } else  if  ( ЕслиСмещениеВдАнныхДляСкрола>=1
                                && UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников==0l ){

                            ////////TODO движение вперет

                            Курсор_ЗагружаемТабеляСозданный[0]=null;

                            ////////////
                            Курсор_ЗагружаемТабеляСозданный[0] =
                                    new MODEL_synchronized(getApplicationContext()).МетодЗагружетУжеготовыеТабеляДляСкролаПОТабелю(КонтекстОдногоСотрудикаВТабеле,
                                            ЦифровоеИмяНовгоТабеля,МЕсяцДляКурсораТабелейДЛяПермещения, ГодДляКурсораТабелей);


                            // TODO: 12.05.2021  перемещение по данным вперед

                           /// Курсор_ЗагружаемТабеляСозданный[0].moveToFirst();

                            Курсор_ЗагружаемТабеляСозданный[0].move(ЕслиСмещениеВдАнныхДляСкрола);  //ТекущееПоложенияВТабелеДляСкрола

                            ////
                       //     Курсор_ЗагружаемТабеляСозданный[0].moveToPosition(ТекущееПоложенияВТабелеДляСкрола-1);///          Курсор_ЗагружаемТабеляСозданный[0].move(ТекущееПоложенияВТабелеДляСкрола);

                              //  Курсор_ЗагружаемТабеляСозданный[0].moveToNext();



                            int ixx=Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("name");

                       String ФИОСледующий=     Курсор_ЗагружаемТабеляСозданный[0].getString(ixx);


                            int ПозицияДанныхВАТбеле=         Курсор_ЗагружаемТабеляСозданный[0].getPosition();
                            ///
                            Log.d(getApplicationContext().getClass().getName(), "ФИОСледующий " + "--" +ФИОСледующий+ "ПозицияДанныхВАТбеле " +ПозицияДанныхВАТбеле);/////

                            // TODO: 07.05.2021 получение UUID дл я струдника из тпбелья  вторая часть и гланове внизу кода это надо затемнить   UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников dwon clear


                                // TODO: 09.05.2021 получаем uuid
                                        

                                int ИНдексГдеНаходитьсяUUID=         Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("uuid");


                                UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников= Курсор_ЗагружаемТабеляСозданный[0].getLong(ИНдексГдеНаходитьсяUUID)    ;

                                Log.d(this.getClass().getName(), "UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников " + UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников);


                                //////
                                Log.e(this.getClass().getName()," Данные в курсор не загруженны ( отсутвуют:) -- МЕсяцДляКурсораТабелей "+МЕсяцДляКурсораТабелей+" ГодДляКурсораТабелей " +ГодДляКурсораТабелей +
                                        " UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников " +UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников);




                            // TODO: 07.05.2021 когда есть id  но молежени выше 1

                            // TODO: 21.05.2021 значения равны
                            }


                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }



                 return null;
             }
         });
         ////////

            countDownLatchПриМеремещенииПоДАнным.countDown();
            /////////////////////////////////////////
         futureПолучениеДанныхВТАбелеСотрудникаКонкретного.get();
         //
            countDownLatchПриМеремещенииПоДАнным.await();

            if(futureПолучениеДанныхВТАбелеСотрудникаКонкретного.isDone()){
                futureПолучениеДанныхВТАбелеСотрудникаКонкретного.cancel(false);
                // TODO: 12.05.2021 метод заполения табеля сотрудника днями и днныапк дням



                //// заполения данными

                МетодЗаполенияТабелемСотрудникаДнемиИДаннымиКним(ЕслиСмещениеВдАнныхДляСкрола, Курсор_ЗагружаемТабеляСозданныйТОлькоОбшееКоличество,ЦифровоеИмяНовгоТабеля);
            }





            //поймать ошибку всего классаIOException | MyException e    NumberFormatException
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        ////
    }

    private void МетодЗаполенияТабелемСотрудникаДнемиИДаннымиКним(int еслиСмещениеВдАнныхДляСкрола, Cursor[] курсор_ЗагружаемТабеляСозданныйТОлькоОбшееКоличество,int ЦифровоеИмяНовгоТабеля) throws ParseException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
        /////TODO ВАЖНО ПОЛУЧИЛИ ДАННЫЕ ИЗ БАЗЫ В КУРСОР СОЗДАННЫХ ТАБЕЛЕЙ !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        if (Курсор_ЗагружаемТабеляСозданный[0].getCount()>0) {




            ////TODO даты обработки
            Log.d(this.getClass().getName()," Курсор_ЗагружаемТабеляСозданный[0].getCount() "+Курсор_ЗагружаемТабеляСозданный[0].getCount() );






            // TODO: 28.04.2021  копируем курсор




            ///TODO ищем имя если его не хватает
            String УниверсальноеИмяТабеля= "";
            /////////
            if (ПолноеИмяТабеляПослеСозданиеНовогоСотрудника!=null) {
                УниверсальноеИмяТабеля=ПолноеИмяТабеляПослеСозданиеНовогоСотрудника;
            }else if (ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки!=null) {
                УниверсальноеИмяТабеля=    ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки;
            } else if (ДепартаментПришелПослеСоздангоНового !=null){
                УниверсальноеИмяТабеля=     ДепартаментПришелПослеСоздангоНового;
            }

            //todo обнуляем
            //TODO заполения табеля из базы через элемент TableLauy
            //
            Log.d(this.getClass().getName()," Курсор_ЗагружаемТабеляСозданный.getCount() " + Курсор_ЗагружаемТабеляСозданный[0].getCount()+"\n" +
                    " ПолноеИмяТабеляПослеСозданиеНовогоСотрудника " +ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);
            Log.d(this.getClass().getName()," Курсор_ЗагружаемТабеляСозданный.getColumnCount() " + Курсор_ЗагружаемТабеляСозданный[0].getColumnCount()
                    + " ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки "
                    +ПолноеИмяТабеляПослеСозданиеНовогоСотрудникаПослеУспешнойВставки+ " UUIDТабеляКнопкаBACKУниверсальный " +UUIDТабеляКнопкаBACKУниверсальный);
            /////



            // КонтейнерДляТабеляВнутириСотрудники.removeAllViews();/////удалем данные с актиывти
            ///TODO определяем массив и заполнем его ниже данными из базы массив двухмерный определяем размер массива
            /*   ГлавныйКонтерйнерДляКомпнентовТабеля.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));*/

            //TODO запоминаем название табеля

            try {
                НазваниеЗагруженногТАбеля =         new  MODEL_synchronized(this).  МетодПолучениеНазваниеТабеляНаОснованииСФО(this,ЦифровоеИмяНовгоТабеля);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


           // НазваниеЗагруженногТАбеля = Курсор_ЗагружаемТабеляСозданный[0].getString(РасположениеИмениТабеля); ///строго имя

            Log.d(this.getClass().getName(), " НазваниеЗагруженногТАбеля" + НазваниеЗагруженногТАбеля);

            ///TODO  проверяем станус проведенный или нет

            int СтатусПроведенныйТабельИлиНЕт = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("status_carried_out");

            ////
            СтаттусТабеля=0;
            //////////////

            СтаттусТабеля = Курсор_ЗагружаемТабеляСозданный[0].getInt(СтатусПроведенныйТабельИлиНЕт); ///строго имя

            Log.d(this.getClass().getName(), " СтаттусТабеля" + СтаттусТабеля);

            if (СтаттусТабеля>0) {

                Toast.makeText(getApplicationContext(), " Табель Проведен !!!. " + "\n" + "(редактирование запрещено).", Toast.LENGTH_SHORT).show();
                /////////
            }


            /////TODO ПОЛУЧАЕМ ИЗ БАЗЫ ОБОЩЕЕ КОЛИЧЕСТВО ЧАСОВ ЕСЛИ ВСЕ ПОЛЯ ЗАПОЛНЕНЫ БЕЗ NULL , А ЕСЛИ NULL  ТО НАЧИНАЕМ ОБРАБОТКУ МЕТОДОМ КОТОРЫЙ ПОДСЧИТВАЕТ ЧИСЛО ЧАСОВ
            //   int НазваниеСтобика= Курсор_ЗагружаемТабеляСозданный.getColumnIndex("sumofhours");

            //  ОбщееКоличествоЛюдейВТабелеТекущем =  Курсор_ЗагружаемТабеляСозданный.getString(НазваниеСтобика);
            /////////
            ////TODO МЕТОД КОТРЫЙ ПОДСИЧТВАЕТ КОЛИЧЕСТВО ЧАСОВ ВСЕСТЕ С NULL



            //////TODO цикл заполения Табеля
            final int[] ИндексСтрокКомпонентовТабеля = {0};
            /////
            int ИндексКолонокКомпонентовТабеля = 0;
            ////TODO выжный компонет СОЕДИНЯЕМ ДВЕ АКТИВТИ НЕМЖУ СЕБЯ ЗАГРУЖАЕМ ОДНЦУ АКТИВТИ В ДРУГУЮ



            /////TODO заполение реальными днями в табеле конкретного указаного месяца ДНИ  МЕСЯЦА
            МетодСозданиеМесяцыСокращенно();


            //TODO запускаем цикл загрузки на активити табель данными из базы
            try{
                ГлавныйКонтейнерТабель.removeAllViews();
                ГлавныйКонтейнерТабель.removeAllViewsInLayout();
            } catch (Exception e) {
                // e.printStackTrace();
       /*         ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());*/
            }


            Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1) " + ХЭШНазваниеДнейНедели.get(1));

         /*   КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла = new View(this);
          НазваниеДанныхВТабелеФИО=new TextView(this);
       НазваниеДанныхВТабелеСНИЛС=new TextView(this);
            ОбщееКоличествоВТабелеСотудников=new TextView(this);*/
            ///TODO future


            LayoutInflater МеханизмЗагрузкиОдногЛайАутавДругой = getLayoutInflater();
            //////
                /*КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла = МеханизмЗагрузкиОдногЛайАутавДругой.inflate(R.layout.activity_main_grid_for_tables_four_columns,//activity_main_find_customer_for_tables // activity_main_grid_for_tables
                                ГлавныйКонтейнерТабель, false);*/
            КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла = МеханизмЗагрузкиОдногЛайАутавДругой.inflate(R.layout.activity_main_grid_for_tables_four_columns_in_mm,//activity_main_find_customer_for_tables // activity_main_grid_for_tables
                    ГлавныйКонтейнерТабель, false);
            ViewGroup.LayoutParams ПараментыКонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.getLayoutParams();

            // TODO: 09.05.2021

/*

           // HorizontalScrollViewВТабелеОдинСотрудник     =(HorizontalScrollView)     КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.HorizontalScrollViewВТабелеОдинСотрудник);

            if (!Build.BRAND.toString().contains("Redmi") ) {
                КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.setPadding(35,20,0,0);
            }else{
                КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.setPadding(0,20,0,0);
            }

            КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.setForegroundGravity(Gravity.CENTER_HORIZONTAL);*/



            /////TODO ТАБЕЛЬ ФИО создаем textview названия дней понелельник вторик среда четеварг
            ///////// todo фио
            НазваниеДанныхВТабелеФИО = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.КонтейнерКудаЗагружаетьсяФИО);

            НазваниеДанныхВТабелеФИО.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
            ///todo  снилс

            // НазваниеДанныхВТабелеСНИЛС = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id. КонтейнерКудаЗагружаетьсяСНИЛС);

            ///toDO ПОСИК И ВСТАВКИ ИМСЯ ТАБЕЛЯ
            int РасположениеИмениСотркдника = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("name");

            ////////////////
           ФИОДляТабеляНаАктивти=null;

            ФИОДляТабеляНаАктивти = Курсор_ЗагружаемТабеляСозданный[0].getString(РасположениеИмениСотркдника);

            int РасположениеСНИЛС = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("snils");

            String СНИЛСДляТабеляНаАктивти = Курсор_ЗагружаемТабеляСозданный[0].getString(РасположениеСНИЛС);

            Log.d(this.getClass().getName(), " ФИОДляТабеляНаАктивти " + ФИОДляТабеляНаАктивти+ "  РасположениеИмениСотркдника " +РасположениеИмениСотркдника+
                    " СНИЛСДляТабеляНаАктивти " +СНИЛСДляТабеляНаАктивти);








            ///TODO ЕСЛИ НЕ ПУСТОЙ ТАБЕЛЬ
            ///TODO НАЧИНАЕМ ЗАПОЛНЯТЬЕ ЕСЛИ СОТРУДНИКА ЕСТЬ
            НазваниеДанныхВТабелеФИО.setText("");
            ////////////
            НазваниеДанныхВТабелеФИО.setText(ФИОДляТабеляНаАктивти.trim()); ///строго имя
            Log.d(this.getClass().getName(), " ФИО " + ФИОДляТабеляНаАктивти);




            ///TODO ГЛАВНЫЙ ЦИКЛ ЗАПОЛЕНИЕНИ ТАБЕЛЕМ СОТРУДНИКАМИ
            do {

                /////TODO SLEEP


                /////TODO создавние строк из linerlouyto в табеле сколько сткром в базе данных андройда столлько на активити строк
                Log.d(this.getClass().getName(), " Курсор_ЗагружаемТабеляСозданный.getCount() " + Курсор_ЗагружаемТабеляСозданный[0].getCount());



                ///todo ПРИСВАИВАЕМ UUID НАЗВАНИЮ ФИО
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("uuid"); ////TODO СЮДА ПОЛЕ UUID

                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);

                НазваниеДанныхВТабелеФИО.setTag(Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня));

                Log.d(this.getClass().getName(), " UUID пристваем Внутри ФИО  " + Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня));

                ////todo УСТАНАВЛИВАЕМ КЛИК НА ФИО
                // НазваниеДанныхВТабелеФИО.setOnLongClickListener(СлушательУдаланиеСотрудникаИзТабеля);

                НазваниеДанныхВТабелеФИО.setOnClickListener(СлушательИнформацияОСотрудника);
                /////TODO     ПЕРВАЯ СТРОКА


                /////todo ПЕРВАЯ СТРОКА НАЗВАНИЯ
                /////TODO ДЕНЬ ПЕРВЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень1);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(1));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(1).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(1).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ

                /////TODO ДЕНЬ ВТОРОЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень2);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(2));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(2).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(2).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ СРЕДА
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень3);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(3));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(3).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(3).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ЧЕТВЕРЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень4);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(4));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(4).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(4).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ПЯТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень5);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(5));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(5).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(5).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ШЕСТРОЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень6);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(6));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(6).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(6).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ СЕДЬМОЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень7);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(7));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(7).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(7).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ВОСЬМОЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень8);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(8));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(8).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(8).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ДЕВЯТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень9);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(9));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(9).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(9).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ДЕСЯТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень10);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(10));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(10).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(10).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ОДИНАЦАТЫЕ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень11);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(11));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(11).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(11).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ДВЕНАЦАТЫЕ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень12);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(12));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(12).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(12).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ТРЕНАЦАТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень13);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(13));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(13).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(13).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ЧЕТЫРНАЦАТЫЕ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень14);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(14));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(14).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(14).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ПЕТНАЦАТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень15);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(15));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(15).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(15).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ШЕСТНАЦАТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаНазваниеДень16);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(16));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(16).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(16).matches("Вс,(.*)")) {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                } else {
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ

                ///TODO  КОНЕЦ ПЕРВОЙ СТРОКИ НАЗВАНИЯ ДАННЫХ (вТ,01,Ср,02)


                ///TODO  НАЧАЛО САМИ ДАННЫЕ ПЕРВОЙ СТРОКИ(1,2,3,4,6,7,8,9)

                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень1);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d1");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней = "";
                СамиДанныеКурсораДляДней = Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" + СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней != null) {
                    СамиДанныеКурсораДляДней = СамиДанныеКурсораДляДней.replaceAll("\\s+", "");
                    // СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")) {
                        СамиДанныеКурсораДляДней = "";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }


                }
                // TODO: 24.05.2021 событие при поднятии клавиатуры



                //////

                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener(СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener(СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления


                /////TODO ТАБЕЛЬ вторая строчка вторник
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень2);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d2");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }

                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }




                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней

                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }




                /////TODO ТАБЕЛЬ вторая строчка среда
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень3);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d3");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели

                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }



                /////TODO ТАБЕЛЬ вторая строчка четверг

                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень4);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d4");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }

                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели

                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);

                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }





                /////TODO ТАБЕЛЬ третья строчка пятница
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень5);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d5");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);



                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }


                ////////////////////////
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления

                /////TODO ТАБЕЛЬ третья строчка суббота
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень6);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d6");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);



                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления

                /////TODO ТАБЕЛЬ третья строчка воскресенье
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень7);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d7");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);




                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }


                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                /////TODO ТАБЕЛЬ третья строчка воскресенье
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень8);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d8");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);



                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }





                ////////////////////////
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень9);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d9");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);





                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }


                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень10);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d10");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                // TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);




                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);





                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }



                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень11);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d11");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);

                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }


                ////////////////////////
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень12);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d12");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней

                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень13);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d13");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней

                ////////////////////////
                ///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }






                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень14);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d14");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели

                ////////////////////////
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }



                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень15);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d15");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);



                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);




                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }



                ////////////////////////
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ПерваяСтрочкаДанныеДень16);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d16");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);





                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                //TODO  КОНЕЦ Сами Данных Табеля (1,2,3,4,5,6)-->


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }
///TODO КОНЕЦ ПЕРВОЙ СТРОЧКИ






                ///TODO НАЧАЛО ВТОРОЙ СТРОКИ

                ///TODO НАЗВАНИЕ ДНЕЙ ВТОРОЙ СТРОКИ
                /////TODO ДЕНЬ 17
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень17);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(17));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(17).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(17).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ

                /////TODO ДЕНЬ ВТОРОЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень18);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(18));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(18).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(18).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ СРЕДА
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень19);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(19));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(19).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(19).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ЧЕТВЕРЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень20);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(20));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(20).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(20).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ПЯТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень21);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(21));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(21).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(21).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ШЕСТРОЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень22);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(22));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(22).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(22).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ СЕДЬМОЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень23);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(23));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(23).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(23).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ВОСЬМОЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень24);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(24));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(24).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(24).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ДЕВЯТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень25);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(25));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(25).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(25).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ДЕСЯТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень26);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(26));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(26).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(26).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ОДИНАЦАТЫЕ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень27);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(27));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(27).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(27).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                /////TODO ДЕНЬ ДВЕНАЦАТЫЕ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень28);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(28));
                ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                if (ХЭШНазваниеДнейНедели.get(28).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(28).matches("Вс,(.*)")){
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                }else{
                    НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                    НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                }
                ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ

                /////TODO ДЕНЬ ТРЕНАЦАТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень29);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(29));

                ///todo  УБИРАЕМ С ЭКРАНА ЕСЛИ ДАННОГО ДНЯ НЕТ В КАЛЕНДАРЕ (ЯРКИЙ ПРИМЕР МЕСЯЦ ФЕВРАЛЬ)
                if (КоличествоДнейвЗагружаемойМесяце<29) {
                    НазваниеДанныхВТабелеДниНедели.setVisibility(View.INVISIBLE);
                }else{
                    ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                    Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                    if (ХЭШНазваниеДнейНедели.get(29).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(29).matches("Вс,(.*)")){
                        НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                        НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                    }else{
                        НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                        НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                    }
                    ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                }
                /////TODO ДЕНЬ ЧЕТЫРНАЦАТЫЕ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень30);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(30));

                ///todo  УБИРАЕМ С ЭКРАНА ЕСЛИ ДАННОГО ДНЯ НЕТ В КАЛЕНДАРЕ (ЯРКИЙ ПРИМЕР МЕСЯЦ ФЕВРАЛЬ)
                if (КоличествоДнейвЗагружаемойМесяце<30) {
                    НазваниеДанныхВТабелеДниНедели.setVisibility(View.INVISIBLE);
                }else{
                    ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                    Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                    if (ХЭШНазваниеДнейНедели.get(30).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(30).matches("Вс,(.*)")){
                        НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                        НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                    }else{
                        НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                        НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                    }
                    ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                }
                ///todo загружем если данные дни есть в календаре
                /////TODO ДЕНЬ ПЕТНАЦАТЫЙ
                НазваниеДанныхВТабелеДниНедели = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаНазваниеДень31);
                НазваниеДанныхВТабелеДниНедели.setText(ХЭШНазваниеДнейНедели.get(31));

                ///todo  УБИРАЕМ С ЭКРАНА ЕСЛИ ДАННОГО ДНЯ НЕТ В КАЛЕНДАРЕ (ЯРКИЙ ПРИМЕР МЕСЯЦ ФЕВРАЛЬ)
                if (КоличествоДнейвЗагружаемойМесяце<31) {
                    НазваниеДанныхВТабелеДниНедели.setVisibility(View.INVISIBLE);
                }else {
                    ////////TODO ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                    Log.d(this.getClass().getName(), " ХЭШНазваниеДнейНедели.get(1)  " + ХЭШНазваниеДнейНедели.get(1));
                    if (ХЭШНазваниеДнейНедели.get(31).matches("Сб,(.*)") || ХЭШНазваниеДнейНедели.get(31).matches("Вс,(.*)")){
                        НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                        НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#DC143C"));
                    }else{
                        НазваниеДанныхВТабелеДниНедели.setBackgroundResource(R.drawable.textlines_tabel_row_name_value);
                        НазваниеДанныхВТабелеДниНедели.setTextColor(Color.parseColor("#008080"));
                    }
                    ////////TODO  конец ВЫХОДНЫЕ ДНИ ДЕЛАЕМ ДРГИМ ДИЗАЙНОМ
                }
                ///TODO  КОНЕЦ ВТОРОЙ СТРОКИ НАЗВАНИЯ ДАННЫХ (вТ,01,Ср,02)






                ///TODO  НАЧАЛО САМИ ДАННЫЕ ВТОРОЙ СТРОКИ(10,11,12,13,14,15)

                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень17);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d17");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                /////TODO ТАБЕЛЬ вторая строчка вторник
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень18);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d18");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);

                ////////
                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }


                /////TODO ТАБЕЛЬ вторая строчка среда
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень19);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d19");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);



                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                /////TODO ТАБЕЛЬ вторая строчка четверг

                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень20);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d20");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);

                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }



                /////TODO ТАБЕЛЬ третья строчка пятница
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень21);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d21");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);



                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);
                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                /////TODO ТАБЕЛЬ третья строчка суббота
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень22);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d22");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);



                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                /////TODO ТАБЕЛЬ третья строчка воскресенье
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень23);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d23");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }


                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                /////TODO ТАБЕЛЬ третья строчка воскресенье
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень24);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d24");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень25);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d25");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);



                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень26);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d26");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }


                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень27);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d27");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }



                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень28);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d28");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);

                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                ///todo загружем если данные дни есть в календаре
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень29);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d29");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);

                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                ///todo  УБИРАЕМ С ЭКРАНА ЕСЛИ ДАННОГО ДНЯ НЕТ В КАЛЕНДАРЕ (ЯРКИЙ ПРИМЕР МЕСЯЦ ФЕВРАЛЬ)
                ///todo  УБИРАЕМ С ЭКРАНА ЕСЛИ ДАННОГО ДНЯ НЕТ В КАЛЕНДАРЕ (ЯРКИЙ ПРИМЕР МЕСЯЦ ФЕВРАЛЬ)
                if (КоличествоДнейвЗагружаемойМесяце<29) {
                    СамиДанныеТабеля.setVisibility(View.INVISIBLE);
                }
                ////////////////////////
                ///todo загружем если данные дни есть в календаре
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень30);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d30");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели
///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);


                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                //////
                ///todo  УБИРАЕМ С ЭКРАНА ЕСЛИ ДАННОГО ДНЯ НЕТ В КАЛЕНДАРЕ (ЯРКИЙ ПРИМЕР МЕСЯЦ ФЕВРАЛЬ)
                if (КоличествоДнейвЗагружаемойМесяце<30) {
                    СамиДанныеТабеля.setVisibility(View.INVISIBLE);
                }


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                ////////////////////////
                ///todo загружем если данные дни есть в календаре
                ///TODO заполняем массив данных из табеля из вертуальныйх данных запоминаем их в масиив для дальнейшего о брашени для обновления
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.ВтораяСтрочкаДанныеДень31);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("d31");
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                /////todo обработка значения для дней
                СамиДанныеКурсораДляДней= "";
                СамиДанныеКурсораДляДней= Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня);
                Log.d(this.getClass().getName(), " СамиДанныеКурсораДляДней" +СамиДанныеКурсораДляДней);
                if (СамиДанныеКурсораДляДней!=null){
                    СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("\\s+","");
                    ////  СамиДанныеКурсораДляДней=    СамиДанныеКурсораДляДней.replaceAll("[^0-9]","");
                    ////TODO МЕНЯЕМ ЦВЕТ ЕСЛИ НОЛЬ ДАННЫЕ
                    if (СамиДанныеКурсораДляДней.equals("0")){
                        СамиДанныеКурсораДляДней="";
                    }
                    // TODO: 19.05.2021 для букв окраиваем в сервый цвет

                    if (СамиДанныеКурсораДляДней.matches("[А-Я]")) {
                        СамиДанныеТабеля.setTextColor(Color.parseColor("#2F4F4F"));
                    }
                }

                //////
                СамиДанныеТабеля.setText(СамиДанныеКурсораДляДней); ///replace("[^0-9]"));
                /////todo обработка значения для дней
                //TODO подключаем слушатели

///TODO слушатели ячеек
                СамиДанныеТабеля.addTextChangedListener(СлушательПолученияДанных);

                СамиДанныеТабеля.setOnClickListener( СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ////////////////////////
                СамиДанныеТабеля.setOnFocusChangeListener( СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления);
                ///todo  УБИРАЕМ С ЭКРАНА ЕСЛИ ДАННОГО ДНЯ НЕТ В КАЛЕНДАРЕ (ЯРКИЙ ПРИМЕР МЕСЯЦ ФЕВРАЛЬ)
                if (КоличествоДнейвЗагружаемойМесяце<31) {
                    СамиДанныеТабеля.setVisibility(View.INVISIBLE);
                }
                ///////////////////////

                ////todo клик который переходит на выбор слов для вставки в  Метка табель
                СамиДанныеТабеля.setOnLongClickListener(   СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления);


                ///todo  установка только чтение данных с табеля без редактирования

                    if(СтаттусТабеля>0){
                        СамиДанныеТабеля.setInputType(InputType.TYPE_NULL);
                        СамиДанныеТабеля.setLongClickable(false);

                    }

                //TODO  КОНЕЦ Сами Данных Табеля (1,2,3,4,5,6)-->

                //TODO ТЕХНИЧЕСКИЙ  БЛОК ВЕРХНЕМ СТРОЧКИ ID И UUID-->
                ///TODO uuid не видивая EDITTEXT понадобиться для обновления UUID
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.СтрочкаНевидимаяUUID);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("uuid"); ////TODO СЮДА ПОЛЕ UUID
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                СамиДанныеТабеля.setText(Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня));
                Log.d(this.getClass().getName(), " ВтораяСтрочкаНевидимаяUUID " + Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня));
                СамиДанныеТабеля.setVisibility(View.GONE);
                ///TODO вытаскиваем UUID
                ///TODO uuid не видивая EDITTEXT понадобиться для обновления ID
                СамиДанныеТабеля = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.СтрочкаНевидимаяID);
                ПосикДня = Курсор_ЗагружаемТабеляСозданный[0].getColumnIndex("_id"); ////TODO СЮДА ПОЛЕ ID
                НазваниеСтолбикаДляЛобкальногоОбноления = Курсор_ЗагружаемТабеляСозданный[0].getColumnName(ПосикДня);
                СамиДанныеТабеля.setTag(НазваниеСтолбикаДляЛобкальногоОбноления);
                СамиДанныеТабеля.setText(Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня));
                Log.d(this.getClass().getName(), " ВтораяСтрочкаНевидимаяID " + Курсор_ЗагружаемТабеляСозданный[0].getString(ПосикДня));
                СамиДанныеТабеля.setVisibility(View.GONE);

                Log.d(this.getClass().getName(), " ИндексСтрокКомпонентовТабеля " + ИндексСтрокКомпонентовТабеля[0]);
                /////TODO увеличиваем шаг  по строчкам
                ИндексСтрокКомпонентовТабеля[0]++;
                //////TODO заврешаем уикл загрузки данных на ктивити табель
                //TODO  ОЧИЩАЕМ ПАМТЬ







/////TODO ФИНАЛ ЗАПОЛЕНИЕ ДАННЫМИ АКТИВИТИ ЧЕРЕЗ ДРУГОЕ АКТВИТИ
                ГлавныйКонтейнерТабель.addView(КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла);


                // TODO: 29.04.2021 если то один

                if( еслиСмещениеВдАнныхДляСкрола >0){
                    break;
                }





            }
            while (Курсор_ЗагружаемТабеляСозданный[0].moveToNext()) ;

            /////todo конец обработки
            ScrollСамогоТабеля.setBackgroundResource(R.drawable.textlines_tabel_row_color_green_mini);
            ScrollСамогоТабеля.requestLayout();
            ScrollСамогоТабеля.pageScroll(View.FOCUS_UP);
            ГлавныйКонтейнерТабель.requestLayout();



            /////TODO после успешнм ЗАПОЛЕНИИ ТАБЕЛЯ ПЕРЕОПРЕДЕЛЯЕМ ЫНЕШНИЙ ВИД
            ///todo после заполнения табелями обнуляем куросры
            //TODO цикл ПЕРЕБОРКИ ДАННЫХ
            ОбщееКоличествоЛюдейВТабелеТекущем = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(getApplicationContext()).
                    МетодПосчётаЧасовСотрудниковВТабеле(getApplicationContext(),UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников ,МЕсяцДляКурсораТабелейДЛяПермещения, ГодДляКурсораТабелей );


            ///TODO запускаем метод ПОСЛЕ УСПЕШНОЙ ГЕНЕРАЦИИ ТАБЕЛЯ

            /// МетодПослеУспешнойГенерацииТабеля();

            Курсор_ЗагружаемТабеляСозданный[0].close();

            курсор_ЗагружаемТабеляСозданныйТОлькоОбшееКоличество[0].close();



            ///TODO В УКАЗАНОМ ТАБЕЛЕ НЕТ НИОДНОГО СОТРУДНИКА СТОРОЧЕК COUNT()* 0 НЕТ СТРОЧЕК В ТАБЕЛЕ
            //TODO запускаем цикл загрузки на активити табель данными из базы
        }else{
            ///TODO В УКАЗАНОМ ТАБЕЛЕ НЕТ НИОДНОГО СОТРУДНИКА СТОРОЧЕК COUNT()* 0 НЕТ СТРОЧЕК В ТАБЕЛЕ
            МетодКогдаНетЗаписейВКурсоре();
        }
    }


    void МетодПослеУспешнойГенерацииТабеля() {

        //TODO ЗАПОЛЯНЕМ ПОЛУЧЕННЫЙ МЕСЯ Ц ПЛУС КОЛИЧЕСТВО ЧАСОВ СОТРУДНИКА КОНКРЕТНОГО
        ОбщееКоличествоВТабелеСотудников.setText(" (" + " " + ОбщееКоличествоЛюдейВТабелеТекущем + "/часы)");


    }

    ///TODO Когда в  КУРСОРЕ ВООБЩЕ НЕТ ДАННЫХ НА УКАЗАННЫЙ МЕСЯЦ
    private void МетодКогдаНетЗаписейВКурсоре() {
        try{
            ГлавныйКонтейнерТабель.removeAllViews();
            ГлавныйКонтейнерТабель.removeAllViewsInLayout();
        } catch (Exception e) {
            /// e.printStackTrace();
            ///метод запись ошибок в таблицу
/*     Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());*/
        }



        /////TODO создавние строк из linerlouyto в табеле сколько сткром в базе данных андройда столлько на активити строк
        LayoutInflater МеханизмЗагрузкиОдногЛайАутавДругой = getLayoutInflater();
        //КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла = new View(this);//activity_main_find_customer_for_tables // activity_main_grid_for_tables
        КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла = МеханизмЗагрузкиОдногЛайАутавДругой.inflate(R.layout.activity_main_grid_for_tables_four_columns,
                ГлавныйКонтейнерТабель, false);
        //   НазваниеДанныхВТабелеФИО=new TextView(this);
        НазваниеДанныхВТабелеФИО = КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.findViewById(R.id.КонтейнерКудаЗагружаетьсяФИО);

        /////TODO ТАБЕЛЬ ФИО создаем textview названия дней понелельник вторик среда четеварг
        ///////// todo фио
        ///TODO ЕСЛИ ИМЕНИ НЕТ ПО НА АКТИВИТИ ПОКАЗЫВАЕМТ ЧТО ТАБЕЛЬ ПУСТОЙ
        НазваниеДанныхВТабелеФИО.setTextColor(Color.RED);
        НазваниеДанныхВТабелеФИО.setText("*Табель  пустой (заполните)*"); ///строго имя
        Log.d(this.getClass().getName(), " ФИО " + "*Пустой табель (заполните)*");
        /////TODO ФИНАЛ ЗАПОЛЕНИЕ ДАННЫМИ АКТИВИТИ ЧЕРЕЗ ДРУГОЕ АКТВИТИ
        ГлавныйКонтейнерТабель.addView(КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла);


////todo удаление из памяти
        КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.invalidate();
        ГлавныйКонтейнерТабель.invalidate();
        ScrollСамогоТабеля.invalidate();
        КонтентТабеляКоторыйМыИБудемЗаполнятьВнутриЦикла.requestLayout();
        ГлавныйКонтейнерТабель.requestLayout();
        ScrollСамогоТабеля.requestLayout();
        ScrollСамогоТабеля.fullScroll(View.FOCUS_UP);


        ///todo
    }





///TODO   КОНЕЦ ScrollView






    ///todo коды ЛОКАЛЬНОГО ОБНОВЛЕНИЕ И УДАЛЕНИЕ СОТРУДНИКА


    /////View/////TODO ТУТ ПЕРЕРХОДИМ НА КОД КОТОРЫЙ ДОБАВЛЯЕТ В ТАБЕЛЬ СЛОВА НЕ ЦИФРЫ ВИДЫ В-О-С
    View.OnLongClickListener СлушательДляДобавленияСловВТабельначениеСтолбикаДляЛокальногоОбновления= new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {

            /////todo ПЕРЕХОДИМ НА МЕТКИ ТАБЕЛЯ
            Log.d(this.getClass().getName(), " View.OnLongClickListener ");
            HashMap<String,Long> ХэшЛовимUUIDIDНазваниеСтолбикаЛокальныйСловоВставитьТабель= МетодЛовимЗначениеВТАбелеДляДобавленияСловВТабель(v);

            Log.d(this.getClass().getName(), "ХэшЛовимUUIDIDНазваниеСтолбикаЛокальный  " + ХэшЛовимUUIDIDНазваниеСтолбикаЛокальныйСловоВставитьТабель.values());


            Log.d(this.getClass().getName(), "ХэшЛовимUUIDIDНазваниеСтолбикаЛокальныйСловоВставитьТабель.values()  " +ХэшЛовимUUIDIDНазваниеСтолбикаЛокальныйСловоВставитьТабель.values());
            /////TODO запускаем сообщение которые справишает О ПЕРЕХОДЕ НА АКТИВТИ МЕТЫКИ ТАБЕЛЯ

            МетодПереходаНаМеткиТабеля(ХэшЛовимUUIDIDНазваниеСтолбикаЛокальныйСловоВставитьТабель);
            /////
            return false;
        }

    };








    /////View/////TODO ТУТ ПОЛУЧАЕМ КУДА ОБНОВЛЯТЬ ДНИ  D1,D2,D3
    View.OnClickListener СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления= new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            /////todo полученине данных uuid id
            Log.d(this.getClass().getName(), " View.OnClickListener");
            МетодЛовимЗначениеВТАбелеUUIDиIDиНазваниеСтоблиув(v);
        }
    };


    //TODO второй long клик на прозопас
    /////View/////TODO ТУТ ПОЛУЧАЕМ КУДА ОБНОВЛЯТЬ ДНИ  D1,D2,D3
    View.OnFocusChangeListener СлушательLONGПолученияНазваниеСтолбикаДляЛокальногоОбновления= new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if (!hasFocus) {
                Log.d("focus", "focus loosed");
                // Do whatever you want here
            } else {
                Log.d("focus", "focused");
                Log.d(this.getClass().getName(), "  View.OnLongClickListener");
                МетодЛовимЗначениеВТАбелеUUIDиIDиНазваниеСтоблиув(v);

            }
        }
    };











    /////View/////TODO метод uuid id названеи стоблика
    public  HashMap МетодЛовимЗначениеВТАбелеUUIDиIDиНазваниеСтоблиув(View v) {
        //////todo заполение
        String СамоЗначениеСтолбикаТабеляДляЛокальногоОбновления = null;//

        String ПолучениеЗначениеСтолбикID= null;//;

        String ПолучениеЗначениеСтолбикUUID= null;//;

        /////TODO  главная очистка перед новой вставкой  в табель АЧИЩАЕМ ПЕРЕРД ЗАПОЛЕНЕНИЕМ



        try{
            /////todo определяем хэшмап для uuid и знпчения для
            Log.d(this.getClass().getName(), "  MotionEvent СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления ");


            EditText ВытаскиваемЗначениеСтолбикаТабеля=null;



            ВытаскиваемЗначениеСтолбикаТабеля = (EditText) v;


            ///////
            String ВытаскиваемЗначениеСтолбикаТабеляДва=null;


            /////todo писваесмиаем d1,d,2,d4
            ВытаскиваемЗначениеСтолбикаТабеляДва = (String) ВытаскиваемЗначениеСтолбикаТабеля.getTag();


            ////todo верхнене значение локального обновления пример D1 , d2
            Log.d(this.getClass().getName(), " ВытаскиваемЗначениеСтолбикаТабеляДва " + ВытаскиваемЗначениеСтолбикаТабеляДва);



            ///todo обнуляем
            //////TODO ВАЖНО ЕСЛИ  не равно ЗНАЧЕНИЕ ДЛЯ НАПРИМЕР D1<>D2 РАЗНЫЕ ПОЛУЧЕН ПРИ КЛИСЕ ТО ТОГДА И ОБНУЛЕМ И ИЗМЕНЯЕМ ЗНАЧЕНИЯ NULLL !!!!!!!!!!!!!!!!!!!!!
            /////todo присваемваем значения новое
            if (ВытаскиваемЗначениеСтолбикаТабеляДва.length()>0) {
                ///////////
                СамоЗначениеСтолбикаТабеляДляЛокальногоОбновления = ВытаскиваемЗначениеСтолбикаТабеляДва.trim();
            }

////////////////////////////////////////
            Log.d(this.getClass().getName(), " charSequenceвторойстолбик: " + СамоЗначениеСтолбикаТабеляДляЛокальногоОбновления);

            //TODO залезаем в обьект на активти где находяться данные табеля
            GridLayout GridRow = (GridLayout) v.getParent();

            Log.d(this.getClass().getName(), " GridRow" + GridRow);

            ///TODO UUID и ID ПОСИК ЕГО ВНУТРИ GRIDLAUTY

            int КоличествоСтобиков = GridRow.getChildCount();

            ///////

            for (int ИндексПоВытаскиваниюUUIDИID = 0; ИндексПоВытаскиваниюUUIDИID < КоличествоСтобиков; ИндексПоВытаскиваниюUUIDИID++) {

////TODO сами столбиков
                TextView СтолбикGridRow = (TextView) GridRow.getChildAt(ИндексПоВытаскиваниюUUIDИID);

                //TODO название столбиков uuid id
                String НазваниеКолонкиGridRow = null;

                НазваниеКолонкиGridRow = String.valueOf(СтолбикGridRow.getTag());

                /////TODO ОПРЕДЕЛЯЕМ КАКАЯ СЕЙЧАС ЯЧЕЙКА В ОБОРАБТКИ ID ИЛИ UUID
                Log.d(this.getClass().getName(), " НазваниеКолонкиGridRow " + НазваниеКолонкиGridRow);


                //todo выбор
                switch (НазваниеКолонкиGridRow.trim()) {


                    //todo fio какой стодик
                    case "uuid":

                        //TODO получение знчение  UUID
                        Log.d(this.getClass().getName(), "  ПолучениеЗначениеСтолбикUUID " + ПолучениеЗначениеСтолбикUUID);
                        ////
                        ПолучениеЗначениеСтолбикUUID = String.valueOf(СтолбикGridRow.getText());

                        Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикUUID " + ПолучениеЗначениеСтолбикUUID +"\n"
                                + " ВытаскиваемЗначениеСтолбикаТабеляДва " +ВытаскиваемЗначениеСтолбикаТабеляДва +
                                " СамоЗначениеЯчейкиТабеля " +СамоЗначениеЯчейкиТабеля);



                        //TODO при если нет UUID  то цепляемся локльное обновление через ID


                        ////
                        if(ПолучениеЗначениеСтолбикUUID !=null  && ВытаскиваемЗначениеСтолбикаТабеляДва!=null) {

                            // TODO: 21.05.2021 перед вставка очищаем ХЭШ

                            ХэшЛовимUUIDIDНазваниеСтолбика.clear();

                            /////TODO ЗАПОЛЯЕМ uuid
                            ХэшЛовимUUIDIDНазваниеСтолбика.put(ВытаскиваемЗначениеСтолбикаТабеляДва, Long.parseLong(ПолучениеЗначениеСтолбикUUID));



                            Log.d(this.getClass().getName(), " ВытаскиваемЗначениеСтолбикаТабеляДва " + ВытаскиваемЗначениеСтолбикаТабеляДва+
                                    " ПолучениеЗначениеСтолбикUUID " +ПолучениеЗначениеСтолбикUUID);

                            // TODO: 21.05.2021
                            ВытаскиваемЗначениеСтолбикаТабеляДва=null;
                            ПолучениеЗначениеСтолбикUUID=null;


                            //////
                        }




                      break;







                    //todo id какой стодик
                    case "_id":

                        //TODO получение знчение ID
                        Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикID " + ПолучениеЗначениеСтолбикID);
                        /////
                        ПолучениеЗначениеСтолбикID = String.valueOf(СтолбикGridRow.getText());

                        Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикID " + ПолучениеЗначениеСтолбикID);


                        // TODO: 21.05.2021 обновление только через ID
                        if (ПолучениеЗначениеСтолбикID!=null  && ВытаскиваемЗначениеСтолбикаТабеляДва!=null){

                            // TODO: 21.05.2021 перед вставка очищаем ХЭШ

                            ХэшЛовимUUIDIDНазваниеСтолбика.clear();
                            /////TODO ЗАПОЛЯЕМ id
                            ХэшЛовимUUIDIDНазваниеСтолбика.put(ВытаскиваемЗначениеСтолбикаТабеляДва, Long.parseLong(ПолучениеЗначениеСтолбикID));


                            Log.d(this.getClass().getName(), "ПолучениеЗначениеСтолбикUUID" + ПолучениеЗначениеСтолбикUUID
                                    + " ПолучениеЗначениеСтолбикID "+ПолучениеЗначениеСтолбикID);


                            // TODO: 21.05.2021
                            ВытаскиваемЗначениеСтолбикаТабеляДва=null;

                            ////////
                            ПолучениеЗначениеСтолбикUUID=null;

///TODO как получили значение выходим BREAK;
                            Log.d(this.getClass().getName(), " ХэшЛовимUUIDIDНазваниеСтолбика.values() " + ХэшЛовимUUIDIDНазваниеСтолбика.values()+"ХэшЛовимUUIDIDНазваниеСтолбика.keySet()  "
                                    +ХэшЛовимUUIDIDНазваниеСтолбика.keySet());

                        }

                        break;



                    default:

                        Log.d(this.getClass().getName(), " NULL значение НазваниеКолонкиGridRow " + НазваниеКолонкиGridRow);




                }


            }
            Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикID " + ПолучениеЗначениеСтолбикID);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                    + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        /////////
        return  ХэшЛовимUUIDIDНазваниеСтолбика;
    }

    // TODO  конец КОД СЛУШАТЕЛЬ ПРИ НАЖАТИИ НА ТАБЕЛЬ Создаем экземпляр TextWatcher:




    /////TODO метод который добавляетв  табель прокме цифр и буквы

    /////View/////TODO метод uuid id названеи стоблика
    public  HashMap МетодЛовимЗначениеВТАбелеДляДобавленияСловВТабель(View v) {
        //////todo заполение
        String СамоЗначениеСтолбикаТабеляДляЛокальногоОбновления = null;//
        String ПолучениеЗначениеСтолбикID= null;//;
        String ПолучениеЗначениеСтолбикUUID= null;//;
        try{
            /////todo определяем хэшмап для uuid и знпчения для
            Log.d(this.getClass().getName(), "  MotionEvent СлушательТачПолученияНазваниеСтолбикаДляЛокальногоОбновления ");
            EditText ВытаскиваемЗначениеСтолбикаТабеля=null;
            ВытаскиваемЗначениеСтолбикаТабеля = (EditText) v;
            ///////
            String ВытаскиваемЗначениеСтолбикаТабеляДва=null;
            /////todo писваесмиаем d1,d,2,d4
            ВытаскиваемЗначениеСтолбикаТабеляДва = (String) ВытаскиваемЗначениеСтолбикаТабеля.getTag();
            ////todo верхнене значение локального обновления пример D1 , d2
            Log.d(this.getClass().getName(), " ВытаскиваемЗначениеСтолбикаТабеляДва " + ВытаскиваемЗначениеСтолбикаТабеляДва);
            ///todo обнуляем
            //////TODO ВАЖНО ЕСЛИ  не равно ЗНАЧЕНИЕ ДЛЯ НАПРИМЕР D1<>D2 РАЗНЫЕ ПОЛУЧЕН ПРИ КЛИСЕ ТО ТОГДА И ОБНУЛЕМ И ИЗМЕНЯЕМ ЗНАЧЕНИЯ NULLL !!!!!!!!!!!!!!!!!!!!!
            /////todo присваемваем значения новое
            СамоЗначениеСтолбикаТабеляДляЛокальногоОбновления = ВытаскиваемЗначениеСтолбикаТабеляДва;

////////////////////////////////////////
            Log.d(this.getClass().getName(), " charSequenceвторойстолбик: " + СамоЗначениеСтолбикаТабеляДляЛокальногоОбновления);

            //TODO залезаем в обьект на активти где находяться данные табеля
            GridLayout GridRow = (GridLayout) v.getParent();
            Log.d(this.getClass().getName(), " GridRow" + GridRow);
            ///TODO UUID и ID ПОСИК ЕГО ВНУТРИ GRIDLAUTY
            int КоличествоСтобиков = GridRow.getChildCount();

            for (int ИндексПоВытаскиваниюUUIDИID = 0; ИндексПоВытаскиваниюUUIDИID < КоличествоСтобиков; ИндексПоВытаскиваниюUUIDИID++) {
////TODO сами столбиков
                TextView СтолбикGridRow = (TextView) GridRow.getChildAt(ИндексПоВытаскиваниюUUIDИID);
                //TODO название столбиков uuid id
                String НазваниеКолонкиGridRow = "";
                НазваниеКолонкиGridRow = String.valueOf(СтолбикGridRow.getTag());

                /////TODO ОПРЕДЕЛЯЕМ КАКАЯ СЕЙЧАС ЯЧЕЙКА В ОБОРАБТКИ ID ИЛИ UUID
                Log.d(this.getClass().getName(), " НазваниеКолонкиGridRow " + НазваниеКолонкиGridRow);


                //todo выбор
                switch (НазваниеКолонкиGridRow.trim()) {
                    //todo id какой стодик
                    case "_id":
                        //TODO получение знчение ID
                        Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикID " + ПолучениеЗначениеСтолбикID);
                        /////
                        ПолучениеЗначениеСтолбикID = String.valueOf(СтолбикGridRow.getText());

                        Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикID " + ПолучениеЗначениеСтолбикID);


                        ///todo заполения Hasmap uuid and id
                        if (ВытаскиваемЗначениеСтолбикаТабеляДва!=null  && ПолучениеЗначениеСтолбикID!=null) {
                            ////
                            Log.d(this.getClass().getName(), "      ХэшЛовимUUIDIDНазваниеСтолбика" + ХэшЛовимUUIDIDНазваниеСтолбика.toString());

                            // TODO: 21.05.2021 перед вставка очищаем ХЭШ

                            ХэшЛовимUUIDIDНазваниеСтолбика.clear();

                            /////TODO ЗАПОЛЯЕМ
                            ХэшЛовимUUIDIDНазваниеСтолбика.put(ВытаскиваемЗначениеСтолбикаТабеляДва, Long.parseLong(ПолучениеЗначениеСтолбикID));

                            //////todo обнуляем переменные
                            ВытаскиваемЗначениеСтолбикаТабеляДва = null;
                            ПолучениеЗначениеСтолбикID = null;
                            ///////

                            Log.d(this.getClass().getName(), " ХэшЛовимUUIDIDНазваниеСтолбика " + ХэшЛовимUUIDIDНазваниеСтолбика.toString());

                        }


                        break;







                        //todo fio какой стодик
                    case "uuid":

                        //TODO получение знчение  UUID

                        Log.d(this.getClass().getName(), "  ПолучениеЗначениеСтолбикUUID " + ПолучениеЗначениеСтолбикUUID);
                        ////
                        ПолучениеЗначениеСтолбикUUID = String.valueOf(СтолбикGridRow.getText());



                        Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикUUID " + ПолучениеЗначениеСтолбикUUID +"\n"
                                + " ВытаскиваемЗначениеСтолбикаТабеляДва " +ВытаскиваемЗначениеСтолбикаТабеляДва +
                                " СамоЗначениеЯчейкиТабеля " +СамоЗначениеЯчейкиТабеля);
                        ///todo заполения Hasmap uuid and id
                        if (ВытаскиваемЗначениеСтолбикаТабеляДва!=null  && ПолучениеЗначениеСтолбикUUID!=null){
                            Log.d(this.getClass().getName(), "      ХэшЛовимUUIDIDНазваниеСтолбика" +    ХэшЛовимUUIDIDНазваниеСтолбика.toString());

                            // TODO: 21.05.2021 перед вставка очищаем ХЭШ

                            ХэшЛовимUUIDIDНазваниеСтолбика.clear();

                            /////TODO ЗАПОЛЯЕМ
                            ХэшЛовимUUIDIDНазваниеСтолбика.put(ВытаскиваемЗначениеСтолбикаТабеляДва ,Long.parseLong(ПолучениеЗначениеСтолбикUUID ));

                            //////todo обнуляем переменные
                            ВытаскиваемЗначениеСтолбикаТабеляДва=null;
                            ПолучениеЗначениеСтолбикUUID=null;
                            ///////



                            Log.d(this.getClass().getName(), " ХэшЛовимUUIDIDНазваниеСтолбика " + ХэшЛовимUUIDIDНазваниеСтолбика.toString());


                        }

                        break;


                }


            }
            Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикID " + ПолучениеЗначениеСтолбикID);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                    + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return  ХэшЛовимUUIDIDНазваниеСтолбика;




    }

    // TODO  конец КОД СЛУШАТЕЛЬ ПРИ НАЖАТИИ НА ТАБЕЛЬ Создаем экземпляр TextWatcher:


































    // TODO КОД СЛУШАТЕЛЬ ПРИ НАЖАТИИ НА ТАБЕЛЬ Создаем экземпляр TextWatcher:
    private final TextWatcher СлушательПолученияДанных = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            Log.d(this.getClass().getName(), "  beforeTextChanged  " + s.toString());
            ПолучениеЗначениеДоИзменения= "";
            ПолучениеЗначениеДоИзменения=s.toString();
            Log.d(this.getClass().getName()," ПолучениеЗначениеДоИзменения  " +ПолучениеЗначениеДоИзменения);
        }


        //TODO второй метод

        public void onTextChanged(CharSequence s, int start, int before, int count) {
            Log.d(this.getClass().getName(),"  onTextChanged  " +s.toString());


            Log.d(this.getClass().getName(),"  afterTextChanged " +s.toString());

            СамоЗначениеЯчейкиТабеля= null;

            СамоЗначениеЯчейкиТабеля= s.toString();

            Log.d(this.getClass().getName(), "  СамоЗначениеЯчейкиТабеля " +  СамоЗначениеЯчейкиТабеля);



            //TODO ОЦЕНКА ЧТО С ДАННЫМИ

            if (ПолучениеЗначениеДоИзменения.matches("(.*)[^0-9](.*)" )) {
                Log.d(this.getClass().getName()," ПолучениеЗначениеДоИзменения " +ПолучениеЗначениеДоИзменения);

                Log.d(this.getClass().getName(), "  СамоЗначениеЯчейкиТабеля " +  СамоЗначениеЯчейкиТабеля);
                //////
                if (СамоЗначениеЯчейкиТабеля.matches("(.*)[0-9](.*)" )) {
                    СамоЗначениеЯчейкиТабеля = СамоЗначениеЯчейкиТабеля.replaceAll("[^0-9]", "");
                }
                Log.d(this.getClass().getName(), "  СамоЗначениеЯчейкиТабеля " +  СамоЗначениеЯчейкиТабеля);


            }
            Log.d(this.getClass().getName()," ПолучениеЗначениеДоИзменения " +ПолучениеЗначениеДоИзменения);



            Log.d(this.getClass().getName(), " СамоЗначениеЯчейкиТабеля.length()" +  СамоЗначениеЯчейкиТабеля.length());
        }




        //Задаем действия для TextView после смены введенных в EditText символов:
        public void afterTextChanged(Editable s) {
            //TODO ДАННЫЙ КОД НЕПОСТРЕДСТВЕННО ЗАРУСКАЕТ ОБНОВЛЕНИЕ ЛОКАЛЬНОЕ С АКТИВТИИ

            int СамоЗначениеЯчейкиТабеляЗначениеНЕБольше24Часов = 0;

            boolean ФлагЗапускатьллкальноеОбновлениеИлинет=false;


      /*      Log.d(this.getClass().getName(),"  afterTextChanged " +s.toString());
            СамоЗначениеЯчейкиТабеля=new String();

            СамоЗначениеЯчейкиТабеля= s.toString();*/



            Log.d(this.getClass().getName(), " СамоЗначениеЯчейкиТабеля" +  СамоЗначениеЯчейкиТабеля);



////TODO запускаем запу запуси даных локально


            if (СамоЗначениеЯчейкиТабеля!=null) {
                if (СамоЗначениеЯчейкиТабеля.length()>0 ) {

                    Log.d(this.getClass().getName(), " СамоЗначениеЯчейкиТабеля.length()" +  СамоЗначениеЯчейкиТабеля.length());
                    /////////todo получем значение И СТАВИМ УСЛОВИЕ НЕ БОЕЛЕЕ 24 ЧИЛСА КАК КАК В СУТКА ТОЛЬКО 24 ЧАСА


                    boolean ПереводимВЦифруТОлькоЕслиИзначальноНетБУквыВнутри=         СамоЗначениеЯчейкиТабеля.matches("(.*)[^0-9](.*)");
                    //////
                    if (ПереводимВЦифруТОлькоЕслиИзначальноНетБУквыВнутри==false) {
                        СамоЗначениеЯчейкиТабеляЗначениеНЕБольше24Часов = Integer.parseInt(СамоЗначениеЯчейкиТабеля);
                    }

                    Log.d(this.getClass().getName(), " СамоЗначениеЯчейкиТабеляЗначениеНЕБольше24Часов " + СамоЗначениеЯчейкиТабеляЗначениеНЕБольше24Часов);

                    if (СамоЗначениеЯчейкиТабеляЗначениеНЕБольше24Часов <= 24) {

                        ////TODO саомЗначение
                        // СамоЗначениеЯчейкиТабеля = s.toString();

                        Log.d(this.getClass().getName(), "  СамоЗначениеЯчейкиТабеля " +  СамоЗначениеЯчейкиТабеля);

                        ФлагЗапускатьллкальноеОбновлениеИлинет=true;


                        /////TODO  НЕ НАДЛО ЗАПУСКАТЬ ЛОКАЛЬНЕО ОБНОВЛЕНИЕ
                    } else {

                        ФлагЗапускатьллкальноеОбновлениеИлинет=false;
                        ////
                        // СамоЗначениеЯчейкиТабеля =new String();

                        Toast aa = Toast.makeText(getBaseContext(), "OPEN", Toast.LENGTH_LONG);
                        ImageView cc = new ImageView(getBaseContext());
                        cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_error);//icon_dsu1_synchronisazia_dsu1_success
                        aa.setView(cc);
                        aa.show();
                        ///
                        Toast.makeText(getBaseContext(), "Нет сохранилось"+
                                "\n"+" (Значение не может быть более 24 (часы).) :" +СамоЗначениеЯчейкиТабеля, Toast.LENGTH_SHORT).show();
                    }




                    //////todo МОЖНО ЗАПУСКАТЬ ЛОКЛАЬНЕО ОБНЛВЛДЕНИ

                }else{
                    ////TODO саомЗначение
                    // СамоЗначениеЯчейкиТабеля = s.toString();

                    Log.d(this.getClass().getName(), "  СамоЗначениеЯчейкиТабеля " +  СамоЗначениеЯчейкиТабеля);

                    //////todo МОЖНО ЗАПУСКАТЬ ЛОКЛАЬНЕО ОБНОВЛЕНИЕ
                    ФлагЗапускатьллкальноеОбновлениеИлинет=true;
                }
            }


            Log.d(this.getClass().getName(), " СамоЗначениеЯчейкиТабеля" +СамоЗначениеЯчейкиТабеля + "  ФлагЗапускатьллкальноеОбновлениеИлинет " + ФлагЗапускатьллкальноеОбновлениеИлинет );



//TODO запускаем локальное обновдене если есть на это все условия

            if( ФлагЗапускатьллкальноеОбновлениеИлинет==true){

///TODOобнуляем akfu

                ФлагЗапускатьллкальноеОбновлениеИлинет=false;



                Log.d(this.getClass().getName(), "  СамоЗначениеЯчейкиТабеляЗначениеНЕБольше24Часов" +    СамоЗначениеЯчейкиТабеляЗначениеНЕБольше24Часов );

                ////// TODO: 20.01.2021 полученое занчение пытаемся обрезать
                Log.d(this.getClass().getName(),"  СамоЗначениеЯчейкиТабеля " +СамоЗначениеЯчейкиТабеля);

                //TODO ограниваем количество символом не более 3 символом не сохраняет
                if (СамоЗначениеЯчейкиТабеля.length()>=3){
                    СамоЗначениеЯчейкиТабеля = СамоЗначениеЯчейкиТабеля.substring(0, 2);
                }


                Log.d(this.getClass().getName(),"  СамоЗначениеЯчейкиТабеля " +СамоЗначениеЯчейкиТабеля + " ХэшЛовимUUIDIDНазваниеСтолбика.size() " +ХэшЛовимUUIDIDНазваниеСтолбика.values());

                ///todo получаем хэш с название стольика и uuid
                try {
                    Log.d(this.getClass().getName(), "  ХэшЛовимUUIDIDНазваниеСтолбика.size()  " + ХэшЛовимUUIDIDНазваниеСтолбика.size());
                    ////todo проверка ПЕРЕД ЛОКАЛЬНЫЙ ОБНОВЛЕНИЕМ ПРОВЕРМЯЕМ ЕСЛИ ТАМО ЗНАЧЕНИЕ НЕ 0 ОН НЕ ЕСТЬ РАЗМЕР А ХЭША условия начало локального обоновления
                    //if (ХэшЛовимUUIDIDНазваниеСтолбика.size() > 0  && СамоЗначениеЯчейкиТабеля!=null && !СамоЗначениеЯчейкиТабеля.equalsIgnoreCase("0") && СамоЗначениеЯчейкиТабеля.length()<5){


                    ///TODO ОЦЕНИВАЕМ ЗНАЧЕНИЕ ТЕКУЩЕЕ ЗНАЧЕНИЕ ЯЧЕЙКИ СТОИТ ЛИ ЕГО ОБНОВЛЕЯТЬ ИЛИ НЕТ if (ХэшЛовимUUIDIDНазваниеСтолбика.size() > 0  && СамоЗначениеЯчейкиТабеля!=null
                    //                        && СамоЗначениеЯчейкиТабеля.length()<=2 && !СамоЗначениеЯчейкиТабеля.equalsIgnoreCase("0")){



                    Log.d(this.getClass().getName(), " Локальное Обновление ХэшЛовимUUIDIDНазваниеСтолбика" + ХэшЛовимUUIDIDНазваниеСтолбика+
                            " СамоЗначениеЯчейкиТабеля " +СамоЗначениеЯчейкиТабеля);
// TODO: 03.06.2021  если вставдяем значене нул то всталвяем в него O

                    if (СамоЗначениеЯчейкиТабеля.length()==0 || СамоЗначениеЯчейкиТабеля==null) {
                        ///////
                        СамоЗначениеЯчейкиТабеля="0";
                    }
                    
                    
                    
                    
                    Log.d(this.getClass().getName(), " Локальное Обновление ХэшЛовимUUIDIDНазваниеСтолбика" + ХэшЛовимUUIDIDНазваниеСтолбика+
                            " СамоЗначениеЯчейкиТабеля " +СамоЗначениеЯчейкиТабеля);
                    
                    
// TODO: 03.06.2021  елси значение нул то мимы из него делаем ноль  ВАЖНО ТУТ УКАЗАНЫ УСЛОВИЯ ПО КОТОРЫМ ПРОИЗВХОДТИ ЛОКАЛЬНОЕ ОБНОВЛЕНИЕ

                    ArrayList<Integer> ЛистСДопустипыЗначениямиДляЛокальноСохранения=new ArrayList();
                    ////
                    for (int ДниДопустимые=0;ДниДопустимые<=24;ДниДопустимые++) {
                        // TODO: 03.06.2021  
                        ЛистСДопустипыЗначениямиДляЛокальноСохранения.add(ДниДопустимые);

                    }

                    Log.d(this.getClass().getName(), " ЛистСДопустипыЗначениямиДляЛокальноСохранения" + ЛистСДопустипыЗначениямиДляЛокальноСохранения.toString());

               boolean РезультатПроверкиЕслиТАкоеЧислоВАрайлистеВставлятьИлиНет=     ЛистСДопустипыЗначениямиДляЛокальноСохранения.contains(Integer.parseInt(СамоЗначениеЯчейкиТабеля));

               ///
                    Log.d(this.getClass().getName(), " РезультатПроверкиЕслиТАкоеЧислоВАрайлистеВставлятьИлиНет" + РезультатПроверкиЕслиТАкоеЧислоВАрайлистеВставлятьИлиНет);

                    /////
                    if (ХэшЛовимUUIDIDНазваниеСтолбика.size() ==1 && СамоЗначениеЯчейкиТабеля.length()>0
                            && СамоЗначениеЯчейкиТабеля.length() <= 2 && РезультатПроверкиЕслиТАкоеЧислоВАрайлистеВставлятьИлиНет==true) {


                        try {

                            ///todo контейнер
                            ContentValues КонтейнерЗаполненияДаннымиПриЛокальномОбновлении = new     ContentValues();
                            // For each loop
                            Log.d(this.getClass().getName(), "  ХэшЛовимUUIDIDНазваниеСтолбика " + ХэшЛовимUUIDIDНазваниеСтолбика.toString());
                            // Iterator
                            Iterator iterator = ХэшЛовимUUIDIDНазваниеСтолбика.entrySet().iterator();

                            // TODO: 20.05.2021  начинаем обновлять только по одну запись если более одной пропускаем

                            if (ХэшЛовимUUIDIDНазваниеСтолбика.size()==1) {
                                ////
                                while (iterator.hasNext()) {
                                    ////
                                    // TODO: 21.05.2021  локальное обновление записи

                                    Map.Entry entry = (Map.Entry) iterator.next();
                                    ///
                                    System.out.println(String.format("(%s, %s)", entry.getKey(), entry.getValue()));


                                             String КлючПоляДляЛокальноОбновление=String.valueOf(entry.getKey());

                                    /////todo заполегния контейнера
                                    if (СамоЗначениеЯчейкиТабеля.length()>0) {
                                        КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.put(КлючПоляДляЛокальноОбновление, СамоЗначениеЯчейкиТабеля);
                                        ////
                                        КлючПоляДляЛокальноОбновление=null;
                                                СамоЗначениеЯчейкиТабеля=null;

                                    }else if (СамоЗначениеЯчейкиТабеля.length()==0){
                                        КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.put(КлючПоляДляЛокальноОбновление, 0);
                                        ////
                                        КлючПоляДляЛокальноОбновление=null;

                                    }
                                    Log.d(this.getClass().getName(), " СамоЗначениеЯчейкиТабеля" + СамоЗначениеЯчейкиТабеля+ " КонтейнерЗаполненияДаннымиПриЛокальномОбновлении " +КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.toString());



                                    //TODO заполение КОНТЕНЕР для локального обновления--дАТА оПЕРАЦИИ
                                    КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.put("date_update", ГлавнаяДатаИВремяОперацийСБазойДанных());
                                    // TODO: 21.05.2021


                                    ///////////
                                    System.out.println(String.format("(%s, %s)", entry.getKey(), entry.getValue()));
                                    Log.d(this.getClass().getName(), "  СамоЗначениеЯчейкиТабеля " + СамоЗначениеЯчейкиТабеля);


                                        String СодержимоеДляЛокальногоОбновленияВременный = String.valueOf(entry.getValue());

                                  Long СодержимоеДляЛокальногоОбновления = Long.parseLong(СодержимоеДляЛокальногоОбновленияВременный);

                                    Log.d(this.getClass().getName(), "  СодержимоеДляЛокальногоОбновления " + СодержимоеДляЛокальногоОбновления);


                                    if (СодержимоеДляЛокальногоОбновления > 0){


                                              String СодержимоеДляЛокальногоОбновленияФинал=String.valueOf(СодержимоеДляЛокальногоОбновления);

                                        Log.d(this.getClass().getName(), "КонтейнерЗаполненияДаннымиПриЛокальномОбновлении " + КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.toString() +
                                                "СодержимоеДляЛокальногоОбновленияФинал " + СодержимоеДляЛокальногоОбновленияФинал);




                                        Log.d(this.getClass().getName(), "  КонтейнерЗаполненияДаннымиПриЛокальномОбновлении " + КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.valueSet() + "\n" +
                                                "  String.valueOf(entry.getValue()) " + entry.getValue());





                                        ///TODO ЗАПУСКАЕМ  МЕТОД ЛОКАЛЬНОГО ОБНОВЛЕНИЯ ВНУТИ ТАБЕЛЯ с самого активти
                                        try {

                                            Long РезультатЛокальногоОбновлениеНаТабеле= null;


                                            // TODO: 27.05.2021
                                            
                                            if (СодержимоеДляЛокальногоОбновленияФинал.length()>0 && КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.size()>0 ) {
                                                
                                                
                                                РезультатЛокальногоОбновлениеНаТабеле = МетодЛокальногоОбновлениеЧерезКликвТабеле(КонтейнерЗаполненияДаннымиПриЛокальномОбновлении, СодержимоеДляЛокальногоОбновленияФинал);
                                            }

                                            Log.d(this.getClass().getName(), "  РезультатЛокальногоОбновлениеНаТабеле" + РезультатЛокальногоОбновлениеНаТабеле);
                                                ////////
                                            // TODO: 21.05.2021 Обнуляем после успешной локально вставки

                                           if (РезультатЛокальногоОбновлениеНаТабеле>0) {
                                               
                                                КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.clear();


                                               СодержимоеДляЛокальногоОбновленияФинал=null;
                                    
                                               ПолучениеЗначениеДоИзменения= null;
                                               
                                               СамоЗначениеЯчейкиТабеля=null;
                                            }


                                      



                                            break;
                                            /////////
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            ///метод запись ошибок в таблицу
                                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),

                                                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                        }







                                        //////


                                    }





                                }//todo end while()
/////////
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        }


                    }///TODO END IF  ПЕРЕД ЛОКАЛЬЫМ ОБНОВЛЕНИЕМ



                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                           new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

                ////todo calabel end

            }








        }//TODO НАДО ЛИ ЗАПУСКАТЬ ЛОКАЛЬНОЕ ОБНОВЛЕНИЕ И ЛИ НЕТ
    };
    ///////КОНЕЦ  СОЗДАГНИЕ СЛУШАТЕЛЯ ДЛЯ ПЕРЕДАЧИ ЕГО В КОД ОБНОВЛЕНИЯ ПОЛУЧАЕМ ID  СТРОЧКИ И ДЛЯ ПРОВЕРКИ ЗНАЧЕНИЕ ЯЧЕЙКИ















    ///todo третий обработчки нажатия
///TODO  удаление ОБРАБОТКА КЛИКА ПО ФИО
    View.OnLongClickListener СлушательУдаланиеСотрудникаИзТабеля = new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            try{
                ////todo
                МыУжеВКодеУденияСотрудника=true;
                TextView ФИОДляУдаление=(TextView) v;
                Log.d(this.getClass().getName(), " v " +v.getTag()+ " ФИОДляУдаление.getText() " +ФИОДляУдаление.getText() );


/////TODO КОД КОТОРЫЙ КОТОРЫ УДАЛЯЮТ СОТРУДНИКА ИЗ ТАБЕЛЯ


                if (PUBLIC_CONTENT.Отладка==true) {
                    СообщениеПредпреждаетОВыбореУдалениеСотрудникаИзТабеля("Оповещение",  "Вы выбрали функцию удаление сотрудника: "+"\n" +ФИОДляУдаление.getText() +
                            " из Табеля."+"\n"+"(Выбор Да/Нет на следующем диалогом окне).", "uuid",(String) v.getTag(), (String) ФИОДляУдаление.getText());
                }else{

                    МетодСообщенииУдалениеСотрудника( "uuid",(String) v.getTag(), (String) ФИОДляУдаление.getText());


                }


            } catch (Exception e) {
                e.printStackTrace();
                Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                        + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
                       new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
            return false;
        }
    };






    ///TODO  удаление ОБРАБОТКА КЛИКА ПО ФИО
    View.OnClickListener СлушательИнформацияОСотрудника = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (МыУжеВКодеУденияСотрудника==false) {
                TextView ФИОДляУдаление = (TextView) v;
                Log.d(this.getClass().getName(), " v " + v.getTag() + " ФИОДляУдаление.getText() " + ФИОДляУдаление.getText() +
                        "  ФИОДляУдаление.getTag() " +ФИОДляУдаление.getTag());
                try{
                    final Cursor[] Курсор_ЗагружаемИнформациюПоФИО = {null};
///TODO ЗАПУСКАЕМ  ПуллПамяти

                    ExecutorService executorService=Executors.newSingleThreadExecutor();
                    Future future=   executorService.submit(new Runnable() {
                        @Override
                        public void run() {


//////TODO ГЛАВНЫЙ КУРСОР ДЛЯ НЕПОСРЕДТСВЕНОГО ЗАГРУЗКИ СОТРУДНИКА
                            //   Toast.makeText(getApplicationContext(), "Информация о сотрудника", Toast.LENGTH_SHORT).show();
                            try {
                                Курсор_ЗагружаемИнформациюПоФИО[0] = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(getApplication()).КурсорУниверсальныйДляБазыДанных("viewtabel",
                                        new String[]{"name","BirthDate", "snils" }, "uuid=?  AND status_send!=?", new String[]{(String) ФИОДляУдаление.getTag(),"Удаленная"},
                                        null, null, "date_update desc", null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                                /////


                            } catch (Exception e) {
                                e.printStackTrace();
                                Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                                        + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
                                       new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                            }

///TODO ЗАПУСКАЕМ  ПуллПамяти

                        }
                    });
                    ///
                    future.get();
                    if(future.isDone()) {
                        executorService.shutdown();
                        future.cancel(false);
                    }


                    //TODO  ОЧИЩАЕМ ПАМТЬ
                    if (Курсор_ЗагружаемИнформациюПоФИО[0].getCount()>0){
                        Курсор_ЗагружаемИнформациюПоФИО[0].moveToFirst();
                        String ФИОИнфо= Курсор_ЗагружаемИнформациюПоФИО[0].getString(0);
                        String ДеньРОжденияИНФО= Курсор_ЗагружаемИнформациюПоФИО[0].getString(1);
                        String СНИЛСИНфо= Курсор_ЗагружаемИнформациюПоФИО[0].getString(2);
//////////
                        СообщениеИнформацияОФИО("Информация о сотруднике",  "ФИО: "  +ФИОИнфо+"\n"+"День рождения: " +ДеньРОжденияИНФО+"\n"+"СНИЛС: " +СНИЛСИНфо+"\n");

                    }

                    Курсор_ЗагружаемИнформациюПоФИО[0].close();
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                           new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

            }
        }};

















    //todo метод удаление сотрудника из табеля
    private void МетодУдалениеСотрудникаИзТабеля(String ДляУдалениеUUID,String СамоЗначениеUUID) {
        try{
            Log.d(this.getClass().getName()," СамоЗначениеUUID "+СамоЗначениеUUID+ " ДляУдалениеUUID " +ДляУдалениеUUID);

            final long[] РезультатУдалениеСотрудникаИзТаблея = {0};
            ///TODO ЗАПУСКАЕМ  ПуллПамяти
            ExecutorService ПуулПамяти = Executors.newCachedThreadPool(); //
            ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными
            String finalСамоЗначениеUUID = СамоЗначениеUUID;
            String finalДляУдалениеUUID = ДляУдалениеUUID;
            ////////////////
            Future МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными = ПуулПамяти.submit(new Runnable() {
                public void run() {
                    System.out.println("Another thread was executed");

                    //////////

                    try {
                        РезультатУдалениеСотрудникаИзТаблея[0] =   new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(getApplicationContext()).
                                УдалениеДанныхЧерезКонтейнерУниверсальная("tabels", finalДляУдалениеUUID,
                                        finalСамоЗначениеUUID);


                        Log.e(this.getClass().getName(),   "РЕЗУЛЬТАТ УДАЛДЕНИЕ ОДНОГО СОТРУДНИКА  РезультатУдалениеСотрудникаИзТаблея[0] "
                                +    РезультатУдалениеСотрудникаИзТаблея[0]);

                        ////
                        Log.e(this.getClass().getName(), "РезультатУдалениеСотрудникаИзТаблея[0] РЕЗУЛЬТАТ УДАЛЕНИЯ ТАБЕЛЯ " +РезультатУдалениеСотрудникаИзТаблея[0]);
                        ///////////
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                                + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
                               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }

                }});


            //TODO ЗАПУСКАЕМ ФУТУРЕ
            МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.get();
            //TODO ФУТУРЕ ЗАВЕРШАЕМ
            if (МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.isDone()) {
                Log.d(this.getClass().getName(), " МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными  "+ МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.toString());
                //TODO ЗАПУСКАЕМ "Эксенкюторе"
                ПуулПамяти.shutdown();
                /////TODO ЗАПУСКАМ ОБНОЛВЕНИЕ ДАННЫХ С СЕРВЕРА ПЕРЕРД ЗАПУСКОМ ПРИЛОЖЕНИЯ ВСЕ ПРИЛОЖЕНИЯ ДСУ-1
            }

            //todo очищаем память

            Log.d(this.getClass().getName()," РезультатУдалениеСотрудникаИзТаблея "+ РезультатУдалениеСотрудникаИзТаблея[0]);
            ///TODO СООБЩЕНИЕ О РЕЗУЛЬТАТОВ
            if (РезультатУдалениеСотрудникаИзТаблея[0] >0){
                //todo после успешной уданеие обнуляем ерпеменные
                ДляУдалениеUUID=null;
                СамоЗначениеUUID=null;
                РезультатУдалениеСотрудникаИзТаблея[0] =0;

                ///todo сообещение о успешном удалении
                if (PUBLIC_CONTENT.Отладка==true) {
                    СообщениеПослеУдаленияСотрудникаИзТабеля("Оповещение",  "Успешное удалание сотрудника из текущего Табеля",true) ;
                } else {

                    МетодЗапускаетСотрудниковПослеУспешногоУдалениеСотрудника();
                }


            }else{
                СообщениеПослеУдаленияСотрудникаИзТабеля("Оповещение",  "Операция удаление сотрудника не прошла ",false);
            }

            // TODO: 18.05.2021 ловим ошибки
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }
    ///todo  конец метода удаления третий обработчки нажатия















    //////
    //////TODO локального обнвлени с Активити в базу
    private Long МетодЛокальногоОбновлениеЧерезКликвТабеле(ContentValues КонтейнерЗаполненияДаннымиПриЛокальномОбновлении ,String ПолучениеЗначениеСтолбикUUID)
            throws InterruptedException, ExecutionException,
            NoSuchMethodException, TimeoutException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, JSONException {
        Long РезультатЛокальногоОбновления = null;
        try {

            Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикUUID " + ПолучениеЗначениеСтолбикUUID +
                    " КонтейнерЗаполненияДаннымиПриЛокальномОбновлении  " + КонтейнерЗаполненияДаннымиПриЛокальномОбновлении);
            ///TOdo универсальное значение или uuid или id КАКОЕ НЕ NULL
            String УниверсальныйИнлификаторЛокальногоОбновлениеиIDиUUID = "";


////TODO сам метод запуска обновления
            if (КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.size() > 0) {///если в контенер заполнилься то начинаем обновление
                final long[] РезультатОбновлениеЧерезКонтрейнер = {0};
                final long[] Результат_ИзмененияВерсииДанныхНаАндройде = {0};
                //TODO принимеем решение через чего БУДЕМ ОБНОВЛЯТЬ ЧЕРЕЗ ID ИЛИ UUID, ПРИОРИТЕТ ID ,НО ЕЛСИ ЕГО НЕТ ТО UUID
                /////TODO  локальное ОБНОВЛЕНИЕ ЧЕРЕЗ UUID ПОЛЕ
                if (ПолучениеЗначениеСтолбикUUID != null) {
                    Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикUUID " + ПолучениеЗначениеСтолбикUUID);


                    boolean РузультатМетодОпределяемуЗаписиКакойСтатусУдаленныйИлиНет =
                            МетодОпределяемуЗаписиКакойСтатусУдаленныйИлиНет(ПолучениеЗначениеСтолбикUUID, "uuid");

                    ////
                    Log.d(this.getClass().getName(), " РузультатМетодОпределяемуЗаписиКакойСтатусУдаленныйИлиНет " + РузультатМетодОпределяемуЗаписиКакойСтатусУдаленныйИлиНет +
                            " КонтейнерЗаполненияДаннымиПриЛокальномОбновлении " + КонтейнерЗаполненияДаннымиПриЛокальномОбновлении);


                    ///todo ПРОИЗВОДИМ ЛОКАЛЬНОЕ ОБНОВЛЕНИЕ ,ЕСЛИ В СТАТУСЕ ОТПРАВИК НЕ СТОИТЬ СТАТУС УДАЛЕННЫЙ
                    //////todo производим локальное обновлени когда статус false --, это значит статуса Уданненый нет

                    try {
                        // TODO: 22.03.2021  вставка только если false запись не Имеет статус Удаленная

                        if (РузультатМетодОпределяемуЗаписиКакойСтатусУдаленныйИлиНет == false) {
                            ///

                            РезультатЛокальногоОбновления = 0l;

                            ///TODO ТОЛЬКО ЛОКАЛЬНОЕ ОБНОВЛЕНИЕ НА ТАБЕЛЕ В АКТИВИТИ
                            РезультатЛокальногоОбновления = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(getApplicationContext()).
                                    МетодЛокальноеОбновлениеВТабеле(КонтейнерЗаполненияДаннымиПриЛокальномОбновлении,
                                            ПолучениеЗначениеСтолбикUUID, РезультатОбновлениеЧерезКонтрейнер, Результат_ИзмененияВерсииДанныхНаАндройде, getApplicationContext());


                            /////

                            Log.d(this.getClass().getName(), " РезультатЛокальногоОбновления " + РезультатЛокальногоОбновления);

                        }


                        //////
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName()
                                + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }


                }


                /// //TODO РЕЗУЛЬТАТ ФИНАЛЬНЫЙ ПОСЛЕ ЛОКАЛЬНОГО ОБНОВЛЕНИЕ ЕСОИ ВСЕ ХОРОШО ТО ОБНУЛЯЕМ ПЕРЕМЕННЫЕ И НЕТ СООБЩЕНИЙ

                Log.d(this.getClass().getName(), " РезультатОбновлениеЧерезКонтрейнер[0]" + РезультатОбновлениеЧерезКонтрейнер[0] +
                        " Результат_ИзмененияВерсииДанныхНаАндройде[0]  " + Результат_ИзмененияВерсииДанныхНаАндройде[0]);

                //TODO ЕЛИ РЕЗУЛЬТАТ ЛОКАЛЬНОГО ОБНОВЛЕНИЯ СРАБОТАЛ ТО И ПОКАЗЫВАЕМ ИЗМЕННЕЯ ЧАСЫ

                if (РезультатОбновлениеЧерезКонтрейнер[0] > 0 && Результат_ИзмененияВерсииДанныхНаАндройде[0] > 0) {


                    ///todo после заполнения табелями обнуляем куросры
                    ////////// TODO ПОДСЧЁТ ЧАСОВ ПОСЛЕ ЛОКАЛЬНОГО ОБНОВЛЕНИЯ
                    ОбщееКоличествоЛюдейВТабелеТекущем = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(getApplicationContext()).
                            МетодПосчётаЧасовСотрудниковВТабеле(КонтекстОдногоСотрудикаВТабеле, UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников, МЕсяцДляКурсораТабелейДЛяПермещения, ГодДляКурсораТабелей);


                    // TODO: 07.05.2021 обнуляем UUID после созданеия подтчета часов
                    //    UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников=0l;


                    ((Activity) КонтекстОдногоСотрудикаВТабеле).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //TODO ЗАПОЛЯНЕМ ПОЛУЧЕННЫЙ МЕСЯ Ц ПЛУС КОЛИЧЕСТВО ЧАСОВ СОТРУДНИКА КОНКРЕТНОГО
                            ОбщееКоличествоВТабелеСотудников.setText(" (" + " " + ОбщееКоличествоЛюдейВТабелеТекущем + "/часы)");
                            /////


                            Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикUUID " + ПолучениеЗначениеСтолбикUUID
                                    + " ХэшЛовимUUIDIDНазваниеСтолбика.values() " + ХэшЛовимUUIDIDНазваниеСтолбика.values() + " СамоЗначениеЯчейкиТабеля " + СамоЗначениеЯчейкиТабеля);


                            ///todo ДОБАЯЛЕМ ПОЛСЕ УСПЕШНОЙ ЛОКАЛЬНОГО ОБНОЛЕНИЕ
                            PUBLIC_CONTENT.КоличествоУспешныхОбновлений++; ////ПРИ УСПЕШНОМ ОБНОВЛЕНИИ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+
                            //todo после ЛОКАЛЬНОГО ОБНОВЛЕНИЯ ОБНУЛЯЕМ
                            Log.d(this.getClass().getName(), " ПолучениеЗначениеСтолбикUUID " + ПолучениеЗначениеСтолбикUUID
                                    + " ХэшЛовимUUIDIDНазваниеСтолбика.values() " + ХэшЛовимUUIDIDНазваниеСтолбика.values() + " СамоЗначениеЯчейкиТабеля " + СамоЗначениеЯчейкиТабеля);
                            ////TODO сообщаем пользователю при успепешном обньвении
                /*Toast.makeText(this, " Успех локальное обновление  Табеля (новое значение:) " +СамоЗначениеЯчейкиТабеля +"\n"+
                        " Описание : "+ХэшЛовимUUIDIDНазваниеСтолбика.keySet()+" / " +ХэшЛовимUUIDIDНазваниеСтолбика.values() , Toast.LENGTH_SHORT).show();*/
                    /*Toast.makeText(this, " Успех обновление  Табеля"+"\n"+
                            "(новое значение:) " +СамоЗначениеЯчейкиТабеля+"\n"+
                            " кол об/вс: "+PUBLIC_CONTENT.КоличествоУспешныхОбновлений, Toast.LENGTH_SHORT).show()*/
                            ////TODO ПОСЛЕ ЛОКАЛЬНОГО ОБНОВЛЕНИЯ ЗАПУСКАЕМ СИНХРОНИЗАЦИЮ ДАННЫХ

                            /////TODO ОБНУЛЯЕМ ЗНАЧЕНИЕ ID AND UUID ЧТОБЫ НЕ БЫЛО ПОВТОРОНОГО ОБНОЛЕНИЕ НЕ СВОЕГО ХОЗЯИНА UUID
                            КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.clear();
                            СамоЗначениеЯчейкиТабеля = null;
                            ПолучениеЗначениеДоИзменения = null;
                            ////todo УДАЛЕНИЕ ИЗ ПАМЯТИ КУРСОРА
                            ////todo удалем из памяти

                            ///TODO  ОБНУЛЯЕМ ПОСЛЕ УСПЕШНОЕ ОБНОВЛЕНОЕ
                            PUBLIC_CONTENT.КоличествоУспешныхОбновлений = 0;
                            РезультатОбновлениеЧерезКонтрейнер[0] = 0;
                            // ХэшЛовимUUIDIDНазваниеСтолбика.clear();


                            ScrollСамогоТабеля.requestLayout();
                            ГлавныйКонтейнерТабель.requestLayout();


                            ГлавныйКонтейнерТабель.invalidate();
                            ScrollСамогоТабеля.invalidate();
                            ////todo УДАЛЕНИЕ ИЗ ПАМЯТИ КУРСОРА
                            Toast aa = Toast.makeText(КонтекстОдногоСотрудикаВТабеле, "OPEN", Toast.LENGTH_SHORT);
                            ImageView cc = new ImageView(getBaseContext());
                            // cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_success);
                            aa.setView(cc);
                            aa.show();


                        }
                    });
//////////todo ошибка нет локального обновления
                } else {
                    //TODO сообщаем пользователю об не успешном локальном обновленеии на активти
                    /*  Toast.makeText(this, "Ошибка локальное обновление Табеля " +ХэшЛовимUUIDIDНазваниеСтолбика.size()  , Toast.LENGTH_SHORT).show();*/


                    ((Activity) КонтекстОдногоСотрудикаВТабеле).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            Toast aa = Toast.makeText(КонтекстОдногоСотрудикаВТабеле, "OPEN", Toast.LENGTH_SHORT);
                            ImageView cc = new ImageView(getBaseContext());
                            cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_error);
                            aa.setView(cc);
                            aa.show();


                            КонтейнерЗаполненияДаннымиПриЛокальномОбновлении.clear();
                            СамоЗначениеЯчейкиТабеля = null;
                            ПолучениеЗначениеДоИзменения = null;
                            ХэшЛовимUUIDIDНазваниеСтолбика.clear();

                        }
                    });
                }

            }


        } catch (Exception e) {
            e.printStackTrace();
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName()
                    + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return РезультатЛокальногоОбновления;

    }




    //todo метод орпреедгния статутс записи обнолвемой удленнва я или нет
    private boolean МетодОпределяемуЗаписиКакойСтатусУдаленныйИлиНет( String ПолучениеЗначениеСтолбикUUID,String ИндификаторСтатус) {
        boolean Результат_СтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНет=false;
        try{
            Log.d(this.getClass().getName(), "  МетодЗапускаЛокальногоОбновлениеЧерезКликвТабеле : ");
            final Cursor[] Курсор_УзнаемСтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНет = {null};



//////TODO ГЛАВНЫЙ КУРСОР ДЛЯ НЕПОСРЕДТСВЕНОГО ЗАГРУЗКИ СОТРУДНИКА

            Результат_СтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНет=    new AsyncTaskLoader<Boolean>(getApplicationContext()) {
                @Nullable
                @org.jetbrains.annotations.Nullable
                @Override
                public Boolean loadInBackground() {

                   boolean Результат_СтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНетВнутри=false;

                    try {
                        Курсор_УзнаемСтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНет[0] = new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("tabels",
                                new String[]{"status_send"}, ИндификаторСтатус+"=? AND status_send=?",new String[]{ПолучениеЗначениеСтолбикUUID,"Удаленная"},
                                null, null, "date_update desc", null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                        /////

                        /////////////
                        if (Курсор_УзнаемСтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНет[0].getCount() > 0) {
                            /////
                            Результат_СтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНетВнутри=true;
                        }else{
                            Результат_СтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНетВнутри=false;
                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                                + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
                               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }
                    ////////////////

                    return Результат_СтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНетВнутри;
                }
            }.loadInBackground();



                ///////todo


///TODO ЗАПУСКАЕМ  ПуллПамяти

                Курсор_УзнаемСтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНет[0].close();





            //////////
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(this.getClass().getName(), "Ошибка " +e + " Метод :"+Thread.currentThread().getStackTrace()[2].getMethodName()
                    + " Линия  :"+Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(),  this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return Результат_СтатусЗаписиДляЛокальногоОбновленияУдаленноеИлиНет;
    }





    //TODO метод получени месяа для записи в одну колонку

    private int  МетодПолучениниеМесяцДляЗАписивОднуКолонку(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        String[] ДелимМЕсяцИгод =ДатаКоторуюНадоПеревестиИзТекставЦифру.split(" ");
        System.out.println( " " + ДелимМЕсяцИгод [0] + " " +ДелимМЕсяцИгод [1]);
        SimpleDateFormat formatмесяц = new SimpleDateFormat("MMMM");
        SimpleDateFormat formatгод = new SimpleDateFormat("yyyy");
        Date date = formatмесяц.parse(ДелимМЕсяцИгод [0]);
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        System.out.println(calendar.get(Calendar.YEAR));
        System.out.println(calendar.get(Calendar.MONTH)+1);
        System.out.println(calendar.get(Calendar.DAY_OF_MONTH));
        System.out.println(new SimpleDateFormat("MMMM").format(calendar.getTime()));
        return   calendar.get(Calendar.MONTH)+1;
    }




    //TODO метод который обрабатывает дни
    String МетодСопоставлениеДнейТАбеляСКалендарем(String ДатаДляКадендаря){

        Calendar c = GregorianCalendar.getInstance();
        SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyy");

        return null;
    }











    ///todo Метод Который Содаенм НАзвание дней недели сокращенно Пн,01,ВТ,03
    private  void МетодСозданиеМесяцыСокращенно() throws ParseException {
        try {
            int МЕсяцДЛяПоказатаВТАбле=   МетодПоказатьМесяцДляЗАписивОднуКолонку(МесяцТабеляФинал);

            int ГодДЛяПоказатаВТАбле=    МетодПоказатьГодДляЗАписивОднуКолонку(МесяцТабеляФинал);

            Log.d(this.getClass().getName(), " МЕсяцДЛяПоказатаВТАбле " +МЕсяцДЛяПоказатаВТАбле +" ГодДЛяПоказатаВТАбле " +ГодДЛяПоказатаВТАбле);

            int ПолученоеКоличествоДнейНаКонкретныйМЕсяц=МетодПолучениеСколькоДнейВКонкретномМесяце(ГодДЛяПоказатаВТАбле,МЕсяцДЛяПоказатаВТАбле);

            SimpleDateFormat СозданияВычисляемВыходные=null;

            ///////TODO сам цикл который заполняет месяцами
            for (int ИндексДней=1;ИндексДней<ПолученоеКоличествоДнейНаКонкретныйМЕсяц+1;ИндексДней++) {



                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                 //
                    СозданияВычисляемВыходные = new SimpleDateFormat("yyyy-MM-dd",new Locale("rus"));

                }else {

                    СозданияВычисляемВыходные = new java.text.SimpleDateFormat("yyyy-MM-dd",new Locale("rus"));

                }


                Date   ДатаПосикаВыходныеДней       = СозданияВычисляемВыходные.parse (ГодДЛяПоказатаВТАбле+"-"+МЕсяцДЛяПоказатаВТАбле+"-"+ИндексДней );

                // Then get the day of week from the Date based on specific locale.
                String РезультатСокращенноВставкиВТабель = new SimpleDateFormat("EEE, dd ", new Locale("ru")).format(ДатаПосикаВыходныеДней );
                //TODO ДНИ НЕДЕЛИ С ЗАГЛАВНОЙ БУКВЫ
                StringBuffer ДниМЕсяцаСЗаглавнойБуквы=new StringBuffer(РезультатСокращенноВставкиВТабель.trim());

                String  СокращенныйДниМесяцаВТабеле=   ДниМЕсяцаСЗаглавнойБуквы.substring(0,1).toUpperCase()
                        +ДниМЕсяцаСЗаглавнойБуквы.substring(1,ДниМЕсяцаСЗаглавнойБуквы.length()).toLowerCase();
                ///////
                System.out.println(СокращенныйДниМесяцаВТабеле);

                //TODO ЗАПОЛЕНЯЕМ ПОЛУЧЕННЫЕ ДНИ НЕДЕЛИ ЧТОБЫ ВСТАВИИТЬ ЕГО В АКТИВТИ

                ХЭШНазваниеДнейНедели.put(ИндексДней, СокращенныйДниМесяцаВТабеле);

                Log.d(this.getClass().getName()," ХЭШНазваниеДнейНедели " +ХЭШНазваниеДнейНедели.toString()+
                        " ХЭШНазваниеДнейНедели.size()  " +ХЭШНазваниеДнейНедели.size());
            }
            ///todo вычисляем сколько дней в месяце текущем
            КоличествоДнейвЗагружаемойМесяце=МетодПолучениеКоличествоДнейвЗагружаемомМесяце(МЕсяцДЛяПоказатаВТАбле ,ГодДЛяПоказатаВТАбле);
            Log.d(this.getClass().getName()," КоличествоДнейвЗагружаемойМесяце " +КоличествоДнейвЗагружаемойМесяце);

            ////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }


    /**
     *
     */
    private  int МетодПолучениеСколькоДнейВКонкретномМесяце(int Год,int Месяц) {
        Date date = null;
        int КонктетныйМесяцВВидеЦифры;
        Calendar cal;
        cal = Calendar.getInstance();
        System.out.println(cal.get(Calendar.MONTH));
        // Create a calendar object and set year and month
        Calendar mycal = new GregorianCalendar(Год, Месяц, 0);
        // Get the number of days in that month
        int КоличествоДнейНаВыбраныйМесяц = mycal.getActualMaximum(Calendar.DAY_OF_MONTH); // 28

        return  КоличествоДнейНаВыбраныйМесяц;
    }






////TODO МЕТОД ТОЛЬКО ДЛЯ ВСТВКИ НОВОГО МЕСЯЦА и ГОД НОВЫЙ




    private int МетодПоказатьМесяцДляЗАписивОднуКолонку(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println( " " + ДатаКоторуюНадоПеревестиИзТекставЦифру + " " +ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatмесяц = new SimpleDateFormat("LLLL  yyyy");
        Date date = formatмесяц .parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        calendar.setTime(date );
        int month = calendar.get(Calendar.MONTH) + 1;
        return   month;
    }

    private int  МетодПоказатьГодДляЗАписивОднуКолонку(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println( "ДатаКоторуюНадоПеревестиИзТекставЦифру " +ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatгод = new SimpleDateFormat("LLLL  yyyy");
        Date date = formatгод.parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        calendar.setTime(date );
        int year = calendar.get(Calendar.YEAR);
        return   year ;
    }

    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
    public String ГлавнаяДатаИВремяОперацийСБазойДанных() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);
    }










    //////TODO СООБЩЕНИЕ ДЛЯ ВЫБОРА ЧТО ДЕЛАТЬ СОЗЖАВАТЬ НОВОГО ПОЛЬЗОВАТЕЛЕЯ ИЛИ ПОДОБРАТЬ УЖЕ СОЗДАННОГО СОТРУДНИКА
    @UiThread
    public void СообщениеДляВыбораСозданиеНовогоСотрудникаИлиЕгоПодобратьДляТабеля(String ШабкаДиалога,boolean Флаг,String UUIDТабеляФинал ,
                                                                                   String МесяцТабеляФинал, String ДепартаментТабеляФинал ) {//  ////MESSAGEBOX ДЛЯ ИНТЕРНЕТА  ПОДКЛЮЧЕНИЕ не успешное нет связи с итрнтнето и/или файлом json
        try{
            //super.MessageBoxs(ШабкаДиалога, СообщениеДиалога, Выбор);
            int ЦветЗначек;
            String ТекстПродолжениеОбновление;
            final AlertDialog DialogBox = new MaterialAlertDialogBuilder(this)
                    .setTitle(ШабкаДиалога)
                    .setPositiveButton( "Новый Сотрудник ?", null)
                    .setNegativeButton("Выбрать Сотрудника ?", null)
                    .setNeutralButton("Закрыть", null)
                    .setIcon(R.drawable.icon_dsu1_new_customer2)
                    .show();

            ///TODO КНОПКА выбор  ДОБАВЛЕНИЕ УЩЕ СУЩЕСТВУЮЩЕГО СОТРУДНИКА
            final Button КнопкаПодобратьНовогоСотрудникаДляТАбеля = DialogBox.getButton(AlertDialog.BUTTON_NEGATIVE);
            DialogBox.getButton(Dialog.BUTTON_NEGATIVE).setTextSize(12);
            DialogBox.getButton(Dialog.BUTTON_NEGATIVE).setTypeface(null, Typeface.BOLD);//////ВЫДЕЛЕМ ЖИРНЫМ ЦВЕТОМ ДАТЫ
            КнопкаПодобратьНовогоСотрудникаДляТАбеля.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Log.d(this.getClass().getName(), "  Кнопка закрыть");
                    //удаляем с экрана Диалог
                    DialogBox.dismiss();
                    //TODO ПОДОБРАТЬ СОТРУДНИКА СУЩЕСТЮЩЕГО
                    Log.d(this.getClass().getName(), " " );

                    Intent Интент_ЗапускПодобратьУжеСуществующегоСотрудника = new Intent();

                    Интент_ЗапускПодобратьУжеСуществующегоСотрудника.setClass(getApplication(), MainActivity_Find_Customers.class);

                    // передача объекта с ключом "hello" и значением "Hello World"
                    Интент_ЗапускПодобратьУжеСуществующегоСотрудника.putExtra("ДепартаментТабеляФинал", ДепартаментТабеляФинал);
                    Log.d(this.getClass().getName(), " ДепартаментТабеляФинал " + ДепартаментТабеляФинал);
                    //////////todo разница если новый сотрудник и ранее созданный
                    if (UUIDТабеляФинал!=null){
                        Интент_ЗапускПодобратьУжеСуществующегоСотрудника.putExtra("UUIDТабеляФинал", UUIDТабеляФинал);
                        Log.d(this.getClass().getName(), "UUIDТабеляФинал" + UUIDТабеляФинал);
                    }else if (UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя!=null){
                        Интент_ЗапускПодобратьУжеСуществующегоСотрудника.putExtra("UUIDТабеляФинал", UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя);
                        Log.d(this.getClass().getName(), " UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя "
                                + UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя);
                    }else{
                        Интент_ЗапускПодобратьУжеСуществующегоСотрудника.putExtra("UUIDТабеляФинал", UUIDТабеляПослеУспешногоСозданиеСотрудника);
                        Log.d(this.getClass().getName(), "UUIDТабеляПослеУспешногоСозданиеСотрудника" + UUIDТабеляПослеУспешногоСозданиеСотрудника);
                    }

                    /////
                    Интент_ЗапускПодобратьУжеСуществующегоСотрудника.putExtra("МесяцТабеляФинал", МесяцТабеляФинал);
                    Log.d(this.getClass().getName(), "МесяцТабеляФинал" + МесяцТабеляФинал);
                    /////
                    Интент_ЗапускПодобратьУжеСуществующегоСотрудника.putExtra("ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника", НазваниеЗагруженногТАбеля);
                    Log.d(this.getClass().getName(), "  НазваниеЗагруженногТАбеля  " + НазваниеЗагруженногТАбеля);
                    ////
                    Интент_ЗапускПодобратьУжеСуществующегоСотрудника.putExtra("МЕсяцДляКурсораТабелей", МЕсяцДляКурсораТабелей);
                    Log.d(this.getClass().getName(), "  МЕсяцДляКурсораТабелей  " + МЕсяцДляКурсораТабелей);
                    /////
                    Интент_ЗапускПодобратьУжеСуществующегоСотрудника.putExtra("ГодДляКурсораТабелей", ГодДляКурсораТабелей);
                    Log.d(this.getClass().getName(), "ГодДляКурсораТабелей " + ГодДляКурсораТабелей);


                    Интент_ЗапускПодобратьУжеСуществующегоСотрудника.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    /////
                    startActivity(Интент_ЗапускПодобратьУжеСуществующегоСотрудника);


                    ////--- ТУТ СТРАРТУЕТ НАЧАЛО ОБМЕНА МЕЖДУ АНДРОЙДОМ И СЕРВЕРОМ ( СИНХРОНИЗАЦИЯ ДАННЫХ  )
                }
            });








/////TODO КНОПКА СОЗДАНИЯ НОВОГО СОТРУДКНИКА
            final Button КнопкаСозданиеНовогоСотрудникаДляТАбеля = DialogBox.getButton(AlertDialog.BUTTON_POSITIVE);
            DialogBox.getButton(Dialog.BUTTON_POSITIVE).setTextSize(12);
            DialogBox.getButton(Dialog.BUTTON_POSITIVE).setTypeface(null, Typeface.BOLD);//////ВЫДЕЛЕМ ЖИРНЫМ ЦВЕТОМ ДАТЫ
            КнопкаСозданиеНовогоСотрудникаДляТАбеля.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Log.d(this.getClass().getName(), "  Кнопка добавить нового ");
                    //удаляем с экрана Диалог
                    DialogBox.dismiss();
                    //////TODO В ДАННОМ КОДЕ МЫ ДОБАВЛЯЕМ УЖЕ СУЩЕСТВУЮЩЕГО СОТРУДКА В ТАБЕЛЬ НОВОГО СОТДУНИКА ДЛЯ ДОБАВЛЕНИЕ ЕГО В  ТАБЕЛЬ
                    //////TODO В ДАННОМ КОДЕ МЫ СОЗДАЕМ НОВОГО СОТДУНИКА ДЛЯ ДОБАВЛЕНИЕ ЕГО В  ТАБЕЛЬ

                    ////TODO ИНТРЕНТ КОТОРЫЙ СОЗДАЕТ НОВГО СОТРУДНИКА
                    Intent Интент_ЗапускСозданиеНовогоСотрудника = new Intent();
                    Интент_ЗапускСозданиеНовогоСотрудника.setClass(getApplication(), MainActivity_New_Cusomers.class); //  ТЕСТ КОД КОТОРЫЙ ЗАПУСКАЕТ ACTIVITY VIEWDATA  ПРОВЕРИТЬ ОБМЕН
                    // передача объекта с ключом "hello" и значением "Hello World"
                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ДепартаментТабеляФинал", ДепартаментТабеляФинал);
                    Log.d(this.getClass().getName(), " ДепартаментТабеляФинал " + ДепартаментТабеляФинал);
                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("UUIDТабеляФинал", UUIDТабеляФинал);
                    Log.d(this.getClass().getName(), "UUIDТабеляФинал" + UUIDТабеляФинал);
                    /////
                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("МесяцТабеляФинал", МесяцТабеляФинал);
                    Log.d(this.getClass().getName(), "МесяцТабеляФинал" + МесяцТабеляФинал);
                    /////
                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника", НазваниеЗагруженногТАбеля);
                    Log.d(this.getClass().getName(), "  НазваниеЗагруженногТАбеля  " + НазваниеЗагруженногТАбеля);
                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("UUIDТабеляПослеУспешногоСозданиеСотрудника", UUIDТабеляПослеУспешногоСозданиеСотрудника);
                    Log.d(this.getClass().getName(), "  UUIDТабеляПослеУспешногоСозданиеСотрудника " + UUIDТабеляПослеУспешногоСозданиеСотрудника);

                    Интент_ЗапускСозданиеНовогоСотрудника.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);


                    /////
                    startActivity(Интент_ЗапускСозданиеНовогоСотрудника);


                    ////--- ТУТ СТРАРТУЕТ НАЧАЛО ОБМЕНА МЕЖДУ АНДРОЙДОМ И СЕРВЕРОМ ( СИНХРОНИЗАЦИЯ ДАННЫХ  )
                }
            });


            ///TODO КНОПКА ЗАКРЫТИЕ СООБЩЕНИЯ
            final Button КнопкаЗакрытьСообщкение = DialogBox.getButton(AlertDialog.BUTTON_NEUTRAL);
            DialogBox.getButton(Dialog.BUTTON_NEUTRAL).setTextSize(12);
            DialogBox.getButton(Dialog.BUTTON_NEUTRAL).setTextColor(Color.GRAY);
            DialogBox.getButton(Dialog.BUTTON_NEUTRAL).setTypeface(null, Typeface.BOLD);//////ВЫДЕЛЕМ ЖИРНЫМ ЦВЕТОМ ДАТЫ
            КнопкаЗакрытьСообщкение.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Log.d(this.getClass().getName(), "  Кнопка добавить уже сущетсвующего сотрудника ");
                    //удаляем с экрана Диалог
                    DialogBox.dismiss();
                    //////TODO В ДАННОМ КОДЕ МЫ добавлем существующего СОТДУНИКА ДЛЯ ДОБАВЛЕНИЕ ЕГО В  ТАБЕЛЬ
                    ////--- ТУТ СТРАРТУЕТ НАЧАЛО ОБМЕНА МЕЖДУ АНДРОЙДОМ И СЕРВЕРОМ ( СИНХРОНИЗАЦИЯ ДАННЫХ  )

                }
            });


        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }




    private int  МетодПолучениниеМесяцДляКурсора(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println( " " + ДатаКоторуюНадоПеревестиИзТекставЦифру + " " +ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatмесяц = new SimpleDateFormat("LLLL  yyyy");
        Date date = formatмесяц .parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        Calendar calendar2 = new GregorianCalendar();
        calendar.setTime(date );
        int month = calendar.get(Calendar.MONTH) + 1;
        return   month;
    }

    //TODO метод получени месяа для записи в одну колонку

    private int  МетодПолучениниеГодДляКурсора(String ДатаКоторуюНадоПеревестиИзТекставЦифру) throws ParseException {
        System.out.println( "ДатаКоторуюНадоПеревестиИзТекставЦифру " +ДатаКоторуюНадоПеревестиИзТекставЦифру);
        SimpleDateFormat formatгод = new SimpleDateFormat("LLLL  yyyy");
        Date date = formatгод.parse(ДатаКоторуюНадоПеревестиИзТекставЦифру);
        Calendar calendar = Calendar.getInstance(new Locale("ru"));
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        return   year ;
    }





    public String ГлавнаяДатаИВремяДляТабеля() {
        Date Дата = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        //dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
        Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
        return dateFormat.format(Дата);
    }
    ///todo ОПРЕДЕЛЯЕМ КОЛИЧЕСТВО ДНЕЙ ЗАГРУЖАЕМОЙ МЕСЯЦ
    protected int МетодПолучениеКоличествоДнейвЗагружаемомМесяце(int Месяц ,int месяцДляСокращенно) {
        Date date = null;
        int КонктетныйМесяцВВидеЦифры;
        try {
            String МесяцПлюсНоль=String.valueOf(Месяц);
            if (МесяцПлюсНоль.length() == 1){
                МесяцПлюсНоль="0"+МесяцПлюсНоль;
            }
            date = new SimpleDateFormat("MMyyyy",new Locale("rus")).parse(МесяцПлюсНоль+ месяцДляСокращенно);
            System.out.println(" date " +date);

        } catch (
                ParseException e) {
            e.printStackTrace();
        }

        Calendar  cal = Calendar.getInstance();
        cal.setTime(date);
        КонктетныйМесяцВВидеЦифры=cal.get(Calendar.MONTH);
        System.out.println(cal.get(Calendar.MONTH));
        // Create a calendar object and set year and month
        // Get the number of days in that month
        int daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH); // 28

        return  daysInMonth;
    }









    ///todo сообщение
    @UiThread
    protected void СообщениеПредпреждаетОВыбореУдалениеСотрудникаИзТабеля(String ШабкаДиалога,  String СообщениеДиалога,
                                                                          String ДляУдалениеUUID,String СамИндификаторUUID,String ФИОДляУдаление) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
//////сам вид
        final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                .setTitle(ШабкаДиалога)
                .setMessage(СообщениеДиалога)
                .setPositiveButton("ОК", null)
                .setIcon(R.drawable.icon_dsu1_tabel_info)
                .show();
/////////кнопка
        final Button MessageBoxUpdateСоздатьТабель = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
        MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
            ///MessageBoxUpdate метод CLICK для DIALOBOX
            @Override
            public void onClick(View v) {
                //удаляем с экрана Диалог
                alertDialog.dismiss();


                МетодСообщенииУдалениеСотрудника(       ДляУдалениеUUID,СамИндификаторUUID,ФИОДляУдаление);


            }


        });
    }


    private void МетодСообщенииУдалениеСотрудника(String ДляУдалениеUUID,String СамИндификаторUUID,String ФИОДляУдаление) {
        МыУжеВКодеУденияСотрудника=false;
        Log.d(this.getClass().getName(), "  ФИНАЛ создание нового сотрудника ");
        СообщениеВыборУдлаляниИлиНЕтСотрудникаИзБазы("Удаление сотрудника","Удаление выбраного сотрудника: " + ФИОДляУдаление+
                " из текущего Табеля ",ДляУдалениеUUID,СамИндификаторUUID,true)  ;
    }






    ///todo сообщение информация о ФИО
    @UiThread
    protected void СообщениеИнформацияОФИО(String ШабкаДиалога,  String СообщениеДиалога) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
//////сам вид
        final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                .setTitle(ШабкаДиалога)
                .setMessage(СообщениеДиалога)
                .setPositiveButton("ОК", null)
                .setIcon(R.drawable.icon_dsu1_info_customer)
                .show();
/////////кнопка
        final Button MessageBoxUpdateСоздатьТабель = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
        MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
            ///MessageBoxUpdate метод CLICK для DIALOBOX
            @Override
            public void onClick(View v) {
                //удаляем с экрана Диалог
                alertDialog.dismiss();
                Log.d(this.getClass().getName(), "  ФИНАЛ создание нового сотрудника ");

            }
        });
    }




    ///TODOVTNJL ПЕРЕХОДА НА АКТИВТИ МЕТКИ ТАБЕЛЯ

    private void МетодПереходаНаМеткиТабеля(HashMap<String,Long> ХэшЛовимUUIDIDНазваниеСтолбикаЛокальныйСловоВставитьТабель) {
        Intent IntentЗапускаемСправочникДЛяСловТабеля=new Intent();
        try{

            IntentЗапускаемСправочникДЛяСловТабеля.setClass(КонтекстОдногоСотрудикаВТабеле, MainActivity_Status_Value_Tabels.class); // Т

            Log.d(this.getClass().getName(), "  ХэшЛовимUUIDIDНазваниеСтолбикаЛокальныйСловоВставитьТабель " +ХэшЛовимUUIDIDНазваниеСтолбикаЛокальныйСловоВставитьТабель.values());

            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("HashMap", ХэшЛовимUUIDIDНазваниеСтолбикаЛокальныйСловоВставитьТабель);
            //////


            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("ДепартаментТабеляПослеПодбора", ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);
            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("UUIDТабеляПослеПодбора", UUIDТабеляПослеУспешногоСозданиеСотрудника);
            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("UUIDТабеляПослеПодбораУниверсальный",  UUIDCтарыйУжеСозданногоТабеляВКоторыйИНужноДобавитьНовгоПользователя);
            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("МесяцТабеляПослеПодбора", МесяцТабеляФинал);
            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("ПолноеНазваниеЗагруженногТАбеляПослеПодбора",ПолноеИмяТабеляПослеСозданиеНовогоСотрудника );
            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника", UUIDТабеляПослеУспешногоСозданиеСотрудника);
            Log.d(this.getClass().getName(), "  UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника " + UUIDТабеляПослеУспешногоСозданиеСотрудника);
            //год и месяц цифр
            //Интент_ПослеПодбораДействуещегоСотрудникаОтпраляемЕгоДляВставки.putExtra("МЕсяцДляКурсораТабелейПослеПодбора", МЕсяцПриВставкеНовогоСотрудника);
            // Интент_ПослеПодбораДействуещегоСотрудникаОтпраляемЕгоДляВставки.putExtra("ГодДляКурсораТабелейПослеПодбора",ГодПриВставкеНовогоСотрудника);
            //todo передает контент при нажатии на кнопку back
            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("UUIDТабеляКнопкаBACKУниверсальный",
                    UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников);
            ///TODO ОПИСАНИЕ ЧТО ПЕРЕДАЕМ
            Log.d(  this.getClass().getName(), " ПолноеНазваниеЗагруженногТАбеля" +ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);


            ///////TODO отправляем данные через интент в АКТИВТИ  МЕТКА ТАБЕЛЯ

            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("ДепартаментТабеляИзВсехСотрудниковВТАбеле", ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);


            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("UUIDТабеляФиналПослеВыбораИзВсехСотрудниковВТАбеле",UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников);

            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("МесяцТабеляФиналИзВсехСотрудниковВТАбеле", МесяцТабеляФинал);

            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("IDЧьиДанныеДляСотрудников",IDЧьиДанныеДляСотрудников);


            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("ГодФиналИзВсехСотрудниковВТАбеле",    ГодТабеляПослеПодбораУниверсальный);



            IntentЗапускаемСправочникДЛяСловТабеля.putExtra("ЦифровоеИмяНовгоТабеля",    ЦифровоеИмяНовгоТабеля );









            IntentЗапускаемСправочникДЛяСловТабеля.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
////todo запускаем активти
            startActivity( IntentЗапускаемСправочникДЛяСловТабеля);

            /// finish();
            КонтекстОдногоСотрудикаВТабелеВнешний=null;

            ХэшЛовимUUIDIDНазваниеСтолбика=null;



        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }










    ///todo сообщение
    @UiThread
    protected void СообщениеПослеУдаленияСотрудникаИзТабеля(String ШабкаДиалога,  String СообщениеДиалога,boolean Статус) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
//////сам вид
        int Значек;
        if (Статус){
            Значек  =R.drawable.icon_dsu1_tabel_info;
        }else{
            Значек  =R.drawable.icon_dsu1_delete_customer;
        }
        final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                .setTitle(ШабкаДиалога)
                .setMessage(СообщениеДиалога)
                .setPositiveButton("ОК", null)
                .setIcon(Значек)
                .show();
/////////кнопка
        final Button MessageBoxUpdateСоздатьТабель = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
        MessageBoxUpdateСоздатьТабель.setOnClickListener(new View.OnClickListener() {
            ///MessageBoxUpdate метод CLICK для DIALOBOX

            @Override
            public void onClick(View v) {
                //удаляем с экрана Диалог
                alertDialog.dismiss();
                Log.d(this.getClass().getName(), "  ФИНАЛ после удалание сотрудуника ");
                //TODO  второе действие заполенние контентом  в табеля в TableLyзаполения табеля из базы через элемент TableLauy
                ///// МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля( МесяцТабеляФинал);
                ///TODO запускаем возврат на предыдущее активывти после успешного удаление сотрудника
                МетодЗапускаетСотрудниковПослеУспешногоУдалениеСотрудника();


                //todo
            }


        });
    }
////todo конец фильаного сообщения о удалени самого табеля


    void МетодЗапускаетСотрудниковПослеУспешногоУдалениеСотрудника() {
        ////TODO ИНТРЕНТ КОТОРЫЙ СОЗДАЕТ НОВГО СОТРУДНИКА
        Intent Интент_ЗапускСозданиеНовогоСотрудника = new Intent();
        Интент_ЗапускСозданиеНовогоСотрудника.setClass(КонтекстОдногоСотрудикаВТабеле, MainActivity_Employees_Tabely.class); //  ТЕСТ КОД КОТОРЫЙ ЗАПУСКАЕТ ACTIVITY VIEWDATA  ПРОВЕРИТЬ ОБМЕН
        // передача объекта с ключом "hello" и значением "Hello World"
        Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ДепартаментТабеляФинал", НазваниеЗагруженногТАбеля);
        Log.d(this.getClass().getName(), " ДепартаментТабеляФинал " + НазваниеЗагруженногТАбеля);
        /////
        Интент_ЗапускСозданиеНовогоСотрудника.putExtra("МесяцТабеляФинал", МесяцТабеляФинал);
        Log.d(this.getClass().getName(), "МесяцТабеляФинал" + МесяцТабеляФинал);
        /////
        Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ДепартаментТабеляВКоторомИНадоСоздатьНовогоСотрудника", НазваниеЗагруженногТАбеля);
        Log.d(this.getClass().getName(), "  НазваниеЗагруженногТАбеля  " + НазваниеЗагруженногТАбеля);
        Интент_ЗапускСозданиеНовогоСотрудника.putExtra("UUIDТабеляПослеУспешногоСозданиеСотрудника", UUIDТабеляПослеУспешногоСозданиеСотрудника);
        Log.d(this.getClass().getName(), "  UUIDТабеляПослеУспешногоСозданиеСотрудника " + UUIDТабеляПослеУспешногоСозданиеСотрудника);
        Интент_ЗапускСозданиеНовогоСотрудника.putExtra("UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника", UUIDТабеляПослеУспешногоСозданиеСотрудника);
        Log.d(this.getClass().getName(), "  UUIDТабеляВКоторомИНадоСоздатьНовогоСотрудника " + UUIDТабеляПослеУспешногоСозданиеСотрудника);


        Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ЦифровоеИмяНовгоТабеляSingle", ЦифровоеИмяНовгоТабеля);


        Log.d(this.getClass().getName(), "  ЦифровоеИмяНовгоТабеля " + ЦифровоеИмяНовгоТабеля);


        Интент_ЗапускСозданиеНовогоСотрудника.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);


        /////
        startActivity(Интент_ЗапускСозданиеНовогоСотрудника);

        // finish();
    }



    ///todo сообщение
    @UiThread
    protected void СообщениеВыборУдлаляниИлиНЕтСотрудникаИзБазы(String ШабкаДиалога,  String СообщениеДиалога,  String UUID,
                                                                String СамоЗначениеUUID,boolean статус ) {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
        try {
//////сам вид
            final AlertDialog alertDialog = new MaterialAlertDialogBuilder(this)
                    .setTitle(ШабкаДиалога)
                    .setMessage(СообщениеДиалога)
                    .setPositiveButton("Удаление", null)
                    .setNegativeButton("Нет", null)
                    .setIcon(R.drawable.icon_dsu1_delete_customer)
                    .show();
/////////кнопка
            final Button MessageBoxУдалениеСотрудникаИзТабеля = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            MessageBoxУдалениеСотрудникаИзТабеля .setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog.dismiss();
                    Log.d(this.getClass().getName(), "  ФИНАЛ создание нового сотрудника " + " UUID " +UUID+ " СамоЗначениеUUID " + СамоЗначениеUUID);


                    Log.d(this.getClass().getName(), "При удалении сотрудника СамоЗначениеUUID " +СамоЗначениеUUID+ " UUID  " +UUID);



                    МетодУдалениеСотрудникаИзТабеля(UUID,СамоЗначениеUUID); //// TODO передаеюм UUID для Удалание

                }
            });

            /////////кнопка
            final Button MessageBoxУдалениеСотрудникаИзТабеляОтмена = alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            MessageBoxУдалениеСотрудникаИзТабеляОтмена.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog.dismiss();
                }
            });


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }





































    private void МетодСвайпВпередПоДАнным() {
        try {
            Log.d(this.getClass().getName(), "ЗАПУСК  Свайп  moveLeft  СПРАВО НА ЛЕВО    onFling   " + new Date());
CountDownLatch countDownLatchДляДвиженияПоДАннымВперед=new CountDownLatch(1);

            // Интент_ЗапускСозданиеНовогоСотрудника.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            //slidrInterface.unlock();
            if (ОбщееКоличествоСОтрудниковДляСкролаПотабелю>1) {

            // TODO: 06.05.2021 СПРАВО НА ЛЕВО
            // TODO: 21.05.2021 увеличиваем значение


                if (ТекущееПоложенияВТабелеДляСкрола == ОбщееКоличествоСОтрудниковДляСкролаПотабелю) {
                    ТекущееПоложенияВТабелеДляСкрола = 1;


                } else {

                    if (ТекущееПоложенияВТабелеДляСкрола <= ОбщееКоличествоСОтрудниковДляСкролаПотабелю) {
                        ТекущееПоложенияВТабелеДляСкрола++;
                    }
                }





                    // TODO: 05.05.2021  moveRight








                countDownLatchДляДвиженияПоДАннымВперед.countDown();
                ///
                countDownLatchДляДвиженияПоДАннымВперед.await();

                ///////////////////////вперед

                if (ТекущееПоложенияВТабелеДляСкрола <= ОбщееКоличествоСОтрудниковДляСкролаПотабелю) {

/*    //TODO #5
МетодЗаполненияАлайЛИстаНовымМЕсцевНовогоТабеля(МесяцТабеляФинал, ТекущееПоложенияВТабелеДляСкрола);

///TODO запускаем метод ПОСЛЕ УСПЕШНОЙ ГЕНЕРАЦИИ ТАБЕЛЯ

МетодПослеУспешнойГенерацииТабеля();*/
                    // TODO: 07.05.2021 вперед  
                    // TODO: 24.05.2021 обнуляем переменные перед передозом 

                    UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников=0l;
                    
                    
                    
                    


                    Intent Интент_ЗапускСозданиеНовогоСотрудника = new Intent();
                    ///////
                    Интент_ЗапускСозданиеНовогоСотрудника.setClass(getApplicationContext(), MainActivity_Single_Tabely.class); //  ТЕСТ КОД КОТОРЫЙ ЗАПУСКАЕТ ACTIVITY VIEWDATA  ПРОВЕРИТЬ ОБМЕН

                    Интент_ЗапускСозданиеНовогоСотрудника.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);


                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("setIDСамогоТабеляВКотромМыНаходились", ТекущееПоложенияВТабелеДляСкрола);

                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("МЕсяцДляКурсораТабелей", МЕсяцДляКурсораТабелейДЛяПермещения);

                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ПередаемСозданнуюДатуНовогоТабеля", МесяцТабеляФинал);


                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ПолноеНазваниеТабеляФинал", ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);


                    Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ЦифровоеИмяНовгоТабеля", ЦифровоеИмяНовгоТабеля);


                    Log.d(getPackageName().getClass().getName(), "swipe  переход через сфайп  ТекущееПоложенияВТабелеДляСкрола" +ТекущееПоложенияВТабелеДляСкрола );


                    if (!Курсор_ЗагружаемТабеляСозданный[0].isClosed()) {
                        Курсор_ЗагружаемТабеляСозданный[0].close();
                    }
                    Курсор_ЗагружаемТабеляСозданный[0]=null;


                    ХэшЛовимUUIDIDНазваниеСтолбика=null;

                    /////
                    startActivity(Интент_ЗапускСозданиеНовогоСотрудника);
                    ///
                    overridePendingTransition( R.transition.svayp_left_up,R.transition.svayp_reght_up);
// TODO: 06.05.2021 вперед по данным

                }


            }

            // TODO: 28.04.2021 ПЕРЕД ПЕРЕДВИЖЕНЕИМ ПРОВЕРЯЕМ ЕСЛИ ЗНАЧЕНИЯ РАВНЫ ТО ОБНУЛЯЕМ ИНДЕКС ПЕРЕМЕЖЕНИЯ




            ///////

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());


        }
    }









    private void МетодСвайпНазаПоДанным() {
        try{
        Log.d(this.getClass().getName(), "ЗАПУСК  moveRight Свайп      onFling   " + new Date());

            CountDownLatch countDownLatchДляДвиженияПоДАннымНазад=new CountDownLatch(1);
            // TODO: 07.05.2021 назад по данным BACK
            if (ОбщееКоличествоСОтрудниковДляСкролаПотабелю>1) {
        // TODO: 06.05.2021 назад
            // TODO: 21.05.2021  Уменьшаем значение на меньшее

                if (ТекущееПоложенияВТабелеДляСкрола == 1) {
                    ТекущееПоложенияВТабелеДляСкрола = ОбщееКоличествоСОтрудниковДляСкролаПотабелю;
                    // ТекущееПоложенияВТабелеДляСкрола=  Курсор_ЗагружаемТабеляСозданный[0].getPosition();

                }else{
                    if (ТекущееПоложенияВТабелеДляСкрола >1) {
                        ТекущееПоложенияВТабелеДляСкрола--;
                    }
                    ///todo вырвиваем индексы

                }




                ///todo вырвиваем индексы


                countDownLatchДляДвиженияПоДАннымНазад.countDown();
                //
                countDownLatchДляДвиженияПоДАннымНазад.await();


                // TODO: 28.04.2021 назад

                // TODO: 07.05.2021 вперед

                UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников=0l;
                //TODO #5
                Intent Интент_ЗапускСозданиеНовогоСотрудника = new Intent();
                ///////
                Интент_ЗапускСозданиеНовогоСотрудника.setClass(getApplicationContext(), MainActivity_Single_Tabely.class); //  ТЕСТ КОД КОТОРЫЙ ЗАПУСКАЕТ ACTIVITY VIEWDATA  ПРОВЕРИТЬ ОБМЕН

                Интент_ЗапускСозданиеНовогоСотрудника.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

                Интент_ЗапускСозданиеНовогоСотрудника.putExtra("setIDСамогоТабеляВКотромМыНаходились", ТекущееПоложенияВТабелеДляСкрола);
                //

                Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ПередаемСозданнуюДатуНовогоТабеля", МесяцТабеляФинал);

                Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ПолноеНазваниеТабеляФинал", ПолноеИмяТабеляПослеСозданиеНовогоСотрудника);

                Интент_ЗапускСозданиеНовогоСотрудника.putExtra("МЕсяцДляКурсораТабелей", МЕсяцДляКурсораТабелейДЛяПермещения);

                Интент_ЗапускСозданиеНовогоСотрудника.putExtra("ЦифровоеИмяНовгоТабеля", ЦифровоеИмяНовгоТабеля);

                if (!Курсор_ЗагружаемТабеляСозданный[0].isClosed()) {
                    Курсор_ЗагружаемТабеляСозданный[0].close();
                }
                Курсор_ЗагружаемТабеляСозданный[0]=null;


                /////
                startActivity(Интент_ЗапускСозданиеНовогоСотрудника);
                ///
                overridePendingTransition( R.transition.svayp_left_down,R.transition.svayp_reght_down);
            }

// TODO: 06.05.2021 назад по данным BACK

        ///////

    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());


    }
    }











    // TODO: 06.05.2021  созадение тача для свайпов   созадение тача для свайпов   созадение тача для свайпов   созадение тача для свайпов   созадение тача для свайпов   созадение тача для свайпов



}



