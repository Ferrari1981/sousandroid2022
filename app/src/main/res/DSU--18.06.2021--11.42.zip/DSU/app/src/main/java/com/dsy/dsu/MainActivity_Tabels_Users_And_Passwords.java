package com.dsy.dsu;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.SQLException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.loader.content.AsyncTaskLoader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.zip.GZIPInputStream;



import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.SecretKeySpec;


import static com.dsy.dsu.PUBLIC_CONTENT.ССылкаНаСозданнуюБазу;

public class MainActivity_Tabels_Users_And_Passwords extends AppCompatActivity {
    ////todo аунтификация
    int ПодсчетОтрицательныйРезультатовАунтификации; ////подсчитываем количество негативныйх попыток долеее 5 послываем программу в спячку

    ///////
    protected Button КнопкаВходавСистему;///КНОПКА ДЛЯ ВХОДЯ В СИСТЕМУ
    protected ProgressBar ПрогрессБарДляВходаСистему;///КНОПКА ДЛЯ ВХОДЯ В СИСТЕМУ
    protected EditText ИмяДляВходаСистему;///КНОПКА ДЛЯ ВХОДЯ В СИСТЕМУ
    protected EditText ПарольДляВходаСистему;///КНОПКА ДЛЯ ВХОДЯ В СИСТЕМУ
    Configuration config;


    protected Context КонтекстСинхроДляАунтификации;


    ////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try{
            super.onCreate(savedInstanceState);

            ////
            КонтекстСинхроДляАунтификации=this;

            ((Activity)  КонтекстСинхроДляАунтификации) .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


            ((Activity) КонтекстСинхроДляАунтификации) .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);


            ////todo запрещяет поворот экрана
            //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            setContentView(R.layout.activity_main__authentication);

            getSupportActionBar().hide(); ///скрывать тул бар

            /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);


         //   getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION  );
            ////
/*
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);*/
            /////
            Log.d(this.getClass().getName(),"   ");
            // Locale locale = Locale.ROOT;
            Locale locale = new Locale("rus");
            Locale.setDefault(locale );
            config =
                    getBaseContext().getResources().getConfiguration();
            config.setLocale(locale);
            createConfigurationContext(config);
            ///TODO разное

            ////
            ////// TODO созданеи шифрование
            if ( PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки==null) {
                //TODO ключ для шифрование и расщифровки
                byte[] CipherKey= "[C@3841f624[B@6415a86b[B@143c678".getBytes();
                PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки =
                        new SecretKeySpec(CipherKey,
                                "AES");
                PUBLIC_CONTENT.ПолитикаШифрование= Cipher.getInstance("AES");
                PUBLIC_CONTENT.ПолитикаШифрование.init(Cipher.ENCRYPT_MODE, PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки);
                ///////
                PUBLIC_CONTENT.ПолитикаРасшифровки= Cipher.getInstance("AES");
                PUBLIC_CONTENT. ПолитикаРасшифровки.init(Cipher.DECRYPT_MODE, PUBLIC_CONTENT.ГлавныйКлючДляШифрованиеИРасшифровки);
                ///// конец шифрование

            }
            ////// конец  TODO созданеи шифрование



            ///TODO компоненты ДЛЯ АУНТИФИКАЦИИИ
        /*    МетодАунтификацииПользователяПриВходевПрограммуДСУ1();//// данный метод в будущем будет запускаться с  кнопки
        // запускаем метод аунтификации пользователя при входе в программу и сучимся на сервлет*/
            Log.d(getPackageName().getClass().getName(), " onCreate(Bundle savedInstanceState)  MainActivity_Tabels_Users_And_Passwords ");


            КнопкаВходавСистему = (Button) findViewById(R.id.КнопкаВходаВПриложение);/////кнопка входа на сервер
            КнопкаВходавСистему.setVisibility(View.VISIBLE);

            ПрогрессБарДляВходаСистему =(ProgressBar)  findViewById(R.id.progressBarДляWIFI); ////програссбар при аунтификации при входе в системму
            ПрогрессБарДляВходаСистему.setVisibility(View.INVISIBLE);// по умолчанию прогресс бар делаем не видеым

            ИмяДляВходаСистему=(EditText )  findViewById(R.id.ИмяДляВходавПрограмму); ////програссбар при аунтификации при входе в системму
            ПарольДляВходаСистему =(EditText )  findViewById(R.id.ПарольДляВходавПрограмму); ////програссбар при аунтификации при входе в системму

            ///////TODO 1



            ///TODO установка разрешений





            String[] permissions = new String[]{
                    Manifest.permission.INTERNET,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.VIBRATE,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.REQUEST_INSTALL_PACKAGES,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS,
                    Manifest.permission.MANAGE_EXTERNAL_STORAGE,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.ACCESS_MEDIA_LOCATION,
                    Manifest.permission.INSTALL_PACKAGES,
                    Manifest.permission.WRITE_SETTINGS,
                    Manifest.permission.WRITE_SECURE_SETTINGS


            };

            //  startService(new Intent(КонтекстFaceApp, Service_ОбновлениеПО.class));
////TODO УСТАНВЛИВАЕМ РАЗРЕШЕНИЯ НА ВСЕ ПРИЛОЖЕНИЯ НАСТРОЙКИ
            ActivityCompat.requestPermissions(this, permissions, 1);







            /////// МетодПодготовкиДляАунтификации(); ////МЕТОД ПРЕДВАРИТЕЛЬНОГО ПОДГОТОВКИ К АУНТИФИКАЦИИ ПОЛЬЗОВАТЛЕЯ

        } catch (Exception e) {
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber() + " ПодсчетОтрицательныйРезультатовАунтификации " + ПодсчетОтрицательныйРезультатовАунтификации);
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }











    @Override
    protected void onDestroy() {
        super.onDestroy();

        //////TODO  данный код срабатывает когда произошда ошивка в базе


    }












    @Override
    protected void onResume() {
        super.onResume();
        try{
            ///////
            МетодПодготовкиДляАунтификации(); ////МЕТОД ПРЕДВАРИТЕЛЬНОГО ПОДГОТОВКИ К АУНТИФИКАЦИИ ПОЛЬЗОВАТЛЕЯ

        } catch (Exception e) {
            ///метод запись ошибок в таблицу
            ПодсчетОтрицательныйРезультатовАунтификации++;///подсчитываем ошибки для точго чтобы приложение пошло спать
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber() + " ПодсчетОтрицательныйРезультатовАунтификации " + ПодсчетОтрицательныйРезультатовАунтификации);
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }

    ////////TODO КОТОРЫЙ НАЧИНАЕМ ТОЛЬКО ЕСЛИ ЕСТЬ ИМЯ И ПАРОЛЬ НАЧИНАЕТЬСЯ ТОЛЬКО С НЯЖАТИЕ КНОПКИ ВХОД
    private void МетодПодготовкиДляАунтификации() {
        try{

            КнопкаВходавСистему.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ПрогрессБарДляВходаСистему.setVisibility(View.VISIBLE);// при нажатии делаем видимый програсссбар
                    Log.d(getPackageName().getClass().getName(), "  private void МетодПодготовкиДляАунтификации()");///
                    /////todo два компонета делаем их не видимые
                    ////имя
                    PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета = ИмяДляВходаСистему.getText().toString().trim();///получаем из формы имя для того чтобы постучаться на сервер
                    ////////////пароль
                    PUBLIC_CONTENT. ПубличноеПарольДлСервлета = ПарольДляВходаСистему.getText().toString().trim();///////получаем из формы пароль для того чтобы постучаться на сервер
                    Log.d(getPackageName().getClass().getName(), "ПубличноеИмяПользовательДлСервлета " +PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета + " ПубличноеПарольДлСервлета " +PUBLIC_CONTENT.ПубличноеПарольДлСервлета);

                    Log.d(getPackageName().getClass().getName(), " ПубличноеИмяПользовательДлСервлета.length()" +PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета.length()
                            + " ПубличноеПарольДлСервлета.length() "+ PUBLIC_CONTENT.ПубличноеПарольДлСервлета.length());///


                    /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

                    ////TODO ----НАЧАЛО АУНТИФИКАЦИИ

                    /////todo НАЧИНАЕМ АУНТИФИКАЦИЮ С СЕРЕВЕРОМ ТОЛЬКО ЕСЛИ ЕСТЬ ИМЯ И ПАРОЛЬ ДЛЯ ПРОДОЛЖЕНИЯ
                    if (PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета.length()>0 &&  PUBLIC_CONTENT.ПубличноеПарольДлСервлета.length()>0){
                        ///


                        ////todo проверяем если подключение к интернуту
                        boolean  РезультатНужноЛиНачатьАунтификациюСотрудникаПоРежимуWIFIилиMObile=false;
                        try {
                            /////TODO метод определяет стоит ли начинать СИНХРОНИЗАЦИЮ ЕСЛИ ПОЛЬЗОВАТЕЛЬ ВЫБРАЛ ПРАВИЛЬНУЮ НАСТРОЙКУ MOBILE ВСЕ ДОСТУПНО  MOBILE/WIF А ЕСЛИ ТОЛЬКО WIFI ТТОЛЬКО ЧЕРЕЗ WIFI
                            РезультатНужноЛиНачатьАунтификациюСотрудникаПоРежимуWIFIилиMObile =МетодГлавныйСинхронизацииДанныхКлиентСервер(getApplicationContext());

                            Log.d(getPackageName().getClass().getName(), "РезультатПРоверкиПодключениеWIFI " +РезультатНужноЛиНачатьАунтификациюСотрудникаПоРежимуWIFIилиMObile  );///
                            ////
                        } catch (Exception e) {
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                            ////// начало запись в файл
                        }


/////todo удаление из памяти

                        /////TODO ПРОВЕРЯЕМ ЕЛСИНЕТ ПОДКЛЮЧЕНИЕ К ИНТРЕНТУ ТО СИНХРОНИЗАЦИЮ НЕ НАЧИНАМЕМ если true то начинаем работать
                        if (РезультатНужноЛиНачатьАунтификациюСотрудникаПоРежимуWIFIилиMObile==true) {



                            //TODO запукаем метод аунтификции
                            МетодАунтификацииПользователяПриВходевПрограммуДСУ1();//// данный метод в будущем будет запускаться с  кнопк




/////////TODO ошибка не найден ни локальный не интренет сервер
                        }else{

                            //TODO ЗАПУСКАЕМ ФУТУРЕ
                            ExecutorService ПуулПамяти = Executors.newSingleThreadExecutor(); //
                            ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными
                            Future МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными = ПуулПамяти.submit(new Runnable() {
                                public void run() {
                                    System.out.println("Another thread was executed");

                                    //TODO ЗАПУСКАЕМ ФУТУРЕ
                                    runOnUiThread(new Runnable()
                                    {
                                        public void run()
                                        {
                                            ПрогрессБарДляВходаСистему.setVisibility(View.VISIBLE);// при нажатии делаем видимый програсссбар


                                            ///TODO после синхронизации ПОКАЗЫВАЕМ ПОЛЬЗОВАТЕЛЮ ЧТО КОЛИЧЕСТОВ УСПЕШНЫХ ВСТАВОК И ОБНОВЕЛЕНИЙ СИНХРОНИЗАЦИИ В ФОНЕ

                                                Toast aa = Toast.makeText(КонтекстСинхроДляАунтификации, "OPEN",Toast.LENGTH_SHORT);
                                                ImageView cc = new ImageView(КонтекстСинхроДляАунтификации);
                                           //     cc.setImageResource(R.drawable.icon_dsu1_synchronis_error_down);//icon_dsu1_synchronisazia_dsu1_success
                                                aa.setView(cc);
                                                aa.show();

                                                ////
                                                //  Toast.makeText(context, "данных для Cинхронизации в фоне нет !!!!" , Toast.LENGTH_SHORT).show();

                                            Toast.makeText(getApplicationContext(), "Нет связи c Cервер/Интернетом ", Toast.LENGTH_SHORT).show();
                                            try {
                                                TimeUnit.MILLISECONDS.sleep(100);
                                            } catch (InterruptedException e) {
                                                e.printStackTrace();
                                            }
                                            ПрогрессБарДляВходаСистему.setVisibility(View.INVISIBLE);// по умолчанию прогресс бар делаем не видеым
                                        }
                                    });

                                }});
                            //TODO ЗАПУСКАЕМ ФУТУРЕ
                            try {
                                МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.get();
                                if (МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.isDone()) {
                                    //TODO ЗАПУСКАЕМ "Эксенкюторе"
                                    ПуулПамяти.shutdown();
                                    МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.cancel(false);

                                }
                            } catch (ExecutionException e) {
                                e.printStackTrace();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                        }////end проверки если сеть или нет TRUE


                        //TODO ОШИБКА КОГДА ВЫ КАК ПОЛЬЗОВАТЕЛЬ НЕ ВПИСАЛИ  ИМЯ И ПАРОЛЬ ДЛЯ АУНДИФИКАЦИИ
                    }else{

                        ExecutorService ПуулПамяти = Executors.newSingleThreadExecutor(); //
                        ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными
                        Future МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными = ПуулПамяти.submit(new Runnable() {
                            public void run() {
                                System.out.println("Another thread was executed");

                                //TODO ЗАПУСКАЕМ ФУТУРЕ
                                runOnUiThread(new Runnable()
                                {
                                    public void run()
                                    {
                                        ПрогрессБарДляВходаСистему.setVisibility(View.VISIBLE);// при нажатии делаем видимый програсссбар
                                        /////
                                        Toast aa = Toast.makeText(КонтекстСинхроДляАунтификации, "OPEN",Toast.LENGTH_SHORT);
                                        ImageView cc = new ImageView(КонтекстСинхроДляАунтификации);
                                        cc.setImageResource(R.drawable.icon_dsu1_error_antrficar_users);//icon_dsu1_synchronisazia_dsu1_success
                                        aa.setView(cc);
                                        aa.show();



                                        ////////
                                        Toast.makeText(getApplicationContext(), "Вы не заполнили Имя/Пароль (заполните все поля и попробуйте еще раз ) ", Toast.LENGTH_SHORT).show();
                                        try {
                                            TimeUnit.MILLISECONDS.sleep(100);
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }
                                        ПрогрессБарДляВходаСистему.setVisibility(View.INVISIBLE);// по умолчанию прогресс бар делаем не видеым
                                    }
                                });

                            }});
                        //TODO ЗАПУСКАЕМ ФУТУРЕ
                        try {
                            МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.get();

                            if (МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.isDone()) {
                                //TODO ЗАПУСКАЕМ "Эксенкюторе"
                                ПуулПамяти.shutdown();
                                МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.cancel(false);

                            }
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }








                    }
                }
            });

        } catch (Exception e) {
            ///метод запись ошибок в таблицу
            ПодсчетОтрицательныйРезультатовАунтификации++;///подсчитываем ошибки для точго чтобы приложение пошло спать
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber() + " ПодсчетОтрицательныйРезультатовАунтификации " + ПодсчетОтрицательныйРезультатовАунтификации);
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }





    ////TODO САМ МЕТОД АУНТИФИКАЦИИ С СЕРВЕРОМ
    private void МетодАунтификацииПользователяПриВходевПрограммуДСУ1() {
        try {
            //////
            final StringBuffer[] БуферУПолученныйРезультатОтСевлетаДляАунтификации = {new StringBuffer()};


            //////TODO Запуск асинхроного ЛОУДОРА ДЛЯ АУНТИФТИКАЦИИ ПОЛЬЗОВАТЕЛЯ
            AsyncTaskLoader asyncTaskLoaderАунтификацияПользователя = new AsyncTaskLoader(КонтекстСинхроДляАунтификации) {

                HttpURLConnection ПодключениекСерверуДляАунтификацииПользователяПриВходе=null;
                String ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе=null;


                @Override
                protected void onStartLoading() {
                    super.onStartLoading();
                    ПрогрессБарДляВходаСистему.setVisibility(View.VISIBLE);// по умолчанию прогресс бар делаем не видеым
                    Log.d(this.getClass().getName(), " onStartLoading() asyncTaskLoaderАунтификацияПользователя ");


                    ////TODO запускаем BACkground

                    forceLoad();
                }


                @Nullable
                @Override
                public Object loadInBackground() {

                    String ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя = null;
                    BufferedReader БуферПодключениеJSONВерсияSQlserver = null;
                    CipherInputStream GZIPПотокаДляОтправкиНаСервер = null;
                    try {
                        Log.d(this.getClass().getName(), " loadInBackground() asyncTaskLoaderАунтификацияПользователя ");

                        /////

                        ///////////
                        ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя = "";
                        ////////само подкючение
                        // URL  Adress = new URL("http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet"+"?" + "ЗаданиеДляСервлетаВнутриПотока=Хотим Получить ID для Генерации  UUID"); ///ДАННАЯ ССЛЫКА ДЛЯ ПОДКЛЮЧЕНИЯ СВЯЗИ

                        String СтрокаСвязиСсервером=PUBLIC_CONTENT.ПубличныйАдресGlassFish + "dsu1.glassfish/DSU1JsonServlet" + "?" + "ЗаданиеДляСервлетаВнутриПотока=Хотим Получить ID для Генерации  UUID";
                        ////
                        Log.d(this.getClass().getName(), " СтрокаСвязиСсервером " +СтрокаСвязиСсервером);
                        ////
                        СтрокаСвязиСсервером = СтрокаСвязиСсервером.replace(" ", "%20");
                        ///
                        Log.d(this.getClass().getName(), " СтрокаСвязиСсервером " +СтрокаСвязиСсервером);



                        URL Adress = new URL(СтрокаСвязиСсервером); //
                        ////////



                        ///
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе=null;
                        /////////////
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе = (HttpURLConnection) (Adress).openConnection();/////САМ ФАЙЛ JSON C ДАННЫМИ
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.setRequestProperty("Content-Type", "application/text; charset=UTF-8");
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.setRequestProperty("Accept-Encoding", "gzip,deflate,sdch");
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.setRequestProperty("Connection", "Keep-Alive");
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.setRequestProperty("Accept-Language", "ru-RU");
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.setRequestMethod("GET"); ////GET //ПРОВЕРЯЕМ ЕСЛИ ПОДКЛЮЧЕНИЕ К СЕВРЛЕТУ С АНДРОЙДА НА SQL SERVER
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.setReadTimeout(5000); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ(1000); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.setConnectTimeout(1000);//todo САМ ПОТОК ДАННЫХ(10000);//todo САМ ПОТОК ДАННЫХ
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.setUseCaches(true);
                        ////////

                        //////МЕТОД ЗАШИВРОВАНИЕ SSL
                        ///////посылаем сашифрованные хэдэры
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.setRequestProperty(PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета,
                                PUBLIC_CONTENT.ПубличноеПарольДлСервлета);  //"dsu1getsession"
                        ////Dalvik/2.1.0 (Linux; U; Android 7.0; Android SDK built for x86 Build/NYC)
                        ПодключениекСерверуДляАунтификацииПользователяПриВходе.connect(); /////////////ТОЛЬКО СОЕДИНЕНИЕ
                       // ПодключениекСерверуДляАунтификацииПользователяПриВходе.getResponseCode();///ВАЖНАЯ КОМАНДА  СТУЧИТЬСЯ В СЕРВЛЕТ ECLIPSE СТУЧИМСЯ ВТОРОЙ РАЗ ЧТОБЫ ПОЛУЧИТЬ УЖЕ САМ JSON////РЕАЛЬНОЕ ПОЛУЧЕНИЕ ДАННЫХ С ИНТРЕНЕТА
                        ////СТУЧИМЬСЯ В СЕРВЛЕТ

                            ПодключениекСерверуДляАунтификацииПользователяПриВходе.getContent(); ////РЕАЛЬНОЕ ПОЛУЧЕНИЕ ДАННЫХ С ИНТРЕНЕТА


                        //todo цикл
                        do {///В ТАБЛИЦЕ КОТОРАЯ ПРИШЛА С SQL SEVER ПЕРЕРБИРАЕМ
                            /////ПОЛУЧАЕМ ЦИФРОВУЮ ВЕРСИЮ  ИМЕНИ ПОЛЬЗЛВАТЕЛЯ ВВ ИДЕ ЦИРЫ С SQL SERVERs
                            if (ПодключениекСерверуДляАунтификацииПользователяПриВходе.getResponseCode() == 200) {/////ЗАХОДИМ В ФАЙЛ ТОЛЬКО КОГДА НЕТ ОШИБКОВ В ПОТОКА ОТ SQL SEVER
                                //TODO шифровани
                                GZIPПотокаДляОтправкиНаСервер = new CipherInputStream(
                                        new GZIPInputStream(ПодключениекСерверуДляАунтификацииПользователяПриВходе.getInputStream()), PUBLIC_CONTENT.ПолитикаРасшифровки);

                                ////TODO буфера проверки пользователя
                                БуферПодключениеJSONВерсияSQlserver = new BufferedReader(new InputStreamReader(
                                        GZIPПотокаДляОтправкиНаСервер,
                                        StandardCharsets.UTF_16));
                                //////
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                    if (БуферПодключениеJSONВерсияSQlserver.lines() != null) {
                                        /////////////САМ ЦИКЛ ЗАПОЛЕНИЯ ИЗ JSON В СТРОКИ
                                        ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя = БуферПодключениеJSONВерсияSQlserver.readLine();
                                        //
                                        if (ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя != null) {



                                            Log.d(this.getClass().getName(), " ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя"
                                                    +ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя);







                                            ////TODO ДАННЫЙ КОД ОПРЕДЕЛЯЕТ ПРИСЛАЛ ЛИ ОШИБКУ СЕРВЕР НА НЕПРАВИЛЬНЫЙ И ПОЛНОСТЬ ОТСУТВУЮЩИЕ ДАННЫЕ ПОЛЬЗОВАТЕЛЯ, КОТОРЫЙ ХОТЕЛ ЗАЙТИ В  СИСТЕМУ
                                            if (!ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя.trim().equalsIgnoreCase("Вы не прошли Аунтификацию (для вас данных нет)") &&

                                                   ! ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя.trim().equalsIgnoreCase("True")   ) {


                                                // TODO: 21.04.2021 успешная унфтикация


                                                PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID = ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя; ///ИЗ ОТВЕТА ПОЛУЧАЕМ ID ПОЛЬЗОВАТЕЛЯ ДЛЯ ГЕНЕРАЦИИ  UUID//
                                                Log.d(this.getClass().getName(), "  ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя " + ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя);

                                                ///
                                                БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].append(ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя);
                                                ////////
                                                Log.d(this.getClass().getName(), " БуферУПолученныйРезультатОтСевлетаДляАунтификации " + БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].toString());



                                                ExecutorService executorService=Executors.newSingleThreadExecutor();
                                            Future<?> futureВставкиИменииПароля=    executorService.submit(new Runnable() {
                                                    @Override
                                                    public void run() {



                                                //// todo после успешного получение имени и пароля записываем их в базу ЗАПУСК МЕТОДА ВСТАВКИ ИМЕНИ И ПАРОЛЯ ПРИ АУНТИФИКАЦИИ БОЛЕЕ 7 ДНЕЙ
                                                МетодВставкиИменииПароляПриАунтификацииБолееСемиДней(); ////ЗАПУСК МЕТОДА ВСТАВКИ ИМЕНИ И ПАРОЛЯ ПРИ АУНТИФИКАЦИИ БОЛЕЕ 7 ДНЕЙ


                                                    }
                                                });
                                                futureВставкиИменииПароля.get();
                                                if(futureВставкиИменииПароля.isDone()){
                                                    executorService.shutdown();
                                                    futureВставкиИменииПароля.cancel(false);
                                                }




                                                //todo  ERROR USERNAME ответ от сервера когда имя не правильно и аунтифкаумя НЕ ПРОШЁЛ ПОЛЬЗОВАТЕЛЬ И ВЫХОМ ИЗ WHILE  ЦИКЛА
                                            } else {

                                                ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе = ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя;
                                                ПодсчетОтрицательныйРезультатовАунтификации++;///подсчитываем ошибки для точго чтобы приложение пошло спать
                                                break;
                                                ////  && !ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя.trim().equalsIgnoreCase("Вы не прошли Аунтификацию (для вас данных нет)"))
                                            }
                                        }
                                    }




                                 //TODO BufferedReader api 23 чтение данных сервера
                                }else{


                                        // TODO: 13.05.2021 reset buffer


                                        ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя = БуферПодключениеJSONВерсияSQlserver.readLine();

                                    Log.d(this.getClass().getName(), " ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя   23 API"
                                            +ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя);

                                        //
                                        if (ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя != null) {



                                            Log.d(this.getClass().getName(), " ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя"
                                                    +ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя);







                                            ////TODO ДАННЫЙ КОД ОПРЕДЕЛЯЕТ ПРИСЛАЛ ЛИ ОШИБКУ СЕРВЕР НА НЕПРАВИЛЬНЫЙ И ПОЛНОСТЬ ОТСУТВУЮЩИЕ ДАННЫЕ ПОЛЬЗОВАТЕЛЯ, КОТОРЫЙ ХОТЕЛ ЗАЙТИ В  СИСТЕМУ
                                            if (!ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя.trim().equalsIgnoreCase("Вы не прошли Аунтификацию (для вас данных нет)") &&
                                                    ! ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя.trim().equalsIgnoreCase("True")) {


                                                // TODO: 21.04.2021 успешная унфтикация


                                                PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID = ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя; ///ИЗ ОТВЕТА ПОЛУЧАЕМ ID ПОЛЬЗОВАТЕЛЯ ДЛЯ ГЕНЕРАЦИИ  UUID//
                                                Log.d(this.getClass().getName(), "  ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя " + ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя);

                                                ///
                                                БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].append(ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя);
                                                Log.d(this.getClass().getName(), " БуферУПолученныйРезультатОтСевлетаДляАунтификации " + БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].toString());



                                                ExecutorService executorService=Executors.newSingleThreadExecutor();
                                                Future future=    executorService.submit(new Runnable() {
                                                    @Override
                                                    public void run() {



                                                        //// todo после успешного получение имени и пароля записываем их в базу ЗАПУСК МЕТОДА ВСТАВКИ ИМЕНИ И ПАРОЛЯ ПРИ АУНТИФИКАЦИИ БОЛЕЕ 7 ДНЕЙ
                                                        МетодВставкиИменииПароляПриАунтификацииБолееСемиДней(); ////ЗАПУСК МЕТОДА ВСТАВКИ ИМЕНИ И ПАРОЛЯ ПРИ АУНТИФИКАЦИИ БОЛЕЕ 7 ДНЕЙ


                                                    }
                                                });
                                                future.get();
                                                if(future.isDone()){
                                                    executorService.shutdown();
                                                    future.cancel(false);
                                                }




                                                //todo  ERROR USERNAME ответ от сервера когда имя не правильно и аунтифкаумя НЕ ПРОШЁЛ ПОЛЬЗОВАТЕЛЬ И ВЫХОМ ИЗ WHILE  ЦИКЛА
                                            } else {

                                                ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе = ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя;
                                                ПодсчетОтрицательныйРезультатовАунтификации++;///подсчитываем ошибки для точго чтобы приложение пошло спать
                                                break;
                                                ////  && !ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя.trim().equalsIgnoreCase("Вы не прошли Аунтификацию (для вас данных нет)"))
                                            }
                                        }










                                }
                            }

                            ///TODO

                        } while (ПроверкаПришёлЛиОтветОтСервлетаДляАунтификацииПользователя == null);/////конец for # количество респонсев
                        ///////
                        Log.d(this.getClass().getName(), " БуферУПолученныйРезультатОтСевлетаДляАунтификации " + БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].toString());


                        if (GZIPПотокаДляОтправкиНаСервер!=null) {
                            GZIPПотокаДляОтправкиНаСервер.close();
                        }

                        if (БуферПодключениеJSONВерсияSQlserver!=null) {
                            БуферПодключениеJSONВерсияSQlserver.close();
                        }







                        /////TODO визуализация решения по аунтификац ии  серверу

                        ////TODO визуализация подключение к серверу и его визуализация
                        ////TODO ВЫКИДЫВАЕМ

                        if (ПодключениекСерверуДляАунтификацииПользователяПриВходе.getResponseCode() == 505) {
                            ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе = "Нет доступа к серверу";
                            ПодсчетОтрицательныйРезультатовАунтификации++;///подсчитываем ошибки для точго чтобы приложение пошло спать
                        }


                        //TODO ЗАПУСКАЕМ ФУТУРЕ
                        МетодВизуализацииПоложительныхИлиОтрицательныхПопытокАунтификации();

                    } catch (Exception e) {
                        ///метод запись ошибок в таблицу
                        ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе = e.toString();
                        ПодсчетОтрицательныйРезультатовАунтификации++;///подсчитываем ошибки для точго чтобы приложение пошло спать

                        //

                        //TODO ЗАПУСКАЕМ ФУТУРЕ
                        МетодВизуализацииПоложительныхИлиОтрицательныхПопытокАунтификации();
                        /////todo данный код когда имя и пароль не правильны
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber() + " ПодсчетОтрицательныйРезультатовАунтификации " + ПодсчетОтрицательныйРезультатовАунтификации);
                               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }


                    /////todo ВЫХОД ПОСЛЕ РАБОТЫ BACKGRAUNG

                    /////
                    return БуферУПолученныйРезультатОтСевлетаДляАунтификации[0];  ///ПодсчетОтрицательныйРезультатовАунтификации
                }



                ///todo метод визуализацци успешных и не успешных аунтифиуаци пользоватле
                private void МетодВизуализацииПоложительныхИлиОтрицательныхПопытокАунтификации() {
                    MainActivity_Tabels_Users_And_Passwords.this.runOnUiThread(new Runnable()
                    {
                        public void run()
                        {

                            Log.d(this.getClass().getName(), " handlerВизуализацияАунтификации ");
                            try {
                                ПрогрессБарДляВходаСистему.setVisibility(View.VISIBLE);// по умолчанию прогресс бар делаем не видеым
                                ПрогрессБарДляВходаСистему.setProgress(ПодсчетОтрицательныйРезультатовАунтификации);
///ОШИБКИ

                                Log.d(this.getClass().getName(), " ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе " + ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе
                                        + " БуферУПолученныйРезультатОтСевлетаДляАунтификации.length() " + БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].length());

                                ///todo В ЗАВИССИМОСТИ КАКОЙ РЕЗЗУЛЬТАТ ЗАПУСКАЕМ ИЛИ НЕТ ЗАХОД В ПРОГРАММУ ПРИ НАЛИЧИИ ОШИБОК

                                if (ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе != null
                                        && БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].length() == 0) {////полученный результат обрабатываем для принятия решения прошел ли пользователь аунтификацию
////////посылаем приложенее поспать
///TODO КОГДА 4 ПОПЫТКИ ПРОШЛИ НЕ УСПЕШНО И МЫ ЗАСЫВАЕМ ПРИЛОЖЕНИЯ НА 30 СЕКУНД
                                    if (ПодсчетОтрицательныйРезультатовАунтификации > 4) {////ПОПЫТКИ НЕ УДАЧНОГО ВХОДА В ПРОГРАММУ СВЫШЕ 5  СООБШАЕМ ПОЛЬЗОВАТЛЮ ЧТО ЕГО ИММ ЯИ ИЛИ ПАРОЛЬ НЕ ПРАВИЛЬНЫЙ И ПРИЛОЖЕНИЕ ОПРАЫЛЕМ В СОН
//  Toast.makeText(getApplicationContext(), "Привышен лимит попыток подключения"+"\n"+" (попробйте через ..... 30 секунд )", Toast.LENGTH_LONG).show();
/////

                                        ПодсчетОтрицательныйРезультатовАунтификации = 0;

                                        /////todo два компонета делаем их не видимые
///TODO  метод засыпания ПОТОК

                                        ///todo В ДАННОМ МЕСТЕ НУДЕН ДЛЯ ПОСЛЕДОВАТЕЛЬНОЙ ВИЗАУЛИЗАЦИИ ПРОГРЕССБАРА И tOAST УВИДОМЕЛНИЯ
                                        ExecutorService ПуулПамяти = Executors.newSingleThreadExecutor(); //
                                        ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными
                                        Future МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными = ПуулПамяти.submit(new Runnable() {
                                            public void run() {
                                                System.out.println("Another thread was executed");


                                                //TODO ЗАПУСКАЕМ ФУТУРЕ
                                                MainActivity_Tabels_Users_And_Passwords.this.runOnUiThread(new Runnable()
                                                {
                                                    public void run()
                                                    {

                                                        ПрогрессБарДляВходаСистему.setVisibility(View.VISIBLE);// при нажатии делаем видимый програсссбар

                                                        try {
                                                            TimeUnit.SECONDS.sleep(10);
                                                        } catch (InterruptedException e) {
                                                            e.printStackTrace();
                                                        }


                                                        if (ПуулПамяти.isShutdown() ){

                                                            ((Activity)КонтекстСинхроДляАунтификации).runOnUiThread(new Runnable() {
                                                                @Override
                                                                public void run() {


                                                            ПрогрессБарДляВходаСистему.setVisibility(View.INVISIBLE);// по умолчанию прогресс бар делаем не видеым
                                                            /////
                                                            Toast aa = Toast.makeText(КонтекстСинхроДляАунтификации, "OPEN",Toast.LENGTH_SHORT);
                                                            ImageView cc = new ImageView(КонтекстСинхроДляАунтификации);
                                                            cc.setImageResource(R.drawable.icon_dsu1_error_antrficar_users);//icon_dsu1_synchronisazia_dsu1_success
                                                           // aa.setView(cc);
                                                         //   aa.show();
                                                            ///
                                                            Toast.makeText(getApplicationContext(), " ИМЯ и/или ПАРОЛЬ неправильный : ( Сон на 10 секунд.....)"
                                                                    + " \n"+ " Попробуйте еще раз ", Toast.LENGTH_SHORT).show();

                                                                }
                                                            });

                                                        }

                                                    }
                                                });

                                            }});
                                        //TODO ЗАПУСКАЕМ ФУТУРЕ
                                        try {
                                            МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.get();

                                            if (МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.isDone()) {


                                                //TODO ЗАПУСКАЕМ "Эксенкюторе"
                                                ПуулПамяти.shutdown();
                                                МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.cancel(false);
                                            }
                                        } catch (ExecutionException e) {
                                            e.printStackTrace();
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }







///todo показываем кнопку послу засыпания процесса аунтификации


///TODO КОГДА ПРОСТО ИМЯ И ПАРОЛЬ НЕ ПОДХОДЯТ меньше 5 ошибок
                                    } else {////ПОПЫТКИ НЕ УДАЧНОГО ВХОДА В ПРОГРАММУ ДО 5 ПРОСТО СООБШАЕМ ПОЛЬЗОВАТЛЮ ЧТО ЕГО ИММ ЯИ ИЛИ ПАРОЛЬ НЕ ПРАВИЛЬНЫЙ

                                        Log.d(this.getClass().getName(), " ПодсчетОтрицательныйРезультатовАунтификации " + ПодсчетОтрицательныйРезультатовАунтификации);
                                        //TODO ЗАПУСКАЕМ ФУТУРЕ
                                        MainActivity_Tabels_Users_And_Passwords.this.runOnUiThread(new Runnable()
                                        {
                                            public void run()
                                            {

                                                Toast aa = Toast.makeText(КонтекстСинхроДляАунтификации, "OPEN",Toast.LENGTH_SHORT);
                                                ImageView cc = new ImageView(КонтекстСинхроДляАунтификации);
                                                cc.setImageResource(R.drawable.icon_dsu1_error_antrficar_users);//icon_dsu1_synchronisazia_dsu1_success
                                                aa.setView(cc);
                                              //  aa.show();

                                                ///////TODO
                                                if (ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе.equalsIgnoreCase("True")) {
                                                    ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе="Имя правильное, Пароль нет !!!!.";
                                                }else if (ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе.equalsIgnoreCase("java.net.SocketTimeoutException: timeout")) {
                                                    ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе="Имя и Пароль не привильны !!!";
                                            }

// TODO: 21.04.2021 Сообщение о неправильные ошибвки при входе сообшеение
                                                Toast.makeText(getApplicationContext(), "Нет Входа: "

                                                        + " ( Лимит 4 попытки.  ) " + ПодсчетОтрицательныйРезультатовАунтификации+
                                                        "\n" + ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе, Toast.LENGTH_SHORT).show();
                                                Log.d(this.getClass().getName(), "  ПодсчетОтрицательныйРезультатовАунтификации " + ПодсчетОтрицательныйРезультатовАунтификации);

                                                ПрогрессБарДляВходаСистему.setVisibility(View.INVISIBLE);// по умолчанию прогресс бар делаем не видеым
                                            }
                                        });
                                    }


//////TODO УСПЕХ ИМЯ И ПАРОЛЬ ЕСТЬ



                                    Log.d(this.getClass().getName(), " Пришёл ID от СЕРВЕРА  БуферУПолученныйРезультатОтСевлетаДляАунтификации.length()" + БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].length());
////// TODO ПРИ УСПЕШНОЙ АУНТИФИКАЦИИ БЕЗ ОШИБОЧНОЙ И СОВПАДЕНИИ И МЕНИ  И ПАРОЛЯ ЗАПУСКАЕММ ДАННЫЕ
                                    Log.d(this.getClass().getName(), " Успешная Аунтификация с сервером  БуферУПолученныйРезультатОтСевлетаДляАунтификации :::  "
                                            + БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].toString());





                                    ///TODO ПРОШЛА УСПЕШНАЯ АУНТИФТИКАЦИЯ И МЫ ЗАПУСКАЕМ МЕТОДЫ ПОСЛЕ АУНТИФИКАЦИИ
                                }else if (БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].length() > 0) {////ЗАПУСКАЕМ ДАННЫЕ ТОЛЬКО ПРИ УСПЕШНОЙ АУНТИФИЦИИ

                                    stopLoading();
                                }


                            } catch (Exception e) {
                                e.printStackTrace();
///метод запись ошибок в таблицу
///метод запись ошибок в таблицу
                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                new КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                            }
                            ////

                        }
                    });
                }


                /////TODO МЕТОД ВСТАВКИ ИМЕНИ И ПАРОЛЯ АУНТИФИКАЦИИ БОЛЕЕ 7  ДНЕЙ
                private void МетодВставкиИменииПароляПриАунтификацииБолееСемиДней() {/////МЕТОД ВСТАВКИ ИМЕНИ И ПАРОЛЯ АУНТИФИКАЦИИ БОЛЕЕ 7  ДНЕЙ

                    try{
                    ////НАЧАЛО ВСТКИ И ОЧИСТКИ ДАННЫХ ПО ВСТКАЕ ИМЕНИ  И ПАРОЛЯ ПРИ АУНТИФИКАЦИИ ПОЛЬЗОВАТЕЛЯ БОЛЕЕ 7 ДНЕЙ
                    Date Дата = Calendar.getInstance().getTime();
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
                    dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                    Log.d(this.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
                    String ДатаДЛяОчисткиИВстсвкиИмениИПароль = dateFormat.format(Дата);
                    ///
                    // /// для очистки



/*

                         ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();



                            ////TODO очистка перерд встакой id
                            ////перерд вставкой имя и пароль для авторризации болеее 7 дней
                            //long Результат_АдаптерДляОчисткиПолученогоУспешноИмяиПарольДляСемидневнойАунтификацииID = ССылкаНаСозданнуюБазу.delete("SuccessLogin", null,null); ////вставка данных имя и пароль


                            if (Результат_АдаптерДляОчисткиПолученогоУспешноИмяиПарольДляСемидневнойАунтификацииID > 0) {
                                ССылкаНаСозданнуюБазу.setTransactionSuccessful();

                            }
                            ССылкаНаСозданнуюБазу.endTransaction();*/
                            ///todo сама вставка новго id


                         ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();

                            //////записываем полученный имя и пароль во временную таблицу ДЛЯ ТОГО ЧТОБЫ ЕСЛИ НУЖНО ЧЕРЕЗ  7 ДНЕЙ ПОТРЕБУЕТЬСЯ
                            ContentValues АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации = new ContentValues();
                            АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации.put("id", БуферУПолученныйРезультатОтСевлетаДляАунтификации[0].toString());
                            АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации.put("success_users", PUBLIC_CONTENT.ПубличноеИмяПользовательДлСервлета);
                            АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации.put("success_login", PUBLIC_CONTENT.ПубличноеПарольДлСервлета);
                            АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации.put("date_update", ДатаДЛяОчисткиИВстсвкиИмениИПароль);


                            //вставка имя и пароль для автроризации более 7 днней
                            long Результат_АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации = ССылкаНаСозданнуюБазу.update("SuccessLogin",
                                    АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации,
                                  null, null); ////вставка данных имя и пароль

                            if (Результат_АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации > 0) { //ПОДТЕРЖДАЕМ ТОЛЬКО ВСТАВКУ НОВГО ИМЕНИ И ПАРОЛЯ
                                ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                            }else{

                                //вставка имя и пароль для автроризации более 7 днней
                              Результат_АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации = ССылкаНаСозданнуюБазу.insert("SuccessLogin",null,
                                        АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации); ////вставка данных имя и пароль


                            }

                    if (Результат_АдаптерДляДобавлениеПолученогоУспешноИмяиПарольДляСемидневнойАунтификации > 0) { //ПОДТЕРЖДАЕМ ТОЛЬКО ВСТАВКУ НОВГО ИМЕНИ И ПАРОЛЯ
                        ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                    }






                            ССылкаНаСозданнуюБазу.endTransaction();//ЗАКРЫЫАЕМ ТРАНЗАКЦИЮ В ЛЮБОМ СЛУЧАЕ


                } catch (SQLException e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                           new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());


                        ССылкаНаСозданнуюБазу.endTransaction();//ЗАКРЫЫАЕМ ТРАНЗАКЦИЮ В ЛЮБОМ СЛУЧАЕ

                }
                    ////// конец записываем полученный имя и пароль во временную таблицу ДЛЯ ТОГО ЧТОБЫ ЕСЛИ НУЖНО ЧЕРЕЗ  7 ДНЕЙ ПОТРЕБУЕТЬСЯ
                }


                ////TODO метод запускаем его ПОСЛЕ УСПЕШНОЙ АУНТИФИКАЦИИ
                @Override
                public void stopLoading() {
                    super.stopLoading();
                    try{
////
                        Log.d(this.getClass().getName(), " stopLoading() asyncTaskLoaderАунтификацияПользователя ");
                        //ПрогрессБарДляВходаСистему.setVisibility(View.INVISIBLE);// по умолчанию прогресс бар делаем не видеым
                      //  TimeUnit.MILLISECONDS.sleep(100);
                        ///
/////
//                        Toast aa = Toast.makeText(КонтекстСинхроДляАунтификации, "OPEN",Toast.LENGTH_SHORT);
//                        ImageView cc = new ImageView(КонтекстСинхроДляАунтификации);
//                        cc.setImageResource(R.drawable.icon_dsu1_success_antrficar_users);//icon_dsu1_synchronisazia_dsu1_success
//                        aa.setView(cc);
//                        aa.show();

                        ///TODO ПОСЛЕ УСПЕШНОЙ УНТИФИКАЦИИ ПОЛЬЗОВАТЛЯ ИМЕНИ И ПАРОЛЯ  ОБНУЛЯЕМ ПЕРЕМЕННЫЕ





                        ///TODO ПЕЕРЕЖД ПЕРРВЫМ ЗАПУСКМО СТАВИМ ФЛАГ ЗАПРЕТА НА ОБНОВЛЕНИЯ

                     //   PUBLIC_CONTENT.ФлагПриПервомЗапускеОграничитьОперациюТолькоВставка=false;

                        ОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе=null;

                        БуферУПолученныйРезультатОтСевлетаДляАунтификации[0] =null;

                        ///TODO УСТАНАВЛИВАЕМ ФЛАГ ПРИ АУНТИФИКАЦИИ И МЯ И ПАРОЛЬ  СТАЫИМ ФЛАГ ОТКЛЮЧИТЬ ОБНОВЛЕНИЕ ПРИ СИНХРОНИЗАЦИИ false по умолчанию проверяем
                        ////todo  ПЫТАЕМСЯ ОРГАНИЗОВАТЬ ОБНОВЛЕНИЕ НО ТОЛЬКО ЕСЛИ ВЛАГ  TRUE










/////// TODO ПОСЛЕ УСПЕШНОА АУНТИФИТКАЦИИ ИЛИ СИНХРОНИЗАЦИИ ЗАПУСКАЕТЬСЯ ДАННЫХ И ЗАТЕМ ЗАПУСКАЕМ ПРИЛОЖЕНИЯпосле успешной вставки переходим сюда
                            Intent Интент_ЗапускСамогоПриложенияЕслиПользовательПослеУспешнойаунтификации = new Intent();
                            Интент_ЗапускСамогоПриложенияЕслиПользовательПослеУспешнойаунтификации.setClass(getApplication(), MainActivity_Sinfrozisaziy_Prograssbar.class); //  MainActivity_FACE_APP.class ТУТ ЗАПВСКАЕТЬСЯ ВЫБОР ПРИЛОЖЕНИЯ КОТОРЫЕ ЕСТЬ FACE APP НА ДАННЫЙ МОМЕТНТ РАЗРАБОТНАО ТАБЕЛЬНЫЙ УЧЁТ
                            Интент_ЗапускСамогоПриложенияЕслиПользовательПослеУспешнойаунтификации.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);/// FLAG_ACTIVITY_SINGLE_TOP
                            ///
                            startActivity(Интент_ЗапускСамогоПриложенияЕслиПользовательПослеУспешнойаунтификации);
                            finishAffinity();



                        ///////TODO КОНЕЦ ASYNCTASKLOADER АУНТИФИКАЦИИЯ
                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                    }
                }

            };
            ///TODO запускаем asyncTaskLoader для акнтификации пользователя проверки этот ли пользователь
            asyncTaskLoaderАунтификацияПользователя.startLoading();

            ///////TODO КОНЕЦ ASYNCTASKLOADER АУНТИФИКАЦИИЯ
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }





    /////todo WIFI МЕТОДА ДЛЯ АНТИФИКАЦИИ
    ///////// TODO ПРОВЕРЯЕТ ЕСЛИ ПОДКЛЧБЕНИ В ИНТРЕНТУ

    boolean  МетодГлавныйСинхронизацииДанныхКлиентСервер(Context  КонтекстКоторыйДляСинхронизации) throws ExecutionException, InterruptedException, TimeoutException {


        /////=----СИНХРОНИЗАЦИЯ
        ///TODO СИНХРОНИЗАЦИЯ ///TODO СИНХРОНИЗАЦИЯ при запуске прилиложения
//TODO ПРОВРЕМ WIFI ПОДКЛЮЧЕН ЛИ
        final boolean[] РезультатПРоверкиПодключениеWIFI = {false};
        final String[] РезутьтатПроверкиТипПодключениякИнтернету = new String[1];


        //////

        ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными
       CompletionService МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными = new ExecutorCompletionService<Boolean>( Executors.newSingleThreadExecutor());
       ///
        МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.submit(new Callable() {
            public Boolean call() {
                System.out.println("Another thread was executed");

                /////
                try{
                    ///TODO ЗАПУСКАЕМ  ПуллПамяти
                    РезутьтатПроверкиТипПодключениякИнтернету[0]=new String();

                    /////todo тут МЫ ПОЛУЧАЕМ В КАКОЙ МОМЕНТ ТИП ПОДКЛЮЧЕНИЯ НА ТЕЛЕФОНЕ МОБИЛЯ ИЛИ  WIFI  И В ЗАВИСИМОСТИ ЧТОБЫ ПОНЯТЬ ЧЕ ЗА ДЕЛА
                    РезутьтатПроверкиТипПодключениякИнтернету[0] = МетодОпределяемКакойТипПодключениеWIFIилиMobile();
                    //////
                    Log.d(this.getClass().getName(), "   РезутьтатПроверкиТипПодключениякИнтернету " + РезутьтатПроверкиТипПодключениякИнтернету[0]);



                    /////TODO ТУТ ПОЛУЧАЕМ  ЗНАЧЕНИЯ ПО УМОЛЧАНИЮ ПРОГРАММЫ РЕЖИМ РАБОТИЫ СИНХРОНИЗАЦИИ ТОЛЬКО ПО  WIFI

                    String ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация =  new MODEL_synchronized(getApplicationContext()).  МетодПолучениеЗначенияРежимаРаботыИнтернетаWifiИлиInternet(getApplicationContext() ,"SuccessLogin","mode_connection");

                    Log.d(this.getClass().getName(), "  ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация " + ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация);


                    // TODo ДАННЫЙ КОД ОПРЕДЕЛЯЕМ КАК МЫ БУДЕМ УЗУЩЕТСВЛЯТЬ РАБОТУ СИНХРОНИЗАЦИИ СЕРВЕРА ПО УМОЛЧАНИЮ ТОЛЬКО С WIFI НАСТРОЙКА В ПРИЛОЖЕНИИ И ТОЛЬКО ПРИНУДИТЕЛЬНО С ТЕЛЕФОНА

                    switch (ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация) {

                        /// TODO ТОЛЬКО ЗАПУСК СИНХРОНИЗАЦИИ ЕЛИ ЕСТЬ WIFI И ВСЕ
                        case "WIFI":
                            // TODo ТОЛЬКО WIFI подключение производим ТУТ ПРАИЛО ЗЕРКАЛЬНО ДОЛЖНО СОВПАСТЬ УСЛОВИЕ WIFI==WIFI
                            if (РезутьтатПроверкиТипПодключениякИнтернету[0].equals("WIFI")) {
                                Log.d(this.getClass().getName(), "  ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация " + ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация +
                                        " РезутьтатПроверкиТипПодключениякИнтернету " + РезутьтатПроверкиТипПодключениякИнтернету[0]);
                                РезультатПРоверкиПодключениеWIFI[0] = false;


                                ///todo вычитсляем есть если подключение к интренту
                                РезультатПРоверкиПодключениеWIFI[0] = УниверсальнайМетодЕслиСвязьсСерверомСоюзАвтодора();
                                Log.d(this.getClass().getName(), " РезультатПРоверкиПодключениеWIFI " + РезультатПРоверкиПодключениеWIFI[0]);
                                //////todo НАЧИНАЕМ СИНХРОНИЗАЦИЮ ТОЛЬКО WIFI
                                //  МетодСинхронизацииКогдаВыяснилиРежимПодключенияИНаличияИнтрента(РезультатПРоверкиПодключениеWIFI[0], КонтекстКоторыйДляСинхронизации);
                            }
                            ///todo Викидываем из кода котому что только WIFI
                            break;

                        /// TODO   ТОЛЬКО ЗАПУСК СИНХРОНИЗАЦИИ ЕСЛИ ПОЛЬЗОВАТЕЛЬ ВЫБРАЛ РЕЖИМ РАБОТЫ  MOBILE И ТОГДА ОБМЕН ОМУЩЕСТВЛЯЕТЬСЯ СРАЗУ И ЧЕРЕЗ СИМКУ И ПО WIFI
                        case "Mobile":
                            ////TODO ДВА В ОДНОМ ЗАПУСКАЕМ СИНХРОНИЗАУЦЦИЮ И ПРИ МОБАЙЛЕ И ПРИ WIFI
                            if (РезутьтатПроверкиТипПодключениякИнтернету[0].equals("Mobile") || РезутьтатПроверкиТипПодключениякИнтернету[0].equals("WIFI")) {
                                // TODo ТОЛЬКО Mobileподключение производим
                                Log.d(this.getClass().getName(), "  ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация " + ТекущаяУстановкаПользователяЧрезеЧегоСинхронизация +
                                        " РезутьтатПроверкиТипПодключениякИнтернету " + РезутьтатПроверкиТипПодключениякИнтернету[0]);
                                РезультатПРоверкиПодключениеWIFI[0] = false;
                                ///todo вычитсляем есть если подключение к интренту
                                РезультатПРоверкиПодключениеWIFI[0] = УниверсальнайМетодЕслиСвязьсСерверомСоюзАвтодора();
                                Log.d(this.getClass().getName(), " РезультатПРоверкиПодключениеWIFI " + РезультатПРоверкиПодключениеWIFI[0]);

                                //////todo НАЧИНАЕМ СИНХРОНИЗАЦИЮ ОБА WIFI/MOBILE
                                //  МетодСинхронизацииКогдаВыяснилиРежимПодключенияИНаличияИнтрента(РезультатПРоверкиПодключениеWIFI[0], КонтекстКоторыйДляСинхронизации);

                            }


                    }
//////
                    ////
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                           new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    ////// начало запись в файл
                }
                ////////

                return  РезультатПРоверкиПодключениеWIFI[0];
            }
        });
        //TODO ЗАПУСКАЕМ ФУТУРЕ
   Future<Boolean> futureПолученияПароля=     МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.poll(1,TimeUnit.MINUTES);


   ///
        РезультатПРоверкиПодключениеWIFI[0]=futureПолученияПароля.get();
///

        if (futureПолученияПароля.isDone()) {

            futureПолученияПароля.cancel(false);
        }
        //TODO ВОЗВРАЩЯЕМ НУЖНО ПОДКЛЮЧАТЬ АУНТИВИКАУИЮ ИЛИ НЕТ
        return  РезультатПРоверкиПодключениеWIFI[0];
    }



    ////TODO метод который отпредеяеть КАКОЙ ТИП ПОДКЛЮЧЕНИ К ИНТРЕНТУ ЧЕРЕЗ WIFI ИЛИ MOBILE
    private String МетодОпределяемКакойТипПодключениеWIFIилиMobile() {
        try{

            ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            ////////
            NetworkInfo wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            if (wifiInfo != null && wifiInfo.isConnected())
            {
                Log.d(MODEL_synchronized.class.getName()," подключние к интренту через wifi");
                return "WIFI";
            }
            wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            if (wifiInfo != null && wifiInfo.isConnected())
            {
                Log.d(MODEL_synchronized.class.getName()," подключние к интренту через mobile");
                return "Mobile";
            }
            wifiInfo = cm.getActiveNetworkInfo();
            if (wifiInfo != null && wifiInfo.isConnected())
            {
                Log.d(MODEL_synchronized.class.getName()," подключние к интренту через "+wifiInfo.getTypeName());
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
        return null;
    }






    ///////// TODO ПРОВЕРЯЕТ ЕСЛИ ПОДКЛЧБЕНИ В ИНТРЕНТУ
    protected   boolean УниверсальнайМетодЕслиСвязьсСерверомСоюзАвтодора() throws ExecutionException, InterruptedException, TimeoutException {
        Context context = this;

        boolean РезультатПрозвонаСокетом=false;
        try{
            System.out.println("УниверсальнайМетодПроверкиПодключениекWIFI ");

            /////todo код ping ip
            // InetAddress АдресПрозвонаСайтаПриВходеВПРОграмму=null;
            //АдресПрозвонаСайтаПриВходеВПРОграмму= InetAddress.getByName("www.google.com"); //"http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet"; //www.google.com
            // Log.d(MODEL_synchronized.class.getName() ," addr.getHostAddress() "+  АдресПрозвонаСайтаПриВходеВПРОграмму.getHostAddress());
            // if (!АдресПрозвонаСайтаПриВходеВПРОграмму.getHostAddress().equalsIgnoreCase("::") && АдресПрозвонаСайтаПриВходеВПРОграмму.getHostAddress().length()>0) {

            //  }
            /////todo код ping ip второйвариант
            try {

                Socket socket = new Socket();
                SocketAddress socketAddress = new InetSocketAddress("80.66.149.58", 8888); //"http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet"; //"216.58.212.131"
                socket.connect(socketAddress, 500);
                РезультатПрозвонаСокетом = true;
                PUBLIC_CONTENT.ПубличныйАдресGlassFish = "http://80.66.149.58:8888/"; //http://80.66.149.58:8888 //8181 ///РЕЖИМ НАСТОЯЩИЕ РАБОТЫ ПРИЛОЖЕНИЯ
                Log.d(MODEL_synchronized.class.getName()," PUBLIC_CONTENT.ПубличныйАдресGlassFish " + PUBLIC_CONTENT.ПубличныйАдресGlassFish);
                ///TODO определяем какой вид подкобченеи mobile and wifi

            }catch (IOException e) {
                РезультатПрозвонаСокетом = false;
                ////TODO ВТОРАЯ ПРОВЕРКА
                try {
                    if (РезультатПрозвонаСокетом==false) {
         /*   HttpURLConnection ПодключениеИнтернетДляОтправкиНаСервер=null;
            URL Adress = null;
            Adress = new URL("http://192.168.254.63:8080/dsu1.glassfish/DSU1JsonServlet");
            ПодключениеИнтернетДляОтправкиНаСервер = (HttpURLConnection) (Adress).openConnection();/////САМ ФАЙЛ JSON C ДАННЫМИ
            ПодключениеИнтернетДляОтправкиНаСервер.setReadTimeout(500); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ(200);
            ПодключениеИнтернетДляОтправкиНаСервер.setConnectTimeout(10000);//todo САМ ПОТОК ДАННЫХ(1000);
            ПодключениеИнтернетДляОтправкиНаСервер.connect();
            РезультатПрозвонаСокетом = true;*/
                        Socket socket = new Socket();
                        SocketAddress socketAddress = new InetSocketAddress("192.168.254.63",8080);
                        socket.connect(socketAddress,500);
                        РезультатПрозвонаСокетом = true;


                        /////
                        String    Adress_String="http://192.168.254.63:8080/";
                        ///
                        Adress_String = Adress_String.replace(" ", "%20");

                        PUBLIC_CONTENT.ПубличныйАдресGlassFish = Adress_String;// PUBLIC_CONTENT.ПубличныйАдресGlassFish = "http://192.168.254.63:8080  /"; //http://80.66.149.58:8888 //8181 ///РЕЖИМ НАСТОЯЩИЕ РАБОТЫ ПРИЛОЖЕНИЯ
                        Log.d(MODEL_synchronized.class.getName(), " PUBLIC_CONTENT.ПубличныйАдресGlassFish " + PUBLIC_CONTENT.ПубличныйАдресGlassFish);
                        ///TODO определяем какой вид подкобченеи mobile and wifi
                    }
                    //МетодОпределяемКакойТипПодключение();
                }catch (IOException ex) {
                    РезультатПрозвонаСокетом = false;
                    ///////todo вторая проверка
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }

        return РезультатПрозвонаСокетом;
    }







}








