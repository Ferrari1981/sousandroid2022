package com.dsy.dsu;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.UiThread;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.gson.internal.bind.JsonTreeWriter;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static com.dsy.dsu.PUBLIC_CONTENT.ССылкаНаСозданнуюБазу;

//вывод данных на Автивити
public class MainActivity_VIEWERRORS extends AppCompatActivity  {

//назначение полец и ссылки на другие классы
//определяем дату вставки
///create ProgressBar
    /**
     * todo данное активти показываем ошибки
     *
     */

    /////ЯЧЕЙКИ
    TextView КонтейнерКудаЗагружаеютьсяОшибкиПрилоджения;//
    ////////БИЛДЕР
    StringBuffer БуерДляОшибок;
    ///
    Cursor[] Курсор_СамиДанные_Error = new Cursor[0];
//// для вставки данных


    ////

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            Log.d(this.getClass().getName(), "Запущен.... метод  onCreate в классе MainActivity_Settings  ; ");

                super.onCreate(savedInstanceState);

            setContentView(R.layout.activitymain_viewlogin); ///activitymain_viewlogin  /// fragment_dashboard
/////
         //  setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
            /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
         //   getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
            //ссылка на схему базы данных;//ссылка на схему базы данных
          //  ССылкаНаСозданнуюБазу = new CREATE_DATABASE(this).ССылкаНаСозданнуюБазу;//ссылка на схему базы данных;//ссылка на схему базы данных
            //заполение TextView
            КонтейнерКудаЗагружаеютьсяОшибкиПрилоджения = (TextView) findViewById(R.id.textViewDATA);
//////
            ////
            //создаем билдер
            БуерДляОшибок = new StringBuffer();
            //////
            //////todo настрока экрана
        //    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);


        ССылкаНаСозданнуюБазу = new CREATE_DATABASE(this).ССылкаНаСозданнуюБазу;//ссылка на схему базы данных;//ссылка на схему базы данных

            //////todo  конец настрока экрана


            /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

            getSupportActionBar().hide(); ///скрывать тул бар




            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);

            //////todo настрока экрана

            //////todo  конец настрока экрана

///////errors
        } catch (Exception e) {
            e.printStackTrace();
///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }



    } // конец    protected void onCreate(Bundle savedInstanceState)

    @Override
    protected void onStop() {
        super.onStop();

try{
        if (БуерДляОшибок.length()>300) {

            Log.d(this.getClass().getName(), "   БуерДляОшибок"+БуерДляОшибок.toString());


            БуерДляОшибок.append("\n").append(" текущий пользователь : ").append(PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID).append(" время: ").append(new Date());

            new ClassSendErros(this).МетодПослываемОшибкиАдминистаторуПо(БуерДляОшибок);




        }

        ///////errors
    } catch (Exception e) {
        e.printStackTrace();
///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
    }

}


    @Override
    protected void onDestroy() {
        super.onDestroy();

        //////TODO  данный код срабатывает когда произошда ошивка в базе

        if(ССылкаНаСозданнуюБазу.isOpen()){
            if(ССылкаНаСозданнуюБазу.inTransaction()){
                ССылкаНаСозданнуюБазу.endTransaction();
            }
          //  ССылкаНаСозданнуюБазу.close();
        }

    }






    //////////////////////////////////////////////////////////////
    @Override
    public void onResume() {
        super.onResume();
// put your code here...
//метод по  выводу даным на Ативити из SQLITE
        try {
            ///
            МетодПросмотраОшибокПриложения();
//метод по  выводу даным на Ативити из SQLITE

///поймать ошибку
        } catch (Exception e) {
//  Block of code to handle errors
            e.printStackTrace();
///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
///////
        }
    }

    /////////////
//запуск метода вставки данных logins
    protected void МетодПросмотраОшибокПриложения() {
        try {
///////
            int ЕстьСтроки = 0;

//сам код
            Log.d(this.getClass().getName(), "Запущен.... метод  Просмотра ошибок MainActivity_VIEWERRORS  ; ");

///////////
                JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();

                ArrayList<EditText> editTextArrayList = new ArrayList<>();

                StringBuffer stringBuffer = new StringBuffer();
                synchronized (stringBuffer) {

                }



                try {




///////////////////////////  TODO курсор для ПОКАЗА ОШИБОК УЖЕ СОЗДАННЫХ END AsyncTask-1
                    Курсор_СамиДанные_Error = new Cursor[]{null};
//получения курсора всех таблиц  базы данных ДСУ-1
                    ExecutorService ПуулПамяти = Executors.newCachedThreadPool(); //
                    ////TODO ЗАПУСКАЕМ  МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными
                    Cursor[] finalКурсор_СамиДанные_Error = Курсор_СамиДанные_Error;
                    Future МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными = ПуулПамяти.submit(new Runnable() {
                        public void run() {
                            System.out.println("Another thread was executed");

                            finalКурсор_СамиДанные_Error[0] = null;
                            ///////
                            finalКурсор_СамиДанные_Error[0] = ССылкаНаСозданнуюБазу.rawQuery("SELECT " +
                                    "ID_Table_ErrorDSU1 AS [ID ТАБЛИЦЫ Ошибки ДСУ-1]," +
                                    "Error AS [Ошибка]," +
                                    "Klass AS [Класс]," +
                                    "Metod AS [Метод]," +
                                    "LineError AS [номер строки]," +
                                    "Data_Operazii_E AS [Дата Ошибки]," +
                                    "whose_error AS [Версия программы]" +
                                    "FROM  ErrorDSU1 ORDER BY  ID_Table_ErrorDSU1 DESC ", new String[]{});
                        }
                    });
                    МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.get();
                    if (МеханизмУправлениеПотокамиОграничеваемИхУжеСозданными.isDone()) {
                        ПуулПамяти.shutdown();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

///запкск потока


//////////
            if (Курсор_СамиДанные_Error[0]!=null) {
                ЕстьСтроки = Курсор_СамиДанные_Error[0].getCount();
            }

//////
                if (ЕстьСтроки > 0) {
                    Log.d(this.getClass().getName(), "В курсоре даннные есть::: ");
/////обязательная строчка надо курсор поставить на first значения чтобы buder смог его прочитать
///////рефакторинг
                    try {
/////ЗАПУСКАЕМ МЕТОД СОЗДАНИЕ ОЩИБОК
                        МетодЗапускаAsynTaskОшибки(ЕстьСтроки, Курсор_СамиДанные_Error[0]);
                        //////

                    } catch (Exception e) {
                        e.printStackTrace();
///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }

/////////
/////////// end AsyncTask-2
/////ОШИБКА НЕТ В КУРСОРЕ ДАННЫХ
                } else {
                    Log.d(this.getClass().getName(), "Ошибка Курсор нет данных  Logins  ");
                  //  МетодСозданиеДиалогаКлассЛогин("Ошибки ПО ТАбельный учёт", "Ошибок нет.");

                    /////ЗАПУСКАЕМ МЕТОД СОЗДАНИЕ ОЩИБОК
                    МетодЗапускаAsynTaskОшибки(ЕстьСтроки, Курсор_СамиДанные_Error[0]);

                }
/////БАЗА НЕ ОТКРЫТА

//поймать ошибку
        } catch (Exception e) {
//  Block of code to handle errors
            e.printStackTrace();
///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
///////
        }
    }

    protected void МетодЗапускаAsynTaskОшибки(int естьСтроки, Cursor Курсор_СамиДанные_Error) {
        try {
////

            String ИнфоТелефон = Build.MANUFACTURER
                    + " " + Build.MODEL + " " + Build.VERSION.RELEASE
                    + " " + Build.VERSION_CODES.class.getFields()[android.os.Build.VERSION.SDK_INT].getName();

///проветка если ссылка на класс
            Log.d(this.getClass().getName(), "естьСтроки "+естьСтроки);
            //

///////////
/////////// start AsyncTask-1
///////////////////////////end  AsyncTask-

            БуерДляОшибок.setLength(0);
////проверка если в курсоре строчки
            Integer ИндексДляПрограссбара = null;
            if (естьСтроки > 0) {
                ////ЕСЛИ ДАННЫЕ ЕСТЬ СТАВИМ КУРСОР НА ПЕРВОЕ МЕСТО
                Курсор_СамиДанные_Error.moveToFirst();
                /////////количество строчекв курсоре
                int КоличествоСтрочекКурсоре = Курсор_СамиДанные_Error.getCount();
                Log.d(this.getClass().getName(), "количество записей в курсоре : " + КоличествоСтрочекКурсоре);


                //////индекс для перемещение по програсбару
                ИндексДляПрограссбара = 0;
                // //ЦИКЛ ЗАПОЛЕНИЕ СТРОК
                do {
                    ///иницализирует програмбар

                    //получение полей из таблицы соотвертвующего типа данных
                    Integer Столбик_ID_Table_ErrorDSU1 = Курсор_СамиДанные_Error.getInt(0);
                    String Столбик_Error = Курсор_СамиДанные_Error.getString(1);
                    String Столбик_Klass = Курсор_СамиДанные_Error.getString(2);
                    String Столбик_Metod = Курсор_СамиДанные_Error.getString(3);
                    Integer LineError_LineError = Курсор_СамиДанные_Error.getInt(4);
                    String LineError_Data_Operazii_E = Курсор_СамиДанные_Error.getString(5);
                    int СтолбикКтоСделалОшибку = Курсор_СамиДанные_Error.getInt(6);
                    //конец  получение полей из таблицы соотвертвующего типа данных
                    //вставляем в билде
                    БуерДляОшибок.append(" #---------Ошибки ПО Табельный Учёт--------------#" + "\n" + "\n" +
                            "   " + Курсор_СамиДанные_Error.getColumnName(0).toUpperCase() + "  : " + Столбик_ID_Table_ErrorDSU1 + "\n" + "\n" +
                            "   " + Курсор_СамиДанные_Error.getColumnName(1).toLowerCase() + "  : " + Столбик_Error.toLowerCase() + "\n" + "\n" +
                            "   " + Курсор_СамиДанные_Error.getColumnName(2).toLowerCase() + "  : " + Столбик_Klass.toLowerCase() + "\n" + "\n" +
                            "   " + Курсор_СамиДанные_Error.getColumnName(3).toLowerCase() + "  : " + Столбик_Metod.toLowerCase() + "\n" + "\n" +
                            "   " + Курсор_СамиДанные_Error.getColumnName(4).toLowerCase() + "  : " + LineError_LineError + "\n" + "\n" +
                            "   " + Курсор_СамиДанные_Error.getColumnName(5).toLowerCase() + "  : " + LineError_Data_Operazii_E + "\n" + "\n" +
                            "   " + Курсор_СамиДанные_Error.getColumnName(6).toLowerCase() + "  : " + СтолбикКтоСделалОшибку + "\n" + "\n" +
                            "   " + ИнфоТелефон + "  : " + "  Инфо. телефона " + "\n" + "\n" +
                            "   " + Build.BRAND.toUpperCase() + "  : " + " Имя " + "\n" + "\n" +
                            Build.VERSION.SDK_INT+ "  : " + " API ("+Build.VERSION.RELEASE+ ")"+ "\n" + "\n" +
                                    "- время : " +new Date().toString()+"-" + "\n"+  "\n"+
                            "   " + "-----------------------------------------" + "\n"+  "\n" );
                    //показать
                    Log.d(this.getClass().getName(), " Содержимое Курсора  :  " + Столбик_ID_Table_ErrorDSU1 + " ");
                    //Toast.makeText(getApplicationContext(), "  Содержимое Курсора  : "+Столбик_Logins_id+" " , Toast.LENGTH_SHORT).show();
                    /////уввкеличиваем для програссбара
                    ИндексДляПрограссбара++;
                    ////////
                } while (Курсор_СамиДанные_Error.moveToNext());

// Build.BRAND.toUpperCase()






//привязваем адаптер
                Курсор_СамиДанные_Error.close();

            }else {


                //вставляем в билде


                //вставляем в билде
                БуерДляОшибок.append(    "---------------Ошибок Нет.-----------"+"\n"+"\n"+
                        "   " + ИнфоТелефон + "  : " + "  Инфо. телефона " + "\n" + "\n" +
                        "   " + Build.BRAND.toUpperCase() + "  : " + " Имя " + "\n" + "\n" +
                        Build.VERSION.SDK_INT+ "  : " + " API ("+Build.VERSION.RELEASE+ ")"+ "\n" + "\n" +
                        "- время : " +new Date().toString()+"-" + "\n"+  "\n"+
                        "   " + "-----------------------------------------" + "\n"+  "\n" );





                Log.d(this.getClass().getName(), " Ошибок Нет. время :   " +new Date().toString());


            }

//////лоим ошибки
            Log.d(this.getClass().getName(), " БуерДляОшибок.toString() "+БуерДляОшибок.toString());


            ////ПОКАЗЫВАЕМ ДАННЫЕ УЖЕ НА АКТИВТИ ОШИБКИ
            if (БуерДляОшибок.length()>0) {
                //////////////////////
                КонтейнерКудаЗагружаеютьсяОшибкиПрилоджения.setText(БуерДляОшибок.toString());
            }
            /////////////////////////////////


            Курсор_СамиДанные_Error.close();









///поймать ошибку
        } catch (Exception e) {
//  Block of code to handle errors
            e.printStackTrace();
///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
///////
        }
    }


    //////ОБЩИЙ МЕТОД СОЗДАНИЕ КЛАССИЧЕСКОГО ДИАЛОГА С КНОПКОЙ ЗАКРЫТЬ
    @UiThread
    public void МетодСозданиеДиалогаКлассЛогин(String ШабкаДиалога, String СообщениеДиалога) {
        try {
///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ
//////сам вид
            final AlertDialog DialogBoxsПростомрДанных = new MaterialAlertDialogBuilder(this)
                    .setTitle(ШабкаДиалога)
                    .setMessage(СообщениеДиалога)
                    .setPositiveButton("Закрыть", null)
                    .show();
/////////кнопка
            final Button MessageBoxUpdateПростомрДанных = DialogBoxsПростомрДанных.getButton(AlertDialog.BUTTON_POSITIVE);
            MessageBoxUpdateПростомрДанных.setOnClickListener(new View.OnClickListener() {

                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
///запуск метода обновления через DIALOGBOX
                    try {
//удаляем с экрана Диалог
                        DialogBoxsПростомрДанных.dismiss();
//соообщение
// Toast.makeText(getApplicationContext(), "Запускаем обновление данных " , Toast.LENGTH_LONG).show();
///////запуск главного меню после того как поняли что в азе нет логинов
                        Intent Интент_Меню_ТолькоПростотДанных;
                        Интент_Меню_ТолькоПростотДанных = new Intent(getApplicationContext(), MainActivity_FACE_APP.class);
///// Toast.makeText(getApplicationContext(), "Выбран пунк меню Главный Экран" , Toast.LENGTH_LONG).show();
                        startActivity(Интент_Меню_ТолькоПростотДанных);
                       // finish();
////ПОСЛЕ ОПЕРАЦИИ ОБНОВЛЕНИЕ ЗАПУСКАМ ГЛАВНЦЮ ФОРМУ ПРОСМОТРА ДАННЫХ
////



//ловим ошибки

                    } catch (Exception e) {
                        e.printStackTrace();
///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                         new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                    }

                }
            });

// /поймать ошибку
        } catch (Exception e) {
//  Block of code to handle errors
            e.printStackTrace();
///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             new КлассВставкиОшибок(getApplication()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }


}//конец public class MainActivity_Recyclerview extends AppCompatActivity {
