package com.dsy.dsu;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;

import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Spliterator;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;

public class MainActivity_history_chat extends AppCompatActivity {


     private ImageButton ImageButtonВыходИзЧата;
    private TabLayout TabLayoutИзЧата;
    private ViewPager ViewPagerзЧата;
    private TabItem tab1,tab2;
    public PagerAdapter pagerAdapter;

    FragmentManager fragmentManager;
    ///
    FragmentTransaction fragmentTransaction;


    ArrayList<String> arrayListTab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_history_chat);



        ////
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);

        /////


        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);







// TODO: 27.04.2021 формируем внешний вид Чата через фрагменты

            TabLayoutИзЧата=(TabLayout)findViewById(R.id.TabLayoutЧат);
            ////////////
            tab1=(TabItem) findViewById(R.id.Tab1);
            ///////////////////
            tab2=(TabItem) findViewById(R.id.Tab2);
            ///////
            ViewPagerзЧата=findViewById(R.id.viewpagerЧат);
            //////////


            fragmentManager=getSupportFragmentManager();
            ///
            fragmentTransaction=fragmentManager.beginTransaction();




            /////////////
    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
        
    }






    //////////////////////////////////////////////////////////////МОДЕЛЬ MVC  ////////////////////////////////////////////////////////////////////////





    @Override
    protected void onStart() {
        super.onStart();
        //
 try{

        // TODO: 16.06.2021


        new MainActivity_history_chat.MODEL(fragmentManager);

        // TODO: 16.06.2021 ЗАПУСКАЕМ НА АКТИВТИ ЧАТ КЛАСС VIEW КОТОРЫЙ ОТВЕЧАЕТ ЗА ОТОБРАЖЕНИЯ ИНФОРМАЦИИ И КЛИК

        new MainActivity_history_chat.VIEW(fragmentManager);

        // TODO: 16.06.2021


        new MainActivity_history_chat.CONTROLLER(fragmentManager,pagerAdapter,arrayListTab);



        /////////////
    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
    }


    }



















// TODO: 16.06.2021


    private class CONTROLLER {


        public CONTROLLER( FragmentManager fragmentManager ,PagerAdapter pagerAdapter,ArrayList<String> arrayListTab) {

            //
            try{

                arrayListTab=new ArrayList<>();

                /**
                 * Добавления авайлиста
                 */
                arrayListTab.add("Сообщения");
                //
                arrayListTab.add("Контакты");
                //
                /**
                 * иницализацуия view pager
                 */


                Log.d(  КлассВставкиОшибок.class.getClass().getName(), " CONTROLLER");

                MainAdapter mainAdapter=new MainAdapter(getSupportFragmentManager());
/**
 * InizLIZzia fagment
 */

                fragment1 ФрагментСообщения=new fragment1();
                ///
                fragment2 ФрагментКонтакты=new fragment2();
                ///
                for (int i = 0; i < arrayListTab.size(); i++) {
                    /**
                     * Iniziali
                     */
                    Bundle bundleДляЧаста=new Bundle();
                    ///
                    //Put string
                    bundleДляЧаста.putString("title", arrayListTab.get(i));
                    ///

                    switch (i){
                        case 0:

                            ФрагментСообщения.setArguments(bundleДляЧаста);
                            ///add fragment
                            mainAdapter.addFragment(ФрагментСообщения,arrayListTab.get(i));

                            ФрагментСообщения=new fragment1();
                            /**
                             * exit
                             */
                            break;

                        case 1:

                            ФрагментКонтакты.setArguments(bundleДляЧаста);
                            ///add fragment
                            mainAdapter.addFragment(ФрагментКонтакты,arrayListTab.get(i));

                            ФрагментКонтакты=new fragment2();

                            /**
                             * exit
                             */
                            break;

                    }






                }


                TabLayoutИзЧата.setupWithViewPager(ViewPagerзЧата);

                /////set adapter
                ViewPagerзЧата.setAdapter(mainAdapter);



                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }





    }

    private class MainAdapter extends FragmentPagerAdapter {

        ArrayList<String> stringArrayList=new ArrayList<>();
        //
        List<Fragment> fragmentList=new ArrayList<>();


        /**
         *
         */
        public void addFragment(Fragment fragment,String title){
            ////add title

            stringArrayList.add(title);
            ///
            fragmentList.add(fragment);

        }


        public MainAdapter(@NonNull @NotNull FragmentManager fm) {
            super(fm);
        }

        @NonNull
        @NotNull
        @Override
        public Fragment getItem(int position) {
            /**
             * return fragment position
             */
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        @Nullable
        @org.jetbrains.annotations.Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            /**
             * Return array list position
             */
            return stringArrayList.get(position);
        }
    }















// TODO: 16.06.2021

    private class MODEL{


        public MODEL( FragmentManager fragmentManager) {

            //
            try{

                Log.d(  КлассВставкиОшибок.class.getClass().getName(), " MODEL");






                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }





    }

// TODO: 16.06.2021


    private class VIEW {


        public VIEW(FragmentManager fragmentManager) {

            //
            try{



                Log.d(  КлассВставкиОшибок.class.getClass().getName(), " VIEW");



                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }





    }

}