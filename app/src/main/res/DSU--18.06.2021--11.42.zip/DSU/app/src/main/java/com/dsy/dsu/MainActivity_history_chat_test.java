package com.dsy.dsu;

import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ConcurrentMap;

public class MainActivity_history_chat_test extends AppCompatActivity {


 Button firstFragmentButton,secondFragmentButton;


    FragmentManager fragmentManager;
    ///
    FragmentTransaction fragmentTransaction;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try{
        super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main_history_chat_test);



        ////
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);

        /////


        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);


            // TODO: 15.06.2021 FRAGMENT


                  firstFragmentButton= findViewById(R.id.fragment1btn);

                    secondFragmentButton= findViewById(R.id.fragment2btn);

                    
      fragmentManager=getSupportFragmentManager();
            ///
          fragmentTransaction=fragmentManager.beginTransaction();

 

            Log.d(this.getClass().getName(), "create FRAGMENT "+new Date());







            //////////////////////////////////////////////////////////////МОДЕЛЬ MVC  ////////////////////////////////////////////////////////////////////////

            // TODO: 16.06.2021


            new   MODEL_CHAT(fragmentManager,firstFragmentButton,secondFragmentButton);

            // TODO: 16.06.2021 ЗАПУСКАЕМ НА АКТИВТИ ЧАТ КЛАСС VIEW КОТОРЫЙ ОТВЕЧАЕТ ЗА ОТОБРАЖЕНИЯ ИНФОРМАЦИИ И КЛИК

        new   VIEW_CHAT(fragmentManager,firstFragmentButton,secondFragmentButton);

            // TODO: 16.06.2021


            new   CONTROLLER_CHAT(fragmentManager,firstFragmentButton,secondFragmentButton);







        /////////////
    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
               new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
        
    }





    private class VIEW_CHAT {


        public VIEW_CHAT( FragmentManager fragmentManager,Button buttonforf1,Button buttonforf2) {

            //
            try{

                

            Log.d(  КлассВставкиОшибок.class.getClass().getName(), " сработала ... FragmentManager class");

                fragment1 f1=new fragment1();


                ////
                fragmentTransaction.add(R.id.framelayout,f1);
                //
                fragmentTransaction.commit();



            /////////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        }





    }
// TODO: 16.06.2021


    private class CONTROLLER_CHAT {


        public CONTROLLER_CHAT( FragmentManager fragmentManager,Button buttonforf1,Button buttonforf2) {

            //
            try{



                buttonforf1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        fragment1 f1=new fragment1();

                        ///
                        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
                        ////
                        fragmentTransaction.replace(R.id.framelayout,f1);
                        //
                        fragmentTransaction.commit();


                    }
                });
//
                buttonforf2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ///
                        fragment2 f2=new fragment2();

                        ///
                        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
                        ////
                        fragmentTransaction.replace(R.id.framelayout,f2);
                        //
                        fragmentTransaction.commit();

                    }
                });

                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }





    }

    private class MODEL_CHAT  {


        public MODEL_CHAT( FragmentManager fragmentManager,Button buttonforf1,Button buttonforf2) {

            //
            try{




                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }





    }



}








