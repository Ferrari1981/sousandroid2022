package com.dsy.dsu;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v4.app.INotificationSideChannel;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.Date;
import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;


public class MyWork_Синхронизация_Локального extends Worker {
    Context Контекст;

    public MyWork_Синхронизация_Локального(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        Контекст = context;
    }

    @Override
    public void onStopped() {
        super.onStopped();
    }


    @NonNull
    @Override
    public Result doWork() {

// Do processing
        try {


            Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWorkУведомления СЛУЖБА MyWork_SynchronizasiyDatas ВНУТРИ КЛАССА doWork  время "
                    + new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data"));


            Log.d(this.getClass().getName(), "   ЗАПУСК ФОНОВОЙ СИНХРОНИЗАЦИИИ С mYwORK_sYNCHRONIZACI  СЛУЖБА  WorkManager Synchronizasiy_Data ");


            /////////TODO запуск нновую нотификашенс устанолвка
            Intent intentСинхронизацияЛокальная = new Intent(Контекст, Service_Синхронизация.class);
            ////////////

            intentСинхронизацияЛокальная.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            /////

            intentСинхронизацияЛокальная.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);

            intentСинхронизацияЛокальная.putExtra("СинхронизацияЛокальная", "СинхронизацияЛокальная");


            // TODO: 01.05.2021 запускаем если все активти невидны спущены вниз

            // TODO: 01.05.2021 запускаем если все активти невидны спущены вниз
            // TODO: 01.05.2021 запускаем если все активти невидны спущены вниз


            boolean ФлагЛюбогоЗапущеногоАктивти = false;

            /////

            //////
            ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(ACTIVITY_SERVICE);
            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
            Log.d("topActivity", "CURRENT Activity ::" + taskInfo.get(0).topActivity.getClassName());
            ComponentName componentInfo = taskInfo.get(0).topActivity;
            componentInfo.getPackageName();
            componentInfo.getClassName();


            Log.d(this.getClass().getName(), "   componentInfo.getPackageName() " + componentInfo.getPackageName() +
                    "  componentInfo.getClassName() " + componentInfo.getClassName());


            //

            // TODO: 08.04.2021
            // TODO: 08.04.2021
            boolean ФлагЗапущенолиКакоеннибутьАктивтиИлинет = false;
            ////////
            ФлагЗапущенолиКакоеннибутьАктивтиИлинет = componentInfo.getClassName().contains("com.dsy.dsu.MainActivity");

            /////


            // TODO: 08.04.2021
            if (ФлагЗапущенолиКакоеннибутьАктивтиИлинет == true) {


                ФлагЛюбогоЗапущеногоАктивти = true;

                Log.d(this.getClass().getName(), "НЕ Запуск MyWorkСинхронизации Активти какае то есть СЛУЖБА   componentInfo.getClassName().startsWith(\"Activity\",33)"
                        + componentInfo.getClassName().startsWith("Activity", 33) + " componentInfo.getClassName() " + componentInfo.getClassName() +
                        " getClass().getName()" + getClass().getName() + " ФлагЗапущенолиКакоеннибутьАктивтиИлинет " + ФлагЗапущенолиКакоеннибутьАктивтиИлинет);

                // TODO: 29.04.2021 end
            } else {

                Log.d(this.getClass().getName(), "ЗАПУСК MyWorkСинхронизации СЛУЖБА  Уведомления (внутри потока) НЕТ НЕ ОДНОГО АКТИВНОГО АКТИВТИ" + new Date()
                        + " +componentInfo.getClassName().startsWith(\"Activity\",33) " + componentInfo.getClassName().startsWith("Activity", 33) +
                        " componentInfo.getClassName()" + componentInfo.getClassName() + " getClass().getName()" + getClass().getName()
                        + " ФлагЗапущенолиКакоеннибутьАктивтиИлинет " + ФлагЗапущенолиКакоеннибутьАктивтиИлинет);

                ФлагЛюбогоЗапущеногоАктивти = false;

            }


            // TODO: 07.06.2021 САМ ЗАПУСК

          try {
                    Контекст.startService(intentСинхронизацияЛокальная);
                    ////
                } catch (IllegalStateException exception) {
                    ///////
                    ContextCompat.startForegroundService(Контекст, intentСинхронизацияЛокальная);
                }



            Log.i(Контекст.getClass().getName(),
                    "Запуск  СЛУЖБА СЛУЖБА Synchronizasiy_Data      Контекст.startService( intentСинхронизацияЛокальная); из      FaceApp  время " + new Date() +
                            " componentInfo.getClassName().startsWith(\"Activity\",33)" + componentInfo.getClassName().startsWith("Activity", 33) +
                            " ФлагЗапущенолиКакоеннибутьАктивтиИлинет " + ФлагЗапущенолиКакоеннибутьАктивтиИлинет);


            Log.i(Контекст.getClass().getName(), "ПОСЛЕ MyWorkУведомления СЛУЖБА СЛУЖБА Synchronizasiy_Data ВНУТРИ КЛАССА doWork  intentСинхронизацияЛокальная время "
                    + new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data"));


            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.e(Контекст.getClass().getName(), " Стоп СЛУЖБА Service_Synchronizaziy из FaceApp в MyWorkУведомления Exception  ошибка в классе MyWorkУведомления" + e.toString());


        }

        return Result.success();
    }


}





























