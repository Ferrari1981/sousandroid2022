package com.dsy.dsu;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static android.content.Context.ACTIVITY_SERVICE;


public class MyWorkОбновлениеПО extends Worker {
    Context Контекст;












    public MyWorkОбновлениеПО(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        Контекст=context;
    }

    @Override
    public void onStopped() {
        super.onStopped();
    }

    @NonNull
    @Override
    public Result doWork() {

// Do processing
        try{

            String РезультатКтоЗагрузил = getInputData().getString("КтоЗапустилWorkmanager");
            РезультатКтоЗагрузил = getInputData().getString("FaceApp");

            Log.d(Контекст.getClass().getName(), "MyWorkОбновлениеПО СЛУЖБА  " + getInputData().getKeyValueMap());

            Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWorkОбновлениеПО СЛУЖБА  ВНУТРИ КЛАССА doWork  MyWorkОбновлениеПО время "
                    +new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager MyWorkОбновлениеПО")+"\n"+
                    "РезультатКтоЗагрузил " +РезультатКтоЗагрузил);


            Intent intentОбновлениеПО = new Intent(Контекст, Service_ОбновлениеПО.class);
            ///
            intentОбновлениеПО.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK );

            intentОбновлениеПО.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);

            intentОбновлениеПО.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION );

            intentОбновлениеПО.setFlags(Intent. FLAG_GRANT_WRITE_URI_PERMISSION );





            // TODO: 07.06.2021 САМ ЗАПУСК

            try {
                Контекст.startService(intentОбновлениеПО);
                ////
            } catch (IllegalStateException exception) {
                ///////
                ContextCompat.startForegroundService(Контекст, intentОбновлениеПО);
            }






            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.e(Контекст.getClass().getName(), " Стоп СЛУЖБА Service_ОбновлениПО в MyWorkОбновлениеПО Exception  ошибка в классе MyWorkУведомления"+e.toString());


        }

        return Result.success();
    }


    }






























