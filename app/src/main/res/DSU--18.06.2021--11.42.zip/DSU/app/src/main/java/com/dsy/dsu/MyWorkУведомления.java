package com.dsy.dsu;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static android.content.Context.ACTIVITY_SERVICE;


public class MyWorkУведомления extends Worker {
    Context Контекст;

    Boolean ФлагЛюбогоЗапущеногоАктивтиВнутри=false;








    public MyWorkУведомления(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        Контекст=context;
    }

    @Override
    public void onStopped() {
        super.onStopped();
    }

    @NonNull
    @Override
    public Result doWork() {

// Do processing
        Boolean ФинальныйФлагЛюбогоЗапущеногоАктивти = null;
        try {

            String РезультатКтоЗагрузил = getInputData().getString("КтоЗапустилWorkmanager");
            /////
            РезультатКтоЗагрузил = getInputData().getString("FaceApp");

            Log.d(Контекст.getClass().getName(), "MyWorkУведомления СЛУЖБА  " + getInputData().getKeyValueMap());

            Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWorkУведомления СЛУЖБА СЛУЖБАService_Notifications ВНУТРИ КЛАССА doWork  MyWorkУведомления время "
                    + new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation") + "\n" +
                    "РезультатКтоЗагрузил " + РезультатКтоЗагрузил);







      /*      /////////TODO запуск нновую нотификашенс устанолвка
            Intent intentСлужбаУведомлений = new Intent(Контекст, Service_Уведомления.class);


            intentСлужбаУведомлений.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            /////////////
            intentСлужбаУведомлений.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);


            // intent.addCategory(Intent.CATEGORY_LAUNCHER);


            intentСлужбаУведомлений.putExtra("СлужбуЗапустил", "BroadcastReceiver");

            // TODO: This method is called when the BroadcastReceiver is receiving*/


            Boolean ФлагЛюбогоЗапущеногоАктивти = false;


            CountDownLatch countDownLatch = new CountDownLatch(1);
            ////
            CompletionService<Boolean> FutureФлагЛюбогоЗапущеногоАктивти = new ExecutorCompletionService<Boolean>(Executors.newCachedThreadPool());


            FutureФлагЛюбогоЗапущеногоАктивти.submit(new Callable<Boolean>() {
                @Override
                public Boolean call() throws Exception {


                    ActivityManager am = (ActivityManager) Контекст.getSystemService(ACTIVITY_SERVICE);
                    List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
                    Log.d("topActivity", "CURRENT Activity ::" + taskInfo.get(0).topActivity.getClassName());
                    ComponentName componentInfo = taskInfo.get(0).topActivity;
                    componentInfo.getPackageName();
                    componentInfo.getClassName();


                    Log.d(this.getClass().getName(), "   componentInfo.getPackageName() " + componentInfo.getPackageName() +
                            "  componentInfo.getClassName() " + componentInfo.getClassName());

                    // TODO: 08.04.2021
                    if (componentInfo.getClassName().matches("com.dsy.dsu.MainActivity(.*)")) {
                        ФлагЛюбогоЗапущеногоАктивтиВнутри = true;


                        /////todo no
                    } else {


                        Log.d(this.getClass().getName(), "ЗАПУСК MyWorkУведомления СЛУЖБА  Уведомления (внутри потока) НЕТ НЕ ОДНОГО АКТИВНОГО АКТИВТИ" + new Date()
                                + " ФлагЛюбогоЗапущеногоАктивти " + ФлагЛюбогоЗапущеногоАктивтиВнутри);
                        ///////
                        ФлагЛюбогоЗапущеногоАктивтиВнутри = false;
                    }


                    Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА ВНУТРИ startService   Вещятеля BroadcastReceiver  Service_Уведомления " + new Date() +
                            "\n" + " Build.BRAND " + Build.BRAND.toString() + " new  PUBLIC_CONTENT(context).   ФлагЗапущеноЛиАктивитиFaceapp " + PUBLIC_CONTENT.ФлагЗапущеноЛиАктивитиFaceapp);


                    return ФлагЛюбогоЗапущеногоАктивтиВнутри;

                }
            });

            ///
            Future<Boolean> futureФлагЛюбогоЗапущеногоАктивти = FutureФлагЛюбогоЗапущеногоАктивти.take();

            ///

            ///////
            countDownLatch.countDown();
            //////////
            ФинальныйФлагЛюбогоЗапущеногоАктивти = futureФлагЛюбогоЗапущеногоАктивти.get();


            ////
            countDownLatch.await();

            ///
            if (futureФлагЛюбогоЗапущеногоАктивти.isDone()) {
                ////////
                futureФлагЛюбогоЗапущеногоАктивти.cancel(false);


                // TODO: 29.04.2021 вуключаем


                if (ФинальныйФлагЛюбогоЗапущеногоАктивти == false) {


                    /////
                    // TODO: 07.06.2021 САМ ЗАПУСК 

  /*                  try {
                        Контекст.startService(intentСлужбаУведомлений);
                    } catch (IllegalStateException exception) {
   ///////
                        ContextCompat.startForegroundService(Контекст, intentСлужбаУведомлений);
                    }
*/


                    

                    ///







                    Log.i(Контекст.getClass().getName(), "ПОСЛЕ MyWorkУведомления СЛУЖБА СЛУЖБАService_Notifications ВНУТРИ КЛАССА doWork  ContextCompat.startForegroundService  MyWorkУведомления время "
                            + new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation") +
                            " ФинальныйФлагЛюбогоЗапущеногоАктивти " + ФинальныйФлагЛюбогоЗапущеногоАктивти);

                }

            }


            // TODO: 28.04.2021 сам запуск



            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.e(Контекст.getClass().getName(), " Стоп СЛУЖБА Service_Уведомления в MyWorkУведомления Exception  ошибка в классе MyWorkУведомления" + e.toString() + "\n" +
                    " ФинальныйФлагЛюбогоЗапущеногоАктивти " + ФинальныйФлагЛюбогоЗапущеногоАктивти);


        }

        return Result.success();
    }


    }






























