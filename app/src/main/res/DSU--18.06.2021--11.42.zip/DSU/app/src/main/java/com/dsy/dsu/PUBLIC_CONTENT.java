package com.dsy.dsu;


import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;


/////--------TODO В ДАННОМ КЛАССЕ СОБРАНЫ ВСЕ СТАТИЧЕСКИЕ ПЕРЕМЕННЫЕ ДЛЯ РАБОТЫ ВСЕГО ПРИЛОЖЕНИЯ DSU-1  ( И БОЛЬШНЕ В КЛАСЕ НИЧЕГО НЕТ )
public  class PUBLIC_CONTENT extends CREATE_DATABASE {


   public PUBLIC_CONTENT(Context context) {

     super(context);
    }


     public static boolean Отладка = false;   // TODO: 17.03.2021 true  это режим отладки

     public   static String ПубличноеИмяПользовательДлСервлета;// 'ЭТА СССЫЛКА ДЛЯ ВСЕХ НА ПОДКЛЮЧЕНИ ДАННЫХ
     /////////
     public   static String ПубличноеПарольДлСервлета;// 'ЭТА СССЫЛКА ДЛЯ ВСЕХ НА ПОДКЛЮЧЕНИ ДАННЫХ
     // public   static String ПубличноеПарольДлСервлета="BwYFZ4EFCAEwBwYFZ4EFCAIwBwYFZ4EFCAMwDAYKKwYBBAGCNwoDFDAMBgorBgEE";// 'ЭТА СССЫЛКА ДЛЯ ВСЕХ НА ПОДКЛЮЧЕНИ ДАННЫХ
     public static final int DEFAULT_COMPRESSION = 9;
     public   static String ПубличноеIDПолученныйИзСервлетаДляUUID;// 'ЭТА СССЫЛКА ДЛЯ ВСЕХ НА ПОДКЛЮЧЕНИ ДАННЫХ
/////ЭТОТ МАССИВ ДЛЯ ВСЕЙ ПРОГРАММЫ ДЛЯ ВСЕГО ОБМЕНА


     static ArrayList<String> ИменаТаблицыОтАндройда = new ArrayList <String>(); ////ГЛАВНЫЙ СПИСОК ТАБЛИЦ ДЛЯ  ОБМЕНАМИ ДАННЫМИ ИЗ НЕГО БУДЕТ БРАТЬСЯ СПИСКО ТАБЛИЦ
     ///////////
     static ArrayList <String> ИменаПроектовОтСервера= new ArrayList <String>(); ////список проектов
     ////ГЛАВНЫЙ СПИСОК ТАБЛИЦ ДЛЯ  ОБМЕНАМИ ДАННЫМИ ИЗ НЕГО БУДЕТ БРАТЬСЯ СПИСКО ТАБЛИЦ
     static LinkedHashMap<String, String> ДатыТаблицыВерсииДанныхОтСервера=new LinkedHashMap<String, String>();


     public static  String ФильтрДляДанныхЯвляетьсяЛиНулевойЗапускКлиента="";

     public static String МакАдресТелефона;//// мак адрес телефона



     //TODO УСТАНАВЛИВАЕМ СТАТИЧЕСКИЕ ПЕРЕРМЕННФЕ УСПЕШНОЙ ВСТАВКИ И УСПЕШНОЙ ОБНОВЛЕНИЯ ДАННЫХ ПРИ СИНХРОНИЗАЦИИ

     static int  КоличествоУспешныхОбновлений;
     static  int   КоличествоУспешныхВставки;

     static int  НейтральноеСостояниеБазДанныхСервераИлиКлиента;


     ////статик
     static String ПУбличныйИмяТаблицыОтАндройда; ////для ПЕРЕРДАЧИ КЛАСУ КТО РАСПРСИВАЕТ JSON УКАЗЫВАЕМ НАЗВАНИЕ ТАБЛТЦЫ ОБРАБОТЧКИ ПРИШЕДШЕЙ ИЗ SQL SERVER


     ////TODO текущая ТАБЛИЦА ПРИ ОБРАБОТКИ СИНХРОНИЗАЦИИ КОТОРАЯ УВЕЛИЧИВАЕТЬСЯ В ЦИКДЕ ПРИ ОБМЕНЕН

     ////
     static int ОбщееКоличествоТаблиц;
     //////

static  boolean ФлагЗапущеноЛиАктивитиFaceapp=false;


     ////шифрование
     static SecretKey ГлавныйКлючДляШифрованиеИРасшифровки;

     static Cipher ПолитикаШифрование;
     ///////
     static Cipher ПолитикаРасшифровки;

     static String ПубличныйАдресGlassFish;


     ///TODO ПУБЛИЧНАЯ ПЕРЕМЕННАЯ КОТОРАЯ ПОКАЗЫВАЕТ ОБЩЕЕ КОЛИЧЕСТВО СТРОК JSON ПРИ ОБМЕНЕ

     static int СколькоСтрочекJSON;

 static int СколькоСтрочекJSONПоКонкретнойТаблице;


     ////TODO ДАННАЯ НАСТРОЙКА ОПРЕДЕЛЯЕТ РЕЖИМ РАБОТЫ СИНХРОНИЗАЦИИ ПО ТРАФИКУ ТОЛЬКО ЧЕРЕЗ WIFI БЕСПЛАТНО ЛИБО ПО MOBILE ЧЕРЕЗ СИМКУ ПЛАТНЫЙ ТРАФИК
   //  static String РежимРаботыСинхронизации="Mobile"; // static String РежимРаботыСинхронизации="WIFI"; рабочий вариант WIFI


     static String    ПУбличныйДанныеПришёлЛиIDДЛяГенерацииUUID;


static String ЦифровоеИмяНовгоТабеля;


 static   String МетодГенерацииUUIDУжеСуществующегоСотрудника;
 static   boolean ФлагЧтоВставкаВТАлицуTemplesУжеБылаОдинРазИБольшеНеНадо;

 ///TODO УСТАНАВЛИВАЕМ ФЛАГ ПРИ АУНТИФИКАЦИИ И МЯ И ПАРОЛЬ  СТАЫИМ ФЛАГ ОТКЛЮЧИТЬ ОБНОВЛЕНИЕ ПРИ СИНХРОНИЗАЦИИ false по умолчанию проверяем

// static boolean ФлагПриПервомЗапускеОграничитьОперациюТолькоВставка=true;


 //todo эта перерменная показывает ТО ЧТО МЫ УЖЕ ЗАХОДИЛИ В МЕТОД ЗАВЕРШЕНИЯ СИНХРОНИЗАЦИИ

////




 static Context КонтекстСотрудникиДляТабеляДлясинхронизации;



 static List<String> АрайЛИстФИОВсеДляПосикаПослеПосика=  Collections.synchronizedList(new LinkedList<String>());

 static List<String> АрайЛИсТОлькоСписокСотрудниковВТабелеОдном=  Collections.synchronizedList(new LinkedList<String>());



static DownloadManager downloadmanager = null;

 static DownloadManager downloadmanagerAPK = null;



static long downloadId = 0;


//////static boolean ФлагРазрешаетОбновлениеПриСинхронизации;

static boolean ФлагЧтоЗаблокированТекущийПользователь=false;


 static String   ЛокальнаяВерсияПО;


 /////
 static StringBuffer ЗаписьОшибковВстврочку=new StringBuffer();


 ////
 public static final String BROADCAST = "PACKAGE_NAME.android.action.broadcast";








}


///////-------------------------TODO    КЛАСС ВСТАВКИ ОШИБОК------------------




//////КЛАСС ВСТАВКИ ДАННЫЕ   ОШИБКИ
class КлассВставкиОшибок extends MODEL_synchronized {
 public static КлассВставкиОшибок Ссылка_КлассВставкиОшибок;
 Context contextДляОшибок;

 public КлассВставкиОшибок(Context context) {
  super(context);
  // ССылкаНаСозданнуюБазу= this.getWritableDatabase(); //ссылка на схему базы данных;//ссылка на схему базы данных
  contextДляОшибок=context;
 }

 //// второй метод с современный
 public  void MessageBoxErrorFile(String ТекстОшибки, String КлассГнерацииОшибки, String МетодаОшибки, Integer ЛинияОшибки) {
  ////
  try {
   Log.d(  КлассВставкиОшибок.class.getClass().getName(), " сработала ... ВСТАВКА ОШИБОК В БАЗУ");
   /////////////////


   //создание КУРСОРА ДЛЯ ВСТАВКИ ОШИБКИ
   ContentValues АДАПТЕРДЛЯВСТВКИОШИБОК = new ContentValues();
   /////
   АДАПТЕРДЛЯВСТВКИОШИБОК.put("Error", ТекстОшибки.toLowerCase());
   АДАПТЕРДЛЯВСТВКИОШИБОК.put("Klass", КлассГнерацииОшибки.toUpperCase());
   АДАПТЕРДЛЯВСТВКИОШИБОК.put("Metod", МетодаОшибки.toUpperCase());
   АДАПТЕРДЛЯВСТВКИОШИБОК.put("LineError", ЛинияОшибки);
   АДАПТЕРДЛЯВСТВКИОШИБОК.put("Data_Operazii_E", ГлавнаяДатаИВремяОперацийСБазой());
   /////


   final Object versio = BuildConfig.VERSION_CODE;
   Integer   ЛокальнаяВерсияПОСравнение = Integer.parseInt(versio.toString());

   АДАПТЕРДЛЯВСТВКИОШИБОК.put("whose_error", ЛокальнаяВерсияПОСравнение);


   //вставка РЕЗУЛЬТАТ ВСТВКИ ОШИБКИ
   Log.d(  КлассВставкиОшибок.class.getClass().getName(), " сработала ... ВСТАВКА ОШИБОК В БАЗУ"+ " АДАПТЕРДЛЯВСТВКИОШИБОК " +
           АДАПТЕРДЛЯВСТВКИОШИБОК.valueSet()  + "  АДАПТЕРДЛЯВСТВКИОШИБОК.valueSet() " +  АДАПТЕРДЛЯВСТВКИОШИБОК.keySet());


   PUBLIC_CONTENT.ЗаписьОшибковВстврочку.setLength(0);

   for (String key : АДАПТЕРДЛЯВСТВКИОШИБОК.keySet()) {
    PUBLIC_CONTENT.ЗаписьОшибковВстврочку.append( "\n"+
            " текущий пользователь : "+PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID
            +"\n  ").append ("    " + key + "  :" + АДАПТЕРДЛЯВСТВКИОШИБОК.get(key) + ",\n"+ "   время: " +new Date());
   }



   if (АДАПТЕРДЛЯВСТВКИОШИБОК.size()>0) {///если в контенер заполнилься то начинаем вставку
    ////////ВЫЗЫВАЕМ ВСТАВКУ ДАННЫХ

   Future futureОшибка= Executors.newSingleThreadExecutor().submit(new Callable<Object>() {
     @Override
     public Object call() throws Exception {


    try {
     ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();

     long   Результат_ВставкиДанных = ССылкаНаСозданнуюБазу.insert("ErrorDSU1", null,  АДАПТЕРДЛЯВСТВКИОШИБОК);

     if (Результат_ВставкиДанных  > 0) {
      ССылкаНаСозданнуюБазу.setTransactionSuccessful();
      АДАПТЕРДЛЯВСТВКИОШИБОК.clear();
      Log.d(КлассВставкиОшибок.class.getName(), " Результат_ВставкиДанных   " +Результат_ВставкиДанных);
     }
     ССылкаНаСозданнуюБазу.endTransaction();
    } catch (Exception e) {
     e.printStackTrace();
    }


      // TODO: 20.05.2021  действие второе очиставот старых ошибок таблицы


      ССылкаНаСозданнуюБазу.execSQL("delete from ErrorDSU1 where whose_error < '"+ЛокальнаяВерсияПОСравнение+"'");




      return null;
     }
    });
// TODO: 11.05.2021  послываем на почту


    futureОшибка.get();
    if(futureОшибка.isDone()){
     futureОшибка.cancel(false);
    }

    /// после вствки в базу обнуляем контейнер данные от сервера
    АДАПТЕРДЛЯВСТВКИОШИБОК.clear();


   }




   //contextДляОшибок




   //ловим ошибку
  } catch (Exception e) {
   //  Block of code to handle errors
   e.printStackTrace();
   ///метод запись ошибок в таблицу
   Log.e( КлассВставкиОшибок.class.getClass().getName(), "Ошибка в самом классе создание ОШИБКА" + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
           " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
   //закрытие классса и метода
  }

 }
 //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
 public  static String ГлавнаяДатаИВремяОперацийСБазой() {
  Date Дата = Calendar.getInstance().getTime();
  DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
  dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
  dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
  Log.d( КлассВставкиОшибок.class.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
  return dateFormat.format(Дата);
 }
 //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
 public  static String ПриФатальнойОшибки() {
  Date Дата = Calendar.getInstance().getTime();
  DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
  dateFormat.setTimeZone(TimeZone.getTimeZone("UTC-03:00"));
  dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
  Log.d( КлассВставкиОшибок.class.getClass().getName(), " ГЛАВНАЯ ДАТА ПРОГРАММЫ ДСУ-1 : " + dateFormat.format(Дата));
  return dateFormat.format(Дата);
 }


}