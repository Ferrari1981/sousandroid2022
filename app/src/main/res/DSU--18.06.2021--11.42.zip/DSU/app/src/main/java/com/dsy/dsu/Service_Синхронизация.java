package com.dsy.dsu;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;



public class Service_Синхронизация extends Service {




    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ///TODO запускаем дВУХсЛУЖБ
try{

        ///
        Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация   " + new Date());


    if ( PUBLIC_CONTENT.СколькоСтрочекJSON==0  && PUBLIC_CONTENT.  ФлагЧтоЗаблокированТекущийПользователь==false) {


        boolean ФлагЛюбогоЗапущеногоАктивти = false;

        ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
        Log.d("topActivity", "CURRENT Activity ::" + taskInfo.get(0).topActivity.getClassName());
        ComponentName componentInfo = taskInfo.get(0).topActivity;
        componentInfo.getPackageName();
        componentInfo.getClassName();


        Log.d(this.getClass().getName(), "   componentInfo.getPackageName() " + componentInfo.getPackageName() +
                "  componentInfo.getClassName() " + componentInfo.getClassName());



            String КтоЗарустилСинхронизацию=             intent.getStringExtra("СинхронизацияЛокальная");



        Log.d(this.getClass().getName(), "   КтоЗарустилСинхронизацию " + КтоЗарустилСинхронизацию);


        // TODO: 26.04.2021 начинаем синхронизацию по условия но сейчас отключена на время



        try {

            ///
            Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация фоновой (внутри потока) " + new Date());

            МетодЗапускаЛокальнойСинхронизации(КтоЗарустилСинхронизацию);


        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }





/////
    }







            ////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }







        return START_REDELIVER_INTENT ;//  return super.onStartCommand(intent, flags, startId);
    }



    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();



        Log.d(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБА  СИнхронизации ");





    }


    private void МетодЗапускаЛокальнойСинхронизации(String КтоЗарустилСинхронизацию) throws InterruptedException, ExecutionException {





        try {



            // TODO: 29.04.2021 вуключаем

                new CONTROLLER_synchronized_LAUNCH_IN_BACKGROUND(getApplicationContext()).
                        МетодЗАпускаСинхронизациивФоне(getApplicationContext(),КтоЗарустилСинхронизацию);
                Log.d(this.getClass().getName(), "МетодЗапускаЛокальнойСинхронизации() СЛУЖБА синхронизации запускаем через  getApplication()");




            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }





















    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }






}