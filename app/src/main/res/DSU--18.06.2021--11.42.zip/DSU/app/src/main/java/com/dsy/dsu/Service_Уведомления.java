package com.dsy.dsu;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.loader.content.AsyncTaskLoader;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Callable;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static com.dsy.dsu.CREATE_DATABASE.ССылкаНаСозданнуюБазу;

public class Service_Уведомления extends Service {////Service

    NotificationManager mNotificationManager=null;
    NotificationCompat.Builder builder=null;
   //// Notification notificationAfterBuild=null;
    ////

    SimpleDateFormat   ФоорматДат ;
    StringBuffer БуферСамиУведомленияЛинкСамиУведомления;

    int     ID_ТаблицаУвендомлений;


    Intent ИнтентДляЗапускаСлужбыПолсеАнализа;

    Boolean РезультатНужноЗапускатьУведомленияИлиНет=false;
    ////////
    private String PROCESS_ID="11";

    private  static AlarmManager alarmManager;



    @Override
    public void onCreate() {
        super.onCreate();
    }








   @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        ///TODO запускаем дВУХсЛУЖБ

        try {











        
        МетодЗапускаСлужбыУведомления(intent);
///
/////////////////////////////


              Log.d(this.getClass().getName(), " СЛУЖБА УВЕДОМЛЕНИЯ В ПОТОКЕ ScheduledExecutorService.......(ожидание 30 секунд ожидания внутри потока ScheduledExecutorService) "
                      +" время: "
                      +new Date());





/////







            Log.d(this.getClass().getName(), " СЛУЖБА УВЕДОМЛЕНИЯ ВЫШЛИ ИЗ ПОТОКА ScheduledExecutorService.......конец" +" время: "+new Date()
                    +" scheduledExecutorService.isShutdown() ");






        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            //   mNotificationManager.cancel(1);///.cancelAll();

            if (mNotificationManager!=null) {
                mNotificationManager.cancelAll();
            }
            // /.cancelAll(); //   mNotificationManager.cancelAll();
            //   mNotificationManager=null;
            //  builder=null;
            Log.d(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБАService_Notifications onDestroy() Exception ");

        }


                // TODO: 08.04.2021 end service thread








        return START_REDELIVER_INTENT  ;//;//START_REDELIVER_INTENT  ///   return super.onStartCommand(intent, flags, startId);
    }




    @Override
    public void onDestroy() {
        super.onDestroy();
        try{
        Log.i(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБАService_Notifications onDestroy() время "+new Date());

// TODO: 20.04.2021 повторыный запуск широковещательного приемника
         //   МетодПовторногоЗапускаШироковещательногоПриемника();


/*            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
            intentFilter.addAction(Intent.ACTION_SCREEN_ON);
            intentFilter.addAction(Intent.ACTION_BOOT_COMPLETED);
            intentFilter.addAction(Intent.ACTION_REBOOT);
            intentFilter.addAction(Intent.ACTION_LOCKED_BOOT_COMPLETED);
            intentFilter.addAction(Intent.ACTION_SYNC);
            intentFilter.addCategory(Intent.CATEGORY_LAUNCHER);

            ///

            registerReceiver(new Broadcasts_Широковещательный_приемник(), intentFilter);








            Intent serviceIntentNotifications = new Intent(  getApplicationContext(), Broadcasts_Широковещательный_приемник.class);
            serviceIntentNotifications.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
            serviceIntentNotifications.setAction(Intent.ACTION_SCREEN_OFF );
            serviceIntentNotifications.setAction(Intent.ACTION_SCREEN_ON );
            serviceIntentNotifications.setAction(Intent.ACTION_BOOT_COMPLETED );
            serviceIntentNotifications.setAction(Intent.ACTION_REBOOT );
            serviceIntentNotifications.setAction(Intent.ACTION_LOCKED_BOOT_COMPLETED );
            serviceIntentNotifications.setAction(Intent.ACTION_SYNC );
            serviceIntentNotifications.addCategory(Intent.CATEGORY_LAUNCHER);


            ////////
            sendBroadcast(serviceIntentNotifications);*/

            Log.i(getApplicationContext().getClass().getName(), " УРА ЗАПУСК ПОСЛЕ Стопа СЛУЖБА СЛУЖБА Service_Notifications Уведомления onDestroy() время "+new Date());


        } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        //   mNotificationManager.cancel(1);///.cancelAll();
            if (mNotificationManager!=null) {
                mNotificationManager.cancelAll();
            }
            Log.d(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБАService_Notifications onDestroy() Exception ");

    }


    }




















    private void МетодПовторногоЗапускаШироковещательногоПриемника() {



        try {

             /*     IntentFilter intentFilter = new IntentFilter();
                intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
                intentFilter.addAction(Intent.ACTION_SCREEN_ON);
                intentFilter.addAction(Intent.ACTION_BOOT_COMPLETED);
                intentFilter.addAction(Intent.ACTION_REBOOT);
                intentFilter.addAction(Intent.ACTION_LOCKED_BOOT_COMPLETED);
                intentFilter.addAction(Intent.ACTION_SYNC);
                 intentFilter.addCategory(Intent.CATEGORY_LAUNCHER);

                ///

                registerReceiver(new Broadcasts_Широковещательный_приемник(), intentFilter);








        Intent serviceIntentNotifications = new Intent(  getApplicationContext(), Broadcasts_Широковещательный_приемник.class);
        serviceIntentNotifications.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        serviceIntentNotifications.setAction(Intent.ACTION_SCREEN_OFF );
        serviceIntentNotifications.setAction(Intent.ACTION_SCREEN_ON );
        serviceIntentNotifications.setAction(Intent.ACTION_BOOT_COMPLETED );
        serviceIntentNotifications.setAction(Intent.ACTION_REBOOT );
        serviceIntentNotifications.setAction(Intent.ACTION_LOCKED_BOOT_COMPLETED );
        serviceIntentNotifications.setAction(Intent.ACTION_SYNC );

            serviceIntentNotifications.addCategory(Intent.CATEGORY_LAUNCHER);




        ////////
   sendBroadcast(serviceIntentNotifications);

*/





        // I want to restart this service again in one hour
/*
        /// AlarmManager alarm = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pendingAlarm = null;
        // TODO: 19.04.2021 определяем дату
        Calendar time = Calendar.getInstance();
          time.add(Calendar.MINUTE,1);


            if (alarmManager==null) {
                alarmManager = (AlarmManager)getApplicationContext().getSystemService(Context.ALARM_SERVICE);
                //



            pendingAlarm=PendingIntent.getBroadcast(getApplicationContext(), 31, serviceIntentNotifications, 0);//+AlarmManager.INTERVAL_FIFTEEN_MINUTES
    */
/*        AlarmManager.AlarmClockInfo alarmClockInfo = new AlarmManager.AlarmClockInfo( time.getTimeInMillis(), pendingAlarm);
            alarmManager.setAlarmClock(alarmClockInfo, pendingAlarm);*//*


            // TODO: 20.04.2021 запуск самого будилника посто ка и сним опреджелилидь

            if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, (time.getTimeInMillis()), pendingAlarm);
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP,time.getTimeInMillis(),pendingAlarm);
            }

*/
/*

            Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА ВНУТРИ  onDestroy()  getBroadcast   Вещятеля BroadcastReceiver  SystemClock.elapsedRealtime()"+new Date());
            }*/
        ///////
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
            if (mNotificationManager!=null) {
                mNotificationManager.cancelAll();
            };
    }
    }









    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    private void МетодЗапускаСлужбыУведомления(Intent intent) {

        try{


            Log.i(getApplicationContext().getClass().getName(), "Запуск метода МетодЗапускаСлужбыУведомления СЛУЖБА СЛУЖБАService_Notifications "+new Date());

        ИнтентДляЗапускаСлужбыПолсеАнализа=intent;

        ФоорматДат = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
        ФоорматДат.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));

        CREATE_DATABASE.ССылкаНаСозданнуюБазу = getApplicationContext().openOrCreateDatabase("Database DSU-1.db", 0, null);//CREATE_DATABASE. ССылкаНаСозданнуюБазу


        // TODO: 31.03.2021 определяем  ктоже запусстил служюу
        String ФлагКтоЗапустилСлужбу = intent.getStringExtra("СлужбуЗапустил");
        //////

        if (ФлагКтоЗапустилСлужбу==null) {
            ФлагКтоЗапустилСлужбу="";
        }

        String ФлагУбратьУведомленияСлужбу=  intent.getStringExtra("Флаг");////          notificationIntentЗакрыть.putExtra("Флаг", "Закрыть Уведомления");
        //////
        if (ФлагУбратьУведомленияСлужбу==null) {
            ФлагУбратьУведомленияСлужбу="";
        }


        if ( PUBLIC_CONTENT.СколькоСтрочекJSON==0  && PUBLIC_CONTENT.  ФлагЧтоЗаблокированТекущийПользователь==false) {


// TODO: 01.04.2021 данное условие запускает соаздание уведомления с начала своего ниже код только реагирует на нажатие кнопки удалить уведомление и саму служюу отстановить кнопка ЗАКРЫТЬ

            boolean ФлагЗапущеналиСлужбаСейчасИлиНет = false;
            if (ФлагКтоЗапустилСлужбу.equalsIgnoreCase("BroadcastReceiver") || ФлагКтоЗапустилСлужбу.equalsIgnoreCase("FaceApp")) {
                // ФлагКтоЗапустилСлужбу = "BroadcastReceiver";


                /////////TODO запуск нновую нотификашенс устанолвка
                МетодЗарускаСозданиеУведомлений(ИнтентДляЗапускаСлужбыПолсеАнализа, ФлагКтоЗапустилСлужбу);

                Log.d(getApplicationContext().getClass().getName(), " Запуск по Расписанию СЛУЖБА  Информирования  BroadcastReceiver или  FaceApp " + "  --" + new Date() + " ФлагКтоЗапустилСлужбу " + ФлагКтоЗапустилСлужбу);


                // TODO: 06.04.2021 Определяем рабоает ли Служба КОД ПРОВЕРЯТЕТНЕ ЗАПУЩЕНАЛИ СЛУЖЬБА И ЕСЛИНЕ ЗАПУЩЕНА ТОНЕ НАДО ЕЕ УДАЛЯТЬ ИЗ ПАМЯТИ


                ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(ACTIVITY_SERVICE);
                List<ActivityManager.RunningServiceInfo> rs = am.getRunningServices(50);

                for (int i = 0; i < rs.size(); i++) {
                    ActivityManager.RunningServiceInfo
                            rsi = rs.get(i);
                    Log.i("Service", "Process " + rsi.process + " with component " + rsi.service.toShortString());

                    // TODO: 06.04.2021
                  if (rsi.service.toShortString().equals("{com.dsy.dsu/com.dsy.dsu.Service_Уведомления}"))   {
                      ФлагЗапущеналиСлужбаСейчасИлиНет = true;
                      //
                      break;
                  }else{
                      Log.i("Service", "Process " + rsi.process + " with component " + rsi.service.toShortString());
                  }

                }


                // TODO: 06.04.2021 ПРИНИМАЕМ РЕШЕНИЕ О ЗАКРЫТИЕ СЛУЖБЫ ЧЕРЕ З КНОПКУ


            } else if (ФлагУбратьУведомленияСлужбу.equalsIgnoreCase("Закрыть Уведомления")) {

                //////TODO МЕТОД КОТОРЫЙ ЗАПУСКАЕТ УВЕДОМЛЕНИЯ ПОСЛЕ АНАЛИЗА ДАТ ПРИ НАЖАТИИ НА КПОНКУ ЗАКРЫТЬ ИЗ САМОГО УВЕДОМЛЕНИЯ
                МетодКоторыйЗапускаетУвеломленияПослеАнализа(ИнтентДляЗапускаСлужбыПолсеАнализа, РезультатНужноЗапускатьУведомленияИлиНет, ФлагКтоЗапустилСлужбу);

                ////
                Log.d(getApplicationContext().getClass().getName(), " Кнопка Остановка  по Расписанию СЛУЖБА  Информирования Закрыть Уведомления " + "  --" + new Date() + " ФлагКтоЗапустилСлужбу " + ФлагКтоЗапустилСлужбу);
            }


        }




        ///////
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
            if (mNotificationManager!=null) {
                mNotificationManager.cancelAll();
            }
        }

}


    /////////////////

    private void МетодЗарускаСозданиеУведомлений(Intent intent, String ФлагКтоЗапустилСлужбу) {

        try{





            try{

                ////TODO   тест код для уведомлений

            /*        CREATE_DATABASE.ССылкаНаСозданнуюБазу.beginTransaction();
                        long   Результат_УдалениеДанных =    CREATE_DATABASE.ССылкаНаСозданнуюБазу.delete("date_work",null, null);
                        Log.d(this.getClass().getName(), "Результат_УдалениеДанных " +
                                Результат_УдалениеДанных);

                        CREATE_DATABASE.ССылкаНаСозданнуюБазу.setTransactionSuccessful();
                        CREATE_DATABASE.ССылкаНаСозданнуюБазу.endTransaction();*/

                ////TODO  КОНЕЦ тест код для уведомлений

                //TODO который вычисляет Нужно СоЗДАВАТЬ И ВЫПОЛНЯТЬ УВЕДОМЛЕНИЯ

CountDownLatch countDownLatchДляУведомленияПрипнятииРешения=new CountDownLatch(1);
/////
                Future<Boolean> futureОпределяемЗапускаУведомленияИлиНет=Executors.newSingleThreadExecutor().submit(new Callable<Boolean>() {
                    @Override
                    public Boolean call() throws Exception {

                        ///
                        Log.d(getApplicationContext().getClass().getName(), " Внутри Future Результат НужноЗапускать Уведомления Или Нет  СЛУЖБА"
                                + "--" + РезультатНужноЗапускатьУведомленияИлиНет);/////

                        РезультатНужноЗапускатьУведомленияИлиНет=МетодВычисляемСтоитСоздаватьИЗапускатьСлужбуНапоминаний(ФлагКтоЗапустилСлужбу);

                        return РезультатНужноЗапускатьУведомленияИлиНет;
                    }
                });
                /////
                countDownLatchДляУведомленияПрипнятииРешения.countDown();
                ///
                РезультатНужноЗапускатьУведомленияИлиНет= futureОпределяемЗапускаУведомленияИлиНет.get();
                ////
                countDownLatchДляУведомленияПрипнятииРешения.await();
                ////
                if(futureОпределяемЗапускаУведомленияИлиНет.isDone()){
                    futureОпределяемЗапускаУведомленияИлиНет.cancel(false);



                    ///
                    Log.d(getApplicationContext().getClass().getName(), " Определили Результат НужноЗапускать Уведомления Или Нет  СЛУЖБА"
                            + "--" + РезультатНужноЗапускатьУведомленияИлиНет);/////


                    if (РезультатНужноЗапускатьУведомленияИлиНет==true) {
                        //////TODO МЕТОД КОТОРЫЙ ЗАПУСКАЕТ УВЕДОМЛЕНИЯ ПОСЛЕ АНАЛИЗА ДАТ
                        МетодКоторыйЗапускаетУвеломленияПослеАнализа(ИнтентДляЗапускаСлужбыПолсеАнализа, РезультатНужноЗапускатьУведомленияИлиНет,ФлагКтоЗапустилСлужбу);

                        Log.d(this.getClass().getName(), "ЗАПУСК ПОСЛЕ АНАЛИЗА ДАТ ЗАПУСКАЕМ УВЕДОМЛЕНИЯ  СЛУЖБА  Синхронизация   "+" ВРЕМЯ "  + new Date()
                              +"\n"  +" РезультатНужноЗапускатьУведомленияИлиНет " +РезультатНужноЗапускатьУведомленияИлиНет);
                    }


                }














                ///////
            } catch (Exception e) {
                //  Block of code to handle errors
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                if (mNotificationManager!=null) {
                    mNotificationManager.cancelAll();
                }
            }







//
            Log.d(this.getClass().getName(), "AsyncРезультатНужноЗапускатьУведомленияИлиНет " );

 /*       //////TODO МЕТОД КОТОРЫЙ ЗАПУСКАЕТ УВЕДОМЛЕНИЯ ПОСЛЕ АНАЛИЗА ДАТ
            МетодКоторыйЗапускаетУвеломленияПослеАнализа(intent, РезультатНужноЗапускатьУведомленияИлиНет);*/


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            //   mNotificationManager.cancel(1);///.cancelAll();

            if (mNotificationManager!=null) {
                mNotificationManager.cancelAll();
            }
            // /.cancelAll(); //   mNotificationManager.cancelAll();
            //   mNotificationManager=null;
            //  builder=null;
            Log.d(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБАService_Notifications onDestroy() Exception ");

        }



    }

    private void МетодКоторыйЗапускаетУвеломленияПослеАнализа(Intent intent, boolean результатНужноЗапускатьУведомленияИлиНет, String ФлагКтоЗапустилСлужбу) {
        ///TODO ЕСЛИ TRUE ТО ЗАПУСКАЕМ УВЕДОМЛЕНИЯ ТОЛЬКО КОГДА  TRUE


        Log.d(this.getClass().getName(), "Результат Нужно Запускать Уведомления Или Нет СЛУЖБА  true and false :: " +
                результатНужноЗапускатьУведомленияИлиНет);


        /////TODO ЗАПУСКАЕМ И СОЗДАЕМ СЕРВИС УВЕДОМЛЕНИЯ

        ////TODO если нул то запускаем службу
        String fName = intent.getStringExtra("Флаг");
        ///
        Log.d(getApplicationContext().getClass().getName(), " Пауза СЛУЖБА СЛУЖБА fName " + fName);


        if (fName != null) {


            ///TODO пацза увидомления
            if (fName.equals("Пауза") && mNotificationManager != null) {
                Log.d(getApplicationContext().getClass().getName(), " Пауза СЛУЖБА СЛУЖБА Service_Уведомления ");

                /////todo NOtofication
                builder.setProgress(100, 50, false);
                mNotificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
                // === Removed some obsoletes
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel(
                            PROCESS_ID,
                            "Channel human readable title",
                            NotificationManager.IMPORTANCE_HIGH);
                    channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                    mNotificationManager.createNotificationChannel(channel);
                    builder.setChannelId(PROCESS_ID);
                }


                ///TODO Запускаем увидомления
                mNotificationManager.notify(Integer.parseInt(PROCESS_ID), builder.build());////         mNotificationManager.notify(Integer.parseInt(PROCESS_ID), builder.build());




////TODO закнрываем напоминания

            } else if (fName.equals("Закрыть Уведомления") ) {
                /////todo NOtofication

                /*StatusBarNotification[] notifications = mNotificationManager.getActiveNotifications();
                int index=0;*/

/*
                for (StatusBarNotification notification : notifications) {

                    mNotificationManager.cancel(notification.getId());///.cancelAll();

                }*/
                if (mNotificationManager!=null) {
                    mNotificationManager.cancelAll();
                }

                ///  stopForeground(true);
                stopSelf();
              /*     mNotificationManager=null;
                  builder=null;*/

                Log.d(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБАService_Notifications  Закрыть Уведомления  ");
                ////////

                /////TODO запускаем Действие

            } else if (fName.equals("Запускаем") && mNotificationManager != null) {

                Intent Интент_ЗапускСамогоПриложенияVIEWERRORS = new Intent();
                Интент_ЗапускСамогоПриложенияVIEWERRORS.setClass(getApplicationContext(), MainActivity_VIEWERRORS.class); // ТУТ ЗАПВСКАЕТЬСЯ ВЫБОР ПРИЛОЖЕНИЯ КОТОРЫЕ ЕСТЬ FACE APP НА ДАННЫЙ МОМЕТНТ РАЗРАБОТНАО ТАБЕЛЬНЫЙ УЧЁТ


                Интент_ЗапускСамогоПриложенияVIEWERRORS.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                //
                startActivity(Интент_ЗапускСамогоПриложенияVIEWERRORS);

                //////
                mNotificationManager.cancel(Integer.parseInt(PROCESS_ID));///.cancelAll();

                Log.d(getApplicationContext().getClass().getName(), " Запускаем СЛУЖБА СЛУЖБАService_Notifications ");
            }


            /////todo запуск службы
            // stopSelf();
        } else {
           /*     Toast.makeText(getApplicationContext(), "  Запуск СЛУЖБАService_Notifications СЛУЖБА" ,
            Toast.LENGTH_LONG).show();*/

/////////TODO запуск нновую нотификашенс устанолвка


            МетодНотификайшен(ФлагКтоЗапустилСлужбу);


        }



    }















































    private void МетодНотификайшен(String ФлагКтоЗапустилСлужбу) {
        try {

            Log.d(getApplicationContext().getClass().getName(), " Создание Уведомлеения СЛУЖБА СЛУЖБА Service_Уведомления ");
///

            PackageManager pm = getApplicationContext().getPackageManager();

            builder=null;






            ////
 /*           Intent notificationIntentЗапустить = new Intent(getApplicationContext(), Service_Уведомления.class);
            notificationIntentЗапустить.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            notificationIntentЗапустить.addCategory(Intent.CATEGORY_LAUNCHER);
            notificationIntentЗапустить.setAction("ru.startandroid.notifications.action_delete");
            notificationIntentЗапустить.putExtra("Флаг", "Запускаем");
            ///////
            PendingIntent ЗапускЗапупускаем = null;


            if (notificationIntentЗапустить.resolveActivity(pm) != null) {
                ЗапускЗапупускаем = PendingIntent.getService(getApplicationContext(),
                        2, notificationIntentЗапустить,
                        PendingIntent.FLAG_CANCEL_CURRENT); //PendingIntent.FLAG_UPDATE_CURRENT
            }*/

            ///////TODO ЗАкрыкть


////
            Intent notificationIntentЗакрыть = new Intent(getApplicationContext(), Service_Уведомления.class);
            notificationIntentЗакрыть.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            //notificationIntentЗакрыть.addCategory(Intent.CATEGORY_LAUNCHER);
            notificationIntentЗакрыть.setAction("ru.startandroid.notifications.action_delete");
            notificationIntentЗакрыть.putExtra("Флаг", "Закрыть Уведомления");
            ///////
            PendingIntent ЗапускЗакрытия = null;


            if (notificationIntentЗакрыть.resolveActivity(pm) != null) {
                ЗапускЗакрытия = PendingIntent.getService(getApplicationContext(),
                        0, notificationIntentЗакрыть,
                        PendingIntent.FLAG_CANCEL_CURRENT); //PendingIntent.FLAG_UPDATE_CURRENT
            }
///
           Intent notificationIntent = new Intent(getApplicationContext(), MainActivity_Face_Start.class);
            notificationIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
         //   notificationIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            notificationIntent.setAction("ru.startandroid.notifications.action_delete");
            notificationIntent.putExtra("Флаг", "Пауза");
            ////////
            PendingIntent ЗапускПауза = null;

            if (notificationIntent.resolveActivity(pm) != null) {

                ЗапускПауза = PendingIntent.getActivities(getApplicationContext(),
                        1, new Intent[]{notificationIntent},
                        PendingIntent.FLAG_CANCEL_CURRENT); //PendingIntent.FLAG_UPDATE_CURRENT
            }


            ////*/
////TODO в данную переменную мы вписываем все наши задачи



            String bigText=null;
        if (PUBLIC_CONTENT.Отладка==true) {
                bigText = БуферСамиУведомленияЛинкСамиУведомления.toString()+" :: "+ФлагКтоЗапустилСлужбу+"--" +new Date();

            } else {
               bigText = БуферСамиУведомленияЛинкСамиУведомления.toString();
            }


            Log.d(this.getClass().getName(), "bigText " +bigText);


            if (bigText!=null) {
                if (bigText.length()>0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        ///"@mipmap/icon_main_tabel_four" ////.setSmallIcon(R.drawable.ic_notifications_black_24dp)
                        builder = new NotificationCompat.Builder(getApplicationContext(), PROCESS_ID)
                              /////
                                .setContentText(bigText)                 // .setContentText("http://developer.alexanderklimov.ru/android/")
                                .setSmallIcon(R.drawable.ic_notifications_black_24dp)////builder.setSmallIcon(R.drawable.ic_launcher_background);//R.mipmap.ic_launcher   ///R.drawable.ic_notifications_black_24dp
                                .setPriority(NotificationCompat.PRIORITY_MAX)
                                .setColor(Color.parseColor("#00ACC1"))
                                .setLargeIcon(BitmapFactory.decodeResource(getResources(),
                                        R.drawable.icon_dsu1_info_customer)) // большая картинка
                                //.setTicker("Последнее китайское предупреждение!") // до Lollipop
                                .setVibrate(new long[]{0, 250, 100, 250})
                                .setShowWhen(true)
                                .setCategory(Notification.CATEGORY_SERVICE)
                                .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE | Notification.FLAG_AUTO_CANCEL)
                                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                                .setStyle(new NotificationCompat.BigTextStyle().bigText(bigText) ).setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                                .addAction(android.R.drawable.ic_delete, "Закрыть", ЗапускЗакрытия)
                                .setAutoCancel(false) // автоматически закрыть уведомление после нажатия////.setStyle(new NotificationCompat.BigTextStyle().bigText(bigText) ).setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                                .setContentIntent(ЗапускПауза)
                                 .setContentInfo("уведомления");
                                ////TODO три кнопки действия PUSH-сообщений



                    } else {
                        builder =
                                new NotificationCompat.Builder(getApplicationContext(), PROCESS_ID)
                        //
                                        .setContentText(bigText)                 // .setContentText("http://developer.alexanderklimov.ru/android/")
                                        .setSmallIcon(R.drawable.ic_notifications_black_24dp)////builder.setSmallIcon(R.drawable.ic_launcher_background);//R.mipmap.ic_launcher   ///R.drawable.ic_notifications_black_24dp
                                        .setPriority(NotificationCompat.PRIORITY_MAX)
                                        .setColor(Color.parseColor("#00ACC1"))
                                        // необязательные настройки
                                        .setLargeIcon(BitmapFactory.decodeResource(getResources(),
                                                R.drawable.icon_dsu1_info_customer)) // большая картинка
                                        //.setTicker("Последнее китайское предупреждение!") // до Lollipop
                                        .setVibrate(new long[]{0, 250, 100, 250})
                                        .setShowWhen(true)
                                        .setCategory(Notification.CATEGORY_SERVICE)
                                        .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE | Notification.FLAG_AUTO_CANCEL)
                                        // .setProgress(100, 100, false)
                                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                                        .setStyle(new NotificationCompat.BigTextStyle().bigText(bigText) ).setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                                        .setAutoCancel(false) // автоматически закрыть уведомление после нажатия////.setStyle(new NotificationCompat.BigTextStyle().bigText(bigText) ).setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                                        .addAction(android.R.drawable.ic_delete, "Закрыть", ЗапускЗакрытия)
                                        .setContentIntent(ЗапускПауза)
                                        .setContentInfo("уведомления");

                                        // автоматически закрыть уведомление после нажатия
                                       // .setContentIntent(ЗапускЗакрытия);
                                        ////TODO три кнопки действия PUSH-сообщений



                    }
                }else{
                    Log.e(this.getClass().getName(), "bigText ПУСТОЙ СЛУЖБЫ " +bigText);
                }
            }else{

                Log.e(this.getClass().getName(), "bigText ПУСТОЙ СЛУЖБЫ " +bigText);
            }


            mNotificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
            // === Removed some obsoletes
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        PROCESS_ID,
                        "Channel human readable title",
                        NotificationManager.IMPORTANCE_HIGH);
                mNotificationManager.createNotificationChannel(channel);
                builder.setChannelId(String.valueOf(PROCESS_ID));
                channel.setDescription("Увеомление для версии выше API 25");

                ///TODO Запускаем увидомления

                    mNotificationManager.notify(Integer.parseInt(PROCESS_ID), builder.build());////   mNotificationManager.notify(Integer.parseInt(PROCESS_ID), builder.build());
                    ///TODO закрытие увидомления
                    //mNotificationManager.cancel(1);///.cancelAll();

                    ///TODO Запускаем увидомления
                    startForeground(Integer.parseInt(PROCESS_ID),builder.build());//builder.build()


            }else{


                    ///TODO Запускаем увидомления
                    startForeground(Integer.parseInt(PROCESS_ID),builder.build());//builder.build()


            }
           /// startForeground(Integer.parseInt(PROCESS_ID),builder.build());//builder.build()



            //////


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            //   mNotificationManager.cancel(1);///.cancelAll();

            if (mNotificationManager!=null) {
                mNotificationManager.cancelAll();
            }


            // /.cancelAll(); //   mNotificationManager.cancelAll();
            //   mNotificationManager=null;
            //  builder=null;
            Log.d(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБАService_Notifications onDestroy() Exception ");

        }







    }


    ///TODO метод определяем стоит запускать и создвать службу напоминаний или нет

    private boolean МетодВычисляемСтоитСоздаватьИЗапускатьСлужбуНапоминаний(String ФлагКтоЗапустилСлужбу) {
       // final boolean[] РезультатВнутриЗапускатьУведомленияИлиНет = {false};
        try {



            ////

            Log.d(this.getClass().getName(), "  СЛУЖБА..... ДЛЯ проверяем нужно ли создвать и запускать службу нпоминаний работа с датами");

            /////todo если не изместен локальная версия являеться null перед проверкой то еще раз применяем выясняем локальную версиюПО для проверки

            long РезультатОбновлениеЛокальнойВерсииПО = 0;
            /////////
            /////TODO когда локальное ПО версию не нашли вытаемся ее увидить в базе

            //////

            ///
            Cursor   Курсор_IDпользоввателяДляСлужб=null;
            ////

            int ПолучениеПравДляТаблицыПрава=0;




                            CREATE_DATABASE.ССылкаНаСозданнуюБазу = getApplicationContext().openOrCreateDatabase("Database DSU-1.db", 0, null);//CREATE_DATABASE. ССылкаНаСозданнуюБазу


            // TODO: 26.05.2021  перед обработкой уведомлений функция удаления Уведомлениц Сообщений не относящиеся к Пользователю


     /*       if (PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID!=null) {
                /////////
                ///CREATE_DATABASE.ССылкаНаСозданнуюБазу.rawQuery("DELETE  From notification WHERE  user_update != "+PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID+"", null);

                long РезультатУдаленияСообщенийНЕОтносящиеСяПользователю=    CREATE_DATABASE.ССылкаНаСозданнуюБазу.delete("notification",
                                "user_update != ?", new String[]{PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID});

                ////

                Log.d(this.getClass().getName(), "  РезультатУдаленияСообщенийНЕОтносящиеСяПользователю " +РезультатУдаленияСообщенийНЕОтносящиеСяПользователю );

            }*/


















            // TODO: 26.05.2021 данные по высичлению ID


             Курсор_IDпользоввателяДляСлужб=
                                    CREATE_DATABASE.ССылкаНаСозданнуюБазу.rawQuery("SELECT *  From notification", null);



    if (Курсор_IDпользоввателяДляСлужб!=null && Курсор_IDпользоввателяДляСлужб.getCount()>0) {
        //////
        Курсор_IDпользоввателяДляСлужб.moveToFirst();
        ///
        int ИНдексПолучениеПрав=Курсор_IDпользоввателяДляСлужб.getColumnIndex("rights");
        ///////
        ПолучениеПравДляТаблицыПрава = Курсор_IDпользоввателяДляСлужб.getInt(ИНдексПолучениеПрав);
///


        Log.d(this.getClass().getName(), "  СЛУЖБА..... получение ID в службе уведомления " +ПолучениеПравДляТаблицыПрава);
//////////
        Курсор_IDпользоввателяДляСлужб.close();


        // TODO: 20.05.2021  продолжение уведомления определяем даты после того как получили права на сотрудника  

        МетодПолучениеДатыПослеПолучениеПравСотрудникаДляУведомления(ПолучениеПравДляТаблицыПрава);
        
        


    } else {
        Log.e(this.getClass().getName(), "  СЛУЖБА.....   НЕ получения ID в службе уведомления " +ПолучениеПравДляТаблицыПрава);

    }


    

        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
            if (mNotificationManager!=null) {
                mNotificationManager.cancelAll();
            }
        }

        // TODO: 20.05.2021  результат
        return РезультатНужноЗапускатьУведомленияИлиНет ;
    }











    // TODO: 20.05.2021  продолжение уведомления определяем даты после того как получили права на сотрудника
    
    
    
    private void МетодПолучениеДатыПослеПолучениеПравСотрудникаДляУведомления(int получениеПравДляТаблицыПрава) throws ParseException {
        // TODO: 20.05.2021 действие вьторое

        Cursor КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет=null;
        try{

        try{
        
            if (получениеПравДляТаблицыПрава >0) {
                ////////
                КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет =
                                                CREATE_DATABASE.ССылкаНаСозданнуюБазу.rawQuery(" SELECT * FROM notification WHERE rights= "+ получениеПравДляТаблицыПрава, null);
            }
        
        
            // TODO: 19.05.2021  ошибки
                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                    if (mNotificationManager!=null) {
                        mNotificationManager.cancelAll();
                    }
                }


        //

        if ( КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет!=null &&
                КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.getCount() > 0) {
            ///////


            КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.moveToFirst();


            //////
            Log.d(this.getClass().getName(), "КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.getCount()  СЛУЖБА " +
                    КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.getCount());
            ////TODO start do

            //TODO перед созданеим
            БуферСамиУведомленияЛинкСамиУведомления=null;
            БуферСамиУведомленияЛинкСамиУведомления=new StringBuffer();

            do {
                ////
                /////
                ID_ТаблицаУвендомлений = 0;

                ID_ТаблицаУвендомлений    = КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.getInt(0);

                //////
                Log.d(this.getClass().getName(), " СЛУЖБА полученный ID таблицы уведемлния ID_ТаблицаУвендомлений " + ID_ТаблицаУвендомлений);

                ///////
                int IDUser_ТаблицаУвендомлений = КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.getInt(1);

                /////
                int Интревал_ТаблицаУвендомлений = КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.getInt(3);

                /////
                String Дата_Начала_ТаблицаУвендомленийТекст = КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.getString(4);


                /////
                String СамиУведомления = КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.getString(5);


                ///TODO ЗАПОЛНЯЕМ БУФЕР ДАННЫМИ

               /// БуферСамиУведомленияЛинкСамиУведомления.append("\n").append("  ").append(СамиУведомления).append(".").append("\n");

                Log.d(this.getClass().getName(), "СамиУведомления " + СамиУведомления +
                        " Дата_Начала_ТаблицаУвендомленийТекст " + Дата_Начала_ТаблицаУвендомленийТекст + " БуферСамиУведомленияЛинкСамиУведомления "
                        + БуферСамиУведомленияЛинкСамиУведомления.toString());


                ///TODO ДАТА ОТ СЕРВЕРА
                Date Дата_НачалаОтСервер = new Date();

                try {
                    ФоорматДат.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                    Дата_НачалаОтСервер = ФоорматДат.parse(Дата_Начала_ТаблицаУвендомленийТекст);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Log.d(this.getClass().getName(), " Дата_НачалаОтСервер" + Дата_НачалаОтСервер + "\n" +
                        " Дата_Начала_ТаблицаУвендомленийТекст " + Дата_Начала_ТаблицаУвендомленийТекст);


                ///TODO ДАТА СЕЙЧАС
                Calendar КалендарьВремениСейчас = Calendar.getInstance();
                КалендарьВремениСейчас.setTime(new Date()); // Now use today date.
                ФоорматДат.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                String ДатаВремениСейчасТекст = ФоорматДат.format(КалендарьВремениСейчас.getTime());
                /////
                Date ДатаВремениСейчас = null;// получена ДАТА ВЕРСИИ ДАННЫХ СЕРВЕРА
                try {
                    ДатаВремениСейчас = ФоорматДат.parse(ДатаВремениСейчасТекст);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Log.d(this.getClass().getName(), "ДатаВремениСейчас " + ДатаВремениСейчас.toString());







                /////TODO сам анализ даты в таблице DATE_WORK

                Date ДатаСравненияНужноПроверятьПередЗапускомУведомления = null;






                // TODO: 19.05.2021

             Cursor Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull =  null;

             try{

                                //////////

                 if (ID_ТаблицаУвендомлений>0) {
                     Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull =
                             CREATE_DATABASE.ССылкаНаСозданнуюБазу.rawQuery(" SELECT * FROM  notification_insider WHERE id= " + ID_ТаблицаУвендомлений, null);

                     /////////////////////////
                 }


                 // TODO: 19.05.2021  ошибки
            } catch (Exception e) {
                //  Block of code to handle errors
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                if (mNotificationManager!=null) {
                    mNotificationManager.cancelAll();
                }
            }


                // TODO: 20.05.2021 дейсиве четверотое

                        if ( Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull!=null &&
                                Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull.getCount() > 0) {

                            ////////
                            Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull.moveToFirst();

                            ///todo В ТАБЛИЦЕ DATA+WORK ЕСТЬ ДАТА И МЫ ЕЕ ВЫТАСКИВАЕМ И ЗАПИСЫВАЕМ НА ДАТУ ДЛЯ ПРОВЕРКИ

                            ///
                            String ПолученаяДатаРанееЗаписанаВТаблицуDate_Work = Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull.getString(6);

                            if (ПолученаяДатаРанееЗаписанаВТаблицуDate_Work != null) {

                                ДатаСравненияНужноПроверятьПередЗапускомУведомления = ФоорматДат.parse(ПолученаяДатаРанееЗаписанаВТаблицуDate_Work);//создаю дату через


                                Log.d(this.getClass().getName(), " Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull.getCount()" + Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull.getCount() +
                                        "  ДатаСравненияНужноПроверятьПередЗапускомУведомления " + ДатаСравненияНужноПроверятьПередЗапускомУведомления);

                            } else {

                                //////////todo ДАТЫ В ТАБЛИЦЕ НЕТ И МЫ ЕЕ ЗАИМСТВУЕМ ИЗ ДАТЫ СТАРТА С СЕРВЕРА ПОСЛЕ СИХРОНИЗАЦИИ
                                ///TODO записываем уже из СОЗДАННОЙ ДАТЫ НАЧАЛО НА СЕРВЕРА ДАТА СТАРТА
                                ДатаСравненияНужноПроверятьПередЗапускомУведомления = Дата_НачалаОтСервер;
                                /////
                                Log.d(this.getClass().getName(), " Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull.getCount()" + Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull.getCount() +
                                        "  ДатаСравненияНужноПроверятьПередЗапускомУведомления " + ДатаСравненияНужноПроверятьПередЗапускомУведомления);

                                Log.d(this.getClass().getName(), " ДатаВремениСейчас" + ДатаВремениСейчас.toString() +
                                        "  ДатаСравненияНужноПроверятьПередЗапускомУведомления " + ДатаСравненияНужноПроверятьПередЗапускомУведомления.toString());
                            }



                            ////TODO CLOSE
                            Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull.close();


                        } else {

                            //////////todo ДАТЫ В ТАБЛИЦЕ НЕТ И МЫ ЕЕ ЗАИМСТВУЕМ ИЗ ДАТЫ СТАРТА С СЕРВЕРА ПОСЛЕ СИХРОНИЗАЦИИ
                            ///TODO записываем уже из СОЗДАННОЙ ДАТЫ НАЧАЛО НА СЕРВЕРА ДАТА СТАРТА
                            ДатаСравненияНужноПроверятьПередЗапускомУведомления = Дата_НачалаОтСервер;
                            /////
                     /*   Log.d(this.getClass().getName(), " Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull.getCount()" + Курсор_ИщемЛиЗначениевСтолбикеDate_WORKNull[0].getCount() +
                                "  ДатаСравненияНужноПроверятьПередЗапускомУведомления " + ДатаСравненияНужноПроверятьПередЗапускомУведомления);

                        Log.d(this.getClass().getName(), " ДатаВремениСейчас" + ДатаВремениСейчас.toString() +
                                "  ДатаСравненияНужноПроверятьПередЗапускомУведомления " + ДатаСравненияНужноПроверятьПередЗапускомУведомления.toString());*/

                        }





















                /////TODO конец сам анализ даты в таблице DATE_WORK


                ////TODO ДАТЫ


                Log.d(this.getClass().getName(), " ДатаВремениСейчас" + ДатаВремениСейчас.toString() +
                        "  ДатаСравненияНужноПроверятьПередЗапускомУведомления " + ДатаСравненияНужноПроверятьПередЗапускомУведомления.toString());


                //TODO ОПРЕДЕЛЯЕМ НУЖНАЛИ ВООБЩЕ ПРОВЕРКА ПО ДАТАМ (первая проверка )
                if (ДатаВремениСейчас.after(ДатаСравненияНужноПроверятьПередЗапускомУведомления)
                        || ДатаВремениСейчас.compareTo(ДатаСравненияНужноПроверятьПередЗапускомУведомления) == 0) {




                    ///TODO флаг указываетт службе что надо ЗАПУСКА СЛУЖБУ УВЕДОМЛЕНИЙ
                    РезультатНужноЗапускатьУведомленияИлиНет = true;



               /*     ////TODO ДАТЫ
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
// Vibrate for 500 milliseconds
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        //deprecated in API 26
                        v.vibrate(50);
                    }*/
                    // TODO: 14.04.2021 очищаем уведеомния перед созданием
                    if (mNotificationManager!=null) {
                        StatusBarNotification[] notifications = mNotificationManager.getActiveNotifications();
                        int index=0;


                        for (StatusBarNotification notification : notifications) {

                            mNotificationManager.cancel(notification.getId());///.cancelAll();

                        }

                    }
                    if (mNotificationManager!=null) {
                        mNotificationManager.cancelAll();

                            Log.i(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБАService_Notifications ДатаВремениСейчас  mNotificationManager.cancelAll()  "+new Date());

                    }





                    Log.d(this.getClass().getName(), " ДатаВремениСейчас" + ДатаВремениСейчас.toString() +
                            "  ДатаСравненияНужноПроверятьПередЗапускомУведомления " + ДатаСравненияНужноПроверятьПередЗапускомУведомления.toString());





                    Log.d(this.getClass().getName(), "\n" + "РезультатНужноЗапускатьУведомленияИлиНет СЛУЖБА Успешно Выполняеться " + "\n" +
                            РезультатНужноЗапускатьУведомленияИлиНет + "\n");


                    /////TODO код вычисляем БУДУШИЙ ПЕРИОД ЗАПУСКА


                    ///TODO ДАТА ВЫЧИСЛЯЕМ
                    final int[] ГОД_Дата_НачалаОтСерверКалендарь = {0};
                    final int[] ГОД_ДатаФиналЗаписываемИзМилисекундФинал = {0};
                    final Date[] ДатаФиналЗаписываемИзМилисекунд = new Date[1];
                    final String[] ДатаФиналЗаписываемИзМилисекундТекст = new String[1];

                    Calendar ГОД_КалендарьВремениСейчас; // Now use today date.



                    //////////////////////////////////TODO для дат нужен


                    ///////


                    /////

                    Date finalДатаВремениСейчас = ДатаВремениСейчас;
                    ///////
                    Date finalДата_НачалаОтСервер = Дата_НачалаОтСервер;



                            try{


                                //TODO ДАТА СРАВНЕНИЯ СЕЙЧАС
                                Calendar ДатаВремениСейчаcКалендарь = Calendar.getInstance();
                                ДатаВремениСейчаcКалендарь.setTime(finalДатаВремениСейчас);
                                Log.d(this.getClass().getName(), "ДатаВремениСейчаcКалендарь " + ДатаВремениСейчаcКалендарь.toString());


                                //TODO ДАТА ОТ СЕРВЕРА НАЧАЛО
                                Calendar Дата_НачалаОтСерверКалендарь = Calendar.getInstance();
                                Дата_НачалаОтСерверКалендарь.setTime(finalДата_НачалаОтСервер);
                                Log.d(this.getClass().getName(), "Дата_НачалаОтСерверКалендарь " + Дата_НачалаОтСерверКалендарь.toString());


                                //TODO (ДЕЙСТВИЕ ПЕРВОЕ)
                                long ИнтревалЧасыКоторыйПришелОтСервераПерводимВМилисекунды=0l;
                                //TODO ВЫЧЕСЛЯЕМ ИНТРЕВАЛ КОТОРЫЙ ПРИШЕЛ ОТ СЕРВЕРА   В МИЛИСЕКУНДЫ

                             ИнтревалЧасыКоторыйПришелОтСервераПерводимВМилисекунды = TimeUnit.MILLISECONDS.convert(Интревал_ТаблицаУвендомлений, TimeUnit.MINUTES); //gives 86400000

                                //    long ИнтревалЧасыКоторыйПришелОтСервераПерводимВМилисекунды=     TimeUnit.HOURS.toMillis(Интревал_ТаблицаУвендомлений);//178000000


                                Log.d(this.getClass().getName(), "ИнтревалЧасыКоторыйПришелОтСервераПерводимВМилисекунды " + ИнтревалЧасыКоторыйПришелОтСервераПерводимВМилисекунды);


                                //TODO (ДЕЙСТВИЕ  ВТОРОЕ )
                                long ФинальныеМилисекундыВычеслнойДаты=0l;
                                //TODO ВЫЧЕСЛЯЕМ формула ИЗ ДВУХ ДАТ МИЛИСЕКУНДЫ ДАТЫ СЕЙЧАС ВРЕМЯ И И ВРЕМЯ КОТОРОЕ ПРИШЛО ОТ СЕРВЕРА
                               ФинальныеМилисекундыВычеслнойДаты = ((ДатаВремениСейчаcКалендарь.getTimeInMillis() - Дата_НачалаОтСерверКалендарь.getTimeInMillis()) /
                                        ИнтревалЧасыКоторыйПришелОтСервераПерводимВМилисекунды) *
                                        ИнтревалЧасыКоторыйПришелОтСервераПерводимВМилисекунды +
                                        Дата_НачалаОтСерверКалендарь.getTimeInMillis() +
                                        ИнтревалЧасыКоторыйПришелОтСервераПерводимВМилисекунды;
                                Log.d(this.getClass().getName(), "ФинальныеМилисекундыВычеслнойДаты " + ФинальныеМилисекундыВычеслнойДаты);


                                //TODO (ДЕЙСТВИЕ  ЧЕТВЕРТОЕ )
                                //TODO ЗАПИСЫВАЕМ ДАТУ ВЫЧЕСЛЕННУЮ В  ПЕРЕЕННУЮ ДАТУ СОЗДАНИЕ ИЗ МИЛИСЕКУНД ДАТЫ


                                ДатаФиналЗаписываемИзМилисекунд[0] = new Date(ФинальныеМилисекундыВычеслнойДаты);
                                ////


                                ФоорматДат = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));//"yyyy-MM-dd HH:mm:ss"//"yyyy-MM-dd'T'HH:mm:ss'Z'"
                                ФоорматДат.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                                //////
                                ДатаФиналЗаписываемИзМилисекундТекст[0] = ФоорматДат.format(ДатаФиналЗаписываемИзМилисекунд[0]);
                                ////

                                ///
                                Log.d(this.getClass().getName(), " СЛУЖБА запись новой даты СРАБАТЫВАЙНЯ ДатаФиналЗаписываемвБазуКлиентаТаблицуDate_WORK  " + ДатаФиналЗаписываемИзМилисекунд[0].toString() + "\n" +
                                        " ДатаФиналЗаписываемИзМилисекунд " + ДатаФиналЗаписываемИзМилисекунд[0]);
                                ///


                                //TODO (ДЕЙСТВИЕ  ПЯТОЕ )
                                //TODO ИЗ ТЕКСТА ДАТЫ ПАСИМ ЕЕ В ДАТУ  (ФИНАЛ)


                                Date ДатаФиналЗаписываемИзМилисекундФинал = ФоорматДат.parse(ДатаФиналЗаписываемИзМилисекундТекст[0]);//создаю дату через
                                ///

                                ////
                                Log.d(this.getClass().getName(), " ФИНАЛ ОЦЕНИВАЕМ ДВЕ ДАТЫ  НУЖНО ЗАПУСКАТЬ УВЕДОМЛЕНИЯ ИЛИ НЕТ," + "\n" +
                                        " ДатаФиналЗаписываемИзМилисекундФинал  " + ДатаФиналЗаписываемИзМилисекундФинал.toString() + "\n" +
                                        " ДатаВремениСейчас " + finalДатаВремениСейчас.toString() + "\n");

                                /////TODO КОНЕЦ ВЫЧЕЛСЕНИЯ ДАТЫ


                                /////TODO конец код вычисляем БУДУШИЙ ПЕРИОД ЗАПУСКА

                                ГОД_Дата_НачалаОтСерверКалендарь[0] = Дата_НачалаОтСерверКалендарь.get(Calendar.YEAR);


                                Calendar ГОД_КалендарьВремениСейчасДляДаты = Calendar.getInstance();
                                /////
                                ГОД_КалендарьВремениСейчасДляДаты.setTime(ДатаФиналЗаписываемИзМилисекундФинал); // Now use today date.


                                ГОД_ДатаФиналЗаписываемИзМилисекундФинал[0] =   ГОД_КалендарьВремениСейчасДляДаты.get(Calendar.YEAR);

                                // TODO: 02.04.2021 сравниваем года чтобы они были одинковые в дате для записи в базу если года разныне знчит это ошибка и, записывать не надо

                                ////
                                Log.d(this.getClass().getName(), " ГОД_Дата_НачалаОтСерверКалендарь " + ГОД_Дата_НачалаОтСерверКалендарь[0] + "\n" +
                                        " ГОД_Дата_НачалаОтСерверКалендарь " + ГОД_Дата_НачалаОтСерверКалендарь[0]);



                            } catch (Exception e) {
                                //  Block of code to handle errors
                                e.printStackTrace();
                                ///метод запись ошибок в таблицу
                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                            new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                                if (mNotificationManager!=null) {
                                    mNotificationManager.cancelAll();
                                }
                            }


                            // TODO: 08.04.2021 вставка даты

                            if (ГОД_Дата_НачалаОтСерверКалендарь[0] == ГОД_ДатаФиналЗаписываемИзМилисекундФинал[0]) {
                                ////TODO Данный Код Записываем в базу date_work новое значение КЛГДА НЕГО НЕТ NULL ИЛИ КОГДА ДАТА В БАЗЕ МЕНЬШЕ ЧЕМ НА СЕРВЕРЕ
                                МетодЗаписиВБазуАндройдаНовуюДатуДЛяСлужбыУведомления(ID_ТаблицаУвендомлений, ДатаФиналЗаписываемИзМилисекундТекст[0], Интревал_ТаблицаУвендомлений);

                                //////todo
                                БуферСамиУведомленияЛинкСамиУведомления.append("\n").append("  ").append(СамиУведомления).append(".").append("\n");

                                Log.d(this.getClass().getName(), "СамиУведомления " + СамиУведомления +
                                        " Дата_Начала_ТаблицаУвендомленийТекст " + Дата_Начала_ТаблицаУвендомленийТекст + " БуферСамиУведомленияЛинкСамиУведомления " + БуферСамиУведомленияЛинкСамиУведомления.toString()+
                                        " Интревал_ТаблицаУвендомлений " +Интревал_ТаблицаУвендомлений+ " ДатаФиналЗаписываемИзМилисекундТекст[0] " +ДатаФиналЗаписываемИзМилисекундТекст[0]);

                            } 
                            

                    ///



/*

                        //////TODO МЕТОД КОТОРЫЙ ЗАПУСКАЕТ УВЕДОМЛЕНИЯ ПОСЛЕ АНАЛИЗА ДАТ
                        МетодКоторыйЗапускаетУвеломленияПослеАнализа(ИнтентДляЗапускаСлужбыПолсеАнализа, РезультатНужноЗапускатьУведомленияИлиНет,ФлагКтоЗапустилСлужбу);

                        Log.d(this.getClass().getName(), "ЗАПУСК ПОСЛЕ АНАЛИЗА ДАТ ЗАПУСКАЕМ УВЕДОМЛЕНИЯ  СЛУЖБА  Синхронизация   "+" ВРЕМЯ "  + new Date());



*/








                    //////TODO ДАТЫ ВЫЧИСЛТИЛИ И НЕ НАДО ЗАПУСКАТЬ СЛУЖБУ УВЕДОМДЕНИЙ
                } else {

                    ////TODO
                    ///TODO флаг указываетт службе что НЕ НАДО ЗАПУСКА СЛУЖБУ УВЕДОМЛЕНИЙ
                    РезультатНужноЗапускатьУведомленияИлиНет = false;


                    Log.d(this.getClass().getName(), "\n" +
                            "РезультатНужноЗапускатьУведомленияИлиНет СЛУЖБА НЕ надо выполнять даты Равны  " + "\n" +
                            РезультатНужноЗапускатьУведомленияИлиНет + "\n" +
                            " ДатаВремениСейчас" + ДатаВремениСейчас.toString() + "\n" +
                            "  ДатаСравненияНужноПроверятьПередЗапускомУведомления " + ДатаСравненияНужноПроверятьПередЗапускомУведомления.toString());




                } // TODO: 02.04.2021 end executer data



                ///TODO ЗАПИСЫВАЕМ В БАЗУ ЕСЛИ NULL В ТАБЛИЦЕ DATE_WORK НЕТ ДАТЫ ВООБЩЕ NULL


                Log.d(this.getClass().getName(), "  ID_ТаблицаУвендомлений   :" + ID_ТаблицаУвендомлений + " Сообщение_ТаблицаУвендомлений ");

                //todo while
            } while (КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.moveToNext());






            ////TODO закрываем курсор

                if (!КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.isClosed()) {
                    КурсорДляАнализаВытаскиваемДатыСтоитЗапускатьСлужбуУведомдениейИлиНет.close();
                }


        }



        // TODO: 19.05.2021  ошибки
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
        if (mNotificationManager!=null) {
            mNotificationManager.cancelAll();
        }
    }




    }


    ///TODO запись  В БАЗУ НОВГО СЗНАЧЕНИЯ ДАТЫ ДЛЯ СЛУЖБЫ УВЕДОМДЕНИЯ


    private boolean МетодЗаписиВБазуАндройдаНовуюДатуДЛяСлужбыУведомления(int ID_ТаблицаУвендомлений ,
                                                                          String ДатаФиналЗаписываемИзМилисекундТекст,
                                                                          int Интревал_ТаблицаУвендомлений) {
        boolean РезультатВставкиНовойДатыВdate_Work = false;
        try{

/////TODO К ДАЕ ПРИБОВЛЯЕМ ИНДИФИКАТОР ЧАСОВ  И ЗАПИСЫВАЕМ
            // Дата_Начала_ТаблицаУвендомлений


            Log.d(this.getClass().getName(), "Дата_Начала_ТаблицаУвендомлений " + ДатаФиналЗаписываемИзМилисекундТекст +"\n"+
                    " Интревал_ТаблицаУвендомлений " +Интревал_ТаблицаУвендомлений );


            CREATE_DATABASE.ССылкаНаСозданнуюБазу = getApplicationContext().openOrCreateDatabase("Database DSU-1.db", 0, null);//CREATE_DATABASE. ССылкаНаСозданнуюБазу


            ContentValues contentValuesЗаполенияНовойДатойDate_WORk=new ContentValues();
            ////


            contentValuesЗаполенияНовойДатойDate_WORk.put("date_work", ДатаФиналЗаписываемИзМилисекундТекст);
            contentValuesЗаполенияНовойДатойDate_WORk.put("id",ID_ТаблицаУвендомлений);
            ///TODO ОБНОЛВЕНИЕ
            CREATE_DATABASE.ССылкаНаСозданнуюБазу.beginTransactionNonExclusive();




            ////// TODO САМО ОБНОВЛЕНИЕ ДАННЫХ В БАЗУ ЧЕРЕЗ КОНТЕЙНЕР
            long Результат_ОбновлениеДанныхДатойDate_WORk = CREATE_DATABASE.ССылкаНаСозданнуюБазу.update("date_work", contentValuesЗаполенияНовойДатойDate_WORk, "id"+"= ?",
                    new String[]{String.valueOf(ID_ТаблицаУвендомлений)});
            ///////



//TODO обновленеи если прошло если не прощло идем НИЖЕ И ДЕЛАЕМ УЖЕ ВСТАВКУ ДАННЫХ
                    if(Результат_ОбновлениеДанныхДатойDate_WORk>0){
                        Log.d(this.getClass().getName(), "Результат_ОбновлениеДанныхДатойDate_WORk " + Результат_ОбновлениеДанныхДатойDate_WORk);

                        CREATE_DATABASE.ССылкаНаСозданнуюБазу.setTransactionSuccessful();


                        //TODO ТОлько встака если прошло если не прощло идем НИЖЕ И ДЕЛАЕМ УЖЕ ВСТАВКУ ДАННЫХ
                    }else{

                        long Результат_ВставкаДанныхДатойDate_WORk = CREATE_DATABASE.ССылкаНаСозданнуюБазу.insert("date_work",null, contentValuesЗаполенияНовойДатойDate_WORk);
                        ///////
                        if(Результат_ВставкаДанныхДатойDate_WORk>0) {
                            Log.d(this.getClass().getName(), "Результат_ОбновлениеДанныхДатойDate_WORk " + Результат_ОбновлениеДанныхДатойDate_WORk);

                            CREATE_DATABASE.ССылкаНаСозданнуюБазу.setTransactionSuccessful();

                        }


                    }
/////////////



            CREATE_DATABASE.ССылкаНаСозданнуюБазу.endTransaction();

            // Log.d(this.getClass().getName(), "Результат_ОбновлениеДанныхДатойDate_WORk " + Результат_ОбновлениеДанныхДатойDate_WORk);


            contentValuesЗаполенияНовойДатойDate_WORk.clear();


        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
            if (mNotificationManager!=null) {
                mNotificationManager.cancelAll();
            }
        }
        return РезультатВставкиНовойДатыВdate_Work;
    }








    //УНИВЕРСАЛЬНЫЙ КУРСОР С ПАРАМЕТРАМИ
    Cursor КурсорУниверсальныйДляБазыДанныхДляСлужбы(String таблица, String колонки, String фильтр, String[] условияфильтра, String групировка,
                                                     String хэвинг, String ордербай, String лимиты)
            throws ExecutionException, InterruptedException, TimeoutException {

        Cursor    Курсор_ИщемПУбличныйIDКогдаегоНетВстатике=null;

        int ПубличныйIDДляСлужбы = 0;

        Cursor    Курсор_УниверсальныйdВнутри=null;

////
        try{
        ////

        ///////ПОПЫТКА ПОДКЛЮЧЧЕНИЕ К ИНТРЕНТУ

        Log.i(this.getClass().getName(), "  колонки " + колонки);


                    ///////////

                    // TODO: 29.03.2021 посик публичного ID




                        Курсор_ИщемПУбличныйIDКогдаегоНетВстатике =
                                new MODEL_synchronized(getApplicationContext()).КурсорУниверсальныйДляБазыДанных("SuccessLogin",
                                        new String[]{"id"}, " id IS NOT NULL", null, null, null, "date_update", "1");//
                        /////////
                        if( Курсор_ИщемПУбличныйIDКогдаегоНетВстатике!=null && Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount()>0){
                            ///
                            Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.moveToFirst();
                            ////
                            Log.d(this.getClass().getName(), " Курсор_ИщемПУбличныйIDКогдаегоНетВстатике " + Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount());

                         ПубличныйIDДляСлужбы =Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getInt(0);


                            // TODO: 20.05.2021

                            if (ПубличныйIDДляСлужбы>0) {

                                PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID=    String.valueOf(ПубличныйIDДляСлужбы);
                            }

                        }
            Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.close();

                        Log.d(this.getClass().getName(), "   ПубличныйIDДляСлужбы " +  ПубличныйIDДляСлужбы);




                    ////TODO сам курсор универсальный
          Курсор_УниверсальныйdВнутри = CREATE_DATABASE.ССылкаНаСозданнуюБазу.rawQuery( "SELECT * FROM notification WHERE user_update="+ ПубличныйIDДляСлужбы,
                            null); //todo включен dictict

if(Курсор_УниверсальныйdВнутри!=null && Курсор_УниверсальныйdВнутри.getCount()>0){
    Курсор_УниверсальныйdВнутри.moveToFirst();
}

                    //    Курсор_Универсальный[0] = CREATE_DATABASE.ССылкаНаСозданнуюБазу.query(таблица, колонки, фильтр, условияфильтра, групировка, хэвинг, ордербай, лимиты); //todo включен dictict
                    /////НАЗВАНИЕ ПОТОКА

                    Log.i(this.getClass().getName(), "НАЗВАНИЕ ПОТОКА В aSYNSTASK " + Thread.currentThread().getName().toUpperCase()
                            + " Курсор_Универсальный строчки :   " + Курсор_УниверсальныйdВнутри.getCount()
                            + " Курсор_Универсальный колонки  : " + Курсор_УниверсальныйdВнутри.getColumnCount() + "  таблица " + таблица);
////
                } catch (Exception e) {///////ошибки
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(MODEL_synchronized.class.getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   КлассВставкиОшибок(getApplicationContext()).MessageBoxErrorFile(e.toString(), MODEL_synchronized.class.getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    if (mNotificationManager!=null) {
                        mNotificationManager.cancelAll();
                    }
                }

return  Курсор_УниверсальныйdВнутри;

    }




























}