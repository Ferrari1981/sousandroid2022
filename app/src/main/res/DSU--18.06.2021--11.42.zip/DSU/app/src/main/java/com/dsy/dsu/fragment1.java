package com.dsy.dsu;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;


public class fragment1 extends ListFragment   implements AdapterView.OnItemClickListener  {

    // TODO: Rename parameter arguments, choose names that match

    View view;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment1_layout, container, false);
        ////

        ///
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Log.d(this.getClass().getName(), "  onClick  MyWorkОбновлениеПО СЛУЖБА  " + view.getId());
            }
        });

        return  view;
    }

    @Override
    public void onActivityCreated(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        ///
        //String[] data={"1","2"};


        LinkedHashMap<String,String> hashMapчат=new LinkedHashMap<>();

        hashMapчат.put("1" ,"Первый");
        ///
        hashMapчат.put("2" ,"Второй");
        ///



        LinkedList<HashMap<String,String >> ДанныеДляФрагмента=new LinkedList<>();
        ///

        SimpleAdapter simpleAdapter=new SimpleAdapter(getActivity(),ДанныеДляФрагмента,R.layout.simple_for_chats,new String[]{"First Line","Second Line"}, new int[]{R.id.text1,R.id.text2});

        /**
         * итертор
         */
        Iterator iteratorДляЧата=hashMapчат.entrySet().iterator();

        ///
        while (iteratorДляЧата.hasNext()) {
            ///
            LinkedHashMap<String,String> hashMapчатВнутри=new LinkedHashMap<>();
            ////
            Map.Entry ХэшВременный=(Map.Entry) iteratorДляЧата.next();
            ///
            hashMapчатВнутри.put("First Line",ХэшВременный.getKey().toString());
            ///
            hashMapчатВнутри.put("Second Line",ХэшВременный.getValue().toString());
            ///
            ДанныеДляФрагмента.add(hashMapчатВнутри);
        }


        setListAdapter(simpleAdapter);
        ///
        getListView().setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        Log.d(this.getClass().getName(), " onItemClick MyWorkОбновлениеПО СЛУЖБА  " + view.getId());


        Toast.makeText(getActivity(),
                "Фрагмент НОМер 1  "    , Toast.LENGTH_SHORT).show();

    }
}