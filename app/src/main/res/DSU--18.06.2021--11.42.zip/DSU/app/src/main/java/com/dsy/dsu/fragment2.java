package com.dsy.dsu;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;


public class fragment2 extends ListFragment implements AdapterView.OnItemClickListener {

    // TODO: Rename parameter arguments, choose names that match
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment2_layout, container, false);
        ///
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Log.d(this.getClass().getName(), "  onClick  MyWorkОбновлениеПО СЛУЖБА  " + view.getId());
            }
        });

        return view;
    }


    @Override
    public void onActivityCreated(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        ///
        String[] data={"3","4"};

        ///
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_list_item_1,
                data

        );

        setListAdapter(arrayAdapter);
        ///
    getListView().setOnItemClickListener(this);



    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


        Log.d(this.getClass().getName(), " onItemClick MyWorkОбновлениеПО СЛУЖБА  " + view.getId());

        Toast.makeText(getActivity(),
                "Фрагмент НОМер 2  "    , Toast.LENGTH_SHORT).show();
    }
}