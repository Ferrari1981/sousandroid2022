package com.dsy.dsu;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Broadcasts_Широковещательный_приемник extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        ////

        try {

            Log.i(this.getClass().getName(), " Внутри Broadcatrecever (intent.getAction()   СЛУЖБА" +(intent.getAction().toString())+" время запуска  " +new Date());

            // TODO: 18.04.2021 запувскает широковещатель
            if (intent.getAction().equals(Intent.ACTION_SCREEN_ON) || intent.getAction().equals(Intent.ACTION_SYNC) ||
                    intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED) ||
                    intent.getAction().equals(Intent.ACTION_LOCKED_BOOT_COMPLETED) ||
                intent.getAction().equals(Intent.ACTION_SCREEN_OFF)
                    || intent.getAction().equals(Intent. ACTION_REBOOT)) {
                ///
                Log.i(this.getClass().getName(), " Внутри Broadcatrecever (intent.getAction()   СЛУЖБА" +(intent.getAction().toString()));





                // TODO: 07.10.2021

               PendingResult pendingResult=goAsync();
               /////


///////////////////
                try {


                    // TODO: 29.09.2021  запуск двух лужб из бродкастера

                    МетодЗапускаСинхоронизацииИзШироковещательногоПриёмника(context);
                    /////


                    МетодЗапускаСлужбВШировоВещятелеУведомления(context);



                        Log.i(context.getClass().getName(), "ЗАПУСК   BroadcastReceiver  СЛУЖБА  ВНУТРИ     public_contentДляШироковещятельногоПриемника.МенеджерПотоков.submit(()-> {   "
                                +new Date() + " СТАТУС WORKMANAGER уведомления-----------"
                                +WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation")+"\n"+
                                "  " +
                                " СТАТУС WORKMANAGER  синхронизация -----------"
                                +WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data"));


                    // TODO: 07.07.2021
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new   Class_Generation_Errors(context.getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                            this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());;

                    Log.e(context.getClass().getName(), " Стоп СЛУЖБА  onReceive onDestroy() Exception "+" ::"+e.toString());


                } finally {


   ///   todo
                    pendingResult.finish();

                    // TODO: 22.04.2021  srart JOBschedele
                    Log.d(this.getClass().getName(), "ВЫХОД ПОСЛЕ ОТРАБОТКИ СЛУЖБА ВНУТРИ startService   Вещятеля BroadcastReceiver" +
                            "  Synchronizasiy_Data pendingIntent    "+ " СТАТУС WORKMANAGER уведомления-----------"
                            +WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation")+
                            " СТАТУС WORKMANAGER  синхронизация -----------"
                            +WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data"));

                }
                /////

            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(context.getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());;
            Log.e(context.getClass().getName(), "  catch (Exception e) Стоп СЛУЖБА  onReceive onDestroy() Exception "+" ::"+e.toString());


        }


    }

















































    private void МетодЗапускаСинхоронизацииИзШироковещательногоПриёмника(Context context) {
        try{
        Log.i(context.getClass().getName(), "ЗАПУСК из BroadcastReceiver СЛУЖБА СЛУЖБА  Synchronizasiy_Data  doWork WorkManager Synchronizasiy_Data время "
                +new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data"));


        Constraints constraintsСинхронизация= new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresCharging(false)
                .setRequiresBatteryNotLow(false)
                .setRequiresStorageNotLow(false)
                .build();
        ///

          String ИмяСлужбыСинхронизации="WorkManager Synchronizasiy_Data";

            PeriodicWorkRequest periodicWorkRequestСинхронизация=new PeriodicWorkRequest.Builder(MyWork_Async_Синхронизация_Общая.class,30,  TimeUnit.MINUTES)//MIN_PERIODIC_FLEX_MILLIS
                .setConstraints(constraintsСинхронизация)
                //    .setInputData(new Data.Builder().putString("КтоЗапустилWorkmanager","BroadCastRecieve").build())
                .addTag(ИмяСлужбыСинхронизации)
                .build();


// Queue the work
        WorkManager.getInstance(context.getApplicationContext()).enqueueUniquePeriodicWork(ИмяСлужбыСинхронизации, ExistingPeriodicWorkPolicy.REPLACE, periodicWorkRequestСинхронизация);
        // WorkManager.getInstance().enqueue(periodicWorkRequest);// workmanager.enqueueUniquePeriodicWork(TAG, ExistingPeriodicWorkPolicy.KEEP, photoCheckWork)




            Log.i(context.getClass().getName(), "После Запуска из  BroadcastReceiver  СЛУЖБА Synchronizasiy_Datas ПОСЛЕ doWork  Synchronizasiy_Dataя время "
                    +new Date() + " СТАТУС WORKMANAGER-----------" +WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data")+
                    "\n"+
                    WorkManager.getInstance(context.getApplicationContext()).getWorkInfoByIdLiveData(periodicWorkRequestСинхронизация.getId())+" \n"+
                    " periodicWorkRequestСинхронизация.getId()" +periodicWorkRequestСинхронизация.getId());





// TODO: 23.04.2021  запуск синхронизации
        //////////
    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(context.getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        Log.e(context.getClass().getName(), " Стоп из BroadcastReceiver  СЛУЖБА Service_Notificatios_Уведомления в BroadCasrReciver onDestroy() Exception "+e.toString());


    }

}













    // TODO: 02.04.2021 метод запуска службы из BroadCastas


    private void МетодЗапускаСлужбВШировоВещятелеУведомления(Context context ) {




        try{


            Log.i(context.getClass().getName(), "ЗАПУСК из BroadcastReceiver СЛУЖБА СЛУЖБАService_Notifications doWork  MyWork_Notifocations_Уведомления время "
                    +new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation"));


            Constraints constraintsУведомления= new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                    .setRequiresCharging(false)
                    .setRequiresBatteryNotLow(false)
                    .setRequiresStorageNotLow(false)
                    .build();
///
            ///
String ИмяСлужбыУведомления="WorkManager NOtofocation";

            PeriodicWorkRequest periodicWorkRequestУведомления=new PeriodicWorkRequest.Builder(MyWork_Notifocations_Уведомления.class,40,  TimeUnit.MINUTES)//MIN_PERIODIC_FLEX_MILLIS
                    .setConstraints(constraintsУведомления)
                    .addTag(ИмяСлужбыУведомления)
                    //.setInputData(new Data.Builder().putString("КтоЗапустилWorkmanager","BroadCastRecieve").build())
                    .build();



// Queue the work
            WorkManager.getInstance(context.getApplicationContext()).enqueueUniquePeriodicWork(ИмяСлужбыУведомления, ExistingPeriodicWorkPolicy.REPLACE, periodicWorkRequestУведомления);


            // WorkManager.getInstance().enqueue(periodicWorkRequest);// workmanager.enqueueUniquePeriodicWork(TAG, ExistingPeriodicWorkPolicy.KEEP, photoCheckWork);



            Log.i(context.getClass().getName(), "После Запуска из  BroadcastReceiver  СЛУЖБА СЛУЖБАService_Notifications ПОСЛЕ doWork  MyWork_Notifocations_Уведомления время "
                    +new Date() + " СТАТУС WORKMANAGER-----------" +WorkManager.getInstance(context.getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation")+"\n"+
                    WorkManager.getInstance(context.getApplicationContext()).getWorkInfoByIdLiveData(periodicWorkRequestУведомления.getId())+" \n"+
                    "periodicWorkRequestУведомления.getId()" +periodicWorkRequestУведомления.getId());


            // TODO: 23.04.2021 jobs



            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(context.getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());;

            Log.e(context.getClass().getName(), " Стоп из BroadcastReceiver  СЛУЖБА Service_Notificatios_Уведомления в BroadCasrReciver onDestroy() Exception "+e.toString());


        }







    }





























/*    private void МетодЗапускаJOBВШироковещательном_Применике(Context context) {
        try{
        ComponentName componentName = new ComponentName(context, JobMyService.class);
        JobInfo info = new JobInfo.Builder(1,componentName)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED) // change this later to wifi
                .setPersisted(true)
                .setPeriodic(900000)
                .build();

        JobScheduler scheduler = (JobScheduler)context.getSystemService(JOB_SCHEDULER_SERVICE);
        int resultCode = scheduler.schedule(info);
        if (resultCode==JobScheduler.RESULT_SUCCESS) {
            Log.d(this.getClass().getName()," СЛУЖБА JOb JOb Scheduled");
        } else {
            Log.d(this.getClass().getName()," СЛУЖБА JOb Job Scheduling fail");
        }



/////////

    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }*/


}