package com.dsy.dsu;

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.os.Build;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Iterator;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;

import javax.crypto.NoSuchPaddingException;

public class Class_Clears_Tables {

    Context contextДляКлассаОчисткиТаблиц;
//

    Class_Async_Background class_async_backgroundГдеНаходитьсяМенеджерПотоков=null;

    CREATE_DATABASE Create_Database_СсылкаНАБазовыйКласс;

    public Class_Clears_Tables(Context context) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {

        contextДляКлассаОчисткиТаблиц = context;
        //


        class_async_backgroundГдеНаходитьсяМенеджерПотоков=new Class_Async_Background(contextДляКлассаОчисткиТаблиц);

        ////


        Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextДляКлассаОчисткиТаблиц);


    }
    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ

    protected Integer ОчисткаТаблицДляПользователяЗапусксFaceApp(Context context, CompletionService МенеджерПотоковВнутрений)
            throws ExecutionException, InterruptedException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
        Integer РезультатДобавленияДатыВерсииПослеУдаления=0;
        try {
            ////
            Class_GRUD_SQL_Operations  class_grud_sql_operationsОчистакаталиц = new Class_GRUD_SQL_Operations(context);

            //   ССылкаНаСозданнуюБазу.yieldIfContendedSafely();
          /*  ОчисткаТаблицысЗаписьюВMODIFITATION_Client("errordsu1",true);
            ОчисткаТаблицысЗаписьюВMODIFITATION_Client("successlogin",true);
            ОчисткаТаблицысЗаписьюВMODIFITATION_Client("settings_tabels",true);*/
// TODO: 09.09.2021 просто очистка таблиц
            // TODO: 19.03.2021 просто очистка таблиц без дат
            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("errordsu1");//

            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("successlogin");

            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("settings_tabels");

            // TODO: 19.03.2021 разниза в том что таблицы ниже участвуют при обменен и им нужно устанивть пепрвоначальные даты после очистки


    /*        ОчисткаТаблицысЗаписьюВMODIFITATION_Client("tabels",false);
            ОчисткаТаблицысЗаписьюВMODIFITATION_Client("notifications",false);
            ОчисткаТаблицысЗаписьюВMODIFITATION_Client("date_work",false);
            ОчисткаТаблицысЗаписьюВMODIFITATION_Client("fio_template",false);
            ОчисткаТаблицысЗаписьюВMODIFITATION_Client("templates",false);
            ОчисткаТаблицысЗаписьюВMODIFITATION_Client("chats",false);
            ОчисткаТаблицысЗаписьюВMODIFITATION_Client("data_chat",false);*/

            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("tabel");//
            ////
            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("data_tabels");//

            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("notifications");

            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("date_work");

            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("fio_template");

            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("templates");

            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("chats");

            class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.offer("data_chat");

            // TODO: 19.03.2021 разниза в том что таблицы ниже участвуют при обменен и им нужно устанивть пепрвоначальные даты после очистки


            Iterator<String> iteratorДляТаблицУдаления = class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.iterator();
            ////
            // TODO: 09.09.2021 loop

            while (iteratorДляТаблицУдаления.hasNext()) {
                ////
                String текущаяТаблицаДляУдваления = (String) iteratorДляТаблицУдаления.next();


                // TODO: 09.09.2021 DELETE УДАЛЕНИЕ ТАБЛИЦ ПЕРЕД УМЕНЫ ПОЛЬЗОВАТЕЛЯ

                // TODO: 09.09.2021 DELETE УДАЛЕНИЕ ТАБЛИЦ ПЕРЕД УМЕНЫ ПОЛЬЗОВАТЕЛЯ

                Integer РезультатУдалениеДанных=      ОчисткаТаблицысЗаписьюВMODIFITATION_Client(текущаяТаблицаДляУдваления.trim(),context,МенеджерПотоковВнутрений);
                //
                Log.d(this.getClass().getName(), "РезультатУдалениеДанных " + РезультатУдалениеДанных);
                //
                // TODO: 09.09.2021  действие второе добалянеим дату


                if (РезультатУдалениеДанных>0) {

                    РезультатДобавленияДатыВерсииПослеУдаления=           МетодПослеУдаленияДобавляемДатуВерсии(текущаяТаблицаДляУдваления.trim(),МенеджерПотоковВнутрений);
                    //
                    Log.d(this.getClass().getName(), "РезультатДобавленияДатыВерсииПослеУдаления " + РезультатДобавленияДатыВерсииПослеУдаления);


                    ////

                    class_grud_sql_operationsОчистакаталиц.БлокирующаяОчереть.peek();

                    // TODO: 09.09.2021 выидываем отработаную названия таблицы
                    ;
                }

            }


        } catch (SQLException e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new Class_Generation_Errors(contextДляКлассаОчисткиТаблиц).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }

        return РезультатДобавленияДатыВерсииПослеУдаления;
    }


    // TODO: 09.09.2021 delete data for tabels
    protected Integer ОчисткаТаблицысЗаписьюВMODIFITATION_Client(String ИмяТаблицы,Context context
            ,CompletionService МенеджерПотоковВнутрений) throws ExecutionException, InterruptedException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
//
        Integer РезультатУдалениеОчисткиТаблиц = 0;



        try {
            //
            Log.d(this.getClass().getName(), "  ИмяТаблицы " + ИмяТаблицы);
            // TODO: 09.09.2021 первое ДЕЙСТВИЕ УДАЛЕНИЕ ТАБЛИЦЫ
Class_GRUD_SQL_Operations class_grud_sql_operationclass_grud_sql_operationsОчисткаsОчистакаталиц=new Class_GRUD_SQL_Operations(context);

            // TODO: 06.09.2021  ПАРАМЕНТЫ ДЛЯ удаление данных

            class_grud_sql_operationclass_grud_sql_operationsОчисткаsОчистакаталиц.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы", ИмяТаблицы);
            //

     /*   class_grud_sql_operationsОчистакаталиц.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("Флаг_ЧерезКакоеПолеУдаление", arrayListСтобцыДляУдаления.get(i)+" IS NULL");
            ///

            class_grud_sql_operationsОчистакаталиц.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ЗнакФлагУдаление","=");*/




            ///TODO РЕЗУЛЬТАТ ОБНОВЛЕНИЕ ДАННЫХ


            РезультатУдалениеОчисткиТаблиц = (Integer) class_grud_sql_operationclass_grud_sql_operationsОчисткаsОчистакаталиц.
                    new DeleteData(contextДляКлассаОчисткиТаблиц).deletedata(class_grud_sql_operationclass_grud_sql_operationsОчисткаsОчистакаталиц.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                    МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

            ///
            ///
            Log.d(context.getClass().getName(), " РезультатУдалениеОчисткиТаблиц" + "--" + РезультатУдалениеОчисткиТаблиц);/////



    /*        // TODO: 09.09.2021   __old

            ССылкаНаСозданнуюБазу.execSQL("delete from " + ИмяТаблицы+"");
*/

        } catch (SQLException e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new Class_Generation_Errors(contextДляКлассаОчисткиТаблиц).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }
        return РезультатУдалениеОчисткиТаблиц;
    }





    // TODO: 09.09.2021  метод добалвние в таблице даты

    Integer МетодПослеУдаленияДобавляемДатуВерсии(String ИмяТаблицы,CompletionService МенеджерПотоковВнутрений) {


        Integer ДобавлениеДатыПослеУдалниеТаблиц = 0;

        try {

            ContentValues contentValuesОчисткаТаблицДобавлениеДат = new ContentValues();
            ///
            contentValuesОчисткаТаблицДобавлениеДат.put("localversionandroid", "1900-01-10 00:00:00");
            ///
            contentValuesОчисткаТаблицДобавлениеДат.put("versionserveraandroid", "1900-01-10 00:00:00");

            contentValuesОчисткаТаблицДобавлениеДат.put("localversionandroid_version", 0);
            ///
            contentValuesОчисткаТаблицДобавлениеДат.put("versionserveraandroid_version", 0);






            //////TODO вторым флагом запрещем при первом запуске заниматься обновдениям  только вставка  при синхронизации ==false значить обнолвение включено ,,,,,
            // ЗНАЧАЕТ ЧТО ИДЕТ ТОЛЬКО ВСТАВКА ДАННЫХ TRUE
            //   if (     finalФлагПриПервомЗапускеОграничитьОперациюТолькоВставка == true ) {

            Class_GRUD_SQL_Operations  class_grud_sql_operationsПослеУдаленияДобавляемДатуВерсии=new Class_GRUD_SQL_Operations(contextДляКлассаОчисткиТаблиц);
            ///TODO ОБНОЛВЕНИЕ

            // TODO: 06.09.2021  ПАРАМЕНТЫ ДЛЯ ОБНОВЛЕНИЯ

            class_grud_sql_operationsПослеУдаленияДобавляемДатуВерсии.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","MODIFITATION_Client");
            //

            class_grud_sql_operationsПослеУдаленияДобавляемДатуВерсии.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("Флаг_ЧерезКакоеПолеОбновлением","name");

            ///
            //

            class_grud_sql_operationsПослеУдаленияДобавляемДатуВерсии.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ЗначениеФлагОбновления",ИмяТаблицы);
            ///

            //

            class_grud_sql_operationsПослеУдаленияДобавляемДатуВерсии.
                    concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ЗнакФлагОбновления","=");

            ////TODO КОНТЕЙНЕР ДЛЯ ОБНОВЛЕНИЯ

            class_grud_sql_operationsПослеУдаленияДобавляемДатуВерсии.contentValuesДляSQLBuilder_Для_GRUD_Операций.putAll(contentValuesОчисткаТаблицДобавлениеДат);



            ///TODO РЕЗУЛЬТАТ ОБНОВЛЕНИЕ ДАННЫХ


            ДобавлениеДатыПослеУдалниеТаблиц= (Integer)  class_grud_sql_operationsПослеУдаленияДобавляемДатуВерсии.
                    new UpdateData(contextДляКлассаОчисткиТаблиц).updatedata(class_grud_sql_operationsПослеУдаленияДобавляемДатуВерсии. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                    class_grud_sql_operationsПослеУдаленияДобавляемДатуВерсии.contentValuesДляSQLBuilder_Для_GRUD_Операций,
                    МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());



            Log.d(this.getClass().getName(), " сработала ...  обнуление версии в MODIFITATION_Client для таблицы " + ИмяТаблицы+
                    " ДобавлениеДатыПослеУдалниеТаблиц  " +ДобавлениеДатыПослеУдалниеТаблиц);




            // TODO: 09.09.2021   ___old

            ////////
            //   long ОчисткаТаблиц=ССылкаНаСозданнуюБазу.update("MODIFITATION_Client", contentValuesОчисткаТаблиц, "name=?", new String[]{ИмяТаблицы}); ////вставка данных имя и пароль

   /*         ОчисткаТаблиц = new    ();
            ОчисткаТаблиц.setTables("MODIFITATION_Client");

*/
/*            /////////////
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ОчисткаТаблиц =    ОчисткаТаблиц.
                        update(ССылкаНаСозданнуюБазу, contentValuesОчисткаТаблиц, "name=?", new String[]{ИмяТаблицы});
            } else {

                ОчисткаТаблиц = ССылкаНаСозданнуюБазу.update("MODIFITATION_Client", contentValuesОчисткаТаблиц, "name=?", new String[]{ИмяТаблицы});
            }


            if (ОчисткаТаблиц > 0) {
                Log.d(this.getClass().getName(), " сработала ...  обнуление версии в MODIFITATION_Client для таблицы " + ИмяТаблицы);

            }*/

        } catch (SQLException | ExecutionException | InterruptedException e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new Class_Generation_Errors(contextДляКлассаОчисткиТаблиц).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }
        ///////
        return ДобавлениеДатыПослеУдалниеТаблиц;
    }
}