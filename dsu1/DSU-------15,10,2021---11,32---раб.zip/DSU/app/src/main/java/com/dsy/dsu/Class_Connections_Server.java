package com.dsy.dsu;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteCursor;
import android.util.Log;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

import javax.crypto.NoSuchPaddingException;

public class Class_Connections_Server  extends  Class_GRUD_SQL_Operations {

    Context contextДляКлассаКоннеткСервер;
    //
    Class_GRUD_SQL_Operations class_grud_sql_operations=null;

    public Class_Connections_Server(Context context) {
        super(context);

        contextДляКлассаКоннеткСервер=context;
///////

        ////
        class_grud_sql_operations=new Class_GRUD_SQL_Operations(contextДляКлассаКоннеткСервер);

    }
    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ



















    ///////// TODO ПРОВЕРЯЕТ ЕСЛИ ПОДКЛЧБЕНИ В ИНТРЕНТУ
    boolean МетодПингаСервераРаботаетИлиНет( @NotNull Context КонтекстКоторыйДляСинхронизации)
            throws ExecutionException, InterruptedException, TimeoutException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {

 
Class_GRUD_SQL_Operations class_grud_sql_operationsПингаСервераРаботаетИлиНет=new Class_GRUD_SQL_Operations(КонтекстКоторыйДляСинхронизации);

        //TODO конец выполения кода через Callble  , отправляем его в главный менеджер пОТОКОВ
        final boolean[] результатПрозвонаСокетом = {false};



        class_grud_sql_operationsПингаСервераРаботаетИлиНет. ЛистДляGRUDопераций=new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                ////


                //todoВТОРАЯ ЧАСТЬ ПИНГА

                // TODO: 02.09.2021  сам код
                try {

                    ///
                    System.out.println("УниверсальнайМетодПроверкиПодключениекWIFI ");

                 Map<String,Integer> concurrentHashMapАдресаПодключенияКСерверу= Collections.synchronizedMap(new LinkedHashMap());
                    //
                    String ИмяСервера=new String();
                    //
                    Integer ИмяПорта=0;


                    /////
                    //concurrentHashMapАдресаПодключенияКСерверу.put("169.254.52.68", 8080);
                    ////todo ТОЛЬКО КОГДА НЕ ОТЛАДКА



                        concurrentHashMapАдресаПодключенияКСерверу.put("tabel.dsu1.ru", 8888);//TODO FALSE  ЭТО  РЕЛИЗ



                        ///
                        /////TODO тест режим
                       // concurrentHashMapАдресаПодключенияКСерверу.put("192.168.254.40", 8080);




                    // TODO: 26.08.2021 loop ping

                    for (Map.Entry<String, Integer> СодержимоеHashMapАдресаПодключенияКСерверу : concurrentHashMapАдресаПодключенияКСерверу.entrySet()) {

                        ИмяСервера=    СодержимоеHashMapАдресаПодключенияКСерверу.getKey();


                        ИмяПорта=     СодержимоеHashMapАдресаПодключенияКСерверу.getValue();


                        Log.d(MODEL_synchronized.class.getName()," ИмяСервера"+ ИмяСервера+" ИмяПорта "+ИмяПорта);

                        /////todo код ping ip
                        // InetAddress АдресПрозвонаСайтаПриВходеВПРОграмму=null;
                        //АдресПрозвонаСайтаПриВходеВПРОграмму= InetAddress.getByName("www.google.com"); //"http://192.168.254.40:8080/dsu1.glassfish/DSU1JsonServlet"; //www.google.com
                        // Log.d(MODEL_synchronized.class.getName() ," addr.getHostAddress() "+  АдресПрозвонаСайтаПриВходеВПРОграмму.getHostAddress());
                        // if (!АдресПрозвонаСайтаПриВходеВПРОграмму.getHostAddress().equalsIgnoreCase("::") && АдресПрозвонаСайтаПриВходеВПРОграмму.getHostAddress().length()>0) {

                        //  }
                        /////todo код ping ip второйвариант
                        try {

                            Socket socket = new Socket();

                            SocketAddress socketAddress = new InetSocketAddress(ИмяСервера, ИмяПорта); //"http://192.168.254.40:8080/dsu1.glassfish/DSU1JsonServlet"; //"216.58.212.131"//80.66.149.58///tabel.dsu1.ru   //8888

                            socket.connect(socketAddress, 1000);


                            ///
                            //socket.close();

                       /* String    Adress_String="http://tabel.dsu1.ru:8888/dsu1.glassfish/DSU1JsonServlet";
                        ///
                        Adress_String = Adress_String.replace(" ", "%20");


                        URL Adress = null;
                        Adress = new URL(Adress_String);

                   HttpURLConnection     ПодключениеКСерверуЧерезБелыйАдрес = (HttpURLConnection) (Adress).openConnection();/////САМ ФАЙЛ JSON C ДАННЫМИ
                        ПодключениеКСерверуЧерезБелыйАдрес.setReadTimeout(1000); //todo САМ ТАЙМАУТ ПОДКЛЮЧЕНИЕ(1000);
                        ПодключениеКСерверуЧерезБелыйАдрес.setConnectTimeout(1000);//todo САМ ПОТОК ДАННЫХ(1000);
                        ПодключениеКСерверуЧерезБелыйАдрес.setUseCaches(true);

                        ПодключениеКСерверуЧерезБелыйАдрес.connect();*/


                            ////////////////////////////

                            // TODO: 24.07.2021  ДОПОЛНИТЕЛЬНАЯ ПРОВЕРКА РАБОТАЕ ЛИ СЕРВЕР В МЕСТЕ С ДАННЫМИ


                            StringBuffer БуферРезуоотатРаботыБазыВсестеССервером =
                                    new Class_Get_Status_Works_SERVER(КонтекстКоторыйДляСинхронизации).
                                            УниверсальныйБуферПолучениеРезультатаРаботаетЛиСерверНаСамомДелеВместесБазойДанных(ИмяСервера,ИмяПорта);



                            // TODO: 02.09.2021
                            Log.d(MODEL_synchronized.class.getName(), " PUBLIC_CONTENT.БуферРезуоотатРаботыБазыВсестеССервером " +
                                    БуферРезуоотатРаботыБазыВсестеССервером.toString());

                            ///////////////////
                            if (БуферРезуоотатРаботыБазыВсестеССервером.toString().toCharArray().length >= 1) {

                                // TODO: 30.07.2021  статус чтосервер рабоатет и реально ест ьданные в базе через метод doHEAD

                                // TODO: 02.08.2021 устанавливаем флаг что работает

                                результатПрозвонаСокетом[0] = true;
                                ////

                                String СтрокаСвязиСсервером ="http://"+ИмяСервера+":"+ИмяПорта+"/";;

                                СтрокаСвязиСсервером = СтрокаСвязиСсервером.replace(" ", "%20");
                                ///
                                Log.d(this.getClass().getName(), " СтрокаСвязиСсервером " +СтрокаСвязиСсервером);


                               /// PUBLIC_CONTENT.ПубличныйАдресGlassFish =СтрокаСвязиСсервером;/// "http://tabel.dsu1.ru:8888/"; //http://80.66.149.58:8888 //8181 ///РЕЖИМ НАСТОЯЩИЕ РАБОТЫ ПРИЛОЖЕНИЯ "http://80.66.149.58:8888/dsu1.glassfish/DSU1JsonServlet";
                                //


                                //TODO ФУТУРЕ ЗАВЕРШАЕМ
                                Log.d(this.getClass().getName(), "   СтрокаСвязиСсервером "+  СтрокаСвязиСсервером);

                                break;
                            }


                            Log.d(MODEL_synchronized.class.getName(), "  БуферРезуоотатРаботыБазыВсестеССервером.toString() " + БуферРезуоотатРаботыБазыВсестеССервером.toString());
                            ///TODO определяем какой вид подкобченеи mobile and wifi

                        } catch (IOException e) {

                            //todo  ФЛАГ  РЕЗУЛЬТАТ  ПИНГА СЕРВЕРА
                            результатПрозвонаСокетом[0] = false;

                        }


                    }
                    //////////
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    // TODO: 01.09.2021 метод вызова
                    new   Class_Generation_Errors(КонтекстКоторыйДляСинхронизации).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                            this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());



                    //todo  ФЛАГ  РЕЗУЛЬТАТ  ПИНГА СЕРВЕРА
                    результатПрозвонаСокетом[0] = false;
                    ////TODO ВТОРАЯ ПРОВЕРКА

                    Log.e(КонтекстКоторыйДляСинхронизации.getClass().getName(), " ОШИБКА ПРИ ПОДКЛЮЧЕНИ ЯК СЕРВЕРУ " + e.toString());


                }

                    // TODO: 29.09.2021

                    // TODO: 29.09.2021  проверяем равны ли выбранный режим с режимо выбранным пользователм

                //
                return результатПрозвонаСокетом[0];
            }
        };

        // TODO: 02.09.2021  EXE ПОСЫЛАЕМ НА ВЫПОЛЕНИЯ
















        // TODO: 12.10.2021  Ссылка Менеджер Потоков

        PUBLIC_CONTENT class_async_backgroundГдеНаходитьсяМенеджерПотоков =new PUBLIC_CONTENT(contextСозданиеБАзы);


   boolean     РезультатПрозвонаСокетом=    (boolean)   class_grud_sql_operationsПингаСервераРаботаетИлиНет
           .new ClassRuntimeExeGRUDOpertions(contextДляКлассаКоннеткСервер).МетодЗапускаОперацийGRUD_exe(class_grud_sql_operationsПингаСервераРаботаетИлиНет. ЛистДляGRUDопераций,
           class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков);

        ///
        Log.d(contextДляКлассаКоннеткСервер.getClass().getName(), " РезультатПрозвонаСокетом " + РезультатПрозвонаСокетом);





        return результатПрозвонаСокетом[0];
    }










}
