package com.dsy.dsu;

import static java.sql.Types.NULL;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObservable;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.androidnetworking.interfaces.OkHttpResponseAndJSONObjectRequestListener;
import com.google.gson.JsonObject;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.acl.Group;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Spliterator;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;
import java.util.function.ToDoubleBiFunction;
import java.util.stream.Stream;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

;import okhttp3.Call;
import okhttp3.EventListener;
import okhttp3.OkHttpClient;


//////-------TODO  ЭТО ПЕРВЫЙ КОНТРОЛЛЕР КОТОРЫЙ ВИЗУАЛИЗИРУЕТ СИНХРОНИЗАЦИЮ С ПРОГРАССБАРОМ---------------------------------------------------------------


///TODO------------------------------------------------------ ЭТО  ВТОРОЙ КОНТРОЛЛЕР КОТОРЫЙ ЗАПУСКАЕТ СИНХРОНИЗАЦИЮ В ФОНЕ  (ВНУТРИ ПРИЛОЖЕНИЕ)---------------------------------------------------


class Class_Async_Background extends MODEL_synchronized {

     Context КонтекстСинхроДляКонтроллераВФоне;

      Activity ActivityДляСинхронизацииОбмена;

   Integer ПубличныйРезультатОтветаОтСерврераУспешно=0;


   Integer СколькоСтрочекJSON;

  Float ФиналПроценты = 0f;

    public int УспешноеКоличествоВставокДанныхсСервера;

    public int УспешноеКоличествоОбновлениеДанныхсСервера;

LinkedBlockingQueue<String> ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧат=new LinkedBlockingQueue();
         ;
    /////////////


    ///
   // PUBLIC_CONTENT public_contentДатыДляГлавныхТаблицСинхронизации=new PUBLIC_CONTENT(contextСозданиеБАзы);


    CREATE_DATABASE       Create_Database_СсылкаНАБазовыйКласс;

    PUBLIC_CONTENT public_contentДатыДляГлавныхТаблицСинхронизации;


  String КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал=new String();



    Boolean UUIDПолеУжеПроверелиЧерезКурсор=false;
    ///
    Boolean IDПолеУжеПроверелиЧерезКурсор=false;




/*    SQLiteCursor Курсор_УзнатьЕслиНаАндройдеТакойUUID = null;/// ТУТ ОН ЗАПОНИМАЕНТ ПОСЛЕНИЙ UUID НА СТРОЙКИ

    SQLiteCursor Курсор_УзнатьЕслиНаАндройдеТакойID = null;*/

    boolean ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА = false;

    ///
    String ФлагКакуюЧастьСинхронизацииЗапускаем =new String();

    //TODO версия данных с сервера

    Long РезультатВерсииДанныхЧатаНаСервере=0l;


    // TODO: 08.09.2021  КЛАСС СИНХРОНИАЗЦИИ ФОНОВОЙ



    ContentValues АдаптерПриОбновленияДанныхсСервера=null;


    ///TODO  INSERT КОНТЕЙНЕРЫ
    ContentValues   АдаптерДляВставкиДанныхсСервер=null;


    Integer ИндексТекущейОперацииJSONДляВизуальнойОбработки=1;


    // TODO: 26.08.2021  МЕНЕДЖЕР ПОТОКВ ДЛЯ GRUD ОПЕРАЦИЙ





    public Class_Async_Background(@NotNull Context context) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
        super(context);
        ////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК

        ////todo
        // TODO: 13.10.2021  подключение к БАЗЕ ДАННЫХ  анных делаем одно без многих NEW


        Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextСозданиеБАзы);

        // TODO: 13.10.2021  подключение к  МЕНЕДЖЕРУ ПОТОКОВ делаем одно без многих NEW

        public_contentДатыДляГлавныхТаблицСинхронизации=new PUBLIC_CONTENT(contextСозданиеБАзы);




        ////// TODO созданеи шифрование
        if (ГлавныйКлючДляШифрованиеИРасшифровки == null) {

            //TODO ключ для шифрование и расщифровки

            byte[] CipherKey = "[C@3841f624[B@6415a86b[B@143c678".getBytes();

           ГлавныйКлючДляШифрованиеИРасшифровки =
                    new SecretKeySpec(CipherKey,
                            "AES");
          ПолитикаШифрование = Cipher.getInstance("AES");

           ПолитикаШифрование.init(Cipher.ENCRYPT_MODE, ГлавныйКлючДляШифрованиеИРасшифровки);
            ///////
           ПолитикаРасшифровки = Cipher.getInstance("AES");

            ПолитикаРасшифровки.init(Cipher.DECRYPT_MODE, ГлавныйКлючДляШифрованиеИРасшифровки);
            ///// конец шифрование
        }
        ////// конец  TODO созданеи шифрование
    }


    // TODO метод запуска СИНХРОНИЗАЦИИ  в фоне

// TODO: 19.08.2021  ДАННЫЙ МЕТОД ЗАПУСКАЕТ СИНХРОНИЗЦИ ДЛЯ ЧАТА


    // TODO метод запуска СИНХРОНИЗАЦИИ  в фоне
    protected Integer МетодЗАпускаФоновойСинхронизации(@NotNull Context contextПриШелИзАктивтиКоторомуНужнаСинхронизация,
                                                                                         String КтоЗарустилСинхронизацию,
                                                  boolean ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТАвнутри,
                                                                                         Activity ActivityДляСинхронизацииОбменаВнутри,
                                                  LinkedBlockingQueue ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧатПришелОтФрагмнтаИлиАктивти,
                                                     String  КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная,Integer СколькоСтрочекJSON) throws InterruptedException {
        //
        /////

        Integer      ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизациивнутри = 0;
        //

        try{

        //
            ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧат=
                    ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧатПришелОтФрагмнтаИлиАктивти;


            Log.i(this.getClass().getName(), "ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧат "
                    + ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧат+
                    " ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧатПришелОтФрагмнтаИлиАктивти  "
                    +ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧатПришелОтФрагмнтаИлиАктивти);



            /////TODO ПЕРЕОПРЕДЕЛЯЕМ КОНТЕКСТ С РАБОТАЮЩЕГО АКТИВТИ ДЛЯ ИНХРОНИЗАЦИИ
            if (contextПриШелИзАктивтиКоторомуНужнаСинхронизация != null) {
                ////
                КонтекстСинхроДляКонтроллераВФоне = contextПриШелИзАктивтиКоторомуНужнаСинхронизация;
                ///
            } else {
                Log.e(this.getClass().getName(), " Ошибка нет Конкеста  ЗАПУСК ФОНОВОЙ СИНХРОНИЗАЦИИ ....." + new Date());

            }

            Log.d(this.getClass().getName(), "ЗАПУСК ФОНОВОЙ СИНХРОНИЗАЦИИ ....." + new Date());
//              ////////

            ActivityДляСинхронизацииОбмена=ActivityДляСинхронизацииОбменаВнутри;

/////
            ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных

            Log.d(this.getClass().getName(), "ActivityДляСинхронизацииОбмена....." + ActivityДляСинхронизацииОбмена);

            /////



            ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизациивнутри=         МетодСамогоФоновойСинхронизации(КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная,
                    ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧат,СколькоСтрочекJSON);


                        Log.d(this.getClass().getName(), " ФОНОВАЯ СИНХОРОНИЗАЦИИИ ИДЁТ... СЛУЖБА ");

            Log.d(this.getClass().getName(), "ТРЕТЬЯ... ФОНОВАЯ СЛУЖБА КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ/И ОБНОВЛЕНИЙ " + ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизациивнутри);








            // TODO: 08.09.2021  clear after async

            /////TODO ПОСЛЕ  СИНХРОНИЗАЦИЕЙ ОБНУЛЯЕМ КОЛИЧЕСТВО СТРОК JSON ОБЩЕЕ  , ПЕРЕД ПОЛУЧЕНИЕМ НОВОГО ЗНАЧЕНИЯ
            ///PUBLIC_CONTENT.СколькоСтрочекJSON = 0;
            /////TODO ПОСЛЕ  СИНХРОНИЗАЦИЕЙ синхронизации по всем таблицам обнулем общее количество успешных вставко и обновлений



            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        /////


        return ОбщегоКоличесвоУспешныхВставкоИЛИОбновлениеФоновойСинхронизациивнутри;
    }


    // TODO: 25.09.2021 ВТОРАЯ ВЕСРИЯ ЗАПУСКА СИНХРОНМИАЗЦИИИ С ТАБЕЛЯ































// TODO: 19.08.2021  ДАННЫЙ МЕТОД ЗАПУСКАЕТ СИНХРОНИЗЦИ ДЛЯ ЧАТА


    // TODO метод запуска СИНХРОНИЗАЦИИ  в фоне
    protected Integer МетодЗАпускаФоновойСинхронизацииВторойВариантЗапускаемИзТабеля(
           Context contextПриШелИзАктивтиКоторомуНужнаСинхронизация,
                                                    String КтоЗарустилСинхронизацию,
                                                    boolean ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТАвнутри,
              Activity ActivityДляСинхронизацииОбменаВнутри,
                                                    String ФлагКакуюЧастьСинхронизацииЗапускаемВнутри,
                                                    String  КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная,
    String ФлагПослеСинхрониазцииПоказываемВыплывающееСообщение) throws InterruptedException {
        //
        final Integer[] РезультатЗапускВизуальнойСинхронизации = {0};


                PUBLIC_CONTENT public_contentДляСинхрониазхцииНеБлокирующейВызываемЕгоКогдаСходимСТАбеляИВсехСотрудников=new PUBLIC_CONTENT(contextСозданиеБАзы);

                try{
                //////

            // TODO: 28.09.2021  ЗАПУСКАЕМ СИНХРОНИАЗЙИИЮ С АЬБЕЛЯ
                ////////
                    public_contentДляСинхрониазхцииНеБлокирующейВызываемЕгоКогдаСходимСТАбеляИВсехСотрудников.  МенеджерПотоков.submit(()->{

                // TODO: 27.09.2021  start

                try{


                    // TODO: 01.07.2021  ЗАПУСКАЕМ ВИЗУАЛЬНУЮ СИНХРОНИЗИЦИЮ С АКТИВТИ ЧДЕ КРУТИТЬСЯ ПРОГРЕСС БАР


              РезультатЗапускВизуальнойСинхронизации[0] =
                            new Class_Async_Background(ActivityДляСинхронизацииОбменаВнутри).
                                    МетодЗАпускаФоновойСинхронизации(ActivityДляСинхронизацииОбменаВнутри,
                                            "СинхронизацияДляЧата", false, ActivityДляСинхронизацииОбменаВнутри, public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда,
                                            КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная,СколькоСтрочекJSON);  //TODO третить параментр false --указывает что обработка всех таблиц кроме чата



                    Log.d(this.getClass().getName(), "  РезультатЗапускВизуальнойСинхронизации[0]"
                            + РезультатЗапускВизуальнойСинхронизации[0] );


                    ///////
            } catch (Exception e) {
                //  Block of code to handle errors
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                // TODO: 01.09.2021 метод вызова
                new Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                        this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
            }finally {


                    ///
                    public_contentДляСинхрониазхцииНеБлокирующейВызываемЕгоКогдаСходимСТАбеляИВсехСотрудников.МенеджерПотоков.poll();
                    ///todo

                    //if (ФлагПослеСинхрониазцииПоказываемВыплывающееСообщение.equalsIgnoreCase( "ПоказыватьПослеСинхрониазцииСообщениеВыплывающее")) {
                    ////
                    ActivityДляСинхронизацииОбменаВнутри.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //

                            Log.d(this.getClass().getName(), "  СЛУЖБА  ИЗ ТАБЕЛЯ ЛИСТА  ЗАПУСТИЛИ ИЗ FACEAPP ФиналРезультатСинхроиназцииЗапускаЧСтрогоИзТабеляВнутри[0] "
                                    + РезультатЗапускВизуальнойСинхронизации[0] );


                            //Toast.makeText(ActivityДляСинхронизацииОбменаВнутри, " Обмен Данными ▲ ▼  кол: " + ФиналРезультатСинхроиназцииЗапускаЧСтрогоИзТабеляВнутри[0], Toast.LENGTH_LONG).show();

                            Toast toast=       Toast.makeText(ActivityДляСинхронизацииОбменаВнутри, null, Toast.LENGTH_LONG);

                            toast.setText(" Обмен Данными ▲ ▼  кол: " +РезультатЗапускВизуальнойСинхронизации[0] );



                            Vibrator v3 = (Vibrator) ActivityДляСинхронизацииОбменаВнутри.getSystemService(Context.VIBRATOR_SERVICE);
                            //
                            if (РезультатЗапускВизуальнойСинхронизации[0] ==0) {

                                // Vibrate for 500 milliseconds
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    v3.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE));
                                } else {
                                    //deprecated in API 26
                                    v3.vibrate(200);
                                }
                            } else {


                                // Vibrate for 500 milliseconds
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    v3.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
                                } else {
                                    //deprecated in API 26
                                    v3.vibrate(300);
                                }
                            }


                            toast.setGravity(Gravity.BOTTOM,0,40);

                            toast.show();

                            // TODO: 08.09.2021  clear after async


                            //}

                            /////TODO ПОСЛЕ  СИНХРОНИЗАЦИЕЙ ОБНУЛЯЕМ КОЛИЧЕСТВО СТРОК JSON ОБЩЕЕ  , ПЕРЕД ПОЛУЧЕНИЕМ НОВОГО ЗНАЧЕНИЯ
                            ///PUBLIC_CONTENT.СколькоСтрочекJSON = 0;
                            /////TODO ПОСЛЕ  СИНХРОНИЗАЦИЕЙ синхронизации по всем таблицам обнулем общее количество успешных вставко и обновлений

                        }
                    });

                }

            ////
                // TODO: 27.09.2021  end


                return  РезультатЗапускВизуальнойСинхронизации[0] ;
            });


            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        /////

        return  РезультатЗапускВизуальнойСинхронизации[0] ;
    }




























































































// TODO: 08.09.2021 НИЖЕ НАЧИНАЮТЬСЯ МЕТОДЫ САМОЙ ФОНОВОЙ СИНХРОНИАЗЦИИ ВНИМАНИЕ !!!!!!!
// TODO: 08.09.2021 НИЖЕ НАЧИНАЮТЬСЯ МЕТОДЫ САМОЙ ФОНОВОЙ СИНХРОНИАЗЦИИ ВНИМАНИЕ !!!!!!!
// TODO: 08.09.2021 НИЖЕ НАЧИНАЮТЬСЯ МЕТОДЫ САМОЙ ФОНОВОЙ СИНХРОНИАЗЦИИ ВНИМАНИЕ !!!!!!!
    // TODO: 08.09.2021 НИЖЕ НАЧИНАЮТЬСЯ МЕТОДЫ САМОЙ ФОНОВОЙ СИНХРОНИАЗЦИИ ВНИМАНИЕ !!!!!!!
// TODO: 08.09.2021 НИЖЕ НАЧИНАЮТЬСЯ МЕТОДЫ САМОЙ ФОНОВОЙ СИНХРОНИАЗЦИИ ВНИМАНИЕ !!!!!!!
    // TODO: 08.09.2021 НИЖЕ НАЧИНАЮТЬСЯ МЕТОДЫ САМОЙ ФОНОВОЙ СИНХРОНИАЗЦИИ ВНИМАНИЕ !!!!!!!
















    ///TODO САМ ФОНОВЫЙ ПОТОК МЕТОД

    Integer МетодСамогоФоновойСинхронизации(String КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная,
                                            LinkedBlockingQueue ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧат,Integer СколькоСтрочекJSONВнутри) {


        String ТекущаяТаблицаДляОБменаДанными = null;

        ////TODO уставналиваем констанку что метод onStart запускалься только один раз

        Integer ФинальныйРезультаФоновойСинхрониазции=0;
        //
        Class_GRUD_SQL_Operations class_grud_sql_operationsМетодСамогоФоновойСинхронизации=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);



        ///
        try {


            СколькоСтрочекJSON=  СколькоСтрочекJSONВнутри;


            // TODO: 01.05.2021 запускаем если все активти невидны спущены вниз*/

            Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА ВНУТРИ startService   Вещятеля BroadcastReceiver  Synchronizasiy_Data " + new Date() +
                    "\n" + " Build.BRAND " + Build.BRAND.toString()+"  СколькоСтрочекJSONВнутри " +СколькоСтрочекJSONВнутри+ " СколькоСтрочекJSON " +СколькоСтрочекJSON);


            ////TODO ТОЛЬКО ПРИ НАЛИЧИИ ИНТРЕНТА  !!!!!!!!!!!!!!!! ЗАПУСК СИНХРОНИЗАЦИИ


 ////
                    Long финальныйРезультаФоновойСинхрониазции=0l;


                    //////TODO ШАГ ТРЕТИЙ  ЗАПУСКАЕМ САМУ СИНХРОНИЗАЦИЮ  сама синхронизация в фоне
            ФинальныйРезультаФоновойСинхрониазции =            МетодНачалоСихронизациивФоне(КонтекстСинхроДляКонтроллераВФоне,КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная); ////Получение Версии Данных Сервера для дальнейшего анализа


                    //todo нет json ля вситавки

                    ///TODO ЗАПУСКАЕМ СРАЗУ МЕТОД ONSTOP В ASYNTASKLOADER ПОТОМУ ЧТО НЕТ ИНТРЕНТА И НЕТ СМЫСЛА ДЕЛАТЬ СИНХРОНИЗАЦИЮ
                   // финальныйРезультаФоновойСинхрониазции =           МетодПослеФононовойСинхроигзации();

                    Log.d(this.getClass().getName(), " ФОНОВАЯ СЛУЖБА КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ/И ОБНОВЛЕНИЙ  ФинальныйРезультаФоновойСинхрониазции " +
                            ПубличныйРезультатОтветаОтСерврераУспешно +  "  ФинальныйРезультаФоновойСинхрониазции " +ФинальныйРезультаФоновойСинхрониазции);



// TODO: 08.09.2021  exe запус синхрониазции в потоке


          /*  ФинальныйРезультаФоновойСинхрониазции=
                    (Long) class_grud_sql_operationsМетодСамогоФоновойСинхронизации.new ClassRuntimeExeGRUDOpertions(contextСозданиеБАзы).
                            МетодЗапускаОперацийGRUD_exe(class_grud_sql_operationsМетодСамогоФоновойСинхронизации.ЛистДляGRUDопераций);*/



            Log.d(this.getClass().getName(), " ФОНОВАЯ СЛУЖБА КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ/И ОБНОВЛЕНИЙ  ФинальныйРезультаФоновойСинхрониазции " +
                    ФинальныйРезультаФоновойСинхрониазции);

/*
           LinkedTransferQueue linkedTransferQueue=new LinkedTransferQueue();
            linkedTransferQueue.transfer(class_grud_sql_operationsМетодСамогоФоновойСинхронизации.ЛистДляGRUDопераций);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                linkedTransferQueue.parallelStream().sorted().forEachOrdered((GG)-> {

                });
            }

          ConcurrentHashMap linkedHashMap=new ConcurrentHashMap();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                linkedHashMap.keySet().stream().sorted().forEachOrdered((Data)->{

                    /////


                });
            }*/


            /////////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

     return ФинальныйРезультаФоновойСинхрониазции;
    }


























//////ПЕРВЫЙ МЕТОД ОБМЕНА ДАННЫМИ С СЕРВЕРОМ МЕТОД GET

    Integer МетодНачалоСихронизациивФоне(@NotNull Context context, String КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная) throws InterruptedException, ExecutionException, TimeoutException, JSONException {

        Integer результатСинхрониазции=0;

        try {
            ////////todo ОБНУЛЯЕМ КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ ИЛИ ОБНОВЛЕНИЙ

            ////TODO ДАННЫЙ ЦИКЛ НУЖЕН ПЕРВЫЙ ШАГОМ ВЫ ВСТАВЛЯЕМ ДАННЫЕ ЕСЛИ ОНИ ЕСТЬ , А ВТОРЫМ ШАГОМ И ИХ ДОГОНЯЕМ ОБНОВЛЕМ ДАННЫЕ ВОТ ТАК  ДЛЯ СИНХРОНИЗАЦИИ

            //// TODO САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ В ФОНЕ
            результатСинхрониазции=     МетодПолучениеIDотСервераДляГеренированиеUUID(КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная); ////САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ///// TODO ГЛАВНЫЙ МЕТОД ОБМЕНА ДАНЫМИ  НА АКТИВИТИ FACE_APP


            ///////////////////////////////
            if(результатСинхрониазции==null){

                ////
                результатСинхрониазции=0;
            }

            Log.d(this.getClass().getName(), " результатСинхрониазции"
                    + результатСинхрониазции);

            ///todo конец финал обрабоатываем обновлениея
            ///todo конец финал обрабоатываем обновлениея

            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

        /////////////////
     return    результатСинхрониазции;
    }













    // TODO: 13.10.2021 нАЧАЛО сИНХРОНИАЗЦИИ

    Integer МетодПолучениеIDотСервераДляГеренированиеUUID(String КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная) throws JSONException, InterruptedException, ExecutionException, TimeoutException {
        ///
        String ДанныеПришёлЛиIDДЛяГенерацииUUID = new String();


        //
        Integer РезультатСинхрониазции=0;
        /////
        try {
            Log.d(this.getClass().getName(), " public   void МетодПолучениеIDОтСервераДляГеренированиеUUID ()" + " ДанныеПришёлЛиIDДЛяГенерацииUUID " + ДанныеПришёлЛиIDДЛяГенерацииUUID +
                    " ДанныеПришёлЛиIDДЛяГенерацииUUID.length()  " + ДанныеПришёлЛиIDДЛяГенерацииUUID.length());

            StringBuffer БуферПолучениеДанных = new StringBuffer();


                    //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
            БуферПолучениеДанных =
                            УниверсальныйБуферПолучениеДанныхсСервера("", "", "", "application/text", "Хотим Получить ID для Генерации  UUID", 0l, "",10000,null,0l,"tabel.dsu1.ru", 8888); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position



            ///////
            if (БуферПолучениеДанных != null && БуферПолучениеДанных.toString().toCharArray().length > 0) {
                ///////

                Log.w(this.getClass().getName(), "  БуферПолучениеДанных.toString()  " + БуферПолучениеДанных.toString());


                do {
                    ДанныеПришёлЛиIDДЛяГенерацииUUID = БуферПолучениеДанных.toString();
                    //
                    Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID  " + ДанныеПришёлЛиIDДЛяГенерацииUUID);




                    //////TODO ПРИСВАИВАЕМ ПОЛУЧЕННЫЙ ID ПУБЛИЧНЫЙ
                   ПубличноеIDПолученныйИзСервлетаДляUUID =Integer.parseInt( БуферПолучениеДанных.toString()); ///ИЗ ОТВЕТА ПОЛУЧАЕМ ID ПОЛЬЗОВАТЕЛЯ ДЛЯ ГЕНЕРАЦИИ  UUID//





                    ///
                    ///todo если мы прошли один раз и нет данных выходим
                    if (ДанныеПришёлЛиIDДЛяГенерацииUUID.length() == 0) {
                        break;
                    }
                } while (ДанныеПришёлЛиIDДЛяГенерацииUUID.length() == 0);/////конец for # количество респонсев
                //////
                Log.d(this.getClass().getName(), "  ПубличноеIDПолученныйИзСервлетаДляUUID  " + ПубличноеIDПолученныйИзСервлетаДляUUID);
                ////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК


                if (ДанныеПришёлЛиIDДЛяГенерацииUUID != null) {
                    ///
                    if (ДанныеПришёлЛиIDДЛяГенерацииUUID.length() > 0) {//ЕСЛИ МЫ ПОЛУЧИЛИ ID  и СОЗДАЛИ НА ЕГО БАЗЕ UUID ТО ПРОХОДИИМ К СЛЕДУЮЩЕМУ КОДУ ПОЛУЧАЕМ ВЕРСИЮ ДАННЫХ СЕРВВЕРА


                        // TODO: 29.03.2021 записываем полученный пуюдтичны ID
                        Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID  " + ДанныеПришёлЛиIDДЛяГенерацииUUID.length());


                        ////TODO создаем списко таблиц запускаем слуд.ющий метод получение версии базы данных
                 РезультатСинхрониазции=        МетодПолучениеСпискаТаблицДляОбменаДанными(ДанныеПришёлЛиIDДЛяГенерацииUUID,КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная);//получаем ID для генерирования UUID
//
                        if(РезультатСинхрониазции==null){
                            //
                            РезультатСинхрониазции=0;
                        }


                        Log.d(this.getClass().getName(), " Данных нет c сервера  РезультатСинхрониазции  "+РезультатСинхрониазции);

                    }
                }


                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера  ");
            }
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
return  РезультатСинхрониазции;
    }

    ///////////////////метод получение ОТ СЕРВЕРА КОНКРЕТНЫЙ СПИСОК ТАДОИЦЦ ДЛЯ ОБМЕНА

























    ////////////МЕТОД ПОЛУЧЕНИЕ  ВЕРСИИ ДАННЫХ
    Integer МетодПолучениеСпискаТаблицДляОбменаДанными(@NotNull String ДанныеПришёлЛиIDДЛяГенерацииUUID,
                                                    String КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная) throws JSONException, InterruptedException, ExecutionException, TimeoutException {///второй метод получаем версию данных на СЕРВЕР ЧТОБЫ СОПОЧТАВИТЬ ДАТЫ

        Log.d(this.getClass().getName(), " ДанныеПришёлЛиIDДЛяГенерацииUUID" + ДанныеПришёлЛиIDДЛяГенерацииUUID);

        String ДанныеПришлаСпискаТаблицДляОбмена = new String();

        StringBuffer БуферПолученияСпискаТАблицДляОбмена = new StringBuffer();


        Class_GRUD_SQL_Operations class_grud_sql_operations;
        ///
        class_grud_sql_operations = new Class_GRUD_SQL_Operations(contextСозданиеБАзы);

       Integer результатСинхронизациииФинал=0;

        ////TODO ПОСЛЕ ОБРАБОТКИ ТАБЛИЦ ОБНУЛЯЕМ


        try {


            ///

            //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
            БуферПолученияСпискаТАблицДляОбмена = УниверсальныйБуферПолучениеДанныхсСервера("view_data_modification", "", "", "application/json",
                    "Хотим Получить Версию Данных Сервера", 0l, ДанныеПришёлЛиIDДЛяГенерацииUUID, 10000, null, 0l,"tabel.dsu1.ru", 8888); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position

            Log.d(this.getClass().getName(), " БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length " + БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length);


            // TODO: 03.09.2021


            if (БуферПолученияСпискаТАблицДляОбмена != null) {
                ////
                if (БуферПолученияСпискаТАблицДляОбмена.toString().toCharArray().length > 3) {


                    do {

                        ДанныеПришлаСпискаТаблицДляОбмена = БуферПолученияСпискаТАблицДляОбмена.toString();

                        //////
                        БуферПолученияСпискаТАблицДляОбмена.append(ДанныеПришлаСпискаТаблицДляОбмена).append("\n");

                        Log.d(this.getClass().getName(), " ДанныеПришлаЛиВерсияДанныхсСервера " + ДанныеПришлаСпискаТаблицДляОбмена);


                    } while (ДанныеПришлаСпискаТаблицДляОбмена == null);/////конец for # количество респонсев
                    /////


                    Log.d(this.getClass().getName(), "  ПубличноеIDПолученныйИзСервлетаДляUUID  " + ПубличноеIDПолученныйИзСервлетаДляUUID +
                            " БуферПолученияСпискаТАблицДляОбмена " + БуферПолученияСпискаТАблицДляОбмена.toString());
                    ////
                    /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                    /////////
                    ///ПОЛУЧЕННЫЙ СПИСОК ЗАПИСЫВАЕМ В ТАБЛИЦУ НАШУ ПЕРЕРМЕННЦУЮ
                    JSONObject ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента = new JSONObject(БуферПолученияСпискаТАблицДляОбмена.toString());///упаковываем в j
                    ///
                    JSONArray МассивJSONТаблиц = ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.names();

                    String НазваниеИзПришедшихТаблицДляКлиента;

                    String СодержимоеИзПришедшихТаблицДляКлиента;

                    String JSONСтрочка;

                    String JSONНазваниеСтолбика;

                    String JSONСодержимоеСтолика;

                    Long JSONСодержимоеСтоликаДляХэша=0l;
                    /////ЦИКЛ КРУТИТЬ JSON


                    public_contentДатыДляГлавныхТаблицСинхронизации.     ДатыТаблицыВерсииДанныхОтСервера=Collections.synchronizedMap(new LinkedHashMap<String, Long>());

                    // TODO: 11.10.2021

                    public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда.clear();

                    /////ЦИКЛ КОТРЫЙ БЕЖИТ ПО СТОРОКА ПРИГЕДШЕГО JSON ФАЙЛА И НАХОДИМ НАЩШИ ТАЮЛИЦЫ ДЛЯ УКАЗАННОГО ПОЛЬЗОВАТСЯ
                    for (int ИндексТаблицыДляДанногоКлиента = 0; ИндексТаблицыДляДанногоКлиента < ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.names().length(); ИндексТаблицыДляДанногоКлиента++) {
                        ////// распарсиваем  josn
                        НазваниеИзПришедшихТаблицДляКлиента = МассивJSONТаблиц.getString(ИндексТаблицыДляДанногоКлиента);

                        СодержимоеИзПришедшихТаблицДляКлиента = ОбьектыJSONТаблицыПришлиКонктетоНаЭтогоКлиента.getString(НазваниеИзПришедшихТаблицДляКлиента); // Here's

                        JSONObject ОбьектJSON = new JSONObject(СодержимоеИзПришедшихТаблицДляКлиента);

                        JSONСтрочка = String.valueOf(ОбьектJSON.names());


                        /////ЦИКЛ КОТРЫЙ БЕЖИТ ПО СТОЛБЦАМ  ПРИГЕДШЕГО JSON ФАЙЛА И НАХОДИМ НАЩШИ ТАЮЛИЦЫ ДЛЯ УКАЗАННОГО ПОЛЬЗОВАТСЯ
                        for (int ИндексТаблицыДляДанногоКлиентаСтолбцы = 0; ИндексТаблицыДляДанногоКлиентаСтолбцы < ОбьектJSON.length(); ИндексТаблицыДляДанногоКлиентаСтолбцы++) {

                            JSONНазваниеСтолбика = String.valueOf(ОбьектJSON.names().get(ИндексТаблицыДляДанногоКлиентаСтолбцы));

                            JSONСодержимоеСтолика = ОбьектJSON.getString(JSONНазваниеСтолбика);

                            ///ЗАПОЛНЯЕМ ТОЛЬКО НАЗВАНИЯ ТАБЛИЦ  ПРЕДНАЗВАНЧЕН ТОЛЬКО ДЛЯ ДАННГО ПОЛЬЗОВАТЕЛЯ ТАБЛИЦЫ ПО КОТОРЫМ БУДЕТ ОБМЕН
                            ///todo вытаскмваем название таблиц для заполения таблицы модификейшен клеинта на андройде

                            if (JSONНазваниеСтолбика.equalsIgnoreCase("ИМЯ ИЗ МОДИФИКАЦИИ СЕРВЕР")) {////&& !JSONСодержимоеСтолика.equalsIgnoreCase("fio")///&& !JSONСодержимоеСтолика.equalsIgnoreCase("fio")

                                ////////TODO ЗАПОЛНЯЕМ АРАЙЛИСТ ЗНАЧЕНИЯ НАЗВАНИЕ ТАБЛИЦ ДЛЯ ОБРАБОТКИ
                                ////
                                public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда.put(JSONСодержимоеСтолика); //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ

                                Log.d(this.getClass().getName(), " JSONСодержимоеСтолика " + JSONСодержимоеСтолика);


                            }



                            /////А ТУТ МЫ ПРОСТО ЗАПОМИНАЕМ НАЗВАНИЕ ТАБЛИЦ С СЕРВЕРА  И ПЛЮС ИХ ДАТЫ ПОСЛЕДНЕГО ИЗМЕНЕНИЕ ДАННЫХ НА ДАННЫХ ТАБЛИЦАХ НА СЕРВЕРЕ
                            if (JSONНазваниеСтолбика.equalsIgnoreCase("ИМЯ ИЗ МОДИФИКАЦИИ СЕРВЕР")) {
                                //////ОТДЕЛЬНО ДляХэшМап
                                JSONСодержимоеСтоликаДляХэша = ОбьектJSON.getLong("ТЕКУЩАЯ ВЕРСИЯ  ТАБЛИЦЫ");/////ТОЛЬКО ДЛЯ HSMAP///"ДАТА ВЕРСИИ СЕРВЕРА"

                                public_contentДатыДляГлавныхТаблицСинхронизации.ДатыТаблицыВерсииДанныхОтСервера.put(JSONСодержимоеСтолика,JSONСодержимоеСтоликаДляХэша); ///// ЗАПОЛНЯЕМ ХЭШМАП ДЛЯ КРНКРЕТНОГО ПОЛЬЗОВАТЕЛЯ ТАБЛИЦ ДЛЯ ТОЛЬКО СЕСИИ

                                Log.d(this.getClass().getName(), " JSONСодержимоеСтолика " + JSONСодержимоеСтолика + "  JSONСодержимоеСтоликаДляХэша  " + JSONСодержимоеСтоликаДляХэша+
                                        "   PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.size() " + public_contentДатыДляГлавныхТаблицСинхронизации.ДатыТаблицыВерсииДанныхОтСервера.size());



                            }
                            //todo проект имена
                            if (JSONНазваниеСтолбика.equalsIgnoreCase("ПРОЕКТЫ")) {

                                public_contentДатыДляГлавныхТаблицСинхронизации.ИменаПроектовОтСервера.add(JSONСодержимоеСтолика); //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ

                                Log.d(this.getClass().getName(), " ИменаПроектовОтСервера " + public_contentДатыДляГлавныхТаблицСинхронизации.ИменаПроектовОтСервера.toString());
                            }


                            // TODO: 27.09.2021  new modul
                            //todo проект имена
                            if (JSONНазваниеСтолбика.equalsIgnoreCase("ТЕКУЩАЯ ВЕРСИЯ  ТАБЛИЦЫ")) {

                                ////PUBLIC_CONTENT.ИменаПроектовОтСервера.add(JSONСодержимоеСтолика); //////ЗАПОЛЯНЕМ АРАЙЛИСТ НАЗВАНИЕМ ТОЛЬКО ТАБЛИЦ КОТОРЫ ПРИШИ ДЛЯ КОНКТНОГО ПОЛЬЗОВАТЕЛЯ

                                Log.d(this.getClass().getName(), " ИменаПроектовОтСервера " + public_contentДатыДляГлавныхТаблицСинхронизации.ИменаПроектовОтСервера.toString()+  "  JSONНазваниеСтолбика " +JSONНазваниеСтолбика);
                            }





                        }
                    }
                    //////
                    /////
                } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                    Log.d(this.getClass().getName(), " Данных нет c сервера  ");


                }
            }


            Log.i(this.getClass().getName(), " ИменаТаблицыОтАндройда " + public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда.toString() +
                    " ДатыТаблицыВерсииДанныхОтСервера " +public_contentДатыДляГлавныхТаблицСинхронизации.toString() + "  ДанныеПришлаСпискаТаблицДляОбмена " +ДанныеПришлаСпискаТаблицДляОбмена);


            if ( public_contentДатыДляГлавныхТаблицСинхронизации.ДатыТаблицыВерсииДанныхОтСервера.size() > 0  && public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда.size()>0) {//ЕСЛИ МЫ ПОЛУЧИЛИ ID  и СОЗДАЛИ НА ЕГО БАЗЕ UUID ТО ПРОХОДИИМ К СЛЕДУЮЩЕМУ КОДУ ПОЛУЧАЕМ ВЕРСИЮ ДАННЫХ СЕРВВЕРА
                ////запускаем слуд.ющий метод получение версии базы данных
                //// TODO запускам если ОТ СЕРВЕРА ПРИШЛИ  ДАННЫЕ СПИСОК ТАБЛИЦ ДЛЯ СОЗДАНИЕ СПИСК ДЛЯ ПОЛЬЗОВАТЕЯД


                Log.i(this.getClass().getName(), " ДанныеПришлаСпискаТаблицДляОбмена " + ДанныеПришлаСпискаТаблицДляОбмена+ "  PUBLIC_CONTENT.ДатыТаблицыВерсииДанныхОтСервера.size() " +
                        public_contentДатыДляГлавныхТаблицСинхронизации.ДатыТаблицыВерсииДанныхОтСервера.size());





                ////TODO ТОЛЬКО НЕ ДЛЯ АКТИВТИ АНОНИМНЫЙ ОБМЕН БЕЗ ВИЗУАЛИЗАЦИИ СИНХРОНИЗАЦИИ
           результатСинхронизациииФинал=
                  МетодЗапускаемЦиклПоТаблицамДляДанногоПользователя(ДанныеПришёлЛиIDДЛяГенерацииUUID, КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная);

  /////
                if(результатСинхронизациииФинал==null){
                    //////
                    результатСинхронизациииФинал=0;
                }

                Log.i(this.getClass().getName(), " результатСинхронизациииФинал " + результатСинхронизациииФинал);



            }


        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
return  результатСинхронизациииФинал;
    }






    /////TODO МЕТОД ЗАПУСКА ЦИКЛА ПО ПОЛУЧЕННЫСМ ТАБЛИЦ С СЕРВЕРА ДАННЫХ ЦИКЛ FOR


    Integer МетодЗапускаемЦиклПоТаблицамДляДанногоПользователя(String ДанныеПришёлЛиIDДЛяГенерацииUUID,
                                                            String КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная) {//КонтекстСинхроДляКонтроллера


        final Integer[] РезультатОбработкиТекущейтаблицыСинхрониазцииВнутриЦикла = {0};
        try {
            /// ТУТ МЫ ЗАПУСКАЕМ ЦИКЛ С ПОЛУЧЕНЫМИ ДО  ЭТГО ТАБЛИЦАП КОНКРЕТНО ДЛЯ  ЭТОГО ПОДЛЬЗОВАТЛЯ
            Log.i(this.getClass().getName(), " ИменаТаблицыОтАндройда " + public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда.toString()
                    + " ДатыТаблицыВерсииДанныхОтСервера " + public_contentДатыДляГлавныхТаблицСинхронизации.ДатыТаблицыВерсииДанныхОтСервера.toString()+ " СколькоСтрочекJSON " +СколькоСтрочекJSON);
            ////TODO настройки поо расширению количесво потоков в момент выполенния
            ////TODO текущая ТАБЛИЦА ПРИ ОБРАБОТКИ СИНХРОНИЗАЦИИ КОТОРАЯ УВЕЛИЧИВАЕТЬСЯ В ЦИКДЕ ПРИ ОБМЕНЕН
            //////TODO выводими обратно в UI вставка

            /////todo КОНЕЦ цикла фор
            ////////


       //     CountDownLatch countDownLatchДляСинхрониазцииФоновой = new CountDownLatch(countNew);


            if (ActivityДляСинхронизацииОбмена!=null) {
                /////
                ActivityДляСинхронизацииОбмена.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if ( MainActivity_Visible_Async.progressBar3ГоризонтальныйСинхронизации!=null) {
                            /////
                            MainActivity_Visible_Async.progressBar3ГоризонтальныйСинхронизации.setMax(public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда.size());
                        }
                        ///

                    }
                });
            }


            // TODO: 14.10.2021  НАЧИНАЕМ ОБРАБОТКУ ТАБЛИЦ ---ОТ СЕРВЕРА И НА СЕРВЕР josn

//
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {


                Log.i(this.getClass().getName(), "  Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу() " + Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());


                Log.i(this.getClass().getName(), " public_contentМенеджерПотоковВнутрений.МенеджерПотоков " +public_contentДатыДляГлавныхТаблицСинхронизации.МенеджерПотоков);

            /*    //////////todo  ГЛАВНЫЙ МЕНЕДЖЕР ПОТОКОВ ПРОЕКТА
                if (public_contentМенеджерПотоковВнутрений.МенеджерПотоков == null) {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        ///////s
                        public_contentМенеджерПотоковВнутрений.МенеджерПотоков=(CompletionService  )  new ExecutorCompletionService<>(Executors.newWorkStealingPool());
                    }else{

                        public_contentМенеджерПотоковВнутрений.МенеджерПотоков=   (  CompletionService)new ExecutorCompletionService<>(Executors.newCachedThreadPool());   ;
                    }

                    Log.i(this.getClass().getName(), " public_contentМенеджерПотоковВнутрений.МенеджерПотоков " +public_contentМенеджерПотоковВнутрений.МенеджерПотоков);


                }*/



                //
                final Integer[] КоличествоТаблицВОбработке = {1};//




                //////todo ДВИГАЕМСЯ ПО ТАБЛИЦАМ




           ///TODO главный цикл внутри по таблицам   ///TODO главный цикл внутри по таблицам    ///TODO главный цикл внутри по таблицам    ///TODO главный цикл внутри по таблицам    ///TODO главный цикл внутри по таблицам

                public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда.stream().spliterator().forEachRemaining((ТекущаяТаблицаИзПотока)->{


            ////// TODO ГЛАВНЫЙ ПЕРВЫЙ ЦИКЛ ОБМЕНА ДАННЫХ в фоне         //////ГЛАВНЫЙ ПЕРВЫЙ ЦИКЛ ОБМЕНА ДАННЫХ         //////ГЛАВНЫЙ ПЕРВЫЙ ЦИКЛ ОБМЕНА ДАННЫХ



                    ////



                //////
                // TODO: 30.03.2021 синхронизация в фоне


                    Log.d(this.getClass().getName(), " ИменаТаблицыОтАндройда " +public_contentДатыДляГлавныхТаблицСинхронизации. ИменаТаблицыОтАндройда.size() +
                            " ТекущаяТаблицаИзПотока " + ТекущаяТаблицаИзПотока+   " СколькоСтрочекJSON  " +СколькоСтрочекJSON);
                //////

       String           ТекущаяТаблицаДляОБменаДанными = (String) ТекущаяТаблицаИзПотока;


          Boolean ПроверяемТекущаяТаблицаПолученнаяИзЦиклаСинхрониазцииДопущенакОбработке=
                  ФлагОбработкаЧастиТаблицНеВсехЗависимостиОбщаяСинхронизацияЗапущенаИлиТолькоЧат.contains(ТекущаяТаблицаДляОБменаДанными);



                Log.d(this.getClass().getName(), " ТекущаяТаблицаДляОБменаДанными " + ТекущаяТаблицаДляОБменаДанными +
                        " ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА " + ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА +
                        " ПроверяемТекущаяТаблицаПолученнаяИзЦиклаСинхрониазцииДопущенакОбработке "
                        +ПроверяемТекущаяТаблицаПолученнаяИзЦиклаСинхрониазцииДопущенакОбработке);


                // TODO: 21.07.2021только таблицы чата


                // TODO: 21.07.2021 все другие таблицы


                    if (ПроверяемТекущаяТаблицаПолученнаяИзЦиклаСинхрониазцииДопущенакОбработке==true) {



                      РезультатОбработкиТекущейтаблицыСинхрониазцииВнутриЦикла[0] =
                                МетодЗапускаСинхрониазцииПоАТблицам(ДанныеПришёлЛиIDДЛяГенерацииUUID,
                                        ТекущаяТаблицаДляОБменаДанными,КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная,
                                        public_contentДатыДляГлавныхТаблицСинхронизации.МенеджерПотоков,СколькоСтрочекJSON);


                        Log.d(this.getClass().getName(), " ТекущаяТаблицаДляОБменаДанными " + ТекущаяТаблицаДляОБменаДанными +
                                "  ЗАКОНЧИЛИ ОБРАБОТКУ ОТДЕЛЬНОЙ ТАЛИЦЫ  ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА "+
                                ТекущаяТаблицаДляОБменаДанными + " ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА "
                                + ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА+  "  РезультатОбработкиТекущейтаблицыСинхрониазцииВнутриЦикла "
                                + РезультатОбработкиТекущейтаблицыСинхрониазцииВнутриЦикла[0] + " СколькоСтрочекJSON " +СколькоСтрочекJSON);


                        // TODO: 05.10.2021  вторая часть после успешной обработки таблицы увеличиваем версию данных если сешно вставка или обовление


                        // TODO: 05.10.2021  ВИЗУАЛЬАНОЕ ОТОБРАЖЕННИЕ В ПРОГРЕСС БАРЕ
                        // TODO: 05.10.2021  ВИЗУАЛЬАНОЕ ОТОБРАЖЕННИЕ В ПРОГРЕСС БАРЕ
                        Integer finalКоличествоТаблицВОбработке = КоличествоТаблицВОбработке[0];
                        ////
                        if (ActivityДляСинхронизацииОбмена!=null) {
                            ///
                            ActivityДляСинхронизацииОбмена.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    if (    MainActivity_Visible_Async.progressBar3ГоризонтальныйСинхронизации!=null) {
                                        ////
                                        MainActivity_Visible_Async.progressBar3ГоризонтальныйСинхронизации.setProgress(finalКоличествоТаблицВОбработке);
                                    }
                                    ///

                                }
                            });
                        }
                        ///todo текущая таблица
                        КоличествоТаблицВОбработке[0]++;

// TODO: 10.09.2021 выкидываем из ПАМЯТИ ОТРАБОТАННУЮ ТАБЛИЦУ

                        Log.i(this.getClass().getName(), "  PUBLIC_CONTENT.ИменаТаблицыОтАндройда.size()   "+public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда.size());

                        ///////




                        РезультатВерсииДанныхЧатаНаСервере=0l;


                        // TODO: 06.10.2021  таблицы не допущенны к обработке
                    }else{



                        Log.d(this.getClass().getName(), " Не допушена к Обработке ТекущаяТаблицаДляОБменаДанными " + ТекущаяТаблицаДляОБменаДанными +
                                " ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА " + ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА +
                                " ПроверяемТекущаяТаблицаПолученнаяИзЦиклаСинхрониазцииДопущенакОбработке "
                                +ПроверяемТекущаяТаблицаПолученнаяИзЦиклаСинхрониазцииДопущенакОбработке);




                    }


                    // TODO: 10.10.2021 clear from queueu

                    try {


                    public_contentДатыДляГлавныхТаблицСинхронизации.ИменаТаблицыОтАндройда.peek();

                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                            this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }

                });
            }



            /// todo после обработки


            ПубличныйРезультатОтветаОтСерврераУспешно= РезультатОбработкиТекущейтаблицыСинхрониазцииВнутриЦикла[0];

            //РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера = 0;

            Log.i(this.getClass().getName(), "  ПубличныйРезультатОтветаОтСерврераУспешно   "+ПубличныйРезультатОтветаОтСерврераУспешно +
                     "   PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице; " +
        " PUBLIC_CONTENT. ФиналПроценты " +  ФиналПроценты+ " РезультатОбработкиТекущейтаблицыСинхрониазцииВнутриЦикла " + РезультатОбработкиТекущейтаблицыСинхрониазцииВнутриЦикла[0]);



            /// todo после обработки  одной таблицы всех таблиц





        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

        return  РезультатОбработкиТекущейтаблицыСинхрониазцииВнутриЦикла[0];
    }









// TODO: 10.09.2021  запускаем метод обработки по таблицам

     Integer МетодЗапускаСинхрониазцииПоАТблицам(String данныеПришёлЛиIDДЛяГенерацииUUID,  String текущаяТаблицаДляОБменаДанными,String КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная,
                                                 CompletionService МенеджерПотоковВнутрений,Integer СколькоСтрочекJSON) {



        Log.d(this.getClass().getName(), " ТекущаяТаблицаДляОБменаДанными " + текущаяТаблицаДляОБменаДанными);

        boolean ОтветЕслиТакаяТаблицаВнутриОбработкиДляПринятияРешениеНачинатьОбрабткуИлиНет = false;
        //todo sleeep
      Integer   РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера=0;



         try {


                ///TODO сон
                 РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера=0;
                        //////TODO метод обрабтки п таюлицам
      РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера=
              МетодДляАнализаВерсийДанныхПолучаемДатыСервера(текущаяТаблицаДляОБменаДанными, данныеПришёлЛиIDДЛяГенерацииUUID,КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная,
                      МенеджерПотоковВнутрений,СколькоСтрочекJSON); ////Получение Версии Данных Сервера для дальнейшего анализа
                ///todo публикум название таблицы или цифру его
                ///TODO увеличиваем таюлицу оработки
                    if(РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера==null){
                        ////
                        РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера=0;
                    }


                Log.d(this.getClass().getName(), " РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера "
                        + РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера);




            // TODO: 12.08.2021 код повышает или уменьшает верисю данных ПОСЛЕ ОБРАБОТКИ ТАБЛИЦЫ И ДАТЫ



            /////////////////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


// TODO: 23.05.2021


        return РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера;
    }








    // TODO: 12.08.2021  метода повышает версиб данных


     Integer МетодПослеGRUDОперацийПовышаемВерсиюДанных( @NotNull Object ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССервера,
                                                                                  @NotNull  String текущаяТаблицаДляОБменаДанными
             ,String  РежимПовышенияВерсииЛокальнаяСервернаяИлиОба
     ,Long РезультатВерсииДанныхЧатаНаСервере,
                                                         CompletionService МенеджерПотоковВнутрений) {

         Integer    Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы=0;


     try{
     // TODO: 05.09.2021

          Long   ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССерверафИНАЛ= Long.parseLong(String.valueOf(ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССервера));



         Log.i(this.getClass().getName(), "   ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССерверафИНАЛ"
                 +ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССерверафИНАЛ );




         if (ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССерверафИНАЛ>0) {


             Log.i(this.getClass().getName(), "   РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервераПовышаемДатыИВерсииДанных"
                     +ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССервера+
                     " ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССервера"
                     +ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССервера );


             Log.i(contextСозданиеБАзы.getClass().getName(), "   РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера"
                     + ВходящийПараметрПослеУспешнойВсатвкиИлиобвнлденияДаннымиССервера +  "  текущаяТаблицаДляОБменаДанными "+  текущаяТаблицаДляОБменаДанными);


             // TODO: 03.09.2021  получение ПО НОВОМУ ДВИЖКУ
             Class_GRUD_SQL_Operations  classGrudSqlOperationsПовышаемВерсиюДАнных;
             // TODO: 30.08.2021    КОД ОБНОВЛЕНИЕ   ДАННЫХ   ЧЕРЕЗ
             //////
             classGrudSqlOperationsПовышаемВерсиюДАнных=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);
             ///
             classGrudSqlOperationsПовышаемВерсиюДАнных.
                     concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы",текущаяТаблицаДляОБменаДанными.trim());
             ///
             classGrudSqlOperationsПовышаемВерсиюДАнных.
                     concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФлагТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба",РежимПовышенияВерсииЛокальнаяСервернаяИлиОба.trim());///  "ЛокальныйСерверныйОба"    ПОСЛЕ КАК ПРИШЛИ ВНЕШНИЕ ДАННЫЕ
             ///



             if (РезультатВерсииДанныхЧатаНаСервере>0) {
                 ///
                 classGrudSqlOperationsПовышаемВерсиюДАнных.
                         concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба",РезультатВерсииДанныхЧатаНаСервере);///  "ЛокальныйСерверныйОба"    ПОСЛЕ КАК ПРИШЛИ ВНЕШНИЕ ДАННЫЕ
                 ///
             }


             ///TODO РЕЗУЛЬТА изменения версии данных
             Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы= (Integer)  classGrudSqlOperationsПовышаемВерсиюДАнных.
                 new ChangesVesionData(contextСозданиеБАзы).
                     changesvesiondata(classGrudSqlOperationsПовышаемВерсиюДАнных. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());
//

             Log.d(contextСозданиеБАзы.getClass().getName(), "Результат_ПриписиИзменнийВерсииДанныхВФонеПриСменеОрганизации " +Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы );
             ////

             // TODO: 03.09.2021


             ///todo  конец  ДАННЫЙ КОД ИЗМЕНЯЕТ ВЕРИСЮ ДАННЫХ


             Log.w(contextСозданиеБАзы.getClass().getName(), "   Результат_ПриписиИзменнийВерсииДанныхВФоне:"
                     + Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы + " ТекущаяТаблицаДляОБменаДанными " + текущаяТаблицаДляОБменаДанными +
                     " Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы " + Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы);


             // TODO: 11.08.2021  доаолнительные запись ДАННЫХ СЕРВРЕА ПОСЛЕ УСТАВКИ НОВЫХ ДАННЫХ С СЕРВРЕА
         }


         if(Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы==null){
             ////
             Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы=0;
         }

        ///TODO конец повышение версиии
         /////////////////
     } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(contextСозданиеБАзы.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }

return  Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы;

    }











































    ///TODO вычисляем если такая таблиЦА ВНУТРИ БАЗЫ
    private boolean МетодВЫчисляемВсеТаблицыВнутриКлинета(String ТекущаяТаблицаДляОБменаДанными,CompletionService МенеджерПотоковВнутрений) {
        ////
        boolean ЕслиТАкаяТаблица = false;
        ///
        Class_GRUD_SQL_Operations class_grud_sql_operationsВЫчисляемВсеТаблицыВнутриКлинета;
        ///
        SQLiteCursor КурсорВсехТаблицВнутри =null;

        try {
   ///////
            class_grud_sql_operationsВЫчисляемВсеТаблицыВнутриКлинета=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);


            class_grud_sql_operationsВЫчисляемВсеТаблицыВнутриКлинета=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);

            ///
            class_grud_sql_operationsВЫчисляемВсеТаблицыВнутриКлинета. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","sqlite_master");
            ///////
            class_grud_sql_operationsВЫчисляемВсеТаблицыВнутриКлинета. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","name");
            //
            class_grud_sql_operationsВЫчисляемВсеТаблицыВнутриКлинета. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","  type =  ?  ");
            ///"_id > ?   AND _id< ?"
            //////
            class_grud_sql_operationsВЫчисляемВсеТаблицыВнутриКлинета. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1","table");
            ///
        /*            class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......

            ////TODO другие поля*/

            ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
            ////
            //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
            ////
            //// class_grud_sql_operationsВерсииДаныхЧатаДляОтправкиЕгоНАСервер. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
            ////
            /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
            ////



            // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

            КурсорВсехТаблицВнутри= (SQLiteCursor)  class_grud_sql_operationsВЫчисляемВсеТаблицыВнутриКлинета.
                    new GetData(contextСозданиеБАзы).getdata(class_grud_sql_operationsВЫчисляемВсеТаблицыВнутриКлинета. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

            Log.d(this.getClass().getName(), "GetData   " +КурсорВсехТаблицВнутри );


/*

            // TODO: 06.09.2021  _old

            Cursor КурсорВсехТаблицВнутри = ССылкаНаСозданнуюБазу.rawQuery("SELECT name FROM sqlite_master WHERE type = 'table'", null);






*/

            if (КурсорВсехТаблицВнутри.getCount() > 0) {
                ///
                КурсорВсехТаблицВнутри.moveToFirst();
                ////
                Log.d(this.getClass().getName(), "  КурсорВсехТаблицВнутри." + КурсорВсехТаблицВнутри.getCount());

                do {
                    ////
                    String ТаблицаИзБазыТекущей=КурсорВсехТаблицВнутри.getString(0);
                    ///
                    Log.d(this.getClass().getName(), "  ТаблицаИзБазыТекущей." +ТаблицаИзБазыТекущей);
                    //////
                    if (ТекущаяТаблицаДляОБменаДанными.equals(ТаблицаИзБазыТекущей)) {
                        Log.d(this.getClass().getName(), "  ТекущаяТаблицаДляОБменаДанными." + ТекущаяТаблицаДляОБменаДанными +
                                "  КурсорВсехТаблицВнутри.getString(0)) " + КурсорВсехТаблицВнутри.getString(0));

                        ЕслиТАкаяТаблица = true;

                        break;
                    }


                    Log.d(this.getClass().getName(), "  ТекущаяТаблицаДляОБменаДанными." + ТекущаяТаблицаДляОБменаДанными +
                            "  КурсорВсехТаблицВнутри.getString(0)) " + КурсорВсехТаблицВнутри.getString(0));


                } while (КурсорВсехТаблицВнутри.moveToNext());
                ////////
                КурсорВсехТаблицВнутри.close();

            } else {
                Log.d(this.getClass().getName(), "  КурсорВсехТаблицВнутри." + КурсорВсехТаблицВнутри.getCount());
                ЕслиТАкаяТаблица = false;
            }


            ///todo публикум название таблицы или цифру его
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

////
        return ЕслиТАкаяТаблица;
    }






















    /////////////////////ИЩЕМ ДАТУ СЕРВЕРВА
    Integer МетодДляАнализаВерсийДанныхПолучаемДатыСервера(String ТекущаяТаблицаДляОБменаДанными,
                                                           String ДанныеПришёлЛиIDДЛяГенерацииUUID,
                                                           @NotNull String КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная,
                                                           CompletionService МенеджерПотоковВнутрений,Integer СколькоСтрочекJSON)
            throws JSONException, InterruptedException, ExecutionException, TimeoutException {
        //
        Integer  РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера=0;
        //
        КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал=КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторная;

        if (КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал.length()==0) {
            ///

            КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал="ПовторныйЗапускСинхронизации";
        }


///TODO принудительно устанвливаем редим работы синхронизации
        Log.d(this.getClass().getName(), " КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал "+КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал);






        Log.d(this.getClass().getName(), " ДанныеПришёлЛиIDДЛяГенерацииUUID  " + ДанныеПришёлЛиIDДЛяГенерацииUUID + " ТекущаяТаблицаДляОБменаДанными "
                + ТекущаяТаблицаДляОБменаДанными);

        Long Полученная_ВерсияДанныхсSqlServer = 0l;

        JSONObject ОбьектыJSONФайлJSONсСервераВерсияSQlserver = new JSONObject();

        String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных = "";

        String ИмитацияВремяДляПроверки;

        Date ИмитациДатыДляПроверки = null;

        ///////
        String ТесктДатыSqlServer = null;


        try {
/////ТУТ -- КОД АНАЛИЗА ДАННЫХ SQL SERVER  ПРИШЕДШЕЙ ТЕКУЩЕЙ ТАБЛИЦЕ ПОЛУЧАЕМ НАЗВАНИЕ БАЗЫ И К НЕЙ ПОЛУЧАЕМ ДАТУ Е НЕЙ

//анализируем записи и ищем нашут текущаю таблицу и дату к ней
            for (Map.Entry<String, Long> ХэшДляАнализаТекущейТаблицыВерсииДанных : public_contentДатыДляГлавныхТаблицСинхронизации.ДатыТаблицыВерсииДанныхОтСервера.entrySet()) {
                //////
                System.out.println(ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey() + " - " + ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue());

                if (ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey().equalsIgnoreCase(ТекущаяТаблицаДляОБменаДанными)) {///ищем в текущей строчке текущуе название таблицы например CFO==CFO
                    ////записываем в json  получену.юю текущаю названеи табиуви к ней дата ВЕРСИЯ ДАННЫХ
                    /////
                    ОбьектыJSONФайлJSONсСервераВерсияSQlserver.put(ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey(), ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue());
                    /////
                    Log.d(this.getClass().getName(), " ОбьектыJSONФайлJSONсСервераВерсияSQlserver " + ОбьектыJSONФайлJSONсСервераВерсияSQlserver.toString());
                    ////////
                    ////ПЕРЕРДАЕМ ИМЯ ТАБЛИЦЫ ОТ SQL SERVER
                    ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных = ХэшДляАнализаТекущейТаблицыВерсииДанных.getKey();
                    //// ПЕРЕДАЕМ ДАТУ ИЗ ТАБЛИЦЫ ОТ SQL SERVER
                    Полученная_ВерсияДанныхсSqlServer = ХэшДляАнализаТекущейТаблицыВерсииДанных.getValue();


                    Log.d(this.getClass().getName(), " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных" + ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных +
                            "\n" + " Полученная_ВерсияДанныхсSqlServer   " + Полученная_ВерсияДанныхсSqlServer);


         
            ////////
             РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера=0;

            // TODO: 05.10.2021
            Log.d(this.getClass().getName(), " РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера " + РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера+
                    "  Полученная_ВерсияДанныхсSqlServer " + Полученная_ВерсияДанныхсSqlServer);


                    /////////////
       РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера=
               МетодДляВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером(ОбьектыJSONФайлJSONсСервераВерсияSQlserver, Полученная_ВерсияДанныхсSqlServer, ТекущаяТаблицаДляОБменаДанными,
                            ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных, ДанныеПришёлЛиIDДЛяГенерацииUUID,МенеджерПотоковВнутрений,СколькоСтрочекJSON);////метод получение даты версии данных из андройда

                    //


                    Log.d(this.getClass().getName(), " РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера " + РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера+
                             "  Полученная_ВерсияДанныхсSqlServer " + Полученная_ВерсияДанныхсSqlServer);


                    // TODO: 05.10.2021 ЕСЛИ ЛОКАЛЬНАЯ ТАБЛИЦА РАВНА С ТАБЛИЦЕЙ С ССЕРВЕРА ПО НАЗВАНИЮ 

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
        return  РезультаУспешнойВсатвкиИлиобвнлденияДаннымиССервера;
    }










    /////////////////////TODO метод ВЫРАВНИВАНИЯ ТАБЛИЦ МЕЖДУ КЛИЕНТОМ И СЕРВЕРОМ КОЛИЧЕСТВО ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ
    Integer МетодДляВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером(JSONObject ФайлJSONcВерсиейДанныхСервера, Long Полученная_ВерсияДанныхсSqlServer,
                                                                          String ИмяТаблицыОтАндройда_Локальноая,
                                                                          String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                                                                          String ДанныеПришёлЛиIDДЛяГенерацииUUID,CompletionService МенеджерПотоковВнутрений,Integer СколькоСтрочекJSON)
            throws InterruptedException, ExecutionException, TimeoutException {

        //////////
        Integer РезультатУспешнойВсатвкиИлиОбновлениясСервреа=null;

        Log.d(this.getClass().getName(), " ФайлJSONcВерсиейДанныхСервера " + ФайлJSONcВерсиейДанныхСервера.toString());

        JSONObject ОбьектыJSONvalue;

        JSONArray КлючJSONПолей = null;

        Cursor КурсорДляАнализаВерсииДанныхАндройда;

        String ТекстВерсииБазыАндрод = "";
        ////////
        String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;

        Date ДатаВерсииДанныхНаАндройдеЛокальногоОбновления = null;

        String ДатаВерсииДанныхНаАндройдеДляМетодаGET = null;

        Date ДатаВерсииДанныхНаАндройде = null;

        ///
        Class_GRUD_SQL_Operations class_grud_sql_operationsВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);

        try {
            //// #1 РАСПАРСИВАЕМ ПРИШЕДШИЙ JSON С СЕРВРЕА ОТ SQL SERVER
            JSONArray КлючиJSONПолей = ФайлJSONcВерсиейДанныхСервера.names();

            for (int ИндексПолучениеВерсииДанныхАндройда = 0; ИндексПолучениеВерсииДанныхАндройда < ФайлJSONcВерсиейДанныхСервера.names().length(); ИндексПолучениеВерсииДанныхАндройда++) {
                //
                // TODO: 06.09.2021
                String ИмяПоляДляВставкиВАндйрод = КлючиJSONПолей.getString(ИндексПолучениеВерсииДанныхАндройда); // Here's your key

                Log.d(this.getClass().getName(), " ИмяПоляДляВставкиВАндйрод " + ИмяПоляДляВставкиВАндйрод);

                String СодержимоеПоляДляВставкиВАндйрод = ФайлJSONcВерсиейДанныхСервера.getString(ИмяПоляДляВставкиВАндйрод); // Here's your value

                Log.d(this.getClass().getName(), " ЗначениеСтолбикаНазваниеТаблицНаСервере " + ИмяПоляДляВставкиВАндйрод + " ЗначениеСтолбикаВерсииТаблицНаСервере   " +
                        СодержимоеПоляДляВставкиВАндйрод);


                ///todo  new gRUD-enegree
                class_grud_sql_operationsВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером.
                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","MODIFITATION_Client");
                ///////
                class_grud_sql_operationsВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером.
                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","name");
                //
                class_grud_sql_operationsВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером.
                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","  name=? ");
                ///"_id > ?   AND _id< ?"
                //////
                class_grud_sql_operationsВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером.
                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",ИмяПоляДляВставкиВАндйрод);
                ///
        /*            class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......

            ////TODO другие поля*/

                ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
                ////
                //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
                ////
                //// class_grud_sql_operationsВерсииДаныхЧатаДляОтправкиЕгоНАСервер. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
                ////
                /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                ////



                // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

                КурсорДляАнализаВерсииДанныхАндройда= (SQLiteCursor)  class_grud_sql_operationsВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером.
                        new GetData(contextСозданиеБАзы).getdata(class_grud_sql_operationsВырвниванияНазванийТаблицВВерсияДанныхНаКлиентеСсервером. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                Log.d(this.getClass().getName(), "GetData  КурсорДляАнализаВерсииДанныхАндройда  " +КурсорДляАнализаВерсииДанныхАндройда );


/*
                // TODO: 06.09.2021  _old
                ///// #2 ТЕПЕРЬ ПОЛУЧЕНЫЕ ДАННЫЕ А ТОЧНЕЕ НАЗВАНИЕ ТАБЛИЦ ЗАПИСЫВАЕМ В ВЕРСИЮ ДАННЫХ АНДРОЙД
                КурсорДляАнализаВерсииДанныхАндройда = КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[]{"name"}, "name=?", new String[]{ИмяПоляДляВставкиВАндйрод},
                        null, null, null, null);///"SELECT name  FROM MODIFITATION_Client WHERE name=?",НазваниеТаблицНаСервере
                //"SuccessLogin", "date_update","id=","1",null,null,null,null
                ////////вставляем ноое название талицы если ее нет на андройде в таблице модификаци данных

*/


                if (КурсорДляАнализаВерсииДанныхАндройда != null) {
                    ///////
                    КурсорДляАнализаВерсииДанныхАндройда.moveToFirst();

                    Log.d(this.getClass().getName(), " КурсорДляАнализаВерсииДанныхАндройда.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());
                }
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////

                // TODO: 05.10.2021 ЗНАЧЕНИЕ КУРСОРА МИНУС 1 КОВОРИТ ОТ ТОМ ЧТО ТАБЛИЦЫ КОТОРАЯ ЕСТЬ НА СЕРВЕРА ПОЧЕМУ ТО ОТСУТСТУЕТ НА КЛИЕНТЕ И НАМ ЕЕ НАДО ДОБАВИТЬ 
                //ОЧЕНЬ ВАЖНО ЕСЛИ ЭТОТ КУРСОР ВЕРНЕТЬ ПОЛОЖИТЕЛЬНО ЦИФРУ ЭТО ЗНАЧИИТ ЧТО ТАКАЯ ТАБЛИЦУ УЖЕ ЕСТЬ НА АНДРОЙДЕ И ВСТАВЛЯЕТЬ ЕЕ НЕ НАДО
                if (КурсорДляАнализаВерсииДанныхАндройда.getCount() < 1) {/////ЕСЛИ КУРСОР ВОЗВРЯЩАЕТ ЦИФРУ 1 ТО ТОГДА ДАННАЯ ТАБОИЦА УЖЕ ЕСТЬ В ТАБЛИЦЕ ВЕРСИЙ ДАНЫХ АНДРОЙДА
                    //////
                    Log.d(this.getClass().getName(), " КурсорДляАнализаВерсииДанныхАндройда.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());

                    ContentValues КонтейнерВствкаНовыхИменТаблицМодифика = new ContentValues();

                    КонтейнерВствкаНовыхИменТаблицМодифика.put("name", ИмяПоляДляВставкиВАндйрод);////ЗАПОЛЯНЕМ КОНТЕРЙНЕР ИМЯ ТАБЛИЦЫ КОТОРОЙ НЕТ ИЗ  СЕРВЕРА
                    //КонтейнерВствкаНовыхИменТаблицМодифика.put("versionserveraandroid", "2001-11-01 00:00:00");////ЗАПОЛЯНЕМ КОНТЕРЙНЕР ДАТУ ГЕНЕРИРУЕМ В ТАБЛИЦУ КОТОРО НЕТ
                    /////записываем если такой таблицы нет  на андройде в таблице модификация данных


                    Long РезультатВставкиДанных = ВставкаДанныхЧерезКонтейнерУниверсальная("MODIFITATION_Client", КонтейнерВствкаНовыхИменТаблицМодифика, ИмяТаблицыОтАндройда_Локальноая, "", false, 0, false,
                            КонтекстСинхроДляКонтроллераВФоне,
                            ActivityДляСинхронизацииОбмена,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу(),СколькоСтрочекJSON,0,ФиналПроценты); ////false  не записывать изменениея в таблице модификавет версия

                    Log.d(this.getClass().getName(), " РезультатВставкиДанных " + РезультатВставкиДанных);
                    ////
                    /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                }
                Log.i(this.getClass().getName(), " НазваниеТаблицНаСервере  " + ИмяПоляДляВставкиВАндйрод + " ФайлJSONcВерсиейДанныхСервера.names().length() "
                        + ФайлJSONcВерсиейДанныхСервера.names().length() + " КурсорДляАнализаВерсииДанныхАндройда.getCount()  " + КурсорДляАнализаВерсииДанныхАндройда.getCount());


                // TODO: 05.10.2021


                break;
//внутри цикла
            }



            //////
            Log.d(this.getClass().getName(), " ИмяТаблицыОтАндройда_Локальноая " + ИмяТаблицыОтАндройда_Локальноая + " Полученная_ВерсияДанныхсSqlServer "
                    + Полученная_ВерсияДанныхсSqlServer + " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных "
                    + ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных);



            //// ПОЛУЧИЛИ ДАТУ ОТ SQL SERVER  ДЛЯ ОПРЕЕЛЕННОЙ ТАБЛИЦЫ И ЗАПОЛНИЛИ ТАБЛИЦУ МОДИФИКАЦИЯ ДАНЫХ НА КЛИЕНТЕ  И ИДЕМ УЖЕ АНАЛИЗИРОВАТЬ ИХ НИЖЕ
            if (Полученная_ВерсияДанныхсSqlServer> 0) {
                //////
                Log.d(this.getClass().getName(), " ИмяТаблицыОтАндройда_Локальноая " + ИмяТаблицыОтАндройда_Локальноая + " Полученная_ВерсияДанныхсSqlServer "
                        + Полученная_ВерсияДанныхсSqlServer + " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных "
                        + ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных);



                //
                РезультатУспешнойВсатвкиИлиОбновлениясСервреа=0;
                //////////метод анализа данных
      РезультатУспешнойВсатвкиИлиОбновлениясСервреа=
              МетодАнализаВресииДАнныхКлиента(ИмяТаблицыОтАндройда_Локальноая, Полученная_ВерсияДанныхсSqlServer, ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных, ДанныеПришёлЛиIDДЛяГенерацииUUID,
                      МенеджерПотоковВнутрений);



      /////////
                Log.i(this.getClass().getName(), " РезультатУспешнойВсатвкиИлиОбновлениясСервреа  " + РезультатУспешнойВсатвкиИлиОбновлениясСервреа);
            }








        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
        return  РезультатУспешнойВсатвкиИлиОбновлениясСервреа;
    }










    ////////////////////////////ДАННЫЙ МЕТОД ПОСЛЕ ВЫШЕ СТОЯШЕГО ВЫРАВНИЯНИЯ НАЗВАНИЙ ТАБЛИЦ ПРИСТУПАЕТ К САМОМУ АНАЛИЗУ ДАННЫХ ВЕРСИИ ДАННЫХ НАХОДЯЩИХСЯ НА АНДРОЙДЕ
    Integer МетодАнализаВресииДАнныхКлиента(String ИмяТаблицыОтАндройда_Локальноая,
                                         Long Полученная_ВерсияДанныхсSqlServer,
                                         String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                                         String ДанныеПришёлЛиIDДЛяГенерацииUUID,
                                            CompletionService МенеджерПотоковВнутрений) {

        Log.d(this.getClass().getName(), " Полученная_ВерсияДанныхсSqlServer " +Полученная_ВерсияДанныхсSqlServer);

        SQLiteCursor КурсорДляАнализаВерсииДанныхАндройда = null;

        ////////////////

        Long ВерсииДанныхНаАндройдеЛокальнаяЛокальная = 0l;

        Long ВерсииДанныхНаАндройдеСерверная = 0l;

        Integer РезультатУспешнойВсатвкиИлиОбвовлениясСервера=0;

        // String ДатаВерсииДанныхНаАндройдеЛокальногоОбновленияДляМетодаGET = null;


        Class_GRUD_SQL_Operations class_grud_sql_operationsАнализаВресииДАнныхКлиента;


        try {

///
            class_grud_sql_operationsАнализаВресииДАнныхКлиента=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);

            ///
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","MODIFITATION_Client");
            ///////
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","name,localversionandroid_version, versionserveraandroid_version");
            //
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","name=? ");
                    ///"_id > ?   AND _id< ?"
                    //////
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",ИмяТаблицыОтАндройда_Локальноая);
                    ///
/*            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......

            ////TODO другие поля

            ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);*/
            ////
            //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
            ////
           // class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
            ////
            /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
            ////

            // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

            КурсорДляАнализаВерсииДанныхАндройда= (SQLiteCursor)  class_grud_sql_operationsАнализаВресииДАнныхКлиента.
                    new GetData(contextСозданиеБАзы).getdata(class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

            Log.d(this.getClass().getName(), "GetData "+КурсорДляАнализаВерсииДанныхАндройда  );




            ///// todo
            // УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
            /////////ВАЖНО ЕСЛИ БОЛЬШЕ НУЛ ЗНАЧИТ В АНДРОЙДЕ ТАБЛИЦА С ТАКИМ НАЗВАНИЕМ УЖЕ ЕСТЬ

                /////
                if (КурсорДляАнализаВерсииДанныхАндройда.getCount() > 0) {////ВЫЖНОЕ УСЛОВИЕ ЕСЛИ КУРСОР ВЕРНУЛ БОЛЬШЕ НУЛЯ  ДАННАЕ ТОЛЬКО ТОГДА НАЧИНАЕМ АНАЛИЗ ВЕРСИИ ДАННЫХ НА АНДРОЙДЕ

                    КурсорДляАнализаВерсииДанныхАндройда.moveToFirst();

                    Log.d(this.getClass().getName(), "  Курсор_УзнаемВерсиюБазыНаАдройде.getCount() " + КурсорДляАнализаВерсииДанныхАндройда.getCount());
                    //////////////


                    // TODO: 05.10.2021  получаем верию данных лолькано    --- локльную

                    ВерсииДанныхНаАндройдеЛокальнаяЛокальная = КурсорДляАнализаВерсииДанныхАндройда.getLong(КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("localversionandroid_version"));


                    Log.d(this.getClass().getName(), "   ВерсииДанныхНаАндройдеЛокальнаяЛокальная " + ВерсииДанныхНаАндройдеЛокальнаяЛокальная);


                    // TODO: 05.10.2021  получаем верию данных лолькано  - ерверную


                    ВерсииДанныхНаАндройдеСерверная = КурсорДляАнализаВерсииДанныхАндройда.getLong(КурсорДляАнализаВерсииДанныхАндройда.getColumnIndex("versionserveraandroid_version"));


                    Log.d(this.getClass().getName(), "   ВерсииДанныхНаАндройдеСерверная " +ВерсииДанныхНаАндройдеСерверная);

                    ///////////ОПРЕДЕЛЯЕМ ДАТУ АНДРОЙДА ДЛЯ СОСТЫКОВКИ С ДАТОЙ SQ; SERVER//// ПОЛУЧАЕМ ДАТУ НА АНДРОЙДЕ ПОЛСЕДНЕЕ ИЗМЕНЕНИЯ ПРИШЕДЩИЕ ДАННЫЕ С СЕРВЕРА

                } else {


                    Log.d(this.getClass().getName(), "  НЕт такой таблицы и нет Данных КурсорДляАнализаВерсииДанныхАндройда.getCount()" + КурсорДляАнализаВерсииДанныхАндройда.getCount());
                }


            // TODO: 05.10.2021  КОГДА ВСЕ ДАННЫЕ ЕСТЬ ТРИ ПЕРЕМЕННЫЕ ПОЛУЧЕНИЕ ПЕРЕХОИМ ДАЛЬШЕ ПОЛЯ ЛОКАЛЬНАЯ ВЕРСИЯ ДАННЫХ, СЕРВЕНАЯ ВЕРСИЯ ДАННЫХ, И ТЕРТЬЯ ВЕРИСЯ С СЕРВЕРА ПО ДАННОЙ ТАБЕЛИЦВ



            Log.d(this.getClass().getName(), "   ВерсииДанныхНаАндройдеСерверная " +ВерсииДанныхНаАндройдеСерверная+
                    "   ВерсииДанныхНаАндройдеЛокальнаяЛокальная " + ВерсииДанныхНаАндройдеЛокальнаяЛокальная
                    +"   Полученная_ВерсияДанныхсSqlServer " +Полученная_ВерсияДанныхсSqlServer);


            // TODO: 05.10.2021 ПРИ НАЛИЧИИ ВСЕХ ТРЕХ ПОЗИЦИЙ ЛОКАЛЬНАЯ ВЕРСИЯ С АНДРОЙДА   И СЕРВРНАЯ ВЕРСИЯ С АНДРОЙДА И  ПРИШЕДШЕЯ ВЕРСИЯ С СЕРВЕРА
                
                
            ///
            if (ВерсииДанныхНаАндройдеЛокальнаяЛокальная !=null  && ВерсииДанныхНаАндройдеСерверная!=null && Полученная_ВерсияДанныхсSqlServer!=null) {


                // TODO: 05.10.2021

                 РезультатУспешнойВсатвкиИлиОбвовлениясСервера=0;
                ///////////////


                //TODO СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
         РезультатУспешнойВсатвкиИлиОбвовлениясСервера=       МетодПринятияРешенияПолучитьДанныесСервераИлиОтправитьДанныесКлиента(
                 ВерсииДанныхНаАндройдеЛокальнаяЛокальная,
                 ВерсииДанныхНаАндройдеСерверная,
                 Полученная_ВерсияДанныхсSqlServer,
                 ИмяТаблицыОтАндройда_Локальноая,
                 ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                 ДанныеПришёлЛиIDДЛяГенерацииUUID,
                 МенеджерПотоковВнутрений);///СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР

                Log.d(this.getClass().getName(), "   РезультатУспешнойВсатвкиИлиОбвовлениясСервера " +РезультатУспешнойВсатвкиИлиОбвовлениясСервера);








            }
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл

        }
        return  РезультатУспешнойВсатвкиИлиОбвовлениясСервера;
    }














    //TODO СЛЕДУЮЩИЙ ЭТАМ РАБОТЫ ОПРЕДЕЛЯЕМ ЧТО МЫ ДЕЛАЕМ ПОЛУЧАЕМ ДАННЫЕ С СЕВРЕРА ИЛИ НА ОБОРОТ  ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР
    Integer МетодПринятияРешенияПолучитьДанныесСервераИлиОтправитьДанныесКлиента(Long ВерсииДанныхНаАндройдеЛокальнаяЛокальная,
                                                                                 Long ВерсииДанныхНаАндройдеСерверная,
                                                                              Long Полученная_ВерсияДанныхсSqlServer,
                                                                              String ИмяТаблицыОтАндройда_Локальноая,
                                                                                 String ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных,
                                                                              String ДанныеПришёлЛиIDДЛяГенерацииUUID,
                                                                                 CompletionService МенеджерПотоковВнутрений) {
        //
        Log.d(this.getClass().getName(), " ВерсииДанныхНаАндройдеЛокальнаяЛокальная " + ВерсииДанныхНаАндройдеЛокальнаяЛокальная +
                " ВерсииДанныхНаАндройдеСерверная " + ВерсииДанныхНаАндройдеСерверная
                + " Полученная_ВерсияДанныхсSqlServer " + Полученная_ВерсияДанныхсSqlServer+
                "  ИмяТаблицыОтАндройда_Локальноая " +ИмяТаблицыОтАндройда_Локальноая+
               " ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных " +ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных+
                 "  ДанныеПришёлЛиIDДЛяГенерацииUUID " +ДанныеПришёлЛиIDДЛяГенерацииUUID);


        // TODO: 05.10.2021

                Integer РезультатУспешнойВставкиИлИОбвновленияССервера=0;//РезультатУспешнойВставкиИлИОбвновленияССервера
        
        
        
        
        try {




///// TODO НАЗВАНИЯ  ОБЯЗАТОЛЬНОЕ УСЛОВИЕ НАЗВАНИЕ ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ НАПРИМЕР  CFO==CFO
            if (ИмяТаблицыНаSqlServerИзТаблицыВерсииДанных.equalsIgnoreCase(ИмяТаблицыОтАндройда_Локальноая)) {//////ОБЯЗАТОЛЬНОЕ УСЛОВИЕ НАЗВАНИЕ ТАБЛИЦ ДОЛЖНО БЫТЬ ОДИНАКОВЫМ НАПРИМЕР  CFO==CFO


                // TODO: 01.08.2021  ОБРАБОТКА ТОЛЬКО ДЛЯ ТАЮДИЦ КРОМЕ ЧАТА   (ОБРАБОТКА ВСЕХ ТАБЛИЦ , КРОМЕ ТАБЛИЦ ЧАТА )  (ОБРАБОТКА ВСЕХ ТАБЛИЦ , КРОМЕ ТАБЛИЦ ЧАТА )

                        Log.d(this.getClass().getName(),
                                " ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА" + ФлагУказываетЧтоТОлькоОбработкаТаблицДляЧАТА + " ИмяТаблицыОтАндройда_Локальноая " + ИмяТаблицыОтАндройда_Локальноая);
                        //TODO вычисялем локалнуюю версию чата curennt cat local


                        // TODO: 11.08.2021 --  ПЕРВОЕ ДЕЙСТИЕ ОТПРАВЛЯЕМ МЕТОД POS()-> НА СЕРВЕР   // TODO: 11.08.2021 --  ПЕРВОЕ ДЕЙСТИЕ ОТПРАВЛЯЕМ МЕТОД POS()-> НА СЕРВЕР   // TODO: 11.08.2021 --  ПЕРВОЕ ДЕЙСТИЕ ОТПРАВЛЯЕМ МЕТОД POS()-> НА СЕРВЕР


                        // TODO: 11.08.2021  ЛОКАЛЬНАЯ СЕРВЕРНАЯ НА АНДРОЙДЕ

                        Long РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера = 0l;

                        // TODO: 12.08.2021 СЕРВЕРАНАЯ ДАТА ЛОКАЛЬНАЯ

                        РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера =
                                МетодПолученияЛокальнойВерсииДаныхЧатаДляОтправкиЕгоНАСервер("MODIFITATION_Client", "versionserveraandroid_version",
                                contextСозданиеБАзы, ИмяТаблицыОтАндройда_Локальноая);


                        Log.d(this.getClass().getName(),
                                " РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера" +
                                        РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера);
                        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        // TODO: 11.08.2021  ЛОКАЛЬНАЯ СЕРВЕРНАЯ НА АНДРОЙДЕ

                        Long РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее = 0l;

                        // TODO: 12.08.2021 ЛОКАЛЬНАЯ ДАТА ЛОКАЛЬНАЯ

                        РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее =
                                МетодПолученияЛокальнойВерсииДаныхЧатаДляОтправкиЕгоНАСервер("MODIFITATION_Client", "localversionandroid_version",
                                contextСозданиеБАзы, ИмяТаблицыОтАндройда_Локальноая);


                        Log.d(this.getClass().getName(),
                                " РезультаПолученаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее" + РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее);











                // TODO: 05.10.2021  ПЕРВОЕ ДЕЙСТВИЕ  ДЕЙСТВИЕ ЕСЛИ НЕТ ОТПРАВЛЕНИЕ ВЫШЕ ДАННЫХ      // TODO: 05.10.2021  ПЕРВОЕ ДЕЙСТВИЕ  ДЕЙСТВИЕ ЕСЛИ НЕТ ОТПРАВЛЕНИЕ ВЫШЕ ДАННЫХ
                // TODO: 05.10.2021  ПЕРВОЕ ДЕЙСТВИЕ  ДЕЙСТВИЕ ЕСЛИ НЕТ ОТПРАВЛЕНИЕ ВЫШЕ ДАННЫХ
                // TODO: 05.10.2021  ПЕРВОЕ ДЕЙСТВИЕ  ДЕЙСТВИЕ ЕСЛИ НЕТ ОТПРАВЛЕНИЕ ВЫШЕ ДАННЫХ






                ////// TODO запуск отпарвки  ЛОКАЛЬНАЯ ПРОВЕРКА ВЕРСИИ ДАНННЫХ  #1 НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ ПОСЛЕДНАЯЯ НАДО С АНДРОЙДА ПОСЛАТЬ ДАННЫЕ НА СЕРВЕР
                        if (РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее >
                                РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера) {  ///  && ФлагКакуюЧастьСинхронизацииЗапускаем.equalsIgnoreCase("Запускаем Только Отправления Синхронизации")//ПРОВЕРЯЕМ ДАТЫ КАКАЯ БОЛЬШЕ МЕНЬШЕ тут больше что слева sql server
                            //////  НАЧАЛО  ЛОКАЛЬНАЯ ПРОВЕРКА ВНУТИРИ АНДРОЙДА ПО ДАТАМ МЕЖДУ СОБОЙ

                            Log.d(this.getClass().getName(),
                                    " ЛОКАЛЬНАЯ ВЕРСИЯ (последнего серверного обновления) ЧАТ   РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера   "
                                            + РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера
                                            + "  ЛОКАЛЬНАЯ ЛОКАЛЬНАЯ ВЕРСИЯ (локальные обновления созданые на андройде) ЧАТ   РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее   "
                                            + РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее +
                                            " ФлагКакуюЧастьСинхронизацииЗапускаем " + ФлагКакуюЧастьСинхронизацииЗапускаем
                                            + "РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера  "
                                            + РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера +
                                            "  ИмяТаблицыОтАндройда_Локальноая " + ИмяТаблицыОтАндройда_Локальноая+
                                    "  ПОСЛЕДНИЙ УСПЕШНЫЙ ОБНОВЛЕНИЕ С СЕРВРЕА "+РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера+"\n"+
                                    "  ПОСЛЕДНИЙ УСПЕШНЫЙ ДОБАЛВЕНИЯ НОВОГО СООБЩЕНИЯ " +РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее );



                  /*  ////TODO ПЕРЕДАЕМ ДАТЫ МЕТОДУ ДЛЯ ОТПРАВКИ ДАННЫХ НА СЕРВЕР ДЛЯ ЭТОГО ЕГО НЕМНОГО ПРЕОБРАЗУЕМs
                    DateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", new Locale("ru"));
                    String ДатаВерсииДанныхНаSqlServerДляОтправкиНаСерверДанных =dateFormat.format(ДатаВерсииДанныхНаSqlServer );
                            ///////todo МЕТОД GET запускаем метод POST посылаем Данные на сервер
                    /////МетодПосылаемДанныеНаСервер(ИмяТаблицыОтАндройда_Локальноая ,ДатаВерсииДанныхНаSqlServerДляОтправкиНаСерверДанных ); //////МЕТОД POST*/


                            ////// todo МЕТОД POST
                            РезультатУспешнойВставкиИлИОбвновленияССервера =
                                    МетодПосылаемДанныеНаСервервФоне(ИмяТаблицыОтАндройда_Локальноая, РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера,
                                            МенеджерПотоковВнутрений);
                            ////// todo МЕТОД POST() в фоне

                            ////// todo ВНИМАНИЕ ТУТ КОД НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ БОЛЬШЕ  ЧЕМ НА СЕРВЕРЕ   ,,,,,,, И МЫ ДОЛЖНЫ С ТЕЛЕФОНА ОТОСЛАТЬ ДАННЫЕ НА СЕВРЕР SQL SEVER   POST ()
                            ///
                            Log.d(this.getClass().getName(),
                                    "    РезультатУспешнойВставкиИлИОбвновленияССервера  " + РезультатУспешнойВставкиИлИОбвновленияССервера +
                                            " РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера "
                                            + РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера +
                                            "  РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее " + РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее);


                            //////// TODO  В ДАННОМ СЛУЧАЕ НА СЕРВРЕР ВЕРСИЯ  ДАННЫХ СТАРШЕ ЧЕМ НА АНДЙРОДЕ , И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВЕРА  GET()



                            // TODO: 12.08.2021 код повышает или уменьшает верисю данных при отправке данных


                            if (РезультатУспешнойВставкиИлИОбвновленияССервера>0) {


                                // TODO: 12.08.2021 код повышает или уменьшает верисю данных
                                Integer РезультатПовышенияВерсииДанныхДатыиВерсии = МетодПослеGRUDОперацийПовышаемВерсиюДанных(РезультатУспешнойВставкиИлИОбвновленияССервера,
                                        ИмяТаблицыОтАндройда_Локальноая,"Серверный",РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее,МенеджерПотоковВнутрений);//ЛокальныйСерверныйОба

                                Log.i(this.getClass().getName(), "   ИмяТаблицыОтАндройда_Локальноая"
                                        + ИмяТаблицыОтАндройда_Локальноая + " РезультатУспешнойВставкиИлИОбвновленияССервера " + РезультатУспешнойВставкиИлИОбвновленияССервера +
                                        "  РезультатПовышенияВерсииДанныхДатыиВерсии " + РезультатПовышенияВерсииДанныхДатыиВерсии);



                            }





















                            // TODO: 05.10.2021  ВТОРОЕ ДЕЙСТВИЕ ЕСЛИ НЕТ ОТПРАВЛЕНИЕ ВЫШЕ ДАННЫХ ,  МЫ ЗАОДНО ЕЩЕ РАЗ ДЕЛАЕМ ПРОВЕРКУ НЕ НАДО ЛИ ЧТО НИБУТЬ ОТПРАВИТЬ НА СЕРВЕР ,
                            //TODO: **КОГДА ЕСТЬ КАКИЕ ТО СТРОКИ В КОТОРЫХ ПРИСУДСТУЕТ NULL ПО ПОЛУ ID  --- ЭТО ЗНАЧИТ ЧТО ОНИ ЕЩЕ НЕ БЫЛИ НА СЕРВЕРЕ , И ИХ НАДО ОТПРАВИТЬ
                            // TODO: 05.10.2021  ВТОРОЕ ДЕЙСТВИЕ ЕСЛИ НЕТ ОТПРАВЛЕНИЕ ВЫШЕ ДАННЫХ ,  МЫ ЗАОДНО ЕЩЕ РАЗ ДЕЛАЕМ ПРОВЕРКУ НЕ НАДО ЛИ ЧТО НИБУТЬ ОТПРАВИТЬ НА СЕРВЕР ,
                            //TODO: **КОГДА ЕСТЬ КАКИЕ ТО СТРОКИ В КОТОРЫХ ПРИСУДСТУЕТ NULL ПО ПОЛУ ID  --- ЭТО ЗНАЧИТ ЧТО ОНИ ЕЩЕ НЕ БЫЛИ НА СЕРВЕРЕ , И ИХ НАДО ОТПРАВИТЬ







                            ////////
                        }else  {







                            // TODO: 05.10.2021  ДЕЙСТИВЕ ТРЕТЬЕ ПОЛУЧАЕМ ДАННЫХ  ССЕРВЕРА ПО ВЕРИСЯ ВСЕ ТАБЛИЦЫ ПОСЛЫВАЕМ НА СЕРВЕР
                            // TODO: 05.10.2021  ДЕЙСТИВЕ ТРЕТЬЕ ПОЛУЧАЕМ ДАННЫХ  ССЕРВЕРА ПО ВЕРИСЯ ВСЕ ТАБЛИЦЫ ПОСЛЫВАЕМ НА СЕРВЕР

                            // TODO: 05.10.2021  ДЕЙСТИВЕ ТРЕТЬЕ ПОЛУЧАЕМ ДАННЫХ  ССЕРВЕРА ПО ВЕРИСЯ ВСЕ ТАБЛИЦЫ ПОСЛЫВАЕМ НА СЕРВЕР
                            // TODO: 05.10.2021  ДЕЙСТИВЕ ТРЕТЬЕ ПОЛУЧАЕМ ДАННЫХ  ССЕРВЕРА ПО ВЕРИСЯ ВСЕ ТАБЛИЦЫ ПОСЛЫВАЕМ НА СЕРВЕР






                            // TODO: 04.10.2021  каждый раз убнялем серверную верисю


                            РезультатВерсииДанныхЧатаНаСервере = 0l;


                            Log.d(this.getClass().getName(),
                                    " Полученная_ВерсияДанныхсSqlServer " + Полученная_ВерсияДанныхсSqlServer +
                                            "  РезультатВерсииДанныхЧатаНаСервере " +РезультатВерсииДанныхЧатаНаСервере  );



                            ////////
                            РезультатВерсииДанныхЧатаНаСервере =Полученная_ВерсияДанныхсSqlServer;


                            // TODO: 11.08.2021 НОВЫЙ ОБМЕН ДАННЫМИС СЕРВЕРРОМ НА ОСНОВЕ ВЕРСИЙ ДАННЫХ  ПОКА ТОЛЬКО ДЛЯ ЧАТА


                            Log.d(this.getClass().getName(),
                                    " РезультатВерсииДанныхЧатаНаСервере  " + РезультатВерсииДанныхЧатаНаСервере+
                                            "  РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера "+РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера
                                            +  " ФлагКакуюЧастьСинхронизацииЗапускаем " +ФлагКакуюЧастьСинхронизацииЗапускаем  +  " РезультатУспешнойВставкиИлИОбвновленияССервера " +РезультатУспешнойВставкиИлИОбвновленияССервера);


                            // TODO: 12.08.2021 START GET()-> // TODO: 12.08.2021 START GET()->  // TODO: 12.08.2021 START GET()->  // TODO: 12.08.2021 START GET()->  // TODO: 12.08.2021 START GET()->
                            // TODO: 12.08.2021 СЕРВЕРАНАЯ ДАТА ЛОКАЛЬНАЯ


                            // TODO: 11.08.2021 --ПЕРВОЕ УСЛОВИЕ НОВОГО МЕХАНИЗМА  ПРОВЕРЯЕМ НЕ БОЛЬШЕ ЛИ ВЕРСИЯ ДАННЫХ НА СЕРВЕРЕ ???  GET()->

                            if (РезультатВерсииДанныхЧатаНаСервере > РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера  ) { // С СЕРВЕРА//&& ФлагКакуюЧастьСинхронизацииЗапускаем.equalsIgnoreCase("Запускаем Только Получения Синхронизации")
                                //////
                                ///////
                                Log.d(this.getClass().getName(), " НА SQL SERVER  ДАТА больше версия" +
                                        "  ЛОКАЛЬНАЯ ВЕРСИЯ (последнего серверного обновления) ЧАТ  РезультаПолученаяЛокальнаяВерсияДанныхДляОтправкиНаСервер " + РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера +
                                        " и  ТЕКУЩАЯ СЕРВЕРНАЯ ВЕРСИЯ  ЧАТ РезультатВерсииДанныхЧатаНаСервере " + РезультатВерсииДанныхЧатаНаСервере);

                                // TODO: 19.08.2021 уменьшаемм для повторгого повторной отправки


                                //////////TODO МЕТОД get
                                РезультатУспешнойВставкиИлИОбвновленияССервера =
                                        МетодПолучаемДаннныесСервера(ИмяТаблицыОтАндройда_Локальноая, ВерсииДанныхНаАндройдеСерверная, ДанныеПришёлЛиIDДЛяГенерацииUUID,
                                                ВерсииДанныхНаАндройдеЛокальнаяЛокальная, РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера,
                                                МенеджерПотоковВнутрений);/// ЗАПУСКАМ МЕТОД ПОЛУЧЕНИЕ ДАННЫХ С СЕРВЕРА    МЕТОД GET


                                Log.d(this.getClass().getName(), " ПОСЛЕ УСПЕШНОЙ ОТПАРВКИ ДАННЫХ НА СЕРВЕР" +
                                        " РезультатУспешнойВставкиИлИОбвновленияССервера " + РезультатУспешнойВставкиИлИОбвновленияССервера +
                                        "  РезультатВерсииДанныхЧатаНаСервере" + РезультатВерсииДанныхЧатаНаСервере);
                                /////В ДАНОМ СЛУЧАЕ ДАННЫЕ СИНХРОНИЗИРОВАТЬ НЕ НАДО ВЕСРИЯ ДАННЫХ НА СЕРВРЕР И НА КЛИЕНТЕ ОДИНАКОВЫ


                                ////TODO КОГДА ДАТЫ РАВНЫ И НЕ ПОЛУЧАТЬ ДАННЫЕ И ОТСЫЛАТЬ НЕ НАДО GET() И POST() ОБА НЕ СРАБОТАЛИ


                                // TODO: 12.08.2021 ПОСЛЕ УСПЕШНОГО ПОЛУЧЕНИЕ ДАННЫХ или уменьшает верисю данных



                                if (РезультатУспешнойВставкиИлИОбвновленияССервера>0) {


                                    // TODO: 12.08.2021 код повышает или уменьшает верисю данных
                                    Integer РезультатПовышенияВерсииДанныхДатыиВерсии = МетодПослеGRUDОперацийПовышаемВерсиюДанных(РезультатУспешнойВставкиИлИОбвновленияССервера,
                                            ИмяТаблицыОтАндройда_Локальноая,"ЛокальныйСерверныйОба",РезультатВерсииДанныхЧатаНаСервере,МенеджерПотоковВнутрений);//ЛокальныйСерверныйОба

                                    Log.i(this.getClass().getName(), "   ИмяТаблицыОтАндройда_Локальноая"
                                            + ИмяТаблицыОтАндройда_Локальноая + " РезультатУспешнойВставкиИлИОбвновленияССервера " + РезультатУспешнойВставкиИлИОбвновленияССервера +
                                            "  РезультатПовышенияВерсииДанныхДатыиВерсии " + РезультатПовышенияВерсииДанныхДатыиВерсии);
                                }





























                                // TODO: 05.10.2021  ВТОРОЕ ДЕЙСТВИЕ ЕСЛИ НЕТ ОТПРАВЛЕНИЕ ВЫШЕ ДАННЫХ ,  МЫ ЗАОДНО ЕЩЕ РАЗ ДЕЛАЕМ ПРОВЕРКУ НЕ НАДО ЛИ ЧТО НИБУТЬ ОТПРАВИТЬ НА СЕРВЕР ,
                                //TODO: **КОГДА ЕСТЬ КАКИЕ ТО СТРОКИ В КОТОРЫХ ПРИСУДСТУЕТ NULL ПО ПОЛУ ID  --- ЭТО ЗНАЧИТ ЧТО ОНИ ЕЩЕ НЕ БЫЛИ НА СЕРВЕРЕ , И ИХ НАДО ОТПРАВИТЬ
                                // TODO: 05.10.2021  ВТОРОЕ ДЕЙСТВИЕ ЕСЛИ НЕТ ОТПРАВЛЕНИЕ ВЫШЕ ДАННЫХ ,  МЫ ЗАОДНО ЕЩЕ РАЗ ДЕЛАЕМ ПРОВЕРКУ НЕ НАДО ЛИ ЧТО НИБУТЬ ОТПРАВИТЬ НА СЕРВЕР ,
                                //TODO: **КОГДА ЕСТЬ КАКИЕ ТО СТРОКИ В КОТОРЫХ ПРИСУДСТУЕТ NULL ПО ПОЛУ ID  --- ЭТО ЗНАЧИТ ЧТО ОНИ ЕЩЕ НЕ БЫЛИ НА СЕРВЕРЕ , И ИХ НАДО ОТПРАВИТЬ



                            }/*else{


                                // TODO: 08.10.2021  елси нет данных на отправку попробуем еще раЗ ПРОВЕРИТЬ НА СТРОЧКИ КО ТОРЫЕ NULLL ЭТО ЗНАЧИТ ОНИЕЩЕ НЕ БЫЛИ НА СЕРВЕРЕ
                                // TODO: 19.08.2021 дополгнтельны метод котрый ищет еще не отпрвленные данные на сервер
                                ClassCalculateInFieldIDNULLMeanDataValueNotyetsent Класс_ИщетЕщеНеотправленныеСообщения =
                                        new ClassCalculateInFieldIDNULLMeanDataValueNotyetsent(contextСозданиеБАзы, ИмяТаблицыОтАндройда_Локальноая);
                                //////
                                Класс_ИщетЕщеНеотправленныеСообщения.setТекущаяТаблицаГдеЕстьвIdПолеNULL(ИмяТаблицыОтАндройда_Локальноая);


                                // TODO: 12.10.2021ЗАПУСКАЕМ ТЕРТИЙ ВАРИАРТ ПОТПРАВВКИКК ДАННННЫНЫХХ  КООГДА ХОТЬ В ПОЛЕ ID сть NULLL

                                Long РезультатЭтоЗначениеПоказываетЧтоЕстьКоеЧТоЧТоЕщенеОтправленноСообщенеиеИмыДополнительноОправляем
                                        = Класс_ИщетЕщеНеотправленныеСообщения.МетодВычисляемЕщенеОтправленныеСообщенияНаСервер();


                                Log.d(this.getClass().getName(),
                                        " РезультатЭтоЗначениеПоказываетЧтоЕстьКоеЧТоЧТоЕщенеОтправленноСообщенеиеИмыДополнительноОправляем" +
                                                РезультатЭтоЗначениеПоказываетЧтоЕстьКоеЧТоЧТоЕщенеОтправленноСообщенеиеИмыДополнительноОправляем);





                                if (       РезультатЭтоЗначениеПоказываетЧтоЕстьКоеЧТоЧТоЕщенеОтправленноСообщенеиеИмыДополнительноОправляем > 0) {


                                    Log.d(this.getClass().getName(),
                                            " РезультатЭтоЗначениеПоказываетЧтоЕстьКоеЧТоЧТоЕщенеОтправленноСообщенеиеИмыДополнительноОправляем" +
                                                    РезультатЭтоЗначениеПоказываетЧтоЕстьКоеЧТоЧТоЕщенеОтправленноСообщенеиеИмыДополнительноОправляем);

                                    // TODO: 04.10.2021



                                    ////// todo МЕТОД POST
                                    РезультатУспешнойВставкиИлИОбвновленияССервера =
                                            МетодПосылаемДанныеНаСервервФоне(ИмяТаблицыОтАндройда_Локальноая, РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера);
                                    ////// todo МЕТОД POST() в фоне

                                    ////// todo ВНИМАНИЕ ТУТ КОД НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ БОЛЬШЕ  ЧЕМ НА СЕРВЕРЕ   ,,,,,,, И МЫ ДОЛЖНЫ С ТЕЛЕФОНА ОТОСЛАТЬ ДАННЫЕ НА СЕВРЕР SQL SEVER   POST ()
                                    ///
                                    Log.d(this.getClass().getName(),
                                            "    РезультатУспешнойВставкиИлИОбвновленияССервера  " + РезультатУспешнойВставкиИлИОбвновленияССервера +
                                                    " РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера "
                                                    + РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера +
                                                    "  РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее " + РезультаПолученаяЛокальнаяЛокальнаяВерсияДанныхКогдаПользовательСоздалНовыеДаннее);


                                    //////// TODO  В ДАННОМ СЛУЧАЕ НА СЕРВРЕР ВЕРСИЯ  ДАННЫХ СТАРШЕ ЧЕМ НА АНДЙРОДЕ , И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВЕРА  GET()


                                    // TODO: 12.08.2021 код повышает или уменьшает верисю данных при отправке данных






                            }*/

                            // TODO: 11.08.2021   КОНЕЦ ОБРАБОТКА МЕХАНИЗМА СИНХРОНИЗАИИ КОГДА МЫ ПРИНИМАЕМ РЕШЕНИЯ ОТПРАВЛЯТЬ ИЛИ ПРИНИМАИТЬ ДАННЫЕ  ДЛЯ ЧАТА ТУТ РЕШАЕМ ЧЕРЕЗ ДАТЫ


                            // TODO: 11.08.2021  КОНЕЦ НОВОГО ОБМЕНА ЧЕРЕЗ ВЕРСИЮ ДАННЫХ ДЛЯ ЧАТА


                        }





























            }//todo название серверной таблицы и локльноеимя таблицы одно и тоже


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }








        Log.i(this.getClass().getName(), "   РезультатУспешнойВставкиИлИОбвновленияССервера"
                + РезультатУспешнойВставкиИлИОбвновленияССервера + "  ПубличныйРезультатОтветаОтСерврераУспешно " +ПубличныйРезультатОтветаОтСерврераУспешно);
        ///////
        if(РезультатУспешнойВставкиИлИОбвновленияССервера==0 ){
            ///
            РезультатУспешнойВставкиИлИОбвновленияССервера=   ПубличныйРезультатОтветаОтСерврераУспешно;
        }






        return  РезультатУспешнойВставкиИлИОбвновленияССервера;
    }












    // TODO: 19.08.2021 Класс ВЫЧИСЛЯЕТ ЕЩЕ НЕ ОТРРВЛЕННЫЕ СООБЩЕНИЯ НА СЕРВЕР ИЗ ЧАТА
    class ClassCalculateInFieldIDNULLMeanDataValueNotyetsent  {
        ////

    private     String  ТекущаяТаблицаГдеЕстьвIdПолеNULL;

        public ClassCalculateInFieldIDNULLMeanDataValueNotyetsent(Context context,String  ТекущаяТаблицаГдеЕстьвIdПолеNULL) {


            Log.d(this.getClass().getName(), "ТекущаяТаблицаГдеЕстьвIdПолеNULL "
                    +ТекущаяТаблицаГдеЕстьвIdПолеNULL);
        }

        public String getТекущаяТаблицаГдеЕстьвIdПолеNULL() {
            return ТекущаяТаблицаГдеЕстьвIdПолеNULL;
        }

        public void setТекущаяТаблицаГдеЕстьвIdПолеNULL(String текущаяТаблицаГдеЕстьвIdПолеNULL) {
            ТекущаяТаблицаГдеЕстьвIdПолеNULL = текущаяТаблицаГдеЕстьвIdПолеNULL;
        }



        // TODO: 19.08.2021 МЕТОД ВЫЧИСЛЯЕТ ЕЩЕ НЕ ОТРРВЛЕННЫЕ СООБЩЕНИЯ НА СЕРВЕР ИЗ ЧАТА


    private Long МетодВычисляемЕщенеОтправленныеСообщенияНаСервер(CompletionService МенеджерПотоковВнутрений) {

        Long ЕслиВПолеIdЗначениеNUll=0l;

        //
        SQLiteCursor Курсор_ЗначениемФИО_ВообщеЕстьЛиНеОтправленныеСтрочкиСNULLЗначениямивСтолбикеID=null;
        ////
        Class_GRUD_SQL_Operations class_grud_sql_operationsВычисляемЕщенеОтправленныеСообщенияНаСервер;

        try{


            Log.d(this.getClass().getName(), "ТекущаяТаблицаГдеЕстьвIdПолеNULL "
                    +ТекущаяТаблицаГдеЕстьвIdПолеNULL);

            class_grud_sql_operationsВычисляемЕщенеОтправленныеСообщенияНаСервер=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);



            switch (ТекущаяТаблицаГдеЕстьвIdПолеNULL.trim()){



                case "fio":
                case "chats":
                case "data_chat":
                case "tabel":
                case "data_tabels":








           //    ИщемЗначенияNULLВТаблицахЧат.appendWhere("_id  IS NULL ");//_id =  ?


                   /*  sqLiteCursorКурсорсоЗначениемФИО=
                                       КтоНаписалСообщениеФИО.query(ССылкаНаСозданнуюБазу,new String[]{"*"},"_id",new String[]{String.valueOf(ПолученноеФИОКемБылоНаписаноСообщение)},null,null,null,null);*/
            ///
            class_grud_sql_operationsВычисляемЕщенеОтправленныеСообщенияНаСервер. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы",ТекущаяТаблицаГдеЕстьвIdПолеNULL);
            ///////
            class_grud_sql_operationsВычисляемЕщенеОтправленныеСообщенияНаСервер. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","uuid");
            //
           class_grud_sql_operationsВычисляемЕщенеОтправленныеСообщенияНаСервер. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","  _id  IS  NULL    ");
            ///"_id > ?   AND _id< ?"
            //////
         ///  class_grud_sql_operationsВычисляемЕщенеОтправленныеСообщенияНаСервер. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",0);
            ///
                    //////
                   // class_grud_sql_operationsВычисляемЕщенеОтправленныеСообщенияНаСервер. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",0);



/*            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......

            ////TODO другие поля

            ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);*/
            ////
            //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
            ////
            // class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
            ////
            /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
            ////

            // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

            Курсор_ЗначениемФИО_ВообщеЕстьЛиНеОтправленныеСтрочкиСNULLЗначениямивСтолбикеID= (SQLiteCursor)  class_grud_sql_operationsВычисляемЕщенеОтправленныеСообщенияНаСервер.
                    new GetData(contextСозданиеБАзы).getdata(class_grud_sql_operationsВычисляемЕщенеОтправленныеСообщенияНаСервер. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

            Log.d(this.getClass().getName(), "GetData "+Курсор_ЗначениемФИО_ВообщеЕстьЛиНеОтправленныеСтрочкиСNULLЗначениямивСтолбикеID  );


/*


            // TODO: 06.09.2021  _old
            sqLiteCursorКурсорсоЗначениемФИО=
                    (SQLiteCursor)    ИщемЗначенияNULLВТаблицахЧат.query(ССылкаНаСозданнуюБазу,new String[]{"uuid" }
                            ,null,null,null,null,null);
*/


            if(Курсор_ЗначениемФИО_ВообщеЕстьЛиНеОтправленныеСтрочкиСNULLЗначениямивСтолбикеID.getCount()>0){
                //
                Курсор_ЗначениемФИО_ВообщеЕстьЛиНеОтправленныеСтрочкиСNULLЗначениямивСтолбикеID.moveToFirst();
                /////
                 ЕслиВПолеIdЗначениеNUll = Курсор_ЗначениемФИО_ВообщеЕстьЛиНеОтправленныеСтрочкиСNULLЗначениямивСтолбикеID.getLong(0);
                //

                Log.d(this.getClass().getName(), "  СЛУЖБА ДА ДА ДА Сработала !!!!  в таблице ЧАТА chats and data_chat   " +
                        "есть NULL (не отправленные сообщения на сервер ) ФиоКтоНАписалСообщение  " + ЕслиВПолеIdЗначениеNUll  + "\n"+
                        "  ТекущаяТаблицаГдеЕстьвIdПолеNULL " +ТекущаяТаблицаГдеЕстьвIdПолеNULL);
            }

        /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК






                    //
                    break;

            }



    } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
    // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        ////// начало запись в файл
    }

        return  ЕслиВПолеIdЗначениеNUll;
    }

    }





    // TODO: 19.08.2021   КОнец Класс ВЫЧИСЛЯЕТ ЕЩЕ НЕ ОТРРВЛЕННЫЕ СООБЩЕНИЯ НА СЕРВЕР ИЗ ЧАТА
    // TODO: 19.08.2021   КОнец Класс ВЫЧИСЛЯЕТ ЕЩЕ НЕ ОТРРВЛЕННЫЕ СООБЩЕНИЯ НА СЕРВЕР ИЗ ЧАТА




























    /////МЕТОД КОГДА НА СЕРВЕРЕ ВЕРСИЯ ДАННЫХ ВЫШЕ И МЫ ПОЛУЧАЕМ ДАННЫЕ С СЕРВРА
    Integer МетодПолучаемДаннныесСервера(String имяТаблицыОтАндройда_локальноая,
                                         Long ВерсииДанныхНаАндройдеСерверная,
                                      String ДанныеПришёлЛиIDДЛяГенерацииUUID,
                                         Long ВерсииДанныхНаАндройдеЛокальнаяЛокальная
                                ,Long  РезультаПолученаяЛокальнаяВерсияДанныхДляОтправкиНаСервер,CompletionService МенеджерПотоковВнутрений) {
        ////
        Log.d(this.getClass().getName(), "  ДанныеПришёлЛиIDДЛяГенерацииUUID " + ДанныеПришёлЛиIDДЛяГенерацииUUID);

Integer РезультатФоновнойСинхронизации=0;
        ////
        StringBuffer БуферПолученныйJSON = null;
        try {
            Log.d(this.getClass().getName(), "  МетодПолучаемДаннныесСервера" + "  имяТаблицыОтАндройда_локальноая" + имяТаблицыОтАндройда_локальноая);

            //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
            StringBuffer БуферПолучениеДанных = new StringBuffer();

            // TODO: 15.06.2021 получение данных ссервера в фоне

                    try {

                        ////////////////
                        БуферПолучениеДанных = УниверсальныйБуферПолучениеДанныхсСервера(имяТаблицыОтАндройда_локальноая, "",
                        "", "application/json", "Хотим Получить  JSON", ВерсииДанныхНаАндройдеСерверная, ДанныеПришёлЛиIDДЛяГенерацииUUID,120000,null,
                                РезультаПолученаяЛокальнаяВерсияДанныхДляОтправкиНаСервер,"tabel.dsu1.ru", 8888);



                        /////ЦИКЛ ПЕРЕБОРА JSON КОТОРЫЙ ПРИШЁЛ\
                        Log.d(this.getClass().getName(), "  БуферПолучениеДанных.toString()) " + БуферПолучениеДанных.toString());



                    } catch (IOException e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }
                    //////
// TODO: 05.10.2021  ПОЛУЧЕННЫЙ JSON ПОТОК ОТ СЕРВЕРА

            if (БуферПолучениеДанных != null && БуферПолучениеДанных.toString().toCharArray().length > 3) {
                /////
                БуферПолученныйJSON = new StringBuffer();

                /////ЦИКЛ ПЕРЕБОРА JSON КОТОРЫЙ ПРИШЁЛ\
                Log.d(this.getClass().getName(), "  БуферПолучениеДанных.toString()) " + БуферПолучениеДанных.toString());


                // TODO: 05.10.2021  loop

                do {
                    БуферПолученныйJSON.append(БуферПолучениеДанных.toString());



                    Log.d(this.getClass().getName(), " БуферПолученныйJSON внутри цикла  " + БуферПолученныйJSON.toString());


                } while (БуферПолучениеДанных == null);
                //////



                ////////Присылаем количестов строчек обработанных на сервлете
                Log.d(this.getClass().getName(), " БуферПолученныйJSON.length()  " + БуферПолученныйJSON.length());
                //////
                Log.d(this.getClass().getName(), " БуферПолученныйJSON  " + БуферПолученныйJSON.toString());
                ////
                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                int Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы = 0;


                Log.i(this.getClass().getName(), "   Результат_ПриписиИзменнийВерсииДанныхВФоне:"
                        + Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы + " имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);


                /////////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА
                Log.d(this.getClass().getName(), " Данных нет c сервера сам файл JSON  ");
            }

            //////


            // TODO: 05.10.2021   ПОЛУЧИЛИ ДАННЫХ С СЕРВЕРА  
            // TODO: 05.10.2021   ПОЛУЧИЛИ ДАННЫХ С СЕРВЕРА  

            if (БуферПолученныйJSON != null && БуферПолученныйJSON.toString().toCharArray().length > 3) {

                Log.d(this.getClass().getName(), "  БуферПолученныйJSON " + БуферПолученныйJSON.toString());

                ///как только получиили данные как первый запуска переключаем флаг что далее будет не первый запуск , ТО ТОГДА МЫ ФИЛЬТР ОБНОВЛЯНЕМ И ПЕРЕКОЛЮЧЕМ ЕГО НА НЕ ПЕРВЫЙ ЗАПУСК
            
                
                
                
                
                try {
                    //////TODO запускаем метод распарстивая JSON
                    РезультатФоновнойСинхронизации=        МетодПарсингJSONФайлаОтСервреравФоне(БуферПолученныйJSON, имяТаблицыОтАндройда_локальноая,МенеджерПотоковВнутрений);/////ЗАПУСК МЕТОДА ПАСРИНГА JSON



                    Log.i(this.getClass().getName(), " РезультатФоновнойСинхронизации  "  +РезультатФоновнойСинхронизации);
                    
                    //поймать ошибку всего классаIOException | MyException e    NumberFormatException
                } catch (Exception e) {
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                }


            } else {
                Log.i(this.getClass().getName(), " Сервер пристал пустой файл Запрос по вашем параметрам не т данных в сервере (SQL Server)  БуферПолученныйJSON ");
            }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
        Log.i(this.getClass().getName(), " РезультатФоновнойСинхронизации "+РезультатФоновнойСинхронизации);

        РезультатФоновнойСинхронизации= РезультатФоновнойСинхронизации+  РезультатФоновнойСинхронизации;
        /////
        return РезультатФоновнойСинхронизации;
    }












    /////// TODO МЕТОД ПАСРИНГА ПРИШЕДШЕГО  С СЕРВЕРА ВНУТРИ ASYNSTASK В ФОНЕ
    Integer МетодПарсингJSONФайлаОтСервреравФоне(StringBuffer БуферПолученныйJSON,
                                                 String имяТаблицыОтАндройда_локальноая,
                                                 CompletionService МенеджерПотоковВнутрений) throws InterruptedException, JSONException {
        ///
        Integer РезулттаВставкиИЛИОбвлоенияФФоне = 0;


        Log.d(this.getClass().getName(), " БуферПолученныйJSON " + БуферПолученныйJSON.toString());


        ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных

        //////
        //////
        ////TODO ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON
        JSONObject JSON_ПерваяЧасть = new JSONObject(БуферПолученныйJSON.toString());/////ВАЖНО ПОЛУЧЕНИЕ JSON ОБЬЕКТОВ ИЗ БУФЕРА , ЧТОБЫ ДАЛЛЕ РАЗНЕСТИ ЕГО ПО СТРОЧКАМ
        ////TODO ДВИЖОК ПАРСИНГ JSON
        JSONArray JSON_ВтораяЧасть = JSON_ПерваяЧасть.names();////КОЛИЧЕСТВВОсТРОЧЕК В JSON
        //////todoОбнуялем
        ///TODO
        boolean СработалПоворот = false;
        ///////TODO ОПРЕДЕЛЯЕМ ОБЩЕЕ КОЛИЧЕСТВО JSON ВСЕГО МЕТОД
        ///TODO симофор устанавлием


        ///TODO SLEEP
        ////


        ///TODO Для Получение данных с сервера

/*            ContentValues АдаптерПриОбновленияДанныхсСервера = new ContentValues();
            //////
            ContentValues    АдаптерДляВставкиДанныхсСервер = new ContentValues();*/

        HashMap<String, Integer> ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек = new HashMap<>();

        //TODO пытаемся СделатьОчреть


        // Iterator<String> iteratorГлавныйПарсингJSONОтСервера = JSON_ПерваяЧасть.keys();



        Iterator<String> iteratorJSON = JSON_ПерваяЧасть.keys();


        //////TODO ИДЁМ ПО СТРОКАМ --JSON
        Integer РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций = ИндексТекущейОперацииJSONДляВизуальнойОбработки;




        while (iteratorJSON.hasNext()) {
            //////TODO ИДЁМ ПО СТРОКАМ --JSON

            //// todo парсинг данных которы е пришли с сервера JSON ОБРАБОТКАТ СТРОК
            //  while ( iteratorГлавныйПарсингJSONОтСервера.hasNext() ) {
            try {

                //TODO ЗАСЫПАЕТ ЦИКЛ ВАЖНО ДЛЯ ОТОБРАЖЕНИЯ КОЛИЧЕСТВРОСТРОК ПРИ РАСПАРСИВАНИИ JSON ПЕРВЫЙ  ---ПОЛУЧЕНИЕ ДАННЫХ
                 /*   try {
                        TimeUnit.MILLISECONDS.sleep(0);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }*/
//     .tryLock(5, TimeUnit.MILLISECONDS);


                ////


                /// ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ


                ///////  ----- TODO НЕПОСРЕДСТВЕННО САМ JSON
                String JSON_ТретьяЧасть = null;

                ////TODO СДВИГАЕМ ИТЕРАТОР ПРИ СИНХРОНИЗАЦИИИ НЕ СНАЧАЛА

                ///TODO без сдвига
                JSON_ТретьяЧасть = (String) iteratorJSON.next();//// iteratorГлавныйПарсингJSONОтСервера.next();
                /////
                Log.d(this.getClass().getName(), " Текущая строка json которй пришел сервера " + " JSON_ТретьяЧасть " + JSON_ТретьяЧасть);

////todo передаем количество операций для визуализации обновлениея  вставки

                ///

                Log.d(this.getClass().getName(), " JSON_ТретьяЧасть  " + JSON_ТретьяЧасть + " JSON_ТретьяЧасть   " + JSON_ТретьяЧасть.length());
                /////
                JSONObject JSON_ЧетвертаяЧасть = null;

                JSON_ЧетвертаяЧасть = JSON_ПерваяЧасть.getJSONObject(JSON_ТретьяЧасть);

                Log.d(this.getClass().getName(), " JSON_ЧетвертаяЧасть " + JSON_ЧетвертаяЧасть.toString() + " JSON_ЧетвертаяЧасть " + JSON_ЧетвертаяЧасть.length());
                //////
                JSONObject JSON_ПятаяЧасть = null;


                JSON_ПятаяЧасть = new JSONObject(String.valueOf(JSON_ЧетвертаяЧасть));

                Log.d(this.getClass().getName(), " ОбьектыJSONvalue" + JSON_ПятаяЧасть.toString());

                ///TODO  UPDATE КОНТЕЙНЕРЫ


                /////TODO ПАРСИНГ JSON ПРИШЁЛ С СЕРВЕРА SQL SERVER
                String JSON_ИмяСтолбца = new String();

                String JSON_ИмяСтолбцаПосик = new String();

                String JSON_ИмяСодержимое = new String();


                //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ
                ///TODO  UPDATE КОНТЕЙНЕРЫ    //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ

                АдаптерПриОбновленияДанныхсСервера = new ContentValues();


                ///TODO  INSERT КОНТЕЙНЕРЫ    //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ
                АдаптерДляВставкиДанныхсСервер = new ContentValues();

//////////
///TODO  ОБНУЯЛЕМ ПЕРЕД НОВОЙ СТРОЧКОЙ    //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ

                Long UUIDПолученныйИзПришедшегоJSON = 0l;
                ///TODO  ОБНУЯЛЕМ ПЕРЕД НОВОЙ СТРОЧКОЙ    //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ
                Integer IDИзПришедшегоJSON = 0;
//

                //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ

                Boolean ЕслиВСтоликахUUIDПоле = false;
                //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ
                Boolean ЕслиВСтоликахIDПоле = false;
                ///

                //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ

                UUIDПолеУжеПроверелиЧерезКурсор = false;
                //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ
                IDПолеУжеПроверелиЧерезКурсор = false;

                //todo обнуляем данные укакзатели перед каждой НОВОЙ СТРЧКОЙ




                //////TODO ИДЁМ ПО СТОЛБЦАМ --JSON
                for (int ИндексПеремещенияПоСтрокеJSON = 0; ИндексПеремещенияПоСтрокеJSON < JSON_ЧетвертаяЧасть.length(); ИндексПеремещенияПоСтрокеJSON++) {

                    //////TODO ИДЁМ ПО СТРОКАМ --JSON
                    //TODO сомо имя json
                    JSON_ИмяСтолбца = (String) JSON_ПятаяЧасть.names().get(ИндексПеремещенияПоСтрокеJSON);
                    /////////////
                    JSON_ИмяСтолбца = JSON_ИмяСтолбца.trim();
                    /////////////////////
                    System.out.println("  JSON_ИмяСтолбца  " + JSON_ИмяСтолбца);


                    ////TODO само значение json

                    JSON_ИмяСодержимое = String.valueOf(JSON_ПятаяЧасть.get(String.valueOf(JSON_ИмяСтолбца)));
                    ///
                    JSON_ИмяСодержимое = JSON_ИмяСодержимое.trim();
//////////////////////////
                    System.out.println("  JSON_ИмяСодержимое  " + JSON_ИмяСодержимое);



                        // TODO: 14.10.2021 ТОЛЬКО ID КОГДА НЕТ ID
                        /////TODO если  ID

                        if (JSON_ПятаяЧасть.has("id")==true) {
                            ///
                            Object  IDИзПришедшегоJSONВнутри  =   JSON_ПятаяЧасть.get("id");
                            ///
                            IDИзПришедшегоJSON=Integer.parseInt(String.valueOf(IDИзПришедшегоJSONВнутри));
                            /////
                            System.out.println("  IDИзПришедшегоJSON  " + IDИзПришедшегоJSON);
                        }else {


                            // TODO: 14.10.2021 ТОЛЬКО ID КОГДА НЕТ UUID
                            //////
                            if (JSON_ПятаяЧасть.has("uuid")==true) {
                                // TODO: 14.10.2021 ТОЛЬКО ID КОГДА НЕТ UUID
                                //////
                                Object UUIDПолученныйИзПришедшегоJSONВнутри =  JSON_ПятаяЧасть.get("uuid");
                                ///
                                UUIDПолученныйИзПришедшегоJSON=Long.parseLong(String.valueOf(UUIDПолученныйИзПришедшегоJSONВнутри));

                                System.out.println("  UUIDПолученныйИзПришедшегоJSON  " + UUIDПолученныйИзПришедшегоJSON);





                                // TODO: 14.10.2021 ТОЛЬКО ID КОГДА НЕТ ID
                            }


                        }






                    // TODO: 16.09.2021


                    Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца + " JSON_ИмяСодержимое  " + JSON_ИмяСодержимое + " IDИзПришедшегоJSON "
                            + IDИзПришедшегоJSON + "  JSON_ИмяСодержимое.length() " + JSON_ИмяСодержимое.length());


                    // TODO: 27.05.2021 механиз удаление из таблицы Уведомлений Лишних Значений


                    if (имяТаблицыОтАндройда_локальноая.equalsIgnoreCase("notification") && JSON_ИмяСтолбцаПосик.equalsIgnoreCase("id")) {

                        // TODO: 27.05.2021  заполянем ХЭШ для только дтаблица Уведомления
                        ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек.put(JSON_ИмяСтолбцаПосик, IDИзПришедшегоJSON);

                        ///////
                        Log.d(this.getClass().getName(), "   ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек " +
                                ХэшIDУведомленияДляПриняитиеРешениеУлалениеЛишнихСтрочек.values());
                    }


                    // TODO: 14.09.2021
                    Log.d(this.getClass().getName(), " JSON_ИмяСтолбца.toString() " + JSON_ИмяСтолбца);


                    /////todo метод заполенения получым json файлом В АДАПТЕР ВСТАВКИ И/ИЛИ ОБНОВЛЕНИЕ ПРОСТО ЗАПОЛЯНЕМ


                    // TODO: 15.09.2021  ЛЮБОЕ ТЕКУЩЕЕЕ ПОЛЕ В НУТРИ ИДУЩЕГО ЦИКЛА
                    if (JSON_ИмяСтолбца.length() > 0) {


                        // TODO: 15.09.2021  ДВА МЕТОДА ЗАПОЛЕНИЯ  КОНТЕРЙНЕРА   ЧЕРЕЗ UUID, ТОЛЬКО ПРИ НАЛИИ ЗАПОЛНЕНОГО ПОЛЯ UUID НЕ NULL
                        // TODO: 14.09.2021



                            // TODO: 15.09.2021


                            // TODO: 15.09.2021  ДВА МЕТОДА ЗАПОЛЕНИЯ КОНТЕРЙНЕРА  ЧЕРЕЗ ID, ТОЛЬКО ПРИ НАЛИИ ЗАПОЛНЕНОГО ПОЛЯ ID НЕ NULL

                            Log.d(this.getClass().getName(), " IDИзПришедшегоJSON " + IDИзПришедшегоJSON);

                            if (IDИзПришедшегоJSON>0 ) {
                                //

                                Log.d(this.getClass().getName(), " IDИзПришедшегоJSON " + IDИзПришедшегоJSON);
                                ///
                                МетодЗаполнениеПолученымJSONсСервераВКонтейнерТолькоПоIDвФоне(JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая,
                                        String.valueOf(IDИзПришедшегоJSON),МенеджерПотоковВнутрений);//////МЕТОД ЗАПОЛЕНЕНИЯ JSON ПОЛЕЙ ПОЛУЧЕННЫЙ С СЕРВЕРА В КОНТЕЙНЕР  ДЛЯ ОПРЕДЕЛЕНИЯ ВСТАВЛЯИ ИЛИ ОБНОВЛЯТЬ

                            }else {



                                Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON " + UUIDПолученныйИзПришедшегоJSON);


                                if (UUIDПолученныйИзПришедшегоJSON>0) {
                                    ///
                                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON " + UUIDПолученныйИзПришедшегоJSON);
                                    ////
                                    МетодЗаполнениеПолученымJSONсСервераВКонтейнерТолькоПОUUIDвФоне(String.valueOf(UUIDПолученныйИзПришедшегоJSON),
                                            JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая,МенеджерПотоковВнутрений);//////МЕТОД ЗАПОЛЕНЕНИЯ JSON ПОЛЕЙ ПОЛУЧЕННЫЙ С СЕРВЕРА В КОНТЕЙНЕР  ДЛЯ ОПРЕДЕЛЕНИЯ ВСТАВЛЯИ ИЛИ ОБНОВЛЯТЬ


                                }

                            }




                        //


                    }


                    Log.d(this.getClass().getName(), " АдаптерПриОбновленияДанныхсСервера  :: " + АдаптерПриОбновленияДанныхсСервера.size() + "\n" +
                            " АдаптерДляВставкиДанныхсСервер " + АдаптерДляВставкиДанныхсСервер.size());


                }///todo end for СТОЛБЦЫ


                //
                //////// TODO МЕТОД ПЕРОСРЕДСТВЕНОЙ ЗАПИСЬ В  БАЗУ АНДРОЙДА ДАННЫМИС SQL SERVER метод конкретной записо заполеного контерйнра json в  базуу

                Integer Результат_ОбновлениеДаннымисСервера = МетодаЗаписиВБазуКонтейнераОБНОВЛЕНИЕJSONвФоне(имяТаблицыОтАндройда_локальноая,
                        UUIDПолученныйИзПришедшегоJSON, IDИзПришедшегоJSON,МенеджерПотоковВнутрений,
                        Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу(),СколькоСтрочекJSON,
                        ИндексТекущейОперацииJSONДляВизуальнойОбработки,ФиналПроценты);///////после того как
/////

                Log.d(this.getClass().getName(), " Результат_ОбновлениеДаннымисСервера  :: " + Результат_ОбновлениеДаннымисСервера);


// TODO: 09.09.2021 ДВЕ ОПЕРАЦИИ ВСТАВКА И ОБНОВЛНИЕ


                //////// TODO МЕТОД ПЕРОСРЕДСТВЕНОЙ ЗАПИСЬ В  БАЗУ АНДРОЙДА ДАННЫМИС SQL SERVER метод конкретной записо заполеного контерйнра json в  базуу

                Long Результат_ВставкаДаннымисСервера = МетодаЗаписиВБазуКонтейнераВСТАВКАJSONвФоне(имяТаблицыОтАндройда_локальноая,
                        МенеджерПотоковВнутрений,
                        Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу(),СколькоСтрочекJSON,
                        ИндексТекущейОперацииJSONДляВизуальнойОбработки,ФиналПроценты);///////после того как
/////

                Log.d(this.getClass().getName(), " Результат_ВставкаДаннымисСервера :::  " + Результат_ВставкаДаннымисСервера);




/////TODO СЛИЯНИЕ ОПЕРАЦИЙ ВСТАВКИ И ОБНОВЛЕНИЯ ОПЕРАЦИЙ В ОДНУ




                Log.d(this.getClass().getName(), " Результат_ОбновлениеДаннымисСервера :::  "
                        + Результат_ОбновлениеДаннымисСервера+ "  Результат_ВставкаДаннымисСервера "
                        +Результат_ВставкаДаннымисСервера);


                // TODO: 13.10.2021   УВЕЛИЧИВАЕМ НА 1 СТРОКУ ОБРАБОТКИ ДАННЫХ

                if ( Результат_ВставкаДаннымисСервера>0 ) {
                    // TODO: 13.10.2021

                    ИндексТекущейОперацииJSONДляВизуальнойОбработки++;
                    // TODO: 13.10.2021
                    Log.d(this.getClass().getName(), "  Результат_ОбновлениеДаннымисСервера " + Результат_ОбновлениеДаннымисСервера + " Результат_ВставкаДаннымисСервера " + Результат_ВставкаДаннымисСервера+
                            " ИндексТекущейОперацииJSONДляВизуальнойОбработки  "  +ИндексТекущейОперацииJSONДляВизуальнойОбработки);

                }
                // TODO: 13.10.2021   УВЕЛИЧИВАЕМ НА 1 СТРОКУ ОБРАБОТКИ ДАННЫХ

                if (Результат_ОбновлениеДаннымисСервера > 0  ) {
                    // TODO: 13.10.2021
                    ИндексТекущейОперацииJSONДляВизуальнойОбработки++;
                    // TODO: 13.10.2021
                    Log.d(this.getClass().getName(), "  Результат_ОбновлениеДаннымисСервера " + Результат_ОбновлениеДаннымисСервера
                            + " Результат_ВставкаДаннымисСервера " + Результат_ВставкаДаннымисСервера+
                            " ИндексТекущейОперацииJSONДляВизуальнойОбработки  "  +ИндексТекущейОперацииJSONДляВизуальнойОбработки);

                    ////
                }






                Log.d(this.getClass().getName(), " РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций" + РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций +
                        "  Результат_ОбновлениеДаннымисСервера " + Результат_ОбновлениеДаннымисСервера + " Результат_ВставкаДаннымисСервера " + Результат_ВставкаДаннымисСервера+
                         " ИндексТекущейОперацииJSONДляВизуальнойОбработки  "  +ИндексТекущейОперацииJSONДляВизуальнойОбработки);
                /////



            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                // TODO: 01.09.2021 метод вызова
                new Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ////// начало запись в файл
            }




           /// iteratorJSON.remove();

            // TODO: 25.08.2021 выкидываем из памяти





        }




        //
        Log.d(this.getClass().getName(), " Конец  ПАРСИНГА ОБРАБОАТЫВАЕМОМЙ ТАБЛИЦЫ  ::::: "
                + имяТаблицыОтАндройда_локальноая  + "  РезультатВставкаИлиОбнолвенияВФоне " +РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций+
                 " ИндексТекущейОперацииJSONДляВизуальнойОбработки " +ИндексТекущейОперацииJSONДляВизуальнойОбработки);
        /////
        // TODO: 14.10.2021 обьядиняем две операции вставки и обновлении слияние для ответа произвошли изменения вообщем по таблице

        if (ИндексТекущейОперацииJSONДляВизуальнойОбработки> РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций) {

            // TODO: 14.10.2021
            РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций=1;



        } else {
            // TODO: 14.10.2021
            РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций=0;
        }

        Log.d(this.getClass().getName(), "  РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций " + РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций);
        //todo end for



        //////////
        /////////////
        return РезультатВставкаИлиОбнолвенияВФонеОбщийДвухОпераций;
    }



















// TODO: 15.09.2021  ЗАПОЛНЕНИЯ КОНТЕЙНЕРА ТОЛЬКО UUID

    //////МЕТОД ТОЛЬКО ЗАПОЛЕНИЕЯ КОНТЕЙНЕРА ВСТАВКИ И ОБНОВЛЕНИЕ ДАННЫХ КОТОРЫЕ ПРИШЛИ С СЕРВЕРА
    Integer МетодЗаполнениеПолученымJSONсСервераВКонтейнерТолькоПОUUIDвФоне( String UUIDПолученныйИзПришедшегоJSON, String JSON_ИмяСтолбца, String JSON_ИмяСодержимое
            , String имяТаблицыОтАндройда_локальноая,CompletionService МенеджерПотоковВнутрений) { /////МЕТОД ЗАПОЛЕНЕИЯ КОНТЕЙНЕРОМ JSON ПОЛЯМИы
        //
        Integer  РезультатЗаполенияКонтейнераДляВставкиИДляОбновления=0;
        //////TODO анализиует СТОЛЮИК UUID

        try {


            ///TODO ДАННЫЙ КОД ОБРЕЗАЮТ ДАТУ А ТРИ НАЗАД ЕСЛИ ДЛИНА ДАТЫ РОВНЯЕТЬСЯ 22 СИМВОЛА
/*            if (JSON_ИмяСтолбца.equalsIgnoreCase("date_update")) {
                //Todo цикл обработаки лишних символом даты date_update
                while (true) {
                    if (JSON_ИмяСодержимое.length() > 19) {
                        ////TODO УДАЛЯЕМ СИЩГИЕ СИМВОЛЫ В  ДАТЕ
                        JSON_ИмяСодержимое = JSON_ИмяСодержимое.substring(0, JSON_ИмяСодержимое.length() - 1);

                    } else {
                        // code block to be executed
                        Log.d(this.getClass().getName(), " JSON_ИмяСодержимое " + JSON_ИмяСодержимое + " JSON_ИмяСодержимое.length()  " + JSON_ИмяСодержимое.length());
                        break;
                    }

                }
            }*/

            ////ДЛЯ НАЧАЛО ОЦЕНИВАЕМ ЕСЛИ UUID В ЭТОЙ ТЕКУЩЕЙ ЗАПИСИ ,, ЗАПОМИНАЕМ ЕГО И ДАЛЕЕ ОТ РЕЗУЛЬТАТО В НАЧИНАЕМ ЛИБО ВСТАКУ ЛИБО ОБНОВЛЕНИЕ АДАЕЫХ
            ////////ПРОВЕРЯЕМ UUID ЕСЛИ Т ЕКУЩЕЕ ПОЛЕ UUID
            Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца);


            String ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде = null;

            String ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде = null;


            //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ      //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ        //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ

            //////TODO вторым флагом запрещем при первом запуске заниматься обновдениям  только вставка  при синхронизации ==false значить обнолвение включено ,,,,, ЗНАЧАЕТ ЧТО ИДЕТ ТОЛЬКО ВСТАВКА ДАННЫХ TRUE
            // final boolean ДанныйФлагРазрешаетОбновлеениеТОлькоПослеПерсвойСинхронизации = PUBLIC_CONTENT.ФлагПриПервомЗапускеОграничитьОперациюТолькоВставка;


//final boolean СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации=PUBLIC_CONTENT.ФлагРазрешаетОбновлениеПриСинхронизации;
            //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID


            //////
            // TODO: 16.03.2021 выбираем как обнолять через uuid and id
            if (UUIDПолученныйИзПришедшегоJSON != null) {
                //////
                if (UUIDПолученныйИзПришедшегоJSON.length() > 0) {
                    /////TODO запрет на обновление если Первая Синхронизация

                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON " + UUIDПолученныйИзПришедшегоJSON.length() + "JSON_ИмяСтолбца " + JSON_ИмяСтолбца);

                    //TODO UUID
        РезультатЗаполенияКонтейнераДляВставкиИДляОбновления=
                МетодАнализаUUIDСинхрониазциявФоне(UUIDПолученныйИзПришедшегоJSON, JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая,МенеджерПотоковВнутрений);
             //////////todo
                    Log.d(this.getClass().getName(), " РезультатЗаполенияКонтейнераДляВставкиИДляОбновления " +РезультатЗаполенияКонтейнераДляВставкиИДляОбновления);

                    //////TODO анализиует СТОЛЮИК UUID
                }


                // TODO: 16.03.2021 когда нет UUID
            }

            // Log.d(this.getClass().getName(), " СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации " + СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации);


            //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ


            ////TODO САМО ДЕЛЕНИЕ ДАННЫХ С СЕРВЕРА НА ВСТАВКУ ДАННЫХ ИЛИ ЕЕ ОБНОВЛЕНИЯ ЗАВИСМОСТИ ЕСЛИ  UUID ИЛИ ID


            ////
            /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
        return  РезультатЗаполенияКонтейнераДляВставкиИДляОбновления;
    }












// TODO: 15.09.2021  ЗАПОЛНЕНИЯ КОНТЕЙНЕРА ТОЛЬКО ID

    //////МЕТОД ТОЛЬКО ЗАПОЛЕНИЕЯ КОНТЕЙНЕРА ВСТАВКИ И ОБНОВЛЕНИЕ ДАННЫХ КОТОРЫЕ ПРИШЛИ С СЕРВЕРА
    Integer МетодЗаполнениеПолученымJSONсСервераВКонтейнерТолькоПоIDвФоне(String JSON_ИмяСтолбца, String JSON_ИмяСодержимое
            , String имяТаблицыОтАндройда_локальноая, String IDИзПришедшегоJSON,CompletionService МенеджерПотоковВнутрений) { /////МЕТОД ЗАПОЛЕНЕИЯ КОНТЕЙНЕРОМ JSON ПОЛЯМИы
        //

        //////TODO анализиует СТОЛЮИК UUID
        Integer РезультатЗаполенияКонтейнераДляВставкиИДляОбновления=0;
        ////
        try {


            ///TODO ДАННЫЙ КОД ОБРЕЗАЮТ ДАТУ А ТРИ НАЗАД ЕСЛИ ДЛИНА ДАТЫ РОВНЯЕТЬСЯ 22 СИМВОЛА
           /*   if (JSON_ИмяСтолбца.equalsIgnoreCase("date_update")) {
              //Todo цикл обработаки лишних символом даты date_update
                while (true) {
                    if (JSON_ИмяСодержимое.length() > 19) {
                        ////TODO УДАЛЯЕМ СИЩГИЕ СИМВОЛЫ В  ДАТЕ
                        JSON_ИмяСодержимое = JSON_ИмяСодержимое.substring(0, JSON_ИмяСодержимое.length() - 1);

                    } else {
                        // code block to be executed
                        Log.d(this.getClass().getName(), " JSON_ИмяСодержимое " + JSON_ИмяСодержимое + " JSON_ИмяСодержимое.length()  " + JSON_ИмяСодержимое.length());
                        break;
                    }

                }
            }*/

            ////ДЛЯ НАЧАЛО ОЦЕНИВАЕМ ЕСЛИ UUID В ЭТОЙ ТЕКУЩЕЙ ЗАПИСИ ,, ЗАПОМИНАЕМ ЕГО И ДАЛЕЕ ОТ РЕЗУЛЬТАТО В НАЧИНАЕМ ЛИБО ВСТАКУ ЛИБО ОБНОВЛЕНИЕ АДАЕЫХ
            ////////ПРОВЕРЯЕМ UUID ЕСЛИ Т ЕКУЩЕЕ ПОЛЕ UUID
            Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца);


            String ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде = null;

            String ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде = null;


            //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ      //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ        //////TODO А ТУТ ОБНОВЛЕНИЕ ДАННЫХ

            //////TODO вторым флагом запрещем при первом запуске заниматься обновдениям  только вставка  при синхронизации ==false значить обнолвение включено ,,,,, ЗНАЧАЕТ ЧТО ИДЕТ ТОЛЬКО ВСТАВКА ДАННЫХ TRUE
            // final boolean ДанныйФлагРазрешаетОбновлеениеТОлькоПослеПерсвойСинхронизации = PUBLIC_CONTENT.ФлагПриПервомЗапускеОграничитьОперациюТолькоВставка;


//final boolean СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации=PUBLIC_CONTENT.ФлагРазрешаетОбновлениеПриСинхронизации;
            //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID             //////TODO анализиует СТОЛЮИК ID


            //////
            // TODO: 16.03.2021 выбираем как обнолять через uuid and id

                if (IDИзПришедшегоJSON!=null) {
                    ////
                    if (IDИзПришедшегоJSON.length() > 0) {
                        ///
                        Log.d(this.getClass().getName(), "JSON_ИмяСтолбца " + JSON_ИмяСтолбца + " IDИзПришедшегоJSON " + IDИзПришедшегоJSON);
                        ////TODO ID
                        РезультатЗаполенияКонтейнераДляВставкиИДляОбновления=
                                МетодАнализаIDСинхрониазциивФоне( JSON_ИмяСтолбца, JSON_ИмяСодержимое, имяТаблицыОтАндройда_локальноая, IDИзПришедшегоJSON,МенеджерПотоковВнутрений);

                        //////////todo
                        Log.d(this.getClass().getName(), " РезультатЗаполенияКонтейнераДляВставкиИДляОбновления " +РезультатЗаполенияКонтейнераДляВставкиИДляОбновления);
                    }
                }



            // Log.d(this.getClass().getName(), " СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации " + СтатусРеазрешеноЛиОбновлениеПриПервойЧинхронизации);


            //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ       //////TODO А ТУТ ВСТАВКА ДАННЫХ


            ////TODO САМО ДЕЛЕНИЕ ДАННЫХ С СЕРВЕРА НА ВСТАВКУ ДАННЫХ ИЛИ ЕЕ ОБНОВЛЕНИЯ ЗАВИСМОСТИ ЕСЛИ  UUID ИЛИ ID


            ////
            /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
        return  РезультатЗаполенияКонтейнераДляВставкиИДляОбновления;
    }









































    //////////////TODO метод непосредвственой запись в базу данных json КОТОРЫЙ ПРИШЁЛ С СЕРВЕРА---!!!!! ПЕРВАЯ ОПЕРПЦИЯ ВСТАВКА
    Long МетодаЗаписиВБазуКонтейнераВСТАВКАJSONвФоне(String имяТаблицыОтАндройда_локальноая,
                                                     @NotNull CompletionService МенеджерПотоков,
                                                     SQLiteDatabase getБазаДанныхДЛяОперацийВнутри
                                                      ,Integer СколькоСтрочекJSON,
                                                     Integer ИндексТекущейОперацииJSONДляВизуальнойОбработки,
                                                     Float ФиналПроценты ) {////запись полученого json   от сервера через контейнер

        Log.d(this.getClass().getName(), " ИндексТекущейОперацииJSONДляВизуальнойОбработки  " +  ИндексТекущейОперацииJSONДляВизуальнойОбработки + " МенеджерПотоков "+ МенеджерПотоков
        + "  ФиналПроценты " +ФиналПроценты+ " имяТаблицыОтАндройда_локальноая " +имяТаблицыОтАндройда_локальноая+  "СколькоСтрочекJSON " +СколькоСтрочекJSON);

        Long РезультатВставкиЧерезКонтрейнер = 0l;

        try {


            //////////todo ВСТАВКА JSON НА КЛИЕНТА ДАННЫЕ С СЕРВЕРА
            Log.i(this.getClass().getName(), "  АдаптерДляВставкиПриВставкиДанныхсСервера      " + АдаптерДляВставкиДанныхсСервер.size());


            if (АдаптерДляВставкиДанныхсСервер.size() > 0) {///если в контенер заполнилься то начинаем вставку
                ////////ВЫЗЫВАЕМ ВСТАВКУ ДАННЫХ



                // TODO: 10.09.2021 сама операция всатвки

                РезультатВставкиЧерезКонтрейнер = ВставкаДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая, АдаптерДляВставкиДанныхсСервер, имяТаблицыОтАндройда_локальноая,
                        "", true,
                        СколькоСтрочекJSON, true, КонтекстСинхроДляКонтроллераВФоне,ActivityДляСинхронизацииОбмена,МенеджерПотоков,getБазаДанныхДЛяОперацийВнутри,СколькоСтрочекJSON,
                        ИндексТекущейОперацииJSONДляВизуальнойОбработки,ФиналПроценты);

                ///
                Log.d(this.getClass().getName(), "РезультатВставкиЧерезКонтрейнер   " + РезультатВставкиЧерезКонтрейнер);




                /// после вствки в базу обнуляем контейнер данные от сервера
                if (РезультатВставкиЧерезКонтрейнер > 0) {
                    //////
                    //// todo ПРИ УСПЕШНОЙ ВСТАВКИ ДАННЫХ  ПЕРЕДАЕМ СТАТИЧНОМУ СЁЧИКК  ОБНОВЛЕНИЙ ЧТО НАДО УВЕЛИЧИТ ЗНАЧЕНИЕ НА 1+

                    /////TODO ВАЖНО ПОСЛЕ УСПЕШНОЙ ОБРАБОТКИ ПРИСВАИВАЕМ ЗНАЧЕНИЕ присваиваем наверх факсическое значение идущего цикла После Успешного прохода ТАБЛИЦЫ одной ИЗ
                    Log.d(this.getClass().getName(), " РезультатВставкиЧерезКонтрейнер" + РезультатВставкиЧерезКонтрейнер);
                    ///TODO переводим ввобщим в универсальный индификатор


                    ///


                }
                ///
                //  АдаптерДляВставкиДанныхсСерверБуфер.clear();

                АдаптерДляВставкиДанныхсСервер.clear();


                //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON     //// ДВИЖОК ПАРСИНГ JSON
                ///


            }
            //////////todo ВСТАВКА JSON НА КЛИЕНТА ДАННЫЕ С СЕРВЕРА


            ////////// TODO ОБНОВЛЕНИЕ JSON НА КЛИЕНТА


            ///TODO если что -то открыта закрыть

            /////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }/*finally {
            //////Удаляем из памяти Асинтаск
            if (Курсор_УзнатьЕслиНаАндройдеТакойUUID != null) {

                if(!Курсор_УзнатьЕслиНаАндройдеТакойUUID.isClosed()) {

                    Курсор_УзнатьЕслиНаАндройдеТакойUUID.close();

                    Курсор_УзнатьЕслиНаАндройдеТакойUUID = null;
                }

            }

            ////
            if (Курсор_УзнатьЕслиНаАндройдеТакойID != null) {

                if (!Курсор_УзнатьЕслиНаАндройдеТакойID.isClosed()){

                    Курсор_УзнатьЕслиНаАндройдеТакойID.close();

                    Курсор_УзнатьЕслиНаАндройдеТакойID = null;
                }


            }
        }*/
        return  РезультатВставкиЧерезКонтрейнер;
    }


// TODO: 09.09.2021  КОНЕЦ ОПЕРАЦИИ ВСТАВКИ















    //////////////TODO метод непосредвственой запись в базу данных json КОТОРЫЙ ПРИШЁЛ С СЕРВЕРА  ВТОРАЯ ОПЕРАЦИЯ ОБНОВЛЕНИЯ !!!!!!!
    Integer МетодаЗаписиВБазуКонтейнераОБНОВЛЕНИЕJSONвФоне( @NotNull  String имяТаблицыОтАндройда_локальноая,
                                                            @NotNull Long UUIDПолученныйИзПришедшегоJSON,
                                                            @NotNull    Integer IDИзПришедшегоJSON,
                                                            @NotNull CompletionService МенеджерПотоков,

                                                            SQLiteDatabase getБазаДанныхДЛяОперацийВнутри,
                                                            Integer СколькоСтрочекJSON,
                                                            Integer ИндексТекущейОперацииJSONДляВизуальнойОбработки,
                                                            Float ФиналПроценты) {////запись полученого json   от сервера через контейнер

        Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON  " + UUIDПолученныйИзПришедшегоJSON+ "  СколькоСтрочекJSON " +СколькоСтрочекJSON);

        ////
        Integer РезультатОбновлениеЧерезКонтрейнер = 0;


        try {


            //////////todo ВСТАВКА JSON НА КЛИЕНТА ДАННЫЕ С СЕРВЕРА

            ////////// TODO ОБНОВЛЕНИЕ JSON НА КЛИЕНТА
            Log.i(this.getClass().getName(), "  АдаптерДляОбновленияПриВставкиДанныхсСервера " + АдаптерПриОбновленияДанныхсСервера.size());

            if (АдаптерПриОбновленияДанныхсСервера.size() > 0) {///если в контенер заполнилься то начинаем обновление
                ////////ВЫЗЫВАЕМ ОБНОВЛЕНИЕ


                /////TODO делим обновление на два вида если есть UUID ИЛИ НЕТ А ЕСТЬ ID

                ///TODO когда есть только UUID
                if (UUIDПолученныйИзПришедшегоJSON>0) {

                        //////todo UUID UPDATE
                        РезультатОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая, АдаптерПриОбновленияДанныхсСервера,
                                String.valueOf(UUIDПолученныйИзПришедшегоJSON),
                                СколькоСтрочекJSON, true, КонтекстСинхроДляКонтроллераВФоне,
                                "uuid",ActivityДляСинхронизацииОбмена,МенеджерПотоков,getБазаДанныхДЛяОперацийВнутри,СколькоСтрочекJSON,ИндексТекущейОперацииJSONДляВизуальнойОбработки,ФиналПроценты);

                        //

                        Log.d(this.getClass().getName(), "РезультатОбновлениеЧерезКонтрейнер"
                                + РезультатОбновлениеЧерезКонтрейнер);
                        ///TODO когда есть только ID




                }

                // TODO: 08.04.2021 НЕТ UUID И ОБНОВЛЕМ ПО ID
                if (IDИзПришедшегоJSON >0) {
                    ///todo
// TODO: 08.04.2021 НЕТ UUID И ОБНОВЛЕМ ПО ID

                        String ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID = null;

                        ////TODO в обратную сторону обмена из _id в таблице tabels на id меняем ы фоне

                        switch (имяТаблицыОтАндройда_локальноая.trim().toLowerCase()) {

                            case "tabels":
                            case "chats":
                            case "data_chat":
                            case "chat_users":
                            case "fio":
                            case "tabel":
                            case "data_tabels":
                                //
                                System.out.println("  ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID  " + ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID +
                                        " имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);

                                ////////
                                ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID = "_id";


                                break;
                            //
                            default:
                                //
                                ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID = "id";
                                ///

                                System.out.println("  ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID  " + ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID +
                                        " имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);
                        }

                        /////


                        //////todo ID UPDATE
                        РезультатОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерУниверсальная(имяТаблицыОтАндройда_локальноая, АдаптерПриОбновленияДанныхсСервера,
                                String.valueOf(IDИзПришедшегоJSON),
                                СколькоСтрочекJSON,
                                true, КонтекстСинхроДляКонтроллераВФоне, ВзависимостиТакаяТабицаЧерезЭтотИнфдификатораИОбновлеяемДляTables__ID,ActivityДляСинхронизацииОбмена,МенеджерПотоков,
                                Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу(),СколькоСтрочекJSON,ИндексТекущейОперацииJSONДляВизуальнойОбработки,ФиналПроценты);
                        //

                        Log.d(this.getClass().getName(), "РезультатОбновлениеЧерезКонтрейнер"
                                + РезультатОбновлениеЧерезКонтрейнер);


                    }
                }


                /// после обновление  в базу обнуляем контейнер  данные от сервера
                if (РезультатОбновлениеЧерезКонтрейнер > 0) {
//////////////////
                    /////TODO ВАЖНО ПОСЛЕ УСПЕШНОЙ ОБРАБОТКИ ПРИСВАИВАЕМ ЗНАЧЕНИЕ присваиваем наверх факсическое значение идущего цикла После Успешного прохода ТАБЛИЦЫ одной ИЗ
                    Log.d(this.getClass().getName(), " КоличествоУспешныхОбновлений JSON РезультатОбновлениеЧерезКонтрейнер " + РезультатОбновлениеЧерезКонтрейнер);
                    ///TODO переводим ввобщим в универсальный индификатор

                    /////TODO ВАЖНО ПОСЛЕ УСПЕШНОЙ ОБРАБОТКИ ПРИСВАИВАЕМ ЗНАЧЕНИЕ присваиваем наверх факсическое значение идущего цикла После Успешного прохода ТАБЛИЦЫ одной ИЗ


                }

                АдаптерПриОбновленияДанныхсСервера.clear();
                ////


                ////TODO вставка





            ///TODO если что -то открыта закрыть

            /////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }/*finally {
            //////Удаляем из памяти Асинтаск
            if (Курсор_УзнатьЕслиНаАндройдеТакойUUID != null) {

                if(!Курсор_УзнатьЕслиНаАндройдеТакойUUID.isClosed()) {

                    Курсор_УзнатьЕслиНаАндройдеТакойUUID.close();

                    Курсор_УзнатьЕслиНаАндройдеТакойUUID = null;
                }

            }

            ////
            if (Курсор_УзнатьЕслиНаАндройдеТакойID != null) {

                if (!Курсор_УзнатьЕслиНаАндройдеТакойID.isClosed()){

                    Курсор_УзнатьЕслиНаАндройдеТакойID.close();

                    Курсор_УзнатьЕслиНаАндройдеТакойID = null;
                }


            }
        }*/
        return РезультатОбновлениеЧерезКонтрейнер;
    }



















































    ///----------- ТУТ КОД УЖЕ ПОСЫЛАНИЕ ДАННЫХ НА СЕРВЕР МЕТОДУ POST (данные андройда посылаються на сервер)


    /////todo POST МЕТОД КОГДА НА АНДРОЙДЕ ВЕРСИЯ ДАННЫХ ВЫШЕ ЧЕМ НА СЕРВРЕР И МЫ  JSON ФАЙЛ ТУДА МЕТОД POST
    Integer МетодПосылаемДанныеНаСервервФоне(String имяТаблицыОтАндройда_локальноая,
                                             Long РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера,
                                             CompletionService МенеджерПотоковВнутрений) {
        ////

        Integer РезультатОтветаОтСервераУспешнаяВставкаИлиОбновление=0;
        ///
        Log.d(this.getClass().getName(), "  имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);
        ////
        Long Версия_ДанныхАндройДляОтправкиДанныхНАсервер = 0l;
        ////
        int КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки = 0;
        //////
        Integer КоличествоКолоноквОтправвляемойТаблице = 0;
        ////


        // TODO: 06.09.2021
       ///// Class_GRUD_SQL_Operations class_grud_sql_operationsПосылаемДанныеНаСервервФоне;

        try {
            Log.d(this.getClass().getName(), "  МетодПосылаемДанныеНаСервер в фоне ");


            Class_GRUD_SQL_Operations  class_grud_sql_operationsПосылаемДанныеНаСервервФоне = new Class_GRUD_SQL_Operations(contextСозданиеБАзы);


            class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы", "MODIFITATION_Client");
            ///////
            class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки", "versionserveraandroid_version");
            //
            class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика", " name=?   ");
            ///"_id > ?   AND _id< ?"
            //////
            class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1", имяТаблицыОтАндройда_локальноая);
            ///
/*            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
            class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......

            ////TODO другие поля

            ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);*/
            ////
            //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
            ////
            // class_grud_sql_operationsАнализаВресииДАнныхКлиента. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
            ////
            /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
            ////

            // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

            SQLiteCursor КурсорДляАнализаДатыПоследнейОтпракиНаСервер = null;
            ///////
            КурсорДляАнализаДатыПоследнейОтпракиНаСервер = (SQLiteCursor) new Class_GRUD_SQL_Operations(contextСозданиеБАзы).
                    new GetData(contextСозданиеБАзы).getdata(class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                    МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

            Log.d(this.getClass().getName(), "GetData  КурсорДляАнализаДатыПоследнейОтпракиНаСервер "+КурсорДляАнализаДатыПоследнейОтпракиНаСервер );




     /*       // TODO: 06.09.2021  _old
            КурсорДляАнализаДатыПоследнейОтпракиНаСервер= КурсорУниверсальныйДляБазыДанных("MODIFITATION_Client", new String[]{"versionserveraandroid"},
                    "name=?", new String[]
                            {имяТаблицыОтАндройда_локальноая}, null, null, null, null);
            ////////
*/
            //////ОЧИСТКА ПАМЯТИ ОТ ASYNSTASK

            /////////todo  result

       //// КУРСОР ПО ПОИСКУ ДАТФ ПОСЛЕДНЕЙ ОТПРАВКИ НА СЕРВЕР
                ////////
            if (КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount()>0) {

                ///// todo УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                Log.i(this.getClass().getName(), " КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount() " + КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount());

                КурсорДляАнализаДатыПоследнейОтпракиНаСервер.moveToFirst();




                Integer ИндексГлдеНаходитьсяСлолбикСВерисеДанныхСервернойЛОкальноНаТелефоне=КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getColumnIndex( "versionserveraandroid_version");



                Версия_ДанныхАндройДляОтправкиДанныхНАсервер = 0l;

                // TODO: 05.10.2021

                Версия_ДанныхАндройДляОтправкиДанныхНАсервер = КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getLong(ИндексГлдеНаходитьсяСлолбикСВерисеДанныхСервернойЛОкальноНаТелефоне);
                ///TODO ЕСЛИ НЕТ ДАТЫ НЕЧЕГО ОТПРАВЛЯТЬ




                if (Версия_ДанныхАндройДляОтправкиДанныхНАсервер >=0) {

                    Log.d(this.getClass().getName(), " Версия_ДанныхАндройДляОтправкиДанныхНАсервер " + Версия_ДанныхАндройДляОтправкиДанныхНАсервер +
                            "  имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);

                    int КоличествоСтрокПолученыеДляОтпарвкиПоДате = КурсорДляАнализаДатыПоследнейОтпракиНаСервер.getCount();

                    Log.d(this.getClass().getName(), " КоличествоСтрокПолученыеДляОтпарвкиПоДате   " + КоличествоСтрокПолученыеДляОтпарвкиПоДате);


                    ///todo


                }

            }
                    // TODO: 06.09.2021  закрываем
                    ///todo закрываем куроср
                    КурсорДляАнализаДатыПоследнейОтпракиНаСервер.close();


                    // TODO: 21.09.2021  ВТОРАЯ ЧАСТЬ    НЕПОСРЕДСТВЕННО ВЫЯСНИВ ЕСЛИ ДАННЫЕ ДЛЯ ОТПРАВКИ ,      ПОЛУЧАЕМ ДАННЫЕ ДЛЯ САМОЙ ОТПРАВКИ ЧРЕЗ КУРСОР ВТОРОЙ   КурсорДляОтправкиДанныхНаСервер



                    ///todo закрываем куроср
                    Log.d(this.getClass().getName(), " имяТаблицыОтАндройда_локальноая   " + имяТаблицыОтАндройда_локальноая);


                    SQLiteCursor КурсорДляОтправкиДанныхНаСервер = null;



                        Log.d(this.getClass().getName(), " имяТаблицыОтАндройда_локальноая   " + имяТаблицыОтАндройда_локальноая);


                        class_grud_sql_operationsПосылаемДанныеНаСервервФоне = new Class_GRUD_SQL_Operations(contextСозданиеБАзы);


                        class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы", имяТаблицыОтАндройда_локальноая);
                        ///////
                        class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки", "*");
                        //




            Log.d(this.getClass().getName(), " имяТаблицыОтАндройда_локальноая   " + имяТаблицыОтАндройда_локальноая);

            // TODO: 12.10.2021

            switch (имяТаблицыОтАндройда_локальноая.trim()) {


                case "fio":
                case "chats":
                case "data_chat":
                case "tabel":
                case "data_tabels":

                    class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика", "  current_table > ?  ");//AND _id IS NULL
                    ///"_id > ?   AND _id< ?"
                    Log.d(this.getClass().getName(), " имяТаблицыОтАндройда_локальноая   " + имяТаблицыОтАндройда_локальноая);
                    ///TODO
                    break;


                default:

                    class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика", "  current_table > ?     ");///AND  id IS NULL
                    ///"_id > ?   AND _id< ?"
                    Log.d(this.getClass().getName(), " имяТаблицыОтАндройда_локальноая   " + имяТаблицыОтАндройда_локальноая);
            }



                        //////
                        class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",
                                Версия_ДанныхАндройДляОтправкиДанныхНАсервер);
                        ///

                        // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ
                        КурсорДляОтправкиДанныхНаСервер = null;


                        КурсорДляОтправкиДанныхНаСервер = (SQLiteCursor) new Class_GRUD_SQL_Operations(contextСозданиеБАзы).
                                new GetData(contextСозданиеБАзы).getdata(class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                                МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                        Log.d(this.getClass().getName(), "GetData " + КурсорДляОтправкиДанныхНаСервер);



                     /*   // TODO: 06.09.2021   _old
                        КурсорДляОтправкиДанныхНаСервер = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая, new String[]{"*"}, " current_chat > ?  ",
                                new String[]{String.valueOf(РезультаПолученаяЛокальнаяСервернуюВерсиюДанныхКогдаПоследнийРазПришлиДанныесСерера)}, null, null, null, null);
*/
                        //todo ЕСЛИ НЕЧЕГО ОТПРАВЛЯЕТЬ ТО ДОПОЛНТЕЛЬНО ПРОВЕРЯЕМ МОЖЕТ ЕЩЕ ОТПРАВИТЬ НА СЕРВЕР

                        if (КурсорДляОтправкиДанныхНаСервер.getCount() == 0) {/////работаем уже в сгенерированных даннных которые мы отправим на сервер

                            Log.d(this.getClass().getName(), " имяТаблицыОтАндройда_локальноая   " + имяТаблицыОтАндройда_локальноая);

                            // TODO: 06.09.2021 ДОПОЛНИТЕЛЬНЫЙ МЕХАНИЗСМ ОТПРВКИ ДАНННЫХС NULL В ID ПОЛЕ ДЛЯ ЧАТА

                            class_grud_sql_operationsПосылаемДанныеНаСервервФоне = new Class_GRUD_SQL_Operations(contextСозданиеБАзы);


                            class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы", имяТаблицыОтАндройда_локальноая);
                            ///////
                            class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки", "*");

                            // TODO: 12.10.2021 выбор двух вариантов отправки с _id and id


                            // TODO: 12.10.2021

                            switch (имяТаблицыОтАндройда_локальноая.trim()) {


                                case "fio":
                                case "chats":
                                case "data_chat":
                                case "tabel":
                                case "data_tabels":


                                    Log.d(this.getClass().getName(), "имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);


                                    //
                                    class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика", "  _id IS NULL  OR _id = ?   ");
                                    ///"_id > ?   AND _id< ?"
                                    break;


                                default:

                                    Log.d(this.getClass().getName(), "имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);

                                    //
                                    class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика", "  id IS NULL  OR    id = ?   ");
                                    ///"_id > ?   AND _id< ?"

                            }






                            //////
                            class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1", "");
                            ///

                            // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

                            КурсорДляОтправкиДанныхНаСервер = null;

                            КурсорДляОтправкиДанныхНаСервер = (SQLiteCursor) new Class_GRUD_SQL_Operations(contextСозданиеБАзы).
                                    new GetData(contextСозданиеБАзы).getdata(class_grud_sql_operationsПосылаемДанныеНаСервервФоне.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                            Log.d(this.getClass().getName(), "GetData " + КурсорДляОтправкиДанныхНаСервер);


                            // TODO: 06.09.2021  old
/*
                            КурсорДляОтправкиДанныхНаСервер = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая, new String[]{"*"}, " _id IS NULL  OR _id = ? ",
                                    new String[]{""}, null, null, null, null);*/

                        }








                    //////ОЧИСТКА ПАМЯТИ ОТ ASYNSTASK

                    /////TODO результаты

                    if (КурсорДляОтправкиДанныхНаСервер.getCount() > 0) {/////работаем уже в сгенерированных даннных которые мы отправим на сервер
                        /////
                        КурсорДляОтправкиДанныхНаСервер.moveToFirst();
                        ////
                        КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки = КурсорДляОтправкиДанныхНаСервер.getCount();////КОЛИЧЕСТВО СТРОК В АНДРОЙДЕ ДАННЫЕ КОТОРЫЕ НУЖНО ПОСЛЛАТЬ
                        ///
                        КоличествоКолоноквОтправвляемойТаблице = КурсорДляОтправкиДанныхНаСервер.getColumnCount();/////КОЛИЧЕСТВО СТОЛЮЦОВ НА АНДРОДЕ БАЗЕ КОТОРОЫЕ НУЖНО ОТОСЛАТЬ
                        ////
                        Log.d(this.getClass().getName(), " КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки  " + КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки +
                                "  КоличествоКолоноквОтправвляемойТаблице  " + КоличествоКолоноквОтправвляемойТаблице +
                                 "  КурсорДляОтправкиДанныхНаСервер.getCount() " +КурсорДляОтправкиДанныхНаСервер.getCount());


                        // TODO: 06.09.2021  полчено отправляем


                        ////TODO провеояем чтобы  JSON ФАЙЛ БЫЛ НЕ ПУСТЫМ ДЛЯ ОТПРПВИК ЕГО НЕ СЕРВЕР
                        if (КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки > 0) {

                            РезультатОтветаОтСервераУспешнаяВставкаИлиОбновление = 0;

                            Log.d(this.getClass().getName(), "КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки " + КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки);



                            //////// todo упаковываем в  json ПЕРЕХОДИМ НА СЛЕДУЩИМ МЕТОД для отрправки на сервер метод POST() POST() POST() POST() POST() POST()POST()

                            РезультатОтветаОтСервераУспешнаяВставкаИлиОбновление = МетодГенеррируемJSONИзНашыхДанныхвФоне(КурсорДляОтправкиДанныхНаСервер, КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки,
                                    КоличествоКолоноквОтправвляемойТаблице, имяТаблицыОтАндройда_локальноая,МенеджерПотоковВнутрений);
                            //

                            Log.d(this.getClass().getName(), "РезультатОтветаОтСервераУспешнаяВставкаИлиОбновление " + РезультатОтветаОтСервераУспешнаяВставкаИлиОбновление);









                        }

                        // TODO: 21.09.2021 close cursor
                        ///todo закрываем куроср
                        КурсорДляОтправкиДанныхНаСервер.close();





                        // TODO: 27.09.2021     Нет данных для отправки
                    }else{
                        // TODO: 27.09.2021
                        Log.d(this.getClass().getName(), "  Нет данных для отправки   КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки имяТаблицыОтАндройда_локальноая "  +имяТаблицыОтАндройда_локальноая );
                    }










            ///


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
        return  РезультатОтветаОтСервераУспешнаяВставкаИлиОбновление;
    }


























    ////////TODO     МЕТОД ГЕНЕРИРОУЕМ JSON ПОЛЯ НА ОСНОВАНИЕ НАШИХ ДАННЫХ ДЛЯ ПОСЛЕДЖУЮЩЕ ОТПРАВКИ  POST()->
    ////////TODO     МЕТОД ГЕНЕРИРОУЕМ JSON ПОЛЯ НА ОСНОВАНИЕ НАШИХ ДАННЫХ ДЛЯ ПОСЛЕДЖУЮЩЕ ОТПРАВКИ  POST()->
    ////////TODO     МЕТОД ГЕНЕРИРОУЕМ JSON ПОЛЯ НА ОСНОВАНИЕ НАШИХ ДАННЫХ ДЛЯ ПОСЛЕДЖУЮЩЕ ОТПРАВКИ  POST()->

    Integer МетодГенеррируемJSONИзНашыхДанныхвФоне( Cursor КурсорДляОтправкиДанныхНаСерверОтАндройда, int КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки,
                                                Integer КоличествоКолоноквОтправвляемойТаблице, String имяТаблицыОтАндройда_локальноая,CompletionService МенеджерПотоковВнутрений) {
        ///
        Log.d(this.getClass().getName(), " КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки " + КоличествоСтрокПолученыеДляОтпарвкиПоДатеОтпарвки);
        Integer РезультатОтветаОтСервреУспешнаяВставкаИлиОбновления = 0;

        final int[] ЕслиUUIDПриЗабросеДанныхНаСервер = {0};

        final int[] ЕслиIDПриЗабросеДанныхНаСервер = {0};

        JSONObject ГенерацияJSONполейФинал = new JSONObject();///генериция финального поля дляJSON;  ////ПОЛЯ  ДЛЯ  JSON

        try {
///////метод создание josn из наших данных на отправку
            ////
            final String[] ПерхнееПолеJSONПоследнаяОперация = {null};////ПЕРЕРВОДИМ ИЗ INT TO STRING


            Log.d(this.getClass().getName(), " КурсорДляОтправкиДанныхНаСервер.getCount())   "
                    + КурсорДляОтправкиДанныхНаСерверОтАндройда.getCount() + " имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);

            boolean СработалПоворот = false;

            ///// ДО DO WHILE ОБЯЗАТЕЛЬНО

            if (КурсорДляОтправкиДанныхНаСерверОтАндройда.getCount()>0) {
                ///////////
                КурсорДляОтправкиДанныхНаСерверОтАндройда.moveToFirst();
                // TODO: 06.09.2021
                Log.d(contextСозданиеБАзы.getClass().getName(), "КурсорДляОтправкиДанныхНаСерверОтАндройда.getCount() " + КурсорДляОтправкиДанныхНаСерверОтАндройда.getCount());


            }

            final int[] КакаяСтрочкаОбработкиТекущаяя = {1};/////ОСТЛЕЖИВАЕМ ТЕКУЩУЮ СТРОЧКУ ОБРАБОТКИ
            ///TODO ЗАПУСКАЕМ  ПуллПамяти
            ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных

                        //todo бежим по строчкам json
                        do {/////КРУТИТЬ ДАННЫЕ ЧЕРЕЗ ЦИКЛ ОТВЕТЫ ОТ МЕТОДА POST

                            /// ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ
                            ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ отправка данных
                            /// ////TODO ЗАДЕРЖКА ИТЕРАЦИЯ ДЛЯ СИНРОНИЗАЦИИ В ФОНЕ


                            /////////////////
                            JSONObject ГенерацияJSONполей = new JSONObject();  ////ПОЛЯ  ДЛЯ  JSON ///ВАЖНО ГЕНЕРАЦИЯ НОВЫХ ОБЬЕКТОВ JSON НУЖНО СТАВИТЬ ВНУТРИ DO WHILE  НО ДО FOR ЦИКЛА МЕЖДУ НИМИ

                            /////
                            LinkedBlockingQueue<Integer> linkedBlockingDequeГенерируемJSONИзНашихДанныхДляОтправкиНаСервре=new LinkedBlockingQueue<Integer>();
                            //

                            for (Integer i = 0; i < КоличествоКолоноквОтправвляемойТаблице; i++) {
                                ////
                                linkedBlockingDequeГенерируемJSONИзНашихДанныхДляОтправкиНаСервре.put(i);
                            }


                            ///
                            Iterator iteratorГенерируемJSONИзНашихДанныхДляОтправкиНаСервре=linkedBlockingDequeГенерируемJSONИзНашихДанныхДляОтправкиНаСервре.iterator();



                            //todo бежим по столбцам
                            while (iteratorГенерируемJSONИзНашихДанныхДляОтправкиНаСервре.hasNext()) {
                                try {

                                    //////////TODO ЭКСПЕРЕМЕНТ С JSON

                               Integer ИндексПоТАблицамДляОтправки= (Integer) iteratorГенерируемJSONИзНашихДанныхДляОтправкиНаСервре.next();


                                    Log.d(this.getClass().getName(), "  ИндексПоТАблицамДляОтправки " +ИндексПоТАблицамДляОтправки );




                                    //////ПОЛЯ ДЛЯ ВСТВКИ В JSON  ДЛЯ ОТПРАВКИ ЕГО НА СЕРВЕЛТ
                                    String КлючJsonСтроки = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnName(ИндексПоТАблицамДляОтправки);


                                    //TODO сомо имя json
                                    System.out.println(" КлючJsonСтроки  " + КлючJsonСтроки);


                                    /////////
                                    Object ЗначниеJsonСтроки = КурсорДляОтправкиДанныхНаСерверОтАндройда.getString(ИндексПоТАблицамДляОтправки);

                                    Log.d(this.getClass().getName(), " КлючJsonСтроки ::    "
                                            + КлючJsonСтроки + "  ЗначниеJsonСтроки " + ЗначниеJsonСтроки);


                                    //TODO НАЧИНАЕМ ОБРАБАТЫВАТЬ КОГДА ЗНАЧЕНИЕ ПО СТОЛБИКУ ОТРУСТУЕТ VALUE==BULL  #ПЕРВАЯ ЧАСТЬ
                                    Log.d(this.getClass().getName(), " КлючJsonСтроки " + КлючJsonСтроки);
                                    if (ЗначниеJsonСтроки == null) {
                              /*      ////todo если пустые значение по столбику имитируем его как текст но и как цифра для столиков fio and uuid
                                    Log.d(this.getClass().getName(), " КлючJsonСтроки " +КлючJsonСтроки );
                                    if (КлючJsonСтроки.equalsIgnoreCase("fio") || КлючJsonСтроки.equalsIgnoreCase("uuid") || КлючJsonСтроки.equalsIgnoreCase("id")){
                                        //ЗначниеJsonСтроки=null;////чтобы небыло ошибки ПРИНУДИТЕЛЬНО В СОДРЕЖИСОА JSON ГЕНЕРИРУЕМОГО ДОБАВЛЯЕМ ПРОБЕЛЫ ЧТОБЫ JSON ПОД ДАНОМУ ПОЛЮ БЫЛ ЗОЗДАН
                                        ////////// TODO КОНКРЕТАНАЯ ГЕНЕРАЦИЯ  JSON СТРОКИ
                                                ////разрешаем вставку с NULL
                                                if (КлючJsonСтроки!=null ) {
                                                    ///todo генерация самой строки json ниже ключ к нему после for
                                                    ГенерацияJSONполей.put(КлючJsonСтроки, ЗначниеJsonСтроки); ////заполение полей JSON
                                                    ///
                                                    Log.d(this.getClass().getName(), " КлючJsonСтроки  " + КлючJsonСтроки + "  ЗначниеJsonСтроки " +ЗначниеJsonСтроки );
                                                    //todo обнуление после вставки
                                                    КлючJsonСтроки=null;
                                                    ЗначниеJsonСтроки=null;
                                                }
                                    }
            */

                                        //TODO НАЧИНАЕМ ОБРАБАТЫВАТЬ КОГДА ЗНАЧЕНИЕ ПО СТОЛБИКУ ЕСТЬ , ВСЕ  ХОРОШО И ИМЯ СТОБЛИКА ЕСТЬИ ЕГО ЗНАЧЕНИЕ ТОЖЕ ЕСТЬ #ВТОРАЯ ЧАСТЬ
                                        Log.d(this.getClass().getName(), " КлючJsonСтроки " + КлючJsonСтроки);
                                    } else if (ЗначниеJsonСтроки != null) {
                                        ////////// TODO КОНКРЕТАНАЯ ГЕНЕРАЦИЯ  JSON СТРОКИ
                                        if (КлючJsonСтроки != null && ЗначниеJsonСтроки != null) {//ПРОИЗВОДИМ ВСТАВКИ JSON ПОЛЕЙ ТОЛЬКО ЕСЛИ ОНИ НЕ NULL


                                            ////TODO в обратную сторону обмена из _id в таблице tabels на id меняем ы фоне


                                            // TODO: 24.06.2021 меняем местави приотправки на сервер данные однго столика с _id на id

                                            switch (имяТаблицыОтАндройда_локальноая.trim().toLowerCase()) {

                                                case "tabels":
                                                case "chats":
                                                case "data_chat":
                                                case "chat_users":
                                                case "fio":
                                                case "tabel":
                                                case "data_tabels":
                                                    //
                                                    System.out.println("  КлючJsonСтроки  " + КлючJsonСтроки);

                                                    if (КлючJsonСтроки.equals("_id")) {

                                                        КлючJsonСтроки = "id";
                                                        //
                                                        System.out.println("  КлючJsonСтроки  " + КлючJsonСтроки);
                                                    }

                                                    break;
                                            }


                                            //////

                                            /////TODO вытаемся отслидить хотябы один заполненый день
                                            Log.d(this.getClass().getName(), "КлючJsonСтроки " + "--" + КлючJsonСтроки + " З начниеJsonСтроки " + ЗначниеJsonСтроки);/////


                                            ///todo генерация самой строки json ниже ключ к нему после for//   && ЗначниеJsonСтроки.toString().matches("[1-9]"
                                            if (КлючJsonСтроки.matches("[d].*") && КлючJsonСтроки.length() <= 3) {
                                                ///////
                                                ГенерацияJSONполей.put(КлючJsonСтроки, ЗначниеJsonСтроки); ////заполение полей JSON

                                            } else if (ЗначниеJsonСтроки != null) {
                                                ///////
                                                ГенерацияJSONполей.put(КлючJsonСтроки, ЗначниеJsonСтроки); ////заполение полей JSON
                                            }


                                            ///
                                            Log.d(this.getClass().getName(), " КлючJsonСтроки  " + КлючJsonСтроки + "  ЗначниеJsonСтроки " + ЗначниеJsonСтроки);
                                            //todo обнуление после вставки
                                            КлючJsonСтроки = null;
                                            ЗначниеJsonСтроки = null;
                                        }
                                        ///////////////ДОБАЛВЕНИЕ ВЕПХНЕГО ID ПО ВЕРХ JSON ПОЛЕЙ
                                    }


                                    //////////TODO  КОНЕЦ ЭКСПЕРЕМЕНТ С JSON
                                    ///todo  только uuid
                                    ЕслиUUIDПриЗабросеДанныхНаСервер[0] = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("uuid");

                                    if (ЕслиUUIDПриЗабросеДанныхНаСервер[0] >= 0) {

                                        Log.d(this.getClass().getName(), "ЕслиUUIDИлиIDПриЗабросеДанныхНаСервер " + ЕслиUUIDПриЗабросеДанныхНаСервер[0]);
                                        ///////////////ЕСЛИ ID ПОЛЕ ПУСТОЕ ТО ЗАПОЛНЕМЕМ ЕГО ВТОРЫМ ПОЛЕМ
                                        int ИндексДвижениеПОПОлямДЛяФОрмированиеID = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("uuid");
                                        ////todo
                                        ПерхнееПолеJSONПоследнаяОперация[0] = КурсорДляОтправкиДанныхНаСерверОтАндройда.getString(ИндексДвижениеПОПОлямДЛяФОрмированиеID);

                                    }


                                    ///todo  только id
                                    ЕслиIDПриЗабросеДанныхНаСервер[0] = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("id");

                                    if (ЕслиIDПриЗабросеДанныхНаСервер[0] >= 0 && ПерхнееПолеJSONПоследнаяОперация[0] == null) {

                                        Log.d(this.getClass().getName(), "ЕслиUUIDИлиIDПриЗабросеДанныхНаСервер " + ЕслиIDПриЗабросеДанныхНаСервер[0]);
                                        ///////////////ЕСЛИ ID ПОЛЕ ПУСТОЕ ТО ЗАПОЛНЕМЕМ ЕГО ВТОРЫМ ПОЛЕМ
                                        int ИндексДвижениеПОПОлямДЛяФОрмированиеID = КурсорДляОтправкиДанныхНаСерверОтАндройда.getColumnIndex("id");
                                        ////todo
                                        ПерхнееПолеJSONПоследнаяОперация[0] = КурсорДляОтправкиДанныхНаСерверОтАндройда.getString(ИндексДвижениеПОПОлямДЛяФОрмированиеID);

                                    }


                                } catch (Exception e) {
                                    e.printStackTrace();
                                    ///метод запись ошибок в таблицу
                                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    ////// начало запись в файл
                                }




                               ////todo выкидываем из очереди отработнаную строчку

                                linkedBlockingDequeГенерируемJSONИзНашихДанныхДляОтправкиНаСервре.peek();
                            }
                            ///future


                            ////TODO упаковываем jon если хоть какое поле есть   , ЕСЛИ ЕСТЬ ИЛИ ID ИЛИ UUID
                            if (ПерхнееПолеJSONПоследнаяОперация[0] != null && ГенерацияJSONполей != null && ГенерацияJSONполей.length() > 0) {


                                /// todo МЕЖДУ FOR И WHILE
                                Log.i(this.getClass().getName(), " ПерхнееПолеJSONПоследнаяОперация  :     " + ПерхнееПолеJSONПоследнаяОперация[0]
                                        + " ГенерацияJSONполей " + ГенерацияJSONполей.toString());


                                /////////
                                try {
                                    //////////todo КОНКРЕТАНАЯ ГЕНЕРАЦИЯ  JSON ВЕРХНЕГО КЛЮЧА
                                    ГенерацияJSONполейФинал.put(ПерхнееПолеJSONПоследнаяОперация[0], ГенерацияJSONполей);////ВСТАВЛЯЕМ ОДИН JSON в ДРУГОЙ JSON ПОЛУЧАЕМ ФИНАЛЬНЫЙ РЕЗУЛЬТАТ JSON"А

                                } catch (Exception e) {
                                    e.printStackTrace();
                                    ///метод запись ошибок в таблицу
                                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                // TODO: 01.09.2021 метод вызова
                                 new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    ////// начало запись в файл
                                }

                            }


                            КакаяСтрочкаОбработкиТекущаяя[0]++;////ЛОВИМ ТЕКУУЩЮ СТРОЧКУ ОБРАБОТКИ


                            //todo ////


                            //todo  ////

                            ////// todo  КОНЕЦ МЕЖДУ FOR И WHILE
                            ///todo идем по сторчкам  json
                        } while (КурсорДляОтправкиДанныхНаСерверОтАндройда.moveToNext());////ДАННЫЕ КРУТИЯТЬСЯ ДО КОНЦА ДАННЫХ И ГЕНЕРИРУЮ JSON
                        ///todo


                        /////////
                        if (ГенерацияJSONполейФинал.toString().length() > 3) {

                            ///////// TODO ФИНАЛ ПРОСМАТРИВАЕМ СГЕНЕРИРОВАНЫЙ JSON  ФАЙЛ ПОСЛЕ ЦИКЛА DO WHILE СОЗДАИНИЕ НА СТОРОНЕ АНДРОЙДА JSON ПОЛЕЙ
                            Log.d(this.getClass().getName(), " ГенерацияJSONполейФинал  " + ГенерацияJSONполейФинал + " ГенерацияJSONполейФинал " + ГенерацияJSONполейФинал.toString() +
                                    " ГенерацияJSONполейФинал.length() " + ГенерацияJSONполейФинал.length());



                            //TODO ЗАКРЫВАЕМ КУРСОР
                            РезультатОтветаОтСервреУспешнаяВставкаИлиОбновления=0;
                            ///todo МЫ СОЗДАЛИ ФАЙЛ JSON  И ПОСЫЛАЕМ ЕГО НА СЕРВЕР
                            РезультатОтветаОтСервреУспешнаяВставкаИлиОбновления=
                                    МетодПосылаетНаСерверСозданныйJSONФайлвФоне(ГенерацияJSONполейФинал, имяТаблицыОтАндройда_локальноая,МенеджерПотоковВнутрений); ////СГЕНЕРИРОВАНЫЙ JSON ФАЙЛ ЕСЛИ БОЛЬШЕ 2 ССИМВОЛОМ В НЕМ ТО ОТПРАВЛЯЕМ
                            //

                            Log.d(this.getClass().getName(), " РезультатОтветаОтСервреУспешнаяВставкаИлиОбновления  " + РезультатОтветаОтСервреУспешнаяВставкаИлиОбновления);
                        }





            /////todo exit cursor
            КурсорДляОтправкиДанныхНаСерверОтАндройда.close();


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл

        }

        //
        return  РезультатОтветаОтСервреУспешнаяВставкаИлиОбновления;
    }










    //////todo МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST
    Integer МетодПосылаетНаСерверСозданныйJSONФайлвФоне(@NonNull JSONObject ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда, @NonNull String имяТаблицыОтАндройда_локальноая,
                                                        CompletionService МенеджерПотоковВнутрений) {
        /////
        Integer РезультатУспешнойВставкиИлиОбновлениеCallBacksОтСервера=0;

        String ДанныеПришёлВОтветОтМетодаPOST = new String();
        ///

        StringBuffer БуферОтправкаДанныхвФоне = new StringBuffer();
        //



        Class_GRUD_SQL_Operations class_grud_sql_operations;
        ///
        class_grud_sql_operations=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);


        try {
            Log.d(this.getClass().getName(), "  МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST ");

            // TODO: 15.06.2021 проверяем если таблица табель то еси в нутри потока отпралеемого хоть один день d1,d2,d3 защита от пустого траыфика\
            Log.d(this.getClass().getName(), " ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString() "
                    + ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString() +
                    " ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString().toCharArray().length  "
                    + ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда.toString().toCharArray().length +
                    " имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);


                    try {


                            //////todo МЕТОД НЕПОСТРЕДСТВЕННО ОТПРАВЛЯЕМ ДАННЫЕ НА СЕРВЕР МЕТОД POST
                            БуферОтправкаДанныхвФоне = УниверсальныйБуферОтправкиДанныхНаСервера(ГенерацияJSONполейФиналДляОтправкиНаСеврерОтАндройда,
                                   ПубличноеIDПолученныйИзСервлетаДляUUID, имяТаблицыОтАндройда_локальноая,
                                    "Получение JSON файла от Андройда",120000,"tabel.dsu1.ru", 8888); ///БУФЕР ОТПРАВКИ ДАННЫХ НА СЕРВЕР

                            Log.d(this.getClass().getName(), "  СЛУЖБА ВЕРНУЛЬСЯ ОТВЕТ ОТ СЕРВЕРА ОБРАТНО АНДРОЙДУ  БуферОтправкаДанных.toString() " + БуферОтправкаДанныхвФоне.toString());


                            if (БуферОтправкаДанныхвФоне!=null) {

                                if (БуферОтправкаДанныхвФоне.length()>0 ) {

                                    ПубличныйРезультатОтветаОтСерврераУспешно=0;
                                    ////
                                    ПубличныйРезультатОтветаОтСерврераУспешно=БуферОтправкаДанныхвФоне.length();
                                }

                                Log.d(this.getClass().getName(), "БуферОтправкаДанныхвФоне.length() " + БуферОтправкаДанныхвФоне.length());
                            }



                        ////
                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        // TODO: 01.09.2021 метод вызова
                        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ////// начало запись в файл
                    }





            ////TODO  ОТВЕТ ОТ СЕРВЕРА ПОСЛЕ ОТПРАВКИ ДАННЫХ НА СЕРВЕР
            if (БуферОтправкаДанныхвФоне != null) {
                ///


                if (БуферОтправкаДанныхвФоне.length() > 0) {

                    Log.d(this.getClass().getName(), "  БуферОтправкаДанныхвФоне.toString()  " + БуферОтправкаДанныхвФоне.toString());
                    do {
                        ДанныеПришёлВОтветОтМетодаPOST = БуферОтправкаДанныхвФоне.toString();

                        Log.d(this.getClass().getName(), "  ДанныеПришёлВОтветОтМетодаPOST  " + ДанныеПришёлВОтветОтМетодаPOST);

                        //
                        if (ДанныеПришёлВОтветОтМетодаPOST != null) {
                            //
                            break;
                        }

                    } while (ДанныеПришёлВОтветОтМетодаPOST == null);/////конец for # количество респонсев
                }


                ////TODO ответ от сервера РЕЗУЛЬТАТ
                Log.d(this.getClass().getName(), "Успешный Ответ от сервера ДанныеПришёлВОтветОтМетодаPOST в фоне " + ДанныеПришёлВОтветОтМетодаPOST);
                ///
                if (ДанныеПришёлВОтветОтМетодаPOST.length() > 5) {
                    ///
                    //
                    //// TimeUnit.MILLISECONDS.sleep(500);
                    //
     РезультатУспешнойВставкиИлиОбновлениеCallBacksОтСервера=           ДанныеПришёлВОтветОтМетодаPOST.length();

                    Log.d(this.getClass().getName(), " СЛУЖБА УСПЕШНЫЙ ОТВКЕТ ОТ СЕРВЕРА ОТВЕТ CALBACKS  ДанныеПришёлВОтветОтМетодаPOST.length()  "
                            +  ДанныеПришёлВОтветОтМетодаPOST.length()+ " ДанныеПришёлВОтветОтМетодаPOST " +ДанныеПришёлВОтветОтМетодаPOST.toString() );
                }else{
                    Log.d(this.getClass().getName(), " NULL НОЛЬ ОБНОВЛЕНИЙ ИЛИ ВСТАВОК С СЕРВЕРА  СЛУЖБА УСПЕШНЫЙ ОТВКЕТ ОТ СЕРВЕРА ОТВЕТ CALBACKS  ДанныеПришёлВОтветОтМетодаPOST.length() ");
                }


                // TODO: 15.07.2021  только для таблиц указываем ответ от сервер успешно лдии ывставли или обновли данные


                /////УДАЛЯЕМ ИЗ ПАМЯТИ  ОТРАБОТАННЫЙ АСИНАТСК
                /////////
            } else {////ОШИБКА В ПОЛУЧЕНИИ С СЕРВЕРА ТАБЛИУЦЫ МОДИФИКАЦИИ ДАННЫХ СЕРВЕРА


                Log.d(this.getClass().getName(), " Данных нет c сервера  БуферОтправкаДанных.length() в фоне " + БуферОтправкаДанныхвФоне.length());
            }

            Log.d(this.getClass().getName(), " ДанныеПришёлВОтветОтМетодаPOST " + ДанныеПришёлВОтветОтМетодаPOST);

            if (ДанныеПришёлВОтветОтМетодаPOST.length() > 0) {

                /////// данные код анализирует успешные и/ил обновление данных на серврер кторые ему присла пользователь
                МетодАнализаОтветаОтСервераУспешныеВставкиИлиОбновлениевФоне(ДанныеПришёлВОтветОтМетодаPOST, имяТаблицыОтАндройда_локальноая,МенеджерПотоковВнутрений);

            }
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
        return  РезультатУспешнойВставкиИлиОбновлениеCallBacksОтСервера;
    }
















    ///TODO ОТТВЕТ ОТ СЕРВЕРАР ОТ МЕТОДА POST() С РЕЗУЛЬТАТАМИ ВСТАВКИ И ЛИ ОБНОВЛЕНЕИ ДАННЫХ


    /////// данные код анализирует успешные и/ил обновление данных на серврер кторые ему присла пользователь
    void МетодАнализаОтветаОтСервераУспешныеВставкиИлиОбновлениевФоне(String ДанныеПришёлВОтветОтМетодаPOST, String имяТаблицыОтАндройда_локальноая,CompletionService МенеджерПотоковВнутрений) {
        //////

        Log.d(this.getClass().getName(), "  ДанныеПришёлВОтветОтМетодаPOST " + ДанныеПришёлВОтветОтМетодаPOST);


        StringBuffer ОтветОтСервераДляВставки = new StringBuffer();


        try {
            Log.d(this.getClass().getName(), " ДанныеПришёлВОтветОтМетодаPOST             " + ДанныеПришёлВОтветОтМетодаPOST);
/////// данные код анализирует успешные и/ил обновление данных на серврер кторые ему присла пользователь

            ////todo обновление ответной от сервера
            int УспешноеОбновлениеНаСерверe = 0;

            int УспешноеВставкаНаСервере = 0;

            String ВытащилиUUIDИзPOST = "";

            //TODO ОБНОВЛНИЕ
            int УспешныеЛиОтветыОтСервераИлиНет = ДанныеПришёлВОтветОтМетодаPOST.indexOf("::");///TODO если в теле ответа от сервера POSt вообще ::

            if (УспешныеЛиОтветыОтСервераИлиНет > 0) {
                ///////
                for (String ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера : ДанныеПришёлВОтветОтМетодаPOST.split("::")) {
                    /////
                    if (УспешноеОбновлениеНаСерверe == 0) {

                        УспешноеОбновлениеНаСерверe = ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера.indexOf("Обновление");
                    }

                    if (УспешноеВставкаНаСервере == 0) {

                        УспешноеВставкаНаСервере = ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера.indexOf("Вставка");
                    }
                    //////////
                    for (String ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений : ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвера.split(" ")) {

                        Log.d(this.getClass().getName(), "  ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений " + ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений);

                        boolean РезультатЯвляетьсяЦифройВесьТекст = МетодОпределениеВселиЦифрыВстроке(ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений);

                        Log.d(this.getClass().getName(), " РезультатЯвляетьсяЦифройВесьТекст            " + РезультатЯвляетьсяЦифройВесьТекст);

                        if (РезультатЯвляетьсяЦифройВесьТекст == true) {

                            ВытащилиUUIDИзPOST = ЧтоВнутриПришедшегоПоложитльеногоОбновлениеСесвераВнутрений;
                            ////
                            long РезультатПослеОбновлениеЧерезКонтрейнер = 0;


                            РезультатПослеОбновлениеЧерезКонтрейнер = ОбновлениеДанныхЧерезКонтейнерВозвращениеРезультатаОтСервераУниверсальная(имяТаблицыОтАндройда_локальноая,
                                    Long.parseLong(ВытащилиUUIDИзPOST));
                            /// после обновление  в базу обнуляем контейнер  данные от сервера


/////TODO РЕЗУЛЬТАТА ВСТАВКИ ОТВЕТА ОТ СЕРВРЕ НА КЛИНЕТ ПРИ УСПЕШНОЙ ОБНОВЛЕНИИ ИЛИ ВСТАВКЕ
                            if (РезультатПослеОбновлениеЧерезКонтрейнер > 0) {
                                //todo обявлем успешное встаку
                                if (УспешноеОбновлениеНаСерверe > 0) {


                                    Log.d(this.getClass().getName(), " УспешноеОбновлениеНаСерверe "+ УспешноеОбновлениеНаСерверe);
                                    ///////
                                    УспешноеОбновлениеНаСерверe = 0;

                                    ////TODOECGTI
                                } else if (УспешноеВставкаНаСервере > 0) {

                                    //////
                                    Log.d(this.getClass().getName(), " УспешноеОбновлениеНаСерверe "+ УспешноеОбновлениеНаСерверe);
                                    ////todo после успешной операции обнуяем
                                    УспешноеВставкаНаСервере = 0;
                                }
                                ////TODO метод POST ответ от сервера
                                Log.d(this.getClass().getName(), " УспешноеОбновлениеНаСерверe "+ УспешноеОбновлениеНаСерверe);
                            }
                        }
                    }
                    ////// todo Удаляем из памяти Асинтаск

                }
            }


            //////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ////// начало запись в файл
        }
    }


    ///todo являеться ли весь текст числом
    boolean МетодОпределениеВселиЦифрыВстроке(String ВселиЦифрыВтексе) {
        boolean Результат = false;
        try {
            Long.parseLong(ВселиЦифрыВтексе);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }

    }
    ///TODO подсчет часов

    protected int МетодПосчётаЧасовПоСотруднику(Cursor курсор_ЗагружаемТабеляСозданный) {
        int СуммаЧасов = 0;
        if (курсор_ЗагружаемТабеляСозданный.getCount() > 0) {
            курсор_ЗагружаемТабеляСозданный.moveToFirst();
        }
        do {

            for (int ИндексДляИзмененияДней = 1; ИндексДляИзмененияДней < 32; ИндексДляИзмененияДней++) {

                int ИндексЧассыСотрудника = курсор_ЗагружаемТабеляСозданный.getColumnIndex("d" + ИндексДляИзмененияДней);

                int ЧассыСотрудника = курсор_ЗагружаемТабеляСозданный.getInt(ИндексЧассыСотрудника);

                СуммаЧасов = СуммаЧасов + ЧассыСотрудника;

                Log.d(this.getClass().getName(), "    СуммаЧасов " + СуммаЧасов);

            }///TODO END FOR  ПО СТОЛБЦАМ БЕЖИМ

        } while (курсор_ЗагружаемТабеляСозданный.moveToNext());
        ////TODO ПРИСВАИВАЕМ ПОЛУЧЕННЫЕ ЧАСЫ ИЗ БАЗЫ УЖЕ ПЕРЕДЕМ ЕЕ НА АКТИВТИ
        ////todo и ставим курсор на место на первое
        курсор_ЗагружаемТабеляСозданный.moveToFirst();
        return СуммаЧасов;
    }









    ///todo метод подсчёта сотрудниколв их ЧАСЫ
    String МетодПосчётаЧасовСотрудниковВТабеле(Context КонтекстДляЧасов, long UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников, int месяцДляПермещенияПоТабелю, int годДляПермещенияПоТабелю) {
        ///////

        String ОбщееКоличествоЛюдейВТабелеТекущемВнутри = null;


        try {
            Cursor Курсор_ЗагружаемТабеляДляПодсчетаЧасов = new MODEL_synchronized(КонтекстДляЧасов).
                    МетодЗагружетУжеготовыеТабеля(КонтекстДляЧасов, UUIDТабеляПослеУспешногоСозданиеСотрудникаВсехСотридников, месяцДляПермещенияПоТабелю, годДляПермещенияПоТабелю);


            //TODO цикл ПЕРЕБОРКИ ДАННЫХ
            ОбщееКоличествоЛюдейВТабелеТекущемВнутри = String.valueOf(new Class_Async_Background(КонтекстДляЧасов).
                    МетодПосчётаЧасовПоСотруднику(Курсор_ЗагружаемТабеляДляПодсчетаЧасов));

            Log.d(this.getClass().getName(), "  ОбщееКоличествоЛюдейВТабелеТекущемВнутри " + ОбщееКоличествоЛюдейВТабелеТекущемВнутри);

            Курсор_ЗагружаемТабеляДляПодсчетаЧасов.close();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName()
                    + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

        return ОбщееКоличествоЛюдейВТабелеТекущемВнутри;
    }
    //////ТУТ БУДЕТ ЗАПИСЫВАТЬСЯ УСПЕШНОЕ ОБНЛВДЕНИ И ВСТАВКИ ДАННЫХ НА СЕРВЕРЕ ДЛЯ КЛИЕНТА
















    /////TODO ЛОКАЛЬНАЯ ОБНОВЛЕНИЕ ВНУТРИ ТАБЕЛЯ

    Long МетодЛокальноеОбновлениеВТабеле(ContentValues КонтейнерЗаполненияДаннымиПриЛокальномОбновлении, String ПолучениеЗначениеСтолбикUUID,
                                         long[] результатОбновлениеЧерезКонтрейнер,
                                         long[] результат_ИзмененияВерсииДанныхНаАндройде, Context КонтексДляЛокальногоОбновления) throws InterruptedException, ExecutionException, TimeoutException {
        //////

String таблицаДляЛокальногоОбонвления="data_tabels";

                ////TODO ДАТА

                try {
                    ///////TODO САМ ВЫЗОВ МЕТОДА ОБНОВЛЕНИЕ ЛОКАЛЬНОГО обновление uuid
                    результатОбновлениеЧерезКонтрейнер[0] = new Class_Async_Background(КонтексДляЛокальногоОбновления).
                            ЛокальногоОбновлениеДанныхЧерезКонтейнерУниверсальная(таблицаДляЛокальногоОбонвления,
                                    КонтейнерЗаполненияДаннымиПриЛокальномОбновлении,
                                   Long.parseLong(ПолучениеЗначениеСтолбикUUID), "uuid");


                    Log.d(this.getClass().getName(), "результат_ИзмененияВерсииДанныхНаАндройде[0]" + результат_ИзмененияВерсииДанныхНаАндройде[0] +
                            "  результатОбновлениеЧерезКонтрейнер[0] " + результатОбновлениеЧерезКонтрейнер[0]);


                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName()
                            + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(),
       this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }


        return Long.parseLong(String.valueOf( результатОбновлениеЧерезКонтрейнер[0]));//5,TimeUnit.SECONDS

    }















    //TODO Метод ПОДЧСЧЕТА ЧАСОВ ПО ВСЕМ ТАБЕЛЯМ СРАЗУ
    String МетодДосчётаЧасовПоВсемТабелям(long finalПолученныйUUID, Context КонтекстДЛляПодсчетаЧасовПоВсемТабелям,

                                          int месяцДляПермещенияПоТабелю, int годДляПермещенияПоТабелю) {

         /* return (String) new AsyncTaskLoader(КонтекстДЛляПодсчетаЧасовПоВсемТабелям) {
              @Override
              public Object loadInBackground() {*/
        String ПолученыеСуммаЧасовСотрудникаВнутри = null;
        try {
            //TODO вытастиваем непостредственный табель для которго и нужно посчитать часы
            Cursor Курсор_ЗагружаемТабеляДляПодсчетаЧасовПовсемТАбелям = new MODEL_synchronized(КонтекстДЛляПодсчетаЧасовПоВсемТабелям).
                    МетодЗагружетУжеготовыеТабеля(КонтекстДЛляПодсчетаЧасовПоВсемТабелям, finalПолученныйUUID, месяцДляПермещенияПоТабелю, годДляПермещенияПоТабелю);


            //TODO Считаем Сумму часов по всем табелям
            ПолученыеСуммаЧасовСотрудникаВнутри = String.valueOf(new Class_Async_Background(КонтекстДЛляПодсчетаЧасовПоВсемТабелям).
                    МетодПосчётаЧасовПоСотруднику(Курсор_ЗагружаемТабеляДляПодсчетаЧасовПовсемТАбелям));



        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    /*              return ПолученыеСуммаЧасовСотрудникаВнутри;
              }
          }.loadInBackground();
      }*/

        return ПолученыеСуммаЧасовСотрудникаВнутри;

    }











    ///todo АНАЛИЗ UUID
    Integer МетодАнализаUUIDСинхрониазциявФоне(String UUIDПолученныйИзПришедшегоJSON, String JSON_ИмяСтолбца, String JSON_ИмяСодержимое,
                                            String имяТаблицыОтАндройда_локальноая,CompletionService МенеджерПотоковВнутрений)
            throws ExecutionException, InterruptedException, TimeoutException {

        Class_GRUD_SQL_Operations class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне;

  Integer РезультатЕстьUUIDилНет=0;
        ///////

        try {


            ////// TODO ИЗ ПРАВИЛА ЧТО НЕЛЬЗЯ ОБНОЛВЛЯТЬ ПОЕЛ UUID ПРОПУСКАЕМ ЕГО ЭТО КОГДА СТОЛБИК ID ПРОПУСКАЕМ

            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);
//////наобород
//////наобород
            switch (имяТаблицыОтАндройда_локальноая.trim().toLowerCase()) {

                case "tabels":
                case "chats":
                case "data_chat":
                case "chat_users":
                case "fio":
                case "tabel":
                case "data_tabels":
                    //
                    System.out.println("  КлючJsonСтроки  " + JSON_ИмяСтолбца);

                    if (JSON_ИмяСтолбца.equals("id")) {

                        JSON_ИмяСтолбца = "_id";
                        //
                        System.out.println("  КлючJsonСтроки  " + JSON_ИмяСтолбца);
                    }

                    break;
            }


            ///


            System.out.println("  JSON_ИмяСтолбца  " + JSON_ИмяСтолбца + " имяТаблицыОтАндройда_локальноая " + имяТаблицыОтАндройда_локальноая);


/////
            String ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде;
            ////
            ////todo  ПЫТАЕМСЯ ОРГАНИЗОВАТЬ ОБНОВЛЕНИЕ НО ТОЛЬКО ЕСЛИ ВЛАГ  TRUE
            SQLiteCursor Курсор_УзнатьЕслиНаАндройдеТакойUUID =null;




            ///
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);

            ///
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы",имяТаблицыОтАндройда_локальноая);
            ///////
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","uuid");
            //
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","uuid=? ");
                    ///"_id > ?   AND _id< ?"
                    //////
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",UUIDПолученныйИзПришедшегоJSON);
                    ///
   /*         class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......

            ////TODO другие поля

            ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
            ////
            //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
            ////
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
            ////*/
            /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
            ////

            // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

            Курсор_УзнатьЕслиНаАндройдеТакойUUID=null;

            // TODO: 16.07.2021
            Log.d(this.getClass().getName(), "КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал  "+ КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал);
            //////

            if (КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал.equalsIgnoreCase("ПовторныйЗапускСинхронизации") && UUIDПолеУжеПроверелиЧерезКурсор==false) {
                //////
                Курсор_УзнатьЕслиНаАндройдеТакойUUID= (SQLiteCursor)  new Class_GRUD_SQL_Operations(contextСозданиеБАзы).
                        new GetData(contextСозданиеБАзы).getdata(class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());


                ///////
                Log.d(this.getClass().getName(), " Курсор_УзнатьЕслиНаАндройдеТакойUUID " + Курсор_УзнатьЕслиНаАндройдеТакойUUID);


                if ( Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount() > 0) {
                    ///
                    //////
                    Курсор_УзнатьЕслиНаАндройдеТакойUUID.moveToFirst();


                    ///
                    ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде = Курсор_УзнатьЕслиНаАндройдеТакойUUID.getString(0);
                    ///////
                    Log.d(this.getClass().getName(), " ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде " + ДействительноЛиUUIDКоторыйПришелсСервераУжеЕстьНаАндройде);


                    ////////
                    Log.d(this.getClass().getName(), " UUIDПолученныйИзПришедшегоJSON " + UUIDПолученныйИзПришедшегоJSON.length() + " Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount()  "
                            + Курсор_УзнатьЕслиНаАндройдеТакойUUID.getCount() );

                    UUIDПолеУжеПроверелиЧерезКурсор=true;
                }


                Log.d(this.getClass().getName(), "GetData " +Курсор_УзнатьЕслиНаАндройдеТакойUUID );
            }



/*
            ////////TODO _old

            Курсор_УзнатьЕслиНаАндройдеТакойUUID = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,
                    new String[]{"uuid"}, "uuid=?", new String[]{UUIDПолученныйИзПришедшегоJSON}, null, null,
                    null, null);//"SuccessLogin", "date_update","id=","1",null,null,null,null
*/


            ////////



                /////
                if (  UUIDПолеУжеПроверелиЧерезКурсор==true) {
                    /////
                    ///
                    РезультатЕстьUUIDилНет++;





                    Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца + " JSON_ИмяСодержимое " + JSON_ИмяСодержимое);
                    //////МЕТОДКОТРЫЙ ПРИ ОТСТВИИИ UUID ЕГО ГЕНЕРИРЕТ НА ПРИШЕЛДХИ ДАННЫХ

                    /////второе условие чтобы uuid не вставлем тоже


                    /// TODO ТУТ ПРОИЗВОДИТЬСЯ ОБНОВЛЕНИЕ ДАННЫХ
                    АдаптерПриОбновленияДанныхсСервера.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);////заполняем контрейнер обнолвеними

                    ////
                    Log.d(this.getClass().getName(), " Курсор_УзнатьЕслиНаАндройдеТакойUUID " + Курсор_УзнатьЕслиНаАндройдеТакойUUID + " АдаптерПриОбновленияДанныхсСервера.size() "
                            + АдаптерПриОбновленияДанныхсСервера.size());


                    ///TODO ВСТАВКА ЧЕРЕЗ UUID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID
                } else {
                    ///TODO ВСТАВКА ЧЕРЕЗ UUID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID     ///TODO ВСТАВКА ЧЕРЕЗ ID

                    АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                    Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер UUID " + АдаптерДляВставкиДанныхсСервер.size());

                }


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }/*finally {
            //
            if(Курсор_УзнатьЕслиНаАндройдеТакойUUID!=null){
                /////////s
                if(!Курсор_УзнатьЕслиНаАндройдеТакойUUID.isClosed()){
                    //
                    Курсор_УзнатьЕслиНаАндройдеТакойUUID.close();
                }
            }
        }*/


        // TODO: 14.09.2021 Результат Контейнер

        return  РезультатЕстьUUIDилНет;


    }


////////















    ///////todo АНАЛИХ ID
    Integer МетодАнализаIDСинхрониазциивФоне(String JSON_ИмяСтолбца, String JSON_ИмяСодержимое,
                                          String имяТаблицыОтАндройда_локальноая, String IDИзПришедшегоJSON,
                                             CompletionService МенеджерПотоковВнутрений) throws ExecutionException, InterruptedException, TimeoutException {



        Integer  ЕстьIDДляЭтойЗаписиИлиНет=0;
        ////////

        Class_GRUD_SQL_Operations class_grud_sql_operationsАнализаIDСинхрониазциивФоне;
        ///


        try {

            String ИндификаторДляIDВзависмостиОтТаблицы = "id";
            ///
//////наобород
            switch (имяТаблицыОтАндройда_локальноая.trim().toLowerCase()) {

                case "tabels":
                case "chats":
                case "data_chat":
                case "chat_users":
                case "fio":
                case "tabel":
                case "data_tabels":
                    //
                    System.out.println("  КлючJsonСтроки  " + JSON_ИмяСтолбца);

                    ИндификаторДляIDВзависмостиОтТаблицы = "_id";

                    if (JSON_ИмяСтолбца.equals("id")) {
                        //TODO сам столбиц
                        JSON_ИмяСтолбца = ИндификаторДляIDВзависмостиОтТаблицы;
                    }

                    break;
            }

            ///


            System.out.println("  JSON_ИмяСтолбца  " + JSON_ИмяСтолбца + " ИндификаторДляIDВзависмостиОтТаблицы " + ИндификаторДляIDВзависмостиОтТаблицы);


            /////
            String ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде;///////
            ////todo  ПЫТАЕМСЯ ОРГАНИЗОВАТЬ ОБНОВЛЕНИЕ НО ТОЛЬКО ЕСЛИ ВЛАГ  TRUE

         SQLiteCursor   SQLiteCursorКурсор_УзнатьЕслиНаАндройдеТакойID=null;

// TODO: 06.09.2021  start new ende

            class_grud_sql_operationsАнализаIDСинхрониазциивФоне=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);

            ///
            ///
            class_grud_sql_operationsАнализаIDСинхрониазциивФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы",имяТаблицыОтАндройда_локальноая);
            ///////
            class_grud_sql_operationsАнализаIDСинхрониазциивФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки",ИндификаторДляIDВзависмостиОтТаблицы);
            //
            class_grud_sql_operationsАнализаIDСинхрониазциивФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика",ИндификаторДляIDВзависмостиОтТаблицы+"=? ");
            ///"_id > ?   AND _id< ?"
            //////
            class_grud_sql_operationsАнализаIDСинхрониазциивФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",IDИзПришедшегоJSON);
            ///
   /*         class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......

            ////TODO другие поля

            ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
            ////
            //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
            ////
            class_grud_sql_operationsАнализаUUIDСинхрониазциявФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
            ////*/
            /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
            ////

            // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

            SQLiteCursor Курсор_УзнатьЕслиНаАндройдеТакойID=null;
            /////

            Log.d(this.getClass().getName(), "КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал  "+КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал+
                     " IDПолеУжеПроверелиЧерезКурсор " +IDПолеУжеПроверелиЧерезКурсор);


            if (КакойРежимСинхрониазцииПерваяСинхронизациИлиПовторнаяФинал.equalsIgnoreCase("ПовторныйЗапускСинхронизации") && IDПолеУжеПроверелиЧерезКурсор==false) {
                ////////
                Курсор_УзнатьЕслиНаАндройдеТакойID= (SQLiteCursor)  new Class_GRUD_SQL_Operations(contextСозданиеБАзы).
                        new GetData(contextСозданиеБАзы).getdata(class_grud_sql_operationsАнализаIDСинхрониазциивФоне. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                ////////
                Log.d(this.getClass().getName(), " Курсор_УзнатьЕслиНаАндройдеТакойID " + Курсор_УзнатьЕслиНаАндройдеТакойID);


                if ( Курсор_УзнатьЕслиНаАндройдеТакойID.getCount() > 0) {

                    //////////
                    Курсор_УзнатьЕслиНаАндройдеТакойID.moveToFirst();

                    ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде = Курсор_УзнатьЕслиНаАндройдеТакойID.getString(0);
                    Log.d(this.getClass().getName(), "ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде" + ДействительноЛиIDКоторыйПришелсСервераУжеЕстьНаАндройде);


                    ////////
                    Log.d(this.getClass().getName(), " Курсор_УзнатьЕслиНаАндройдеТакойID.getCount() " + Курсор_УзнатьЕслиНаАндройдеТакойID.getCount() +
                            " IDИзПришедшегоJSON " + IDИзПришедшегоJSON);

                    IDПолеУжеПроверелиЧерезКурсор=true;

                }


                Log.d(this.getClass().getName(), "GetData "+Курсор_УзнатьЕслиНаАндройдеТакойID   );
            }




/*
            // TODO: 06.09.2021  _old
            //////
            Курсор_УзнатьЕслиНаАндройдеТакойID = КурсорУниверсальныйДляБазыДанных(имяТаблицыОтАндройда_локальноая,
                    new String[]{ИндификаторДляIDВзависмостиОтТаблицы}, ИндификаторДляIDВзависмостиОтТаблицы + "=?", new String[]{IDИзПришедшегоJSON}, null, null,
                    null, null);//"SuccessLogin", "date_update","id=","1",null,null,null,null
*/

///////



                ///
                if ( IDПолеУжеПроверелиЧерезКурсор==true) {
                    //


                    ЕстьIDДляЭтойЗаписиИлиНет++;


                    Log.d(this.getClass().getName(), " JSON_ИмяСтолбца " + JSON_ИмяСтолбца + " JSON_ИмяСодержимое " + JSON_ИмяСодержимое);
                    //////МЕТОДКОТРЫЙ ПРИ ОТСТВИИИ UUID ЕГО ГЕНЕРИРЕТ НА ПРИШЕЛДХИ ДАННЫХ

                    /////второе условие чтобы uuid не вставлем тоже


                    ////// TODO ИЗ ПРАВИЛА ЧТО НЕЛЬЗЯ ОБНОЛВЛЯТЬ ПОЕЛ UUID ПРОПУСКАЕМ ЕГО ЭТО КОГДА СТОЛБИК ID ПРОПУСКАЕМ


                    ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID          ///TODO ОБНОВЛЕНИЕ ЧЕРЕЗ ID
                    АдаптерПриОбновленияДанныхсСервера.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);////заполняем контрейнер обнолвеними

                    ////
                    Log.d(this.getClass().getName(), " Курсор_УзнатьЕслиНаАндройдеТакойUUID " + Курсор_УзнатьЕслиНаАндройдеТакойID + " АдаптерПриОбновленияДанныхсСервера.size() "
                            + АдаптерПриОбновленияДанныхсСервера.size());


                    ///TODO ВСТАВКА ЧЕРЕЗ ID       ///TODO ВСТАВКА ЧЕРЕЗ ID
                } else {
                    ///TODO ВСТАВКА ЧЕРЕЗ ID

                    АдаптерДляВставкиДанныхсСервер.put(JSON_ИмяСтолбца, JSON_ИмяСодержимое);


                    Log.d(this.getClass().getName(), " АдаптерДляВставкиДанныхсСервер ID " + АдаптерДляВставкиДанныхсСервер.size());


                    /////
                }//todo end     ///////TODO КОГДА ЕСТЬ ТОЛЬКО ID ШНИК ОБНОВЛЕНИЕ




        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }/*finally {
            if (Курсор_УзнатьЕслиНаАндройдеТакойID != null) {
                if(!Курсор_УзнатьЕслиНаАндройдеТакойID.isClosed()){
                    //
                    Курсор_УзнатьЕслиНаАндройдеТакойID.close();
                }
            }
        }*/
        // TODO: 14.09.2021 Результат Контейнер

        return  ЕстьIDДляЭтойЗаписиИлиНет;
    }




































    // TODO: 13.09.2021 МЕТОД ОЧИСТКИ ТАБЛИЦ
    public void МетодОчищаемИзБазыNULLЗначенияя(CompletionService МенеджерПотоковВнутрений) {


        Class_GRUD_SQL_Operations class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя;

        Long РезультатУдалениеОчисткиТаблиц=0l;
        try {

            // TODO: 26.03.2021 ДОПОЛНИТЕЛЬНО ОБНУЛЯЕМ ВСЕ ТАБЕЛЯ С NULL В ФИО ЧТО БЫ ОБМЕН НЕ РУГАЛЬСЯ
                 //  ССылкаНаСозданнуюБазу.

                 ////
                 class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);
                 ///
                 class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя=new Class_GRUD_SQL_Operations(contextСозданиеБАзы);


LinkedBlockingQueue<String> linkedBlockingQueueДляУдалениеТаблиц= new LinkedBlockingQueue();

                 linkedBlockingQueueДляУдалениеТаблиц.put("fio");
                 ////
                 linkedBlockingQueueДляУдалениеТаблиц.put("cfo");
                 ////
                 linkedBlockingQueueДляУдалениеТаблиц.put("tabels");
                 ////
                 linkedBlockingQueueДляУдалениеТаблиц.put("fio");
                 ////
                 linkedBlockingQueueДляУдалениеТаблиц.put("tabels");
                 ////
              Iterator<String> iteratorДляУдалениеНазваниеТаблиц
                      =linkedBlockingQueueДляУдалениеТаблиц.iterator();

              ////
                 ArrayList<String> arrayListСтобцыДляУдаления=new ArrayList();


                while (iteratorДляУдалениеНазваниеТаблиц.hasNext()){
                    ////
                    String ТекущаяНазваниеТаблицыДляУдаления=iteratorДляУдалениеНазваниеТаблиц.next();
                    //
                    Log.d(this.getClass().getName(), "ТекущаяНазваниеТаблицыДляУдаления"+
                            ТекущаяНазваниеТаблицыДляУдаления);

                    //
                    switch (ТекущаяНазваниеТаблицыДляУдаления.trim()){

                        case "tabels":
                            //

                            arrayListСтобцыДляУдаления.add("fio");//
                            //
                            arrayListСтобцыДляУдаления.add("cfo");//
                            ///
                            arrayListСтобцыДляУдаления.add("nametabel_typename");//
                            ////
                            arrayListСтобцыДляУдаления.add("uuid");//




                            ///TODO ОБНОЛВЕНИЕ
                            for (int i = 0; i < arrayListСтобцыДляУдаления.size(); i++) {


                            // TODO: 06.09.2021  ПАРАМЕНТЫ ДЛЯ ОБНОВЛЕНИЯ

                            class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","tabels");
                            //

                            class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("Флаг_ЧерезКакоеПолеУдаление", arrayListСтобцыДляУдаления.get(i)+" IS NULL");
                            ///

                            class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ЗнакФлагУдаление","=");


                            ///TODO РЕЗУЛЬТАТ ОБНОВЛЕНИЕ ДАННЫХ


                                РезультатУдалениеОчисткиТаблиц= (Long)  class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя.
                                        new DeleteData(contextСозданиеБАзы).deletedata(class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                            ///
                            ///
                            Log.d(contextСозданиеБАзы.getClass().getName(), " РезультатУдалениеОчисткиТаблиц" + "--" + РезультатУдалениеОчисткиТаблиц);/////

                            }

                            // TODO: 06.09.2021  clsear
                            arrayListСтобцыДляУдаления.clear();

           /*                 // TODO: 06.09.2021  _old

                            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE fio IS NULL");

                            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE cfo IS NULL");

                            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE nametabel_typename IS NULL");

                            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM tabels   WHERE uuid IS NULL");*/


                            break;
///////
                        case "fio":
                            //
                            arrayListСтобцыДляУдаления.add("uuid");//
                            //
                            ///TODO ОБНОЛВЕНИЕ
                            for (int i = 0; i < arrayListСтобцыДляУдаления.size(); i++) {


                                // TODO: 06.09.2021  ПАРАМЕНТЫ ДЛЯ ОБНОВЛЕНИЯ

                                class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","fio");
                                //

                                class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("Флаг_ЧерезКакоеПолеУдаление", arrayListСтобцыДляУдаления.get(i)+" IS NULL");
                                ///

                                class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ЗнакФлагУдаление","=");


                                ///TODO РЕЗУЛЬТАТ ОБНОВЛЕНИЕ ДАННЫХ


                                РезультатУдалениеОчисткиТаблиц= (Long) class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя.
                                        new DeleteData(contextСозданиеБАзы).deletedata(class_grud_sql_operationsОчищаемИзБазыNULLЗначенияя. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                                ///
                                ///
                                Log.d(contextСозданиеБАзы.getClass().getName(), " РезультатУдалениеОчисткиТаблиц" + "--" + РезультатУдалениеОчисткиТаблиц);/////

                            }

                            // TODO: 06.09.2021  clsear
                            arrayListСтобцыДляУдаления.clear();
                            // TODO: 06.09.2021   _old
/*
                            ССылкаНаСозданнуюБазу.execSQL("DELETE FROM fio   WHERE uuid IS NULL");*/

                            break;
///////

                    }


                    // TODO: 13.09.2021 выкидываем из очереди после обработки

                    linkedBlockingQueueДляУдалениеТаблиц.peek();

                }


            Log.d(this.getClass().getName(), "Удаление даных перед Синхронизацией NULL значения ");

            ///////todo\
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        // TODO: 01.09.2021 метод вызова
        new   Class_Generation_Errors(contextСозданиеБАзы).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
    }









/*    // TODO: 05.07.2021 код запуска метода для данных

    protected Long МетодЗапускаСинхронизацииПередСозданеимНовгоСообщенияДляЧата(Context context) {
        //
        Long РезультатСинхронизацииДОСозданиеЯСообщения = 0l;

        try {

            Log.d(this.getClass().getName(), "  МетодЗаписиНовгоСообщенияСамимКлиентом");


            /////TODO ВТОРОЙ ШАГ СИНХРОНИЗАЦИИ ПОЛУЧАЕМ СПИСОК ТАБЛИЦ КОТОРЫЕ НУЖНО  СИНХРОНИЗИРОВАТЬ 100% процентов , И ПРОВЕРМЯЕМ ЕСЛИ СВЯЗЬ С ИНТЕНТОМ

            boolean РезультатЕслиСвязьСерверомДСУ = false;

            РезультатЕслиСвязьСерверомДСУ =new Class_Connections_Server(context).МетодПингаСервераРаботаетИлиНет(context);

            //TODO ФУТУРЕ ЗАВЕРШАЕМ
            Log.d(this.getClass().getName(), "  РезультатЕслиСвязьСерверомДСУ " + РезультатЕслиСвязьСерверомДСУ);


            // TODO: 29.04.2021 вуключаем

            ////TODO ТОЛЬКО ПРИ НАЛИЧИИ ИНТРЕНТА  !!!!!!!!!!!!!!!! ЗАПУСК СИНХРОНИЗАЦИИ

            if (РезультатЕслиСвязьСерверомДСУ == true) {

*//*

                РезультатСинхронизацииДОСозданиеЯСообщения = new Class_Async_Background(context).
                        МетодЗАпускаФоновойСинхронизацииДляТабеляиДляЧата(context, "СинхронизацияДляЧата", true,ActivityДляСинхронизацииОбмена,null);
*//*



             РезультатСинхронизацииДОСозданиеЯСообщения=         new Class_Async_Background(context).
                        МетодЗАпускаФоновойСинхронизации(context, "СинхронизацияДляЧата", true,ActivityДляСинхронизацииОбмена,null,"ПовторныйЗапускСинхронизации");//"СамыйПервыйЗапускСинхронизации"



                ///
                Log.w(this.getClass().getName(), "МетодЗапускаЛокальнойСинхронизации() СЛУЖБА синхронизации запускаем через  getApplication()  СЛУЖБА фоновая СИНХРОНИЗАЦИЯ" + РезультатСинхронизацииДОСозданиеЯСообщения);

            }

            ///
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());

// TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(КонтекстСинхроДляКонтроллераВФоне).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

        }
        return РезультатСинхронизацииДОСозданиеЯСообщения;
    }
// TODO: 27.07.2021 для чата*/































































































    public  class ClassGettingPublicUserID extends Class_Async_Background {

        Context contextClassGettingPublicUserID;

        public ClassGettingPublicUserID(@NotNull Context context) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
            super(context);

            contextClassGettingPublicUserID=context;
            //



            ////// TODO созданеи шифрование
            if (ГлавныйКлючДляШифрованиеИРасшифровки == null) {
                //TODO ключ для шифрование и расщифровки
                byte[] CipherKey = "[C@3841f624[B@6415a86b[B@143c678".getBytes();
                ГлавныйКлючДляШифрованиеИРасшифровки =
                        new SecretKeySpec(CipherKey,
                                "AES");
               ПолитикаШифрование = Cipher.getInstance("AES");
                ПолитикаШифрование.init(Cipher.ENCRYPT_MODE, ГлавныйКлючДляШифрованиеИРасшифровки);
                ///////
                ПолитикаРасшифровки = Cipher.getInstance("AES");
                ПолитикаРасшифровки.init(Cipher.DECRYPT_MODE, ГлавныйКлючДляШифрованиеИРасшифровки);
                ///// конец шифрование
            }
            ////// конец  TODO созданеи шифрование


        }


        Integer МетодПолучениеОтСервераПубличногоID(CompletionService МенеджерПотоковВнутрений) {

            /////
            Integer ReceivedPublicID = 0;

            ////САМАЯ ПЕРВАЯ КОМАНДА НАЧАЛА ОБМНЕНА ДАННЫМИ

            StringBuffer БуферПолучениеДанных = new StringBuffer();
            ///
            Class_GRUD_SQL_Operations class_grud_sql_operations;

            try {

                ///
                        // TODO: 03.09.2021

                        //////САМ МЕТОД КОТОРЫМ ЗАПУСКАЕМ ПРОЦЕССС ОБМЕНА ДАННЫХ
                        try {
                            БуферПолучениеДанных =
                                    УниверсальныйБуферПолучениеДанныхсСервера("", "", "", "application/text", "Хотим Получить ID для Генерации  UUID", 0l, "",5000,null,0l,"tabel.dsu1.ru", 8888); //// БуферПолученнниеДанныхОтМетодаGET.mark(1000); // save the data we are about to readБуферПолученнниеДанныхОтМетодаGET.reset(); // jump back to the marked position
                            //////////


                            Log.d(this.getClass().getName(), "БуферПолучениеДанных " + БуферПолучениеДанных.toString());

                        } catch (Exception e) {
                            //  Block of code to handle errors
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                            // TODO: 01.09.2021 метод вызова
                            new   Class_Generation_Errors(КонтекстСинхроДляКонтроллераВФоне).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                    Thread.currentThread().getStackTrace()[2].getLineNumber());
                        }
                        ///

                ///
                if (БуферПолучениеДанных.length() > 0) {


                    ///////
                    ПубличноеIDПолученныйИзСервлетаДляUUID = Integer.parseInt(БуферПолучениеДанных.toString());
                    //

                    Log.d(this.getClass().getName(), " ПубличноеIDПолученныйИзСервлетаДляUUID  " + ПубличноеIDПолученныйИзСервлетаДляUUID);
                    //

                    ReceivedPublicID=Integer.parseInt( БуферПолучениеДанных.toString());


                    // TODO: 15.08.2021 записываем полученный Публчного ID

                        //////

          Long РезультатЗаписиНовгоIDБАзу=              new MODEL_synchronized(contextClassGettingPublicUserID).  МетодЗАписиПолученогоОтСервреаIDПубличного(    ReceivedPublicID );




                    ///
                    Log.d(this.getClass().getName(), "РезультатЗаписиНовгоIDБАзу  " + РезультатЗаписиНовгоIDБАзу);


                } else {

                    ///

                    SQLiteCursor Курсор_ВычисляемПУбличныйID = null;

                    // TODO: 05.07.2021  получаем публичный ID

                  //  Курсор_ВычисляемПУбличныйID = new MODEL_synchronized(contextClassGettingPublicUserID).КурсорУниверсальныйБазыДанных("SELECT id FROM SuccessLogin LIMIT 1 ");


                    // TODO: 03.09.2021  новый код движка полчение данных


                    // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                    //
                    ///
                    class_grud_sql_operations=new Class_GRUD_SQL_Operations(КонтекстСинхроДляКонтроллераВФоне);

                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","SuccessLogin");
                    ///////
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","id");
                    //
            /*        class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","uuid=?    AND status_send !=? AND month_tabels=? AND  year_tabels =? AND fio IS NOT NULL ");
                    ///"_id > ?   AND _id< ?"
                    //////
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",finalПолученныйUUID);
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......
*/
                    ////TODO другие поля

                    ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
                    ////
                    //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
                    ////
                    //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update DESC");
                    ////
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                    ////

                    // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

                    Курсор_ВычисляемПУбличныйID= (SQLiteCursor)  new Class_GRUD_SQL_Operations(КонтекстСинхроДляКонтроллераВФоне).
                            new GetData(КонтекстСинхроДляКонтроллераВФоне).getdata(class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,МенеджерПотоковВнутрений,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                    Log.d(this.getClass().getName(), "GetData "+Курсор_ВычисляемПУбличныйID  );




                    /////
                    if (Курсор_ВычисляемПУбличныйID.getCount() > 0) {
                        //////////
                        Курсор_ВычисляемПУбличныйID.moveToFirst();
                        //////////////
                        ПубличноеIDПолученныйИзСервлетаДляUUID = Курсор_ВычисляемПУбличныйID.getInt(0);
                        //////


                    }

                }


                ///
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                // TODO: 01.09.2021 метод вызова
                new   Class_Generation_Errors(КонтекстСинхроДляКонтроллераВФоне).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                        this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }


    return  ReceivedPublicID;
        }


    }


}
