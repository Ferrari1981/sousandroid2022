package com.dsy.dsu;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder   ;
import android.os.Build;
import android.os.Environment;
import android.text.BoringLayout;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.loader.content.AsyncTaskLoader;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor    ;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService  ;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.ToDoubleBiFunction;
import java.util.stream.Stream;

import static java.util.Calendar.getInstance;

import com.google.gson.internal.Streams;

import rx.Observable;


///////TODO КЛАСС ВСЕ ОПЕРАЦИИ ВСТАВКИ УДАЛЕНИЕ ОБНОВЛЕНИЯ ВЫБОРКА ДАННЫХ В ОДНОМ МЕСТЕ
public class Class_GRUD_SQL_Operations extends CREATE_DATABASE {




    ////

    protected AsyncTaskLoader asyncTaskLoaderАунтификацияПользователя=null;

    ///////
    protected Stream Стрим=null;

    ///
    protected LinkedBlockingQueue БлокирующаяОчереть=new LinkedBlockingQueue();


    ///todo визуализаци синхронизации
    /// protected      МенеджерПотоков=null; //newSingleThreadExecutor()

    ///
    private Context contextClass_GRUD_SQL_Operations;
    ////////
    // TODO: 29.08.2021  ДЛЯ ОПЕРАЦИЙ grud РАБОТА С БАЗОЙ

    protected   Map<String,Object> concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций = Collections.synchronizedMap(new LinkedHashMap<String,Object>());
    ///

    protected Callable<Object> ЛистДляGRUDопераций = null;
    //


    // TODO: 29.08.2021  ДЛЯ ОПЕРАЦИЙ grud РАБОТА С БАЗОЙ

    ContentValues contentValuesДляSQLBuilder_Для_GRUD_Операций  = new ContentValues();



    //todo ССЛЫКА НА БАЗОВЫ КЛАСС
  //  CREATE_DATABASE Create_Database_СсылкаНАБазовыйКласс=null;


    private    SQLiteQueryBuilder    SQLBuilder_Для_GRUD_Операций =null;





    // TODO: 27.08.2021  Конструктор Главного Класса для Операций GRUD







    public Class_GRUD_SQL_Operations(@NotNull  Context context) {
        super(context);

        //TODO контроль потоков
        ////
        contextClass_GRUD_SQL_Operations =context;



    }













    //TODO КЛАСС ПОЛУЧЕНИЕ ДАННЫХ
    class  GetData extends Class_GRUD_SQL_Operations {

        public GetData(@NotNull Context context) {
            super(context);

            //todo ПОДКЛЮЯЕМ КЛАСС ВЫШЕСТОЯЩИЙ ДЛЯ РАБОТЫ ОПЕРАЦИЙ grud
            /**
             *
             * @param context
             */
         ///   Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextClass_GRUD_SQL_Operations);
            ////
            ///
            /**
             *
             */
            SQLBuilder_Для_GRUD_Операций =new SQLiteQueryBuilder    ();


            //////////


        }

        // TODO: 30.08.2021  НИЖЕ  УКАЗАНЫ ВСЕ МЕТОДЫ ПОЛУЧЕНИЕ ОБНОВЛЕНИЯ ВСТАВКИ УДАЛЕНИЕ ДАННЫХ


        // TODO: 27.08.2021 МЕТОД  ПОЛУЧЕНИЯ ДАННЫХ
        Object getdata(Map<String,Object>   concurrentHashMap,CompletionService МенеджерПотоков,SQLiteDatabase getБазаДанныхДЛяОперацийВнутри) throws ExecutionException, InterruptedException {
            ///////
            Object Getdata=null;
            //////// TODO запуск менеджера потоков
            // TODO: 29.08.2021 СОЗДАЕМ ЗАДАЧУ ДЛЯ ВЫПОЛЕНИЯ ЧЕРЕЗ CALLABLE





        ЛистДляGRUDопераций=new Callable<Object>() {
                @Override
                public Object call() throws Exception {

                    /////TODO начало самого кода

                    Object getdata=null;
                    /////
                    try {
                        // TODO: 27.08.2021 парарменты
                        String НазваниеОбрабоатываемойТаблицы=null;
                        //
                        String    СтолбцыОбработки=null;

                        String ФорматПосика=null;
                        /////
                        String УсловиеПоиска[]=new String[50];
                        //
                        String ПоляГрупировки=null;
                        ///
                        String УсловиеГрупировки=null;
                        ///
                        String УсловиеСортировки=null;
                        ///
                        String УсловиеЛимита=null;

                        ///true and false
                        Boolean ФлагНепотораяемостиСтрок=false;

                        ////Работа с применением подзапросов

                        String ПодЗапросНомер1=null;
                        ///
                        String ПодЗапросНомер2=null;



                        ///TODO конец параментов
                        // TODO: 27.08.2021 само значние
                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap " + concurrentHashMap.values());


                        //TODO ЦИКЛ ПО ПАРАМЕТРАМ
                        for (Object КлючconcurrentHashMap : concurrentHashMap.keySet()) {

                            Object ЗначениеconcurrentHashMap = concurrentHashMap.get(КлючconcurrentHashMap);
                            //

                            Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap.toString() " + concurrentHashMap.toString());

                            // TODO: 27.08.2021  присваевываем значения полям для получение данных

                            switch (КлючconcurrentHashMap.toString().trim()){

                                case "НазваниеОбрабоатываемойТаблицы" :
                                    //////
                                    НазваниеОбрабоатываемойТаблицы=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                ///////
                                case "СтолбцыОбработки" :
                                    СтолбцыОбработки=ЗначениеconcurrentHashMap.toString().trim();;
                                    break;
                                ///
                                case "ФорматПосика" :
                                    ФорматПосика=ЗначениеconcurrentHashMap.toString().trim();
                                    break;
                                ///
                                //////
                                case "УсловиеПоиска1" :
                                    ///////
                                    УсловиеПоиска[0]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                case "УсловиеПоиска2" :
                                    ///////
                                    УсловиеПоиска[1]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска3" :
                                    ///////
                                    УсловиеПоиска[2]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска4" :
                                    ///////
                                    УсловиеПоиска[3]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска5" :
                                    ///////
                                    УсловиеПоиска[4]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////

                                //////
                                case "УсловиеПоиска6" :
                                    ///////
                                    УсловиеПоиска[5]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////

                                //////
                                case "УсловиеПоиска7" :
                                    ///////
                                    УсловиеПоиска[6]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска8" :
                                    ///////
                                    УсловиеПоиска[7]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска9" :
                                    ///////
                                    УсловиеПоиска[8]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска10" :
                                    ///////
                                    УсловиеПоиска[9]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска11" :
                                    ///////
                                    УсловиеПоиска[10]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска12" :
                                    ///////
                                    УсловиеПоиска[11]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска13" :
                                    ///////
                                    УсловиеПоиска[12]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска14" :
                                    ///////
                                    УсловиеПоиска[13]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска15" :
                                    ///////
                                    УсловиеПоиска[14]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////

                                //////
                                case "УсловиеПоиска16" :
                                    ///////
                                    УсловиеПоиска[15]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////

                                //////
                                case "УсловиеПоиска17" :
                                    ///////
                                    УсловиеПоиска[16]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////
                                //////
                                case "УсловиеПоиска18" :
                                    ///////
                                    УсловиеПоиска[17]=ЗначениеconcurrentHashMap.toString().trim();

                                    break;
                                //////

// TODO: 27.08.2021  конец столбиков с параметрами условия посика


                                //////
                                case "ПоляГрупировки" :
                                    ПоляГрупировки=ЗначениеconcurrentHashMap.toString().trim();
                                    break;
                                /////
                                case "УсловиеГрупировки" :
                                    УсловиеГрупировки=ЗначениеconcurrentHashMap.toString().trim();
                                    break;
                                //////
                                case "УсловиеСортировки" :
                                    УсловиеСортировки=ЗначениеconcurrentHashMap.toString().trim();
                                    break;
                                //////
                                case "УсловиеЛимита" :
                                    УсловиеЛимита=ЗначениеconcurrentHashMap.toString().trim();
                                    break;
                                //////////
                                //////
                                case "ФлагНепотораяемостиСтрок" :
                                    ФлагНепотораяемостиСтрок=  (Boolean) ЗначениеconcurrentHashMap;
                                    break;
                                //////////

                                // TODO: 09.09.2021 Sub --querty
                                //////
                                case "ПодЗапросНомер1" :
                                    ПодЗапросНомер1=ЗначениеconcurrentHashMap.toString().trim();
                                    break;
                                //////////
                                //////
                                case "ПодЗапросНомер2" :
                                    ПодЗапросНомер2=ЗначениеconcurrentHashMap.toString().trim();
                                    break;
                                //////////
                                // TODO: 27.08.2021  конец присвоение параментов

                                // TODO: 27.08.2021  конец присвоение параментов

////
                            }

                        }

                        // TODO: 27.08.2021  проверка параметров чтоюбы небыло NULL
                        LinkedHashMap<String,Object> concurrentHashMapТолькоДляЗбораЗаполенныхПараметровУсловияФильтра=new LinkedHashMap<String,Object> ();

                        // TODO: 30.08.2021   цикл упаковываем ппарметры в массик для ЗАПРОСА
                        for (int i=0;i<УсловиеПоиска.length ; i++ ) {

                            //TODO dont null

                            Log.d(contextClass_GRUD_SQL_Operations.getClass().getName(), "УсловиеПоиска[i] " + УсловиеПоиска[i]);

                            // TODO: 03.09.2021  ВСТАВЛЯЕМ ТОЛЬКО ТЕ ПАРАРМЕНТЫ КОТОРЫ НЕ NULL

                            if (УсловиеПоиска[i] != null) {
                                ////TOdo ПОЛУЧЕНИЕ ХАША ДЛЯ ЗАПСРОСА
                                concurrentHashMapТолькоДляЗбораЗаполенныхПараметровУсловияФильтра.put(УсловиеПоиска[i],УсловиеПоиска[i]);
                                //
                                Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), " concurrentHashMapТолькоДляЗбораЗаполенныхПараметровУсловияФильтра.values().toString()  "
                                        + concurrentHashMapТолькоДляЗбораЗаполенныхПараметровУсловияФильтра.values().toString());

                            }

                        }

                        // TODO: 31.08.2021
                        String[] ПолученныеПараметрыДляУсловияПосикаФинал=null;

                        if (concurrentHashMapТолькоДляЗбораЗаполенныхПараметровУсловияФильтра.size()>0) {
                            /////
                            ПолученныеПараметрыДляУсловияПосикаФинал= concurrentHashMapТолькоДляЗбораЗаполенныхПараметровУсловияФильтра.values().
                                    toArray(new String[ concurrentHashMapТолькоДляЗбораЗаполенныхПараметровУсловияФильтра.size()]);
                        }


                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), " ПолученныеПараметрыДляУсловияПосикаФинал  "
                                + ПолученныеПараметрыДляУсловияПосикаФинал);

                        ///TODO тело самого кода    ////
                        ///

                        SQLBuilder_Для_GRUD_Операций.setTables(НазваниеОбрабоатываемойТаблицы);

                        //
                        if (ФорматПосика!=null) {
                            ////
                            SQLBuilder_Для_GRUD_Операций.appendWhere(ФорматПосика);
                        }
                        ////
                        //
                        if (ФлагНепотораяемостиСтрок!=null) {
                            ////
                            SQLBuilder_Для_GRUD_Операций.setDistinct(ФлагНепотораяемостиСтрок);
                        }
                        ////



                        // TODO: 26.08.2021  только выборка данных EXE -- КОМКАНДА
                        Log.w(this.getClass().getName(), "ПодЗапросНомер1   "
                                + ПодЗапросНомер1 + " ПодЗапросНомер2 " +ПодЗапросНомер2);


                        // TODO: 09.09.2021  ЕСЛИ ПОД ЗАПРОССОВ НЕТ ТО ЭТО ПРОСТОЙ ЗАПРОС ПОЛУЧЕНИЕ ДАННЫХ


                        if (ПодЗапросНомер1==null && ПодЗапросНомер2==null) {
                            ////
                            getdata =
                                    SQLBuilder_Для_GRUD_Операций.query(getБазаДанныхДЛяОперацийВнутри,new String[]{СтолбцыОбработки},
                                            null,ПолученныеПараметрыДляУсловияПосикаФинал
                                            ,ПоляГрупировки, УсловиеГрупировки, УсловиеСортировки,УсловиеЛимита);//ФорматПосика выше


                            // TODO: 09.09.2021  РЕЗУЛЬТА ПОЛУЧЕНИЕ ДАННЫХ ЧЕРЕЗ НОВЫЙ ДВИЖОК

                            // TODO: 09.09.2021  РЕЗУЛЬТА ПОЛУЧЕНИЕ ДАННЫХ ЧЕРЕЗ НОВЫЙ ДВИЖОК


                            Log.w(this.getClass().getName(), "   РЕЗУЛЬТАТ GetData  ПОЛУЧЕНИЕ  ДАННЫХ    КОЛ СТРОЧКЕ:  "+ ((SQLiteCursor) getdata).getCount());


                        } else {

                            // TODO: 09.09.2021  ВТОРОЙ ВАРИАНТ ПОЛУЧЕНИЕ ДАННЫХ С ПРИМЕНЕНИЕМ SUB- ПОД ЗАПРОСА//"SELECT name_col FROM table1 WHERE " + BAR_COLUMN + "='bar'",
                            //                                "SELECT name_col FROM table1 WHERE " + FOO_COLUMN + " LIKE 'foor''"


                            String[] subQueries = new String[] {
                                    ПодЗапросНомер1,
                                    ПодЗапросНомер2
                            };
                            String query =    SQLBuilder_Для_GRUD_Операций.buildUnionQuery(subQueries, null ,null);
                            ///
                            getdata =   getБазаДанныхДЛяОперацийВнутри.rawQuery(query, null);

                            // TODO: 09.09.2021  РЕЗУЛЬТА ПОЛУЧЕНИЕ ДАННЫХ ЧЕРЕЗ НОВЫЙ ДВИЖОК


                            Log.w(this.getClass().getName(), "   РЕЗУЛЬТАТ GetData  ПОЛУЧЕНИЕ  ДАННЫХ  SUB UNION   КОЛ СТРОЧКЕ:  "+ ((SQLiteCursor) getdata).getCount());


                        }




                        Log.w(this.getClass().getName(), " ЕДИНСТВЕННЫЙ         ПОЛУЧЕНИЯ ДАННЫХ   "
                                + getdata);

                        ///TODO тело самого кода    ////

                    } catch (Exception e) {
                        e.printStackTrace();
                        //  Block of code to handle errors
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new   Class_Generation_Errors(contextClass_GRUD_SQL_Operations).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ///////
                    }

                    // TODO: 29.08.2021  MAIN EXE запуск выполения любого кода через  CALLABLE

                    /////TODO конец  самого кода

                    return getdata;
                }
            };


            //TODO конец выполения кода через Callble  , отправляем его в главный менеджер пОТОКОВ

            Getdata=     new ClassRuntimeExeGRUDOpertions(contextClass_GRUD_SQL_Operations).МетодЗапускаОперацийGRUD_exe(ЛистДляGRUDопераций,МенеджерПотоков);

            ////
            Log.d(this.getClass().getName(), "   рЕЗУЛЬТАТ МЕТОДА ПОЛУЧЕНИЕ ДАННЫХ ЧЕРЕЗ ОДИН МЕТДЖЕР ПОТОКОВ  Getdata "+Getdata);



            //////// TODO конец  менеджера потоков

            return Getdata;
        }

    }

// TODO: 17.09.2021  END GETDATA




































    //TODO КЛАСС Вставки ДАННЫХ
    class  InsertData extends Class_GRUD_SQL_Operations {

        public InsertData(@NotNull Context context) {
            super(context);
            /**
             *
             * @param context
             */
           /// Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextClass_GRUD_SQL_Operations);

            /**
             *
             */
            SQLBuilder_Для_GRUD_Операций =new SQLiteQueryBuilder    ();

            //////////

        }



        // TODO: 27.08.2021 МЕТОД  ВСТАВКИ ДАННЫХ
        Object insertdata(Map<String,Object> concurrentHashMap, ContentValues contentValuesВставкаДанных , CompletionService МенеджерПотоков, SQLiteDatabase getБазаДанныхДЛяОперацийВнутри) throws ExecutionException, InterruptedException {
            ///////
            Object InsertData=null;
            //////// TODO запуск менеджера потоков

            try {
                ///TODO тело самого кода List    ////
          ЛистДляGRUDопераций = new Callable<Object>() {
                    @Override
                    public Object call() throws Exception {
                        /////
                        Object insertData=null;
                        // TODO: 30.08.2021  параметры
                        String  НазваниеОбрабоатываемойТаблицы=null;



   /*                     Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap " + concurrentHashMap.values() +
                                "  contentValuesВставкаДанных " +contentValuesВставкаДанных.valueSet());
*/
                        //TODO ЦИКЛ ПО ПАРАМЕТРАМ
                        for (Object КлючconcurrentHashMap : concurrentHashMap.keySet()) {

                            Object ЗначениеconcurrentHashMap = concurrentHashMap.get(КлючconcurrentHashMap);
                            //

                            Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap.toString() " + concurrentHashMap.toString());

                            // TODO: 27.08.2021  присваевываем значения полям для получение данных

                            switch (КлючconcurrentHashMap.toString().trim()){

                                case "НазваниеОбрабоатываемойТаблицы" :
                                    //////
                                    НазваниеОбрабоатываемойТаблицы=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;

                                ///
///
                            }

                        }

                        Log.w(this.getClass().getName(), "   НазваниеОбрабоатываемойТаблицы   "+НазваниеОбрабоатываемойТаблицы);

                        //////TODO конец параменты

                        // TODO: 30.08.2021  ОРМИРУЕМ КОРКАТ БУДЩЕЙ ВСТАВКИ ДАННЫХ

                        ////////////
                        SQLBuilder_Для_GRUD_Операций.setTables(НазваниеОбрабоатываемойТаблицы);

                        /////TODO операция ВСТАВКИ
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            ////////
                            insertData =    SQLBuilder_Для_GRUD_Операций.insert( getБазаДанныхДЛяОперацийВнутри, contentValuesВставкаДанных);
                        } else {
                            /////TODO операция ВСТАВКИ
                            ///
                            insertData =getБазаДанныхДЛяОперацийВнутри.insert(НазваниеОбрабоатываемойТаблицы, null, contentValuesВставкаДанных);

                        }
                        ///////
                        /////TODO РЕЗУЛЬТАТ операция ВСТАВКИ
                        ///
                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), " РЕЗУЛЬТАТ insertData  ВСТАВКИ ЗНАЧЕНИЯ  " +  insertData.toString() );
                        //////

                        return insertData;
                    }
                };


                //TODO конец выполения кода через Callble  , отправляем его в главный менеджер пОТОКОВ

                InsertData=     new ClassRuntimeExeGRUDOpertions(contextClass_GRUD_SQL_Operations).МетодЗапускаОперацийGRUD_exe(ЛистДляGRUDопераций,МенеджерПотоков);

                ///
                Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), " РЕЗУЛЬТАТ InsertData  ВСТАВКИ ЗНАЧЕНИЯ  " +  InsertData.toString() );
                /////




            } catch (Exception e) {
                ///////TODO error
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());

                new   Class_Generation_Errors(contextClass_GRUD_SQL_Operations).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                /////
            }
            //////// TODO конец  менеджера потоков

            return InsertData;
        }

    }













    //TODO КЛАСС Обновление ДАННЫХ
    class  UpdateData extends Class_GRUD_SQL_Operations {

        public UpdateData(@NotNull Context context) {
            super(context);
            /**
             *
             * @param context
             */
          //  Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextClass_GRUD_SQL_Operations);
            /**
             *
             */
            SQLBuilder_Для_GRUD_Операций =new SQLiteQueryBuilder    ();

            //////////

        }


        // TODO: 27.08.2021 МЕТОД  ПОЛУЧЕНИЯ ДАННЫХ
        Object updatedata(Map<String,Object> concurrentHashMap, ContentValues contentValuesДляОбновленияДАнных,CompletionService МенеджерПотоков,SQLiteDatabase getБазаДанныхДЛяОперацийВнутри) throws ExecutionException, InterruptedException {
            ///////////
            Object Updatedata=null;
            //////// TODO запуск менеджера потоков
            try {
                ///TODO тело самого кода List    ////
                ЛистДляGRUDопераций= new Callable<Object>() {
                    @Override
                    public Object call() throws Exception {
                        /////
                        Object updatedata=null;
                        ///
                        // TODO: 30.08.2021  параметры
                        String  НазваниеОбрабоатываемойТаблицы=null;
                        /////
                        String  Флаг_ЧерезКакоеПолеОбновлением=null;

                        //
                        String  ЗначениеФлагОбновления=null;

                        //
                        String ЗнакФлагОбновления=null;


                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap " + concurrentHashMap.values() +
                                "  contentValuesДляОбновленияДАнных " +contentValuesДляОбновленияДАнных.valueSet());

                        //TODO ЦИКЛ ПО ПАРАМЕТРАМ
                        for (Object КлючconcurrentHashMap : concurrentHashMap.keySet()) {

                            Object ЗначениеconcurrentHashMap = concurrentHashMap.get(КлючconcurrentHashMap);
                            //

                            Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap.toString() " + concurrentHashMap.toString());

                            // TODO: 27.08.2021  присваевываем значения полям для получение данных

                            switch (КлючconcurrentHashMap.toString().trim()){

                                //
                                case "НазваниеОбрабоатываемойТаблицы" :
                                    //////
                                    НазваниеОбрабоатываемойТаблицы=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///

                                //
                                case "Флаг_ЧерезКакоеПолеОбновлением" :
                                    //////
                                    Флаг_ЧерезКакоеПолеОбновлением=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///

                                //
                                case "ЗначениеФлагОбновления" :
                                    //////
                                    ЗначениеФлагОбновления=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///
                                //
                                case "ЗнакФлагОбновления" :
                                    //////
                                    ЗнакФлагОбновления=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///




                                ///
///
                            }

                        }

                        Log.w(this.getClass().getName(), "   НазваниеОбрабоатываемойТаблицы   "+НазваниеОбрабоатываемойТаблицы);

                        //////TODO конец параменты

                        // TODO: 30.08.2021  ОРМИРУЕМ КОРКАТ БУДЩЕЙ ВСТАВКИ ДАННЫХ

                        //


                        ////////////
                        SQLBuilder_Для_GRUD_Операций.setTables(НазваниеОбрабоатываемойТаблицы);

                        /////TODO операция ВСТАВКИ

                        /////////////
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                            //////////TODO само обновление
                            updatedata =             SQLBuilder_Для_GRUD_Операций.
                                    update(getБазаДанныхДЛяОперацийВнутри,contentValuesДляОбновленияДАнных, Флаг_ЧерезКакоеПолеОбновлением +  ""+ЗнакФлагОбновления+ "?",
                                            new String[]{ЗначениеФлагОбновления});
                        }else{

                            updatedata =           getБазаДанныхДЛяОперацийВнутри
                                    .update(НазваниеОбрабоатываемойТаблицы,contentValuesДляОбновленияДАнных,Флаг_ЧерезКакоеПолеОбновлением +  ""+ЗнакФлагОбновления+ "?", new String[]{ЗначениеФлагОбновления});
                        }

                        /////TODO РЕЗУЛЬТАТ операция Обновление
                        //////

                        Log.d(contextClass_GRUD_SQL_Operations.getClass().getName(), " updatedata " + updatedata.toString());
                        ////////

                        return updatedata;
                    }
                };


                //TODO конец выполения кода через Callble  , отправляем его в главный менеджер пОТОКОВ

                Updatedata=     new ClassRuntimeExeGRUDOpertions(contextClass_GRUD_SQL_Operations).МетодЗапускаОперацийGRUD_exe(ЛистДляGRUDопераций,МенеджерПотоков);

                ///

                /////
                ///
                Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), " РЕЗУЛЬТАТ Updatedata  ОБНОВЛЕНИЕ ЗНАЧЕНИЯ  " +  Updatedata.toString() );


                /////

            } catch (Exception e) {
                ///////TODO error
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());

                new   Class_Generation_Errors(contextClass_GRUD_SQL_Operations).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                /////
            }
            //////// TODO конец  менеджера потоков

            return Updatedata;
        }

    }




















    //TODO КЛАСС СОН SLEEP ДАННЫХ
    class  SleepData extends Class_GRUD_SQL_Operations {
        public SleepData(@NotNull Context context) {
            super(context);
            /**
             *
             * @param context
             */
            //Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextClass_GRUD_SQL_Operations);

            /**
             *
             */
            SQLBuilder_Для_GRUD_Операций =new SQLiteQueryBuilder    ();


        }
        // TODO: 27.08.2021 МЕТОД  ПОЛУЧЕНИЯ ДАННЫХ
        Object sleepdata(Map<String,Object> concurrentHashMap, ContentValues contentValuesДляСнаДанных,CompletionService МенеджерПотоков,SQLiteDatabase getБазаДанныхДЛяОперацийВнутри) throws ExecutionException, InterruptedException {
            /////
            Object Sleepdata=null;
            //////// TODO запуск менеджера потоков

            try {
                ///TODO тело самого кода List    ////
                //////// TODO запуск менеджера потоков
                ///TODO тело самого кода List    ////
          ЛистДляGRUDопераций =new Callable<Object>() {
                    @Override
                    public Object call() throws Exception {
                        /////
                        Object sleepdata=null;
                        ///
                        // TODO: 30.08.2021  параметры
                        String  НазваниеОбрабоатываемойТаблицы=null;
                        /////
                        String  Флаг_ЧерезКакоеПолеСнаДанных=null;

                        //
                        String  ЗначениеФлагСнаДанных=null;


                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap " + concurrentHashMap.values() +
                                "  contentValuesДляСнаДанных " +contentValuesДляСнаДанных.valueSet());

                        //TODO ЦИКЛ ПО ПАРАМЕТРАМ
                        for (Object КлючconcurrentHashMap : concurrentHashMap.keySet()) {

                            Object ЗначениеconcurrentHashMap = concurrentHashMap.get(КлючconcurrentHashMap);
                            //

                            Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap.toString() " + concurrentHashMap.toString());

                            // TODO: 27.08.2021  присваевываем значения полям для получение данных

                            switch (КлючconcurrentHashMap.toString().trim()){

                                //
                                case "НазваниеОбрабоатываемойТаблицы" :
                                    //////
                                    НазваниеОбрабоатываемойТаблицы=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///

                                //
                                case "Флаг_ЧерезКакоеПолеСнаДанных" :
                                    //////
                                    Флаг_ЧерезКакоеПолеСнаДанных=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///

                                //
                                case "ЗначениеФлагСнаДанных" :
                                    //////
                                    ЗначениеФлагСнаДанных=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///



                                ///
///
                            }

                        }

                        Log.w(this.getClass().getName(), "   НазваниеОбрабоатываемойТаблицы   "+НазваниеОбрабоатываемойТаблицы);

                        //////TODO конец параменты

                        // TODO: 30.08.2021  ОРМИРУЕМ КОРКАТ БУДЩЕЙ ВСТАВКИ ДАННЫХ

                        //


                        ////////////
                        SQLBuilder_Для_GRUD_Операций.setTables(НазваниеОбрабоатываемойТаблицы);

                        /////TODO операция ВСТАВКИ

                        /////////////
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                            //////////TODO само обновление
                            sleepdata =             SQLBuilder_Для_GRUD_Операций.
                                    update(getБазаДанныхДЛяОперацийВнутри,contentValuesДляСнаДанных, Флаг_ЧерезКакоеПолеСнаДанных + "= ?",
                                            new String[]{ЗначениеФлагСнаДанных});
                        }else{

                            sleepdata =           getБазаДанныхДЛяОперацийВнутри
                                    .update(НазваниеОбрабоатываемойТаблицы,contentValuesДляСнаДанных,Флаг_ЧерезКакоеПолеСнаДанных + "= ?", new String[]{ЗначениеФлагСнаДанных});
                        }

                        /////TODO РЕЗУЛЬТАТ операция Обновление
                        //////

                        ////
                        Log.w(this.getClass().getName(), "   рЕЗУЛЬТАТ МЕТОДА ВСТАВКИ ДАННЫХ  УСПЕШНО  deletedata "+sleepdata);

                        ////////

                        return sleepdata;
                    }
                };


                //TODO конец выполения кода через Callble  , отправляем его в главный менеджер пОТОКОВ

                Sleepdata=   new ClassRuntimeExeGRUDOpertions(contextClass_GRUD_SQL_Operations).МетодЗапускаОперацийGRUD_exe(ЛистДляGRUDопераций,МенеджерПотоков);

                ///
                Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), " РЕЗУЛЬТАТ sleepdata  СНА ДАННЫХ  ЗНАЧЕНИЯ  " +  Sleepdata.toString() );
                /////

                /////

                ///
                Log.d(contextClass_GRUD_SQL_Operations.getClass().getName(), " sleepdata " + Sleepdata);
                /////

            } catch (Exception e) {
                ///////TODO error
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(contextClass_GRUD_SQL_Operations).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                /////
            }

            return Sleepdata;
        }

    }


    //TODO










    //TODO КЛАСС Удаление ДАННЫХ
    class  DeleteData extends Class_GRUD_SQL_Operations {
        public DeleteData(@NotNull Context context) {
            super(context);
            /**
             *
             * @param context
             */
            ///Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextClass_GRUD_SQL_Operations);
            /**
             *
             */
            SQLBuilder_Для_GRUD_Операций =new SQLiteQueryBuilder    ();



        }
        // TODO: 27.08.2021 МЕТОД  ПОЛУЧЕНИЯ ДАННЫХ
        Object deletedata(Map<String,Object> concurrentHashMap,CompletionService МенеджерПотоков,SQLiteDatabase getБазаДанныхДЛяОперацийВнутри) throws ExecutionException, InterruptedException {
            /////
            Object Deletedata=null;
            //////// TODO запуск менеджера потоков

            try {
                ///TODO тело самого кода List    ////
                //////// TODO запуск менеджера потоков
                ///TODO тело самого кода List    ////
             ЛистДляGRUDопераций=new Callable<Object>() {
                    @Override
                    public Object call() throws Exception {
                        /////
                        Object deletedata=null;
                        ///
                        // TODO: 30.08.2021  параметры
                        String  НазваниеОбрабоатываемойТаблицы=null;
                        /////
                        String  Флаг_ЧерезКакоеПолеУдаление=null;

                        //
                        String  ЗначениеФлагУдаление=null;
                        //
                        String ЗнакФлагУдаление=null;


                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap " + concurrentHashMap.values());

                        //TODO ЦИКЛ ПО ПАРАМЕТРАМ
                        for (Object КлючconcurrentHashMap : concurrentHashMap.keySet()) {

                            Object ЗначениеconcurrentHashMap = concurrentHashMap.get(КлючconcurrentHashMap);
                            //

                            Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap.toString() " + concurrentHashMap.toString());

                            // TODO: 27.08.2021  присваевываем значения полям для получение данных

                            switch (КлючconcurrentHashMap.toString().trim()){

                                //
                                case "НазваниеОбрабоатываемойТаблицы" :
                                    //////
                                    НазваниеОбрабоатываемойТаблицы=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///

                                //
                                case "Флаг_ЧерезКакоеПолеУдаление" :
                                    //////
                                    Флаг_ЧерезКакоеПолеУдаление=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///

                                //
                                case "ЗначениеФлагУдаление" :
                                    //////
                                    ЗначениеФлагУдаление=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///
                                //
                                case "ЗнакФлагУдаление" :
                                    //////
                                    ЗнакФлагУдаление=ЗначениеconcurrentHashMap.toString();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;
                                ///






                                ///
///
                            }

                        }

                        Log.w(this.getClass().getName(), "   НазваниеОбрабоатываемойТаблицы   "+НазваниеОбрабоатываемойТаблицы);

                        //////TODO конец параменты

                        // TODO: 30.08.2021  ОРМИРУЕМ КОРКАТ БУДЩЕЙ ВСТАВКИ ДАННЫХ

                        //


                        ////////////
                        SQLBuilder_Для_GRUD_Операций.setTables(НазваниеОбрабоатываемойТаблицы);

                        /////TODO операция ВСТАВКИ

                        /////////////
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                            //////////TODO само обновление
                            deletedata =             SQLBuilder_Для_GRUD_Операций.
                                    delete(getБазаДанныхДЛяОперацийВнутри, null,
                                          null);
                        }else{

                            deletedata =           getБазаДанныхДЛяОперацийВнутри
                                    .delete(НазваниеОбрабоатываемойТаблицы,null, null);


                            Log.w(this.getClass().getName(), "   deletedata   "+deletedata);

                            //
                 /*           deletedata =           Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу()
                                    .delete(НазваниеОбрабоатываемойТаблицы,Флаг_ЧерезКакоеПолеУдаление + ""+ЗнакФлагУдаление+ "?", new String[]{ЗначениеФлагУдаление});*/
                        }

                        /////TODO РЕЗУЛЬТАТ операция Обновление
                        //////


                        ////////

                        return deletedata;
                    }
                };


                //TODO конец выполения кода через Callble  , отправляем его в главный менеджер пОТОКОВ

                Deletedata=     new ClassRuntimeExeGRUDOpertions(contextClass_GRUD_SQL_Operations).МетодЗапускаОперацийGRUD_exe(ЛистДляGRUDопераций,МенеджерПотоков);

                ///
                ///
                Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), " РЕЗУЛЬТАТ deletedata  УДАЛЕНИЕ ДАННЫХ  ЗНАЧЕНИЯ  " +  Deletedata.toString() );
                /////

                /////

                ///
                Log.d(contextClass_GRUD_SQL_Operations.getClass().getName(), " deletedata " + Deletedata);
                /////

            } catch (Exception e) {
                ///////TODO error
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());

                new   Class_Generation_Errors(contextClass_GRUD_SQL_Operations).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                /////
            }

            return Deletedata;
        }

    }



    //TODO   конец КЛАСС Удаление ДАННЫХ























    //TODO КЛАСС Вставки ДАННЫХ
    class  ChangesVesionData extends Class_GRUD_SQL_Operations {

        public ChangesVesionData(@NotNull Context context) {
            super(context);
            /**
             *
             * @param context
             */
      ///      Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextClass_GRUD_SQL_Operations);

            /**
             *
             */
            SQLBuilder_Для_GRUD_Операций =new  SQLiteQueryBuilder    ();

            //////////

        }





        // TODO: 27.08.2021 МЕТОД  ВСТАВКИ ДАННЫХ
        Object changesvesiondata(Map<String,Object> concurrentHashMap ,CompletionService  МенеджерПотоков,SQLiteDatabase getБазаДанныхДЛяОперацийВнутри) throws ExecutionException, InterruptedException {
            ///////
            Object Changesvesiondata=null;
            //////// TODO запуск менеджера потоков



            try {
                ///TODO тело самого кода List    ////
               ЛистДляGRUDопераций=new Callable<Object>() {
                    @Override
                    public Object call() throws Exception {
                        /////
                        Object changesvesiondata=null;
                        // TODO: 30.08.2021  параметры
                        String  НазваниеОбрабоатываемойТаблицы=null;
                        //

                        String ФлагТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба=null;

                        Long ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба=0l;

                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap " + concurrentHashMap.values() );


                        //TODO ЦИКЛ ПО ПАРАМЕТРАМ
                        for (Object КлючconcurrentHashMap : concurrentHashMap.keySet()) {

                            Object ЗначениеconcurrentHashMap = concurrentHashMap.get(КлючconcurrentHashMap);
                            //

                            Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap.toString() " + concurrentHashMap.toString());

                            // TODO: 27.08.2021  присваевываем значения полям для получение данных

                            switch (КлючconcurrentHashMap.toString().trim()){

                                case "НазваниеОбрабоатываемойТаблицы" :
                                    //////
                                    НазваниеОбрабоатываемойТаблицы=ЗначениеconcurrentHashMap.toString().trim();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;

                                ///
                                case "ФлагТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба" :
                                    //////
                                    ФлагТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба=ЗначениеconcurrentHashMap.toString().trim();

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;

                                ///

                                ///
                                case "ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба" :
                                    //////
                                    ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба=Long.parseLong(ЗначениеconcurrentHashMap.toString().trim());

                                    // TODO: 27.08.2021  конец присвоение параментов
                                    break;

                                ///


///
                            }

                        }

                        // TODO: 23.09.2021  почле цикла


                        String СгенерированованныйДата=null;
                        //
                        String ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных=null;




                        ///
                        Long РезультатУвеличинаяВерсияДАных=0L;

                        //////
                        СгенерированованныйДата=     new Class_Generation_Data(contextСозданиеБАзы).ГлавнаяДатаИВремяОперацийСБазойДанных();

                        Log.d(this.getClass().getName(), "   ЗАПУСК ФОНОВОЙ СИНХРОНИЗАЦИИИ С mYwORK_sYNCHRONIZACI  СЛУЖБА  WorkManager Synchronizasiy_Data  СгенерированованныйДата "+СгенерированованныйДата);

// TODO: 30.08.2021  ЗАПОЛЕНЕНИ ПОЛУЧЕННЫМИ ДАННЫМИ НОВОЙ ДАТОЙ И НОВОЙ ВЕРИСЕЙ


                        switch (ФлагТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба){
                            /////////////
                            case "Локальное":
                                /////////
                                contentValuesДляSQLBuilder_Для_GRUD_Операций.put("localversionandroid",СгенерированованныйДата);
                                /////////
                                ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных="localversionandroid_version";
                                ///////////////////
                                РезультатУвеличинаяВерсияДАных=
                                        МетодПолученияУвеличинойВесрииДанныхДляТаблицыМодификайшенКлиент(НазваниеОбрабоатываемойТаблицы,ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,contextСозданиеБАзы,getБазаДанныхДЛяОперацийВнутри);
                                ///
                                contentValuesДляSQLBuilder_Для_GRUD_Операций.put(ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,РезультатУвеличинаяВерсияДАных);
                                //
                                break;
                            /////////////
                            case "Серверный":
                                /////////
                                contentValuesДляSQLBuilder_Для_GRUD_Операций.put("versionserveraandroid",СгенерированованныйДата);
                                //
                                /////////
                                ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных="versionserveraandroid_version";
                                ////



                                Log.d(contextСозданиеБАзы.getClass().getName(), "ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба "

                                        +ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба );


                                // TODO: 04.10.2021 вторая часть повышения

                                if (ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба==0) {


                                    РезультатУвеличинаяВерсияДАных=
                                            МетодПолученияУвеличинойВесрииДанныхДляТаблицыМодификайшенКлиент(НазваниеОбрабоатываемойТаблицы,ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,contextСозданиеБАзы,getБазаДанныхДЛяОперацийВнутри);
                                }
                                else{

                                    РезультатУвеличинаяВерсияДАных=    ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба;
                                }

                       /*
                                РезультатУвеличинаяВерсияДАных=
                                        МетодПолученияУвеличинойВесрииДанныхДляТаблицыМодификайшенКлиент(НазваниеОбрабоатываемойТаблицы,ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,contextСозданиеБАзы);*/
                                ///
                                contentValuesДляSQLBuilder_Для_GRUD_Операций.put(ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,РезультатУвеличинаяВерсияДАных);
                                //

                                ///
                                contentValuesДляSQLBuilder_Для_GRUD_Операций.put(ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,РезультатУвеличинаяВерсияДАных);

                                break;
                            /////////////
                            case "ЛокальныйСерверныйОба":




                                // TODO: 04.10.2021  ВТОРАЯ ЧАСТЬ ПОЛЯ В ТАБЛИЦЕ ЭТО КОГДА МЫ ВЫБПВАЛИ ИЗМЕНЕНИЯ СРАЗУ ПО БВУМ ПОЛЯМ И ЛОКАЛЬНАЯ И ССЕРВЕРВАЯ
                                /////////
                                contentValuesДляSQLBuilder_Для_GRUD_Операций.put("localversionandroid",СгенерированованныйДата);
                                ///


                                /////////
                                ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных="localversionandroid_version";
                                ////



                                // TODO: 04.10.2021 вторая часть повышения
                                Log.d(contextСозданиеБАзы.getClass().getName(), "ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба " +ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба );

                                if (ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба==0) {


                                    РезультатУвеличинаяВерсияДАных=
                                            МетодПолученияУвеличинойВесрииДанныхДляТаблицыМодификайшенКлиент(НазваниеОбрабоатываемойТаблицы,ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,contextСозданиеБАзы,getБазаДанныхДЛяОперацийВнутри);
                                }
                                else{

                                    РезультатУвеличинаяВерсияДАных=    ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба;
                                }


                 /*               РезультатУвеличинаяВерсияДАных=
                                        МетодПолученияУвеличинойВесрииДанныхДляТаблицыМодификайшенКлиент(НазваниеОбрабоатываемойТаблицы,ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,contextСозданиеБАзы);*/
                                ///
                                contentValuesДляSQLBuilder_Для_GRUD_Операций.put(ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,РезультатУвеличинаяВерсияДАных);
                                //





                                // TODO: 04.10.2021  ВТОРАЯ ЧАСТЬ ПОЛЯ В ТАБЛИЦЕ ЭТО КОГДА МЫ ВЫБПВАЛИ ИЗМЕНЕНИЯ СРАЗУ ПО БВУМ ПОЛЯМ И ЛОКАЛЬНАЯ И ССЕРВЕРВАЯ


                                // TODO: 04.10.2021  ТОЛЬКО ВРЕМЯ

                                /////////
                                contentValuesДляSQLBuilder_Для_GRUD_Операций.put("versionserveraandroid",СгенерированованныйДата);
                                //





                                /////////
                                ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных="versionserveraandroid_version";
                                ////
                                Log.d(contextСозданиеБАзы.getClass().getName(), "ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба "

                                        +ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба );


                                // TODO: 04.10.2021 вторая часть повышения

                                if (ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба==0) {


                                    РезультатУвеличинаяВерсияДАных=
                                            МетодПолученияУвеличинойВесрииДанныхДляТаблицыМодификайшенКлиент(НазваниеОбрабоатываемойТаблицы,ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,contextСозданиеБАзы,getБазаДанныхДЛяОперацийВнутри);
                                }
                                else{

                                    РезультатУвеличинаяВерсияДАных=    ДополнительныйФлагДляСинхЧАТАТипИзменениеВерсииДанныхЛокальнаяСервернаяИлиОба;
                                }

                                ///
                                contentValuesДляSQLBuilder_Для_GRUD_Операций.put(ПолеНаОснованииКотрогоУвеличиваемВерсиюДанных,РезультатУвеличинаяВерсияДАных);
                                //

                                break;


                            default:
                                throw new NullPointerException("Не выбран не одтн режим");


                        }
















// TODO: 30.08.2021  СОЗДАНИЕ ТРИГЕРА


                        ////

                        /////
                        String ТаблицаОбработки="MODIFITATION_Client";

                        SQLBuilder_Для_GRUD_Операций.setTables(ТаблицаОбработки);


                        /////////////
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            ////////
                            changesvesiondata =             SQLBuilder_Для_GRUD_Операций.
                                    update(getБазаДанныхДЛяОперацийВнутри,
                                            contentValuesДляSQLBuilder_Для_GRUD_Операций,"name=?", new String[]{НазваниеОбрабоатываемойТаблицы});
                        }else{
                            ///////////////

                            changesvesiondata =           getБазаДанныхДЛяОперацийВнутри
                                    .update(ТаблицаОбработки,contentValuesДляSQLBuilder_Для_GRUD_Операций,"name=?", new String[]{НазваниеОбрабоатываемойТаблицы});
                        }


                        //
                        Log.d(this.getClass().getName(), "  СОЗДАН ТРИГЕР ДЛЯ ТАБЛИЦЫ  tabels  update     " + СгенерированованныйДата);


                        Log.d(this.getClass().getName(), "РезультатИзменениеВерсииДанных " +changesvesiondata );

                        return changesvesiondata;
                    }
                };


                //TODO конец выполения кода через Callble  , отправляем его в главный менеджер пОТОКОВ

                Changesvesiondata =    new ClassRuntimeExeGRUDOpertions(contextClass_GRUD_SQL_Operations).МетодЗапускаОперацийGRUD_exe(ЛистДляGRUDопераций,МенеджерПотоков);

                ///
                ///
                Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), " РЕЗУЛЬТАТ changesvesiondata  ИЗМЕНЕНИЯ ДАННЫХ  ЗНАЧЕНИЯ  " +  Changesvesiondata.toString() );
                /////




            } catch (Exception e) {
                ///////TODO error
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());

                new   Class_Generation_Errors(contextClass_GRUD_SQL_Operations).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                /////
            }
            //////// TODO конец  менеджера потоков

            return Changesvesiondata;
        }
/////


        // TODO: 10.08.2021  получение УВЕЛИЧИНОЙ ВЕРСИИ ДАННЫХ ДЛЯ ЧАТА
        Long МетодПолученияУвеличинойВесрииДанныхДляТаблицыМодификайшенКлиент(String Текущаятаблицы ,String ТекущаяяКолонкаТаблицы,@NotNull  Context contextУвеличинойВесрииДанных,SQLiteDatabase getБазаДанныхДЛяОперацийВнутри) {
            ////
            Long  ЗначениеДляПовышениеВерсии=1l;
            /////
            SQLiteCursor Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных=null;
            //

            ////
            try{

                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                ///
                String  ТаблицаДляПовышениеВерсииДанных="MODIFITATION_Client";


                // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ


                Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных= (SQLiteCursor)
                        getБазаДанныхДЛяОперацийВнутри.rawQuery(" SELECT MAX ( " +ТекущаяяКолонкаТаблицы + "  ) AS MAX_R  FROM  " + ТаблицаДляПовышениеВерсииДанных + "   " +
                        " WHERE name = '" + Текущаятаблицы + "' ;", null);

                Log.d(this.getClass().getName(), "GetData "+Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных  );




/*

            // TODO: 06.09.2021  _old

            Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных=    new CREATE_DATABASE(context).
                    ССылкаНаСозданнуюБазу.rawQuery(" SELECT MAX("+ТекущаяяКолонкаТаблицы+") from  "+Текущаятаблицы+" ", null);//data_chat
            // TODO: 10.08.2021
*/







                if(Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.getCount()>0){

                    //
                    Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.moveToFirst();
                    //
                    Integer  ИндексГдеСтолбикМах=Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.getColumnIndex("MAX_R");
                    //
                    ЗначениеДляПовышениеВерсии=Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.getLong(ИндексГдеСтолбикМах);
                    //
                    Log.d(this.getClass().getName(), "  ДО   ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);
                    //////
                    ЗначениеДляПовышениеВерсии++;

                    Log.d(this.getClass().getName(), "   ПОСЛЕ ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);
                }else {

                    //////TODO увеличиваем значени версии данных
                    ЗначениеДляПовышениеВерсии=1l;

                    Log.d(this.getClass().getName(), "ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);

                }


                Log.d(this.getClass().getName(), "ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);
                //
                Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.close();
/*
                    new CREATE_DATABASE(getContext()).    ССылкаНаСозданнуюБазу.execSQL(
                            "CREATE TRIGGER cust_addr_chng_data_chat "+
                                    " AFTER INSERT  ON  chats"+
                                    " BEGIN     INSERT INTO chats(current_chat)    VALUES("+ЗначениеДляПовышениеВерсии+"); END; ");*/
                ///
                Log.d(this.getClass().getName(), " сработала ...  создание таблицы Data_Chat TRIGGER"+ЗначениеДляПовышениеВерсии);


                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(contextУвеличинойВесрииДанных).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                //////
                ЗначениеДляПовышениеВерсии=1l;

                Log.d(this.getClass().getName(), "ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);
            }
            return  ЗначениеДляПовышениеВерсии;
        }


        // TODO: 23.09.2021 только получение верисии данных    только для самой текущей таблицы


        // TODO: 10.08.2021  получение УВЕЛИЧИНОЙ ВЕРСИИ ДАННЫХ ДЛЯ ЧАТА
        Long МетодПолученияУвеличинойВесрииДанныхДляТекущейВнутренейтаблицы(String Текущаятаблицы ,String ТекущаяяКолонкаТаблицы,@NotNull  Context contextУвеличинойВесрииДанных,SQLiteDatabase getБазаДанныхДЛяОперацийВнутри) {
            ////
            Long  ЗначениеДляПовышениеВерсии=1l;
            /////
            SQLiteCursor Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных=null;
            //

            ////
            try{

                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                ///



                // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ


                Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных= (SQLiteCursor)
                        getБазаДанныхДЛяОперацийВнутри.rawQuery(" SELECT MAX ( " +ТекущаяяКолонкаТаблицы.trim() + "  ) AS MAX_R  FROM   MODIFITATION_Client  WHERE  name = '" + Текущаятаблицы.trim() +"'  ;", null);
                ///

              /*  Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных= (SQLiteCursor)
                        Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу().rawQuery(" SELECT MAX ( " +ТекущаяяКолонкаТаблицы + "  ) AS MAX_R  FROM  " + ТаблицаДляПовышениеВерсииДанных + "   " +
                                " WHERE name = '" + Текущаятаблицы + "' ;", null);*/

           /*     Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных= (SQLiteCursor)
                        Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу().rawQuery(" SELECT MAX ( " +ТекущаяяКолонкаТаблицы + "  ) AS MAX_R  FROM  " + Текущаятаблицы +";", null);
                ///*/


                Log.d(this.getClass().getName(), "GetData "+Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных  );




/*

            // TODO: 06.09.2021  _old

            Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных=    new CREATE_DATABASE(context).
                    ССылкаНаСозданнуюБазу.rawQuery(" SELECT MAX("+ТекущаяяКолонкаТаблицы+") from  "+Текущаятаблицы+" ", null);//data_chat
            // TODO: 10.08.2021
*/







                if(Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.getCount()>0){

                    //
                    Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.moveToFirst();
                    //
                    Integer  ИндексГдеСтолбикМах=Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.getColumnIndex("MAX_R");
                    //
                    ЗначениеДляПовышениеВерсии=Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.getLong(ИндексГдеСтолбикМах);
                    //
                    Log.d(this.getClass().getName(), "  ДО   ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);
                    //////
                    ЗначениеДляПовышениеВерсии++;

                    Log.d(this.getClass().getName(), "   ПОСЛЕ ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);
                }else {

                    //////TODO увеличиваем значени версии данных
                    ЗначениеДляПовышениеВерсии=1l;

                    Log.d(this.getClass().getName(), "ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);

                }


                Log.d(this.getClass().getName(), "ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);
                //
                Курсор_КоторыйПолучаетМаксимальюнуВерсиюДанных.close();
/*
                    new CREATE_DATABASE(getContext()).    ССылкаНаСозданнуюБазу.execSQL(
                            "CREATE TRIGGER cust_addr_chng_data_chat "+
                                    " AFTER INSERT  ON  chats"+
                                    " BEGIN     INSERT INTO chats(current_chat)    VALUES("+ЗначениеДляПовышениеВерсии+"); END; ");*/
                ///
                Log.d(this.getClass().getName(), " сработала ...  создание таблицы Data_Chat TRIGGER"+ЗначениеДляПовышениеВерсии);


                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(contextУвеличинойВесрииДанных).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                //////
                ЗначениеДляПовышениеВерсии=1l;

                Log.d(this.getClass().getName(), "ЗначениеДляПовышениеВерсии "+ЗначениеДляПовышениеВерсии);
            }
            return  ЗначениеДляПовышениеВерсии;
        }

    }








































    // TODO: 28.08.2021 гдавный метод выполения операций EXE
    // TODO: 28.08.2021 гдавный метод выполения операций EXE
    //TODO КЛАСС ИСПОЛЕНИЯ В ПОТОКЕ
    class  ClassRuntimeExeGRUDOpertions extends Class_GRUD_SQL_Operations {
        //////
        public ClassRuntimeExeGRUDOpertions(@NotNull Context context ) {

            super(context);




        }
        // TODO: 27.08.2021  МЕТОД ИСПОЛЕНИЯ В ПОТОКЕ
        protected    Object МетодЗапускаОперацийGRUD_exe( Callable<Object> ЗадачаКоторуюнадоВыполнить,CompletionService МенеджерПотоков) throws ExecutionException, InterruptedException {


            // TODO: 14.10.2021  Будущий результат
            Object ФинальныйПолученныйРезультатОперацийGRUD=null;
            
            //////// TODO запуск менеджера потоков
            
            try {


                // TODO: 28.08.2021  ЗАПУСКАЕМ ЗАДАЧУ

                МенеджерПотоков.submit(ЗадачаКоторуюнадоВыполнить);

                ///
                Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "ФИНАЛ   МЕНЕДЖЕРА ПОТОКОВ  GRUD-ОПЕРАЦИЙ  EXE add Callable  ЗадачаКоторуюнадоВыполнить "+ ЗадачаКоторуюнадоВыполнить );
                //


                } catch (Exception e) {
                    ///////TODO error
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());

                    new   Class_Generation_Errors(contextClass_GRUD_SQL_Operations).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                    /////

                /////

                МенеджерПотоков.take().cancel(false);

                // TODO: 28.08.2021 exit exe
            } finally {


                try {


                    ////TODO off Менеджер ПОтоков
                    ФинальныйПолученныйРезультатОперацийGRUD=   МенеджерПотоков.take().get();


                    ////TODO ПОСЛЕ ПОЛУЧЕНИЕ ОТВЕТА

                    Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(),
                            " ФИНАЛ   .GET()  МЕНЕДЖЕРА ПОТОКОВ  GRUD-ОПЕРАЦИЙ     "
                                    + ФинальныйПолученныйРезультатОперацийGRUD + "\n" +
                                    "  .GET() размер ответа  " +ФинальныйПолученныйРезультатОперацийGRUD.toString().length());

                    // TODO: 04.10.2021  ЖДЕМ ВЫПОЛЕНИЯ  МЕНЕДЖЕРА ПОТОКОВ  РЕЗУЛЬТАТ МЕНЕДЖЕРА ПОТОКОВ
                //   while(!БудущийРезультат_GRUD_операци.isDone());





                    // TODO: 04.10.2021 ПОЛУЧЕННЫЙ РЕЗУЛЬТАТ МЕНЕДЖЕРА ПОТОКОВ ПРОВЕРЯЕМ СТАТУС ЗАДАЧИ
/*
                        if (БудущийРезультат_GRUD_операци.isDone()) {
                        ///
                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(),
                                "  В РАБОТЕ ..............    ФИНАЛ   .GET()  МЕНЕДЖЕРА ПОТОКОВ  GRUD-ОПЕРАЦИЙ  EXE   submit -  +БудущийРезультат_GRUD_операци.isDone() "
                                        +БудущийРезультат_GRUD_операци.isDone());



                        // TODO: 04.10.2021 ПОЛУЧЕННЫЙ РЕЗУЛЬТАТ МЕНЕДЖЕРА ПОТОКОВ
                   //     ФинальныйПолученныйРезультатОперацийGRUD=БудущийРезультат_GRUD_операци.get();
                        ///
                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(),
                                " ФИНАЛ   .GET()  МЕНЕДЖЕРА ПОТОКОВ  GRUD-ОПЕРАЦИЙ  EXE   submit - метод БудущийРезультат_GRUD_операци  "
                                        + ФинальныйПолученныйРезультатОперацийGRUD + "\n" +
                                        "  ПОСЛЕ ПОЛУЧЕНИЕ РЕЗУЛЬТАТА СТАТУС ЗАДАЧИ");



                        // TODO: 04.10.2021 ПРОВЕРЯЕМ СТАТУС МЕНЕДЖЕРА ПОТОКОВ

                            // TODO: 13.10.2021 exit loop
                            БудущийРезультат_GRUD_операци.cancel(false);

                            ///
                            Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(),
                                    "  ВЫКЛЮЧАЕМ  Future    ФИНАЛ   .GET()  МЕНЕДЖЕРА ПОТОКОВ  GRUD-ОПЕРАЦИЙ  EXE   submit -  " +
                                            "+ Название ПОТОКА " +Thread.currentThread().getName()+ "\n"+
                                     " Thread.currentThread().isInterrupted() Поток Статус "  +Thread.currentThread().isAlive());




                    }*/


                    //TODO ВЫКЛЮЧЕНИЕ МЕНЕДЖЕРАПОТОКОВ
                    //
                } catch (ExecutionException e) {
                    ///////TODO error
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());

                    new Class_Generation_Errors(contextClass_GRUD_SQL_Operations).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                            this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                    /////
                    /////

                    МенеджерПотоков.take().cancel(false);
                }
            }
            //
            //////////
            //////// TODO конец  менеджера потоков
            return ФинальныйПолученныйРезультатОперацийGRUD;
        }

    }



    //TODO  для визуальной синхрониазциии


// TODO: 28.08.2021  КОНЕЦ гдавный метод выполения операций EXE
    // TODO: 28.08.2021 гдавный метод выполения операций EXE
    //TODO КЛАСС ИСПОЛЕНИЯ В ПОТОКЕ

















































































    //TODO КЛАСС ПОЛУЧЕНИЕ ДАННЫХ Free
    class  GetаFreeData extends Class_GRUD_SQL_Operations {

        public GetаFreeData(@NotNull Context context) {
            super(context);

            //todo ПОДКЛЮЯЕМ КЛАСС ВЫШЕСТОЯЩИЙ ДЛЯ РАБОТЫ ОПЕРАЦИЙ grud
            /**
             *
             * @param context
             */
       ////     Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextClass_GRUD_SQL_Operations);
            ////
            ///
            /**
             *
             */
            SQLBuilder_Для_GRUD_Операций =new SQLiteQueryBuilder    ();


            //////////


        }

        // TODO: 30.08.2021  НИЖЕ  УКАЗАНЫ ВСЕ МЕТОДЫ ПОЛУЧЕНИЕ ОБНОВЛЕНИЯ ВСТАВКИ УДАЛЕНИЕ ДАННЫХ


        // TODO: 27.08.2021 МЕТОД  ПОЛУЧЕНИЯ ДАННЫХ
        Object getfreedata(Map<String,Object>   concurrentHashMap,CompletionService МенеджерПотоков,SQLiteDatabase getБазаДанныхДЛяОперацийВнутри) throws ExecutionException, InterruptedException {
            ///////
            Object GetFreedata=null;
            //////// TODO запуск менеджера потоков
            // TODO: 29.08.2021 СОЗДАЕМ ЗАДАЧУ ДЛЯ ВЫПОЛЕНИЯ ЧЕРЕЗ CALLABLE





            ЛистДляGRUDопераций=new Callable<Object>() {
                @Override
                public Object call() throws Exception {

                    /////TODO начало самого кода

                    Object getfreedata=null;
                    /////
                    try {
                        // TODO: 27.08.2021 парарменты
                        String НазваниеОбрабоатываемойТаблицы=null;
                        //
                        String    СамFreeSQLКОд=null;



                        ///TODO конец параментов
                        // TODO: 27.08.2021 само значние
                        Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap " + concurrentHashMap.values());


                        //TODO ЦИКЛ ПО ПАРАМЕТРАМ
                        for (Object КлючconcurrentHashMap : concurrentHashMap.keySet()) {

                            Object ЗначениеconcurrentHashMap = concurrentHashMap.get(КлючconcurrentHashMap);
                            //

                            Log.w(contextClass_GRUD_SQL_Operations.getClass().getName(), "concurrentHashMap.toString() " + concurrentHashMap.toString());

                            // TODO: 27.08.2021  присваевываем значения полям для получение данных

                            switch (КлючconcurrentHashMap.toString().trim()){

                                case "НазваниеОбрабоатываемойТаблицы" :
                                    //////
                                    НазваниеОбрабоатываемойТаблицы=ЗначениеconcurrentHashMap.toString();

                                    break;
                                ///////
                                case "СамFreeSQLКОд" :
                                    СамFreeSQLКОд=ЗначениеconcurrentHashMap.toString();
                                    break;
                                ///

// TODO: 27.08.2021  конец столбиков с параметрами условия посика


///
                            }

                        }


                        // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ


                        getfreedata= (SQLiteCursor) getБазаДанныхДЛяОперацийВнутри.rawQuery(СамFreeSQLКОд, null);

                        Log.d(this.getClass().getName(), "getfreedata "+getfreedata  );


                        ///TODO тело самого кода    ////

                    } catch (Exception e) {
                        e.printStackTrace();
                        //  Block of code to handle errors
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new   Class_Generation_Errors(contextClass_GRUD_SQL_Operations).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ///////
                    }

                    // TODO: 29.08.2021  MAIN EXE запуск выполения любого кода через  CALLABLE

                    /////TODO конец  самого кода

                    return getfreedata;
                }
            };


            //TODO конец выполения кода через Callble  , отправляем его в главный менеджер пОТОКОВ

            GetFreedata=     new ClassRuntimeExeGRUDOpertions(contextClass_GRUD_SQL_Operations).МетодЗапускаОперацийGRUD_exe(ЛистДляGRUDопераций,МенеджерПотоков);

            ////
            Log.d(this.getClass().getName(), "   рЕЗУЛЬТАТ МЕТОДА ПОЛУЧЕНИЕ ДАННЫХ ЧЕРЕЗ ОДИН МЕТДЖЕР ПОТОКОВ  GetFreedata "+GetFreedata);



            //////// TODO конец  менеджера потоков

            return GetFreedata;
        }

    }

// TODO: 17.09.2021  END GETDATA


















}


























