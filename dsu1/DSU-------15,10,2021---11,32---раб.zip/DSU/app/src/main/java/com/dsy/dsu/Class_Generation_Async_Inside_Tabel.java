package com.dsy.dsu;

import android.content.Context;
import android.util.Log;

import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.Date;

public class Class_Generation_Async_Inside_Tabel {

    Context contextДляКлассаАсинхронноВнутриТАбеля;

    public Class_Generation_Async_Inside_Tabel(Context context) {

        contextДляКлассаАсинхронноВнутриТАбеля=context;

    }
    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
    // TODO: 01.07.2021  метод
    Integer МетодЗапускаФоновойСинхронизацииАсинхронно(Context context) {

        Integer РезультатФоновойСинхронизации = 0;
        try {

            ////
/*

            /////////
             РезультатФоновойСинхронизации=      new Class_Async_Background(getApplicationContext()).
                    МетодЗАпускаСинхронизациивФоне(getApplicationContext());////КонтекстFaceApp*/
            // TODO: 11.05.2021 ЗПУСКАЕМ СЛУЖБУ ОБНОВЛЕНИЕ ПО


            Constraints constraintsService_Синхронизация = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .setRequiresCharging(false)
                    .setRequiresBatteryNotLow(false)
                    .setRequiresStorageNotLow(false)
                    .build();
            ///

            String ИмяСлужбыСинхронизациТАбеляСинхронизаиция = "WorkManager Внутри Табеля Синхрониазция";

            OneTimeWorkRequest OneTimeWorkRequest_Синхронизация = new OneTimeWorkRequest.Builder(MyWork_Async_Синхронизация_Общая.class)
                    .setConstraints(constraintsService_Синхронизация)
                    //    .setInputData(new Data.Builder().putString("КтоЗапустилWorkmanager","BroadCastRecieve").build())
                    // .setInitialDelay(3,TimeUnit.SECONDS)
                    .addTag(ИмяСлужбыСинхронизациТАбеляСинхронизаиция)
                    .build();


// Queue the work
            WorkManager.getInstance(context).enqueueUniqueWork(ИмяСлужбыСинхронизациТАбеляСинхронизаиция, ExistingWorkPolicy.APPEND, OneTimeWorkRequest_Синхронизация);
            // WorkManager.getInstance().enqueue(periodicWorkRequest);// workmanager.enqueueUniquePeriodicWork(TAG, ExistingPeriodicWorkPolicy.KEEP, photoCheckWork)


            Log.i(this.getClass().getName(), " Дополнительный вызов на SINGLE  табеле После Запуска из  FaceApp  СЛУЖБА ОбновлениеПО  ПОСЛЕ doWork WorkManager Локальная Синхрониазция  время "
                    + new Date() + " СТАТУС WORKMANAGER-----------" + WorkManager.getInstance(context).getWorkInfosByTag("WorkManager WorkManager Локальная Синхрониазция"));


            ////////
            Log.d(this.getClass().getName(), " СЛУЖБА МетодЗапускаЛокальнойСинхронизации() СЛУЖБА  getApplication() на СЛУЖБА на Активити FaceApp МетодЗапускаФоновойСинхронизацииПоПериоду" +
                    " РезультатФоновойСинхронизации " + РезультатФоновойСинхронизации);
            /////////


            /////////

        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(context.getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return РезультатФоновойСинхронизации;

    }
}
