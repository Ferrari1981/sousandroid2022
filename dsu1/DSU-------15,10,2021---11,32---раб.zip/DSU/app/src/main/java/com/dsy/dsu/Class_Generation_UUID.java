package com.dsy.dsu;

import static java.util.Calendar.getInstance;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public class Class_Generation_UUID {

    Context contextДляКлассаВремени;

    Integer ПубличноеIDПолученныйИзСервлетаДляUUID=0;


    CREATE_DATABASE   Create_Database_СсылкаНАБазовыйКласс;


    public Class_Generation_UUID(Context context) {

        contextДляКлассаВремени=context;

///////TODO
          Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(contextДляКлассаВремени);
    }
    //функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ
    // TODO: 05.07.2021













    // TODO ГЕНЕРАЦИЯ UUID ВВИДЕ ЦИФРЫ
    public Object МетодГенерацииUUID(Context contextДЛяUUID) {

        Long UUIDФинал = null;
        //
        String UUID=new String();

        SQLiteCursor Курсор_ИщемПУбличныйIDКогдаегоНетВстатике = null;


        try {
            // TODO ГЕНЕРАЦИЯ UUID ВВИДЕ ЦИФРЫ
            //"yyyyMMddHHmmssSSS" //"EEEEE MMMMM yyyy HH:mm:ss.SSSSSSZ"
            Date Дата = getInstance().getTime();
            // DateFormat dateFormat = new SimpleDateFormat("yyyyddMMHHmmssSS", new Locale("ru"));
            DateFormat dateFormat = new SimpleDateFormat("yyddMMHHmmssS", new Locale("ru"));

            dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));

            String СгенерированоДатаДляUUIDШагПервый = dateFormat.format(Дата);

            Long СгенерированоДатаВТипеLong = Long.parseLong(СгенерированоДатаДляUUIDШагПервый);


            //todo гененируем если есть публичный id


            // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ
            Class_GRUD_SQL_Operations class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ= new Class_GRUD_SQL_Operations(contextДЛяUUID);
            ///
            class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СамFreeSQLКОд",
                    " SELECT id  FROM successlogin  ORDER BY date_update DESC ;");


            // TODO: 12.10.2021  Ссылка Менеджер Потоков

            PUBLIC_CONTENT  class_async_backgroundГдеНаходитьсяМенеджерПотоков =new PUBLIC_CONTENT (contextДЛяUUID);


            ///////
            SQLiteCursor            Курсор_ПолучаемИмяСотрудникаИзТаблицыФИО= (SQLiteCursor) class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ.
                    new GetаFreeData(contextДЛяUUID).getfreedata(class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                    class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

            if(Курсор_ПолучаемИмяСотрудникаИзТаблицыФИО.getCount()>0){
                ////

                Курсор_ПолучаемИмяСотрудникаИзТаблицыФИО.moveToFirst();

                /////
                ПубличноеIDПолученныйИзСервлетаДляUUID=         Курсор_ПолучаемИмяСотрудникаИзТаблицыФИО.getInt(0);
///


                Log.d(this.getClass().getName(), " ПубличноеIDПолученныйИзСервлетаДляUUID  " + ПубличноеIDПолученныйИзСервлетаДляUUID);


            }




            // TODO: 24.03.2021 ЕслиВубличногоНЕтТоНАходим ЕГо
            final int[] ПолученныйID = {0};
            //////////
            if ( ПубличноеIDПолученныйИзСервлетаДляUUID>0) {


             Class_GRUD_SQL_Operations    concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций=new Class_GRUD_SQL_Operations(contextДЛяUUID);



                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                ///
                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","SuccessLogin");
                ///////
                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","id");
                //
                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика"," id IS NOT NULL");
                ///"_id > ?   AND _id< ?"
                //////
                //concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",ТекущееСФО);
                ///
             /*       concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","12");
                    //
                    concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3","13");////УсловиеПоискаv4,........УсловиеПоискаv5 .......*/

                ////TODO другие поля

                /////classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
                ////
                ///  concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки","date_update DESC");
                ////
                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update DESC");
                ////
                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                ////




                // TODO: 12.10.2021  Ссылка Менеджер Потоков

             class_async_backgroundГдеНаходитьсяМенеджерПотоков =new PUBLIC_CONTENT (contextДЛяUUID);

                // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ


                Курсор_ИщемПУбличныйIDКогдаегоНетВстатике= (SQLiteCursor) concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.
                        new GetData(contextДЛяUUID).getdata(concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                        class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());



                Log.d(this.getClass().getName(), "GetData " +Курсор_ИщемПУбличныйIDКогдаегоНетВстатике );




/*

                // TODO: 06.09.2021  old
                    Курсор_ИщемПУбличныйIDКогдаегоНетВстатике =
                            new MODEL_synchronized(context).КурсорУниверсальныйДляБазыДанных("SuccessLogin",
                                    new String[]{"id"}, " id IS NOT NULL", null, null, null, "date_update DESC", "1");//


*/

                    ///////TODO new uuid
                    if (Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount() > 0) {
                        /////
                        Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.moveToFirst();
                        ////
                        Log.d(this.getClass().getName(), " Курсор_ИщемПУбличныйIDКогдаегоНетВстатике " + Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getCount());

                        ПолученныйID[0] = Курсор_ИщемПУбличныйIDКогдаегоНетВстатике.getInt(0);


                    }


                    Log.d(this.getClass().getName(), "   ПолученныйID[0] " + ПолученныйID[0]);





                Log.d(this.getClass().getName(), "  PUBLIC_CONTENT.ПубличноеIDПолученныйИзСервлетаДляUUID"
                        + ПубличноеIDПолученныйИзСервлетаДляUUID + " String.valueOf(ПолученныйID[0]) " + String.valueOf(ПолученныйID[0]));




                if (ПолученныйID[0] > 0) {

                    UUID = String.valueOf(ПубличноеIDПолученныйИзСервлетаДляUUID + СгенерированоДатаВТипеLong);// Integer.parseInt(UUIDФинал.trim());

                    Log.i(this.getClass().getName(), " UUID " + UUID+ "  ПубличноеIDПолученныйИзСервлетаДляUUID " +ПубличноеIDПолученныйИзСервлетаДляUUID + " СгенерированоДатаВТипеLong " +СгенерированоДатаВТипеLong);
                }



            }else{

           /*     Random random=new Random();
           Integer СлучайноеЧисло=     random.nextInt(100);*/


                UUID = "0" + СгенерированоДатаВТипеLong;//
                /////
                Log.e(this.getClass().getName(), "   UUID--сгенерировал uuid ьез пуьличного id " + UUID);

            }


// TODO: 23.09.2021  ФИНАЛЬНОЕ ПОЛУЧЕНИЕ UUID СГЕНЕРИРОВАЫЙ

            UUIDФинал=Long.parseLong(UUID);

            Log.w(this.getClass().getName(), "   UUIDФинал " + UUID);


            //todo обнуляем
            СгенерированоДатаВТипеLong = null;//////

            ///
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(contextДЛяUUID).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }




        // TODO: 06.09.2021  новый UUID
        return UUIDФинал;
    }

}
