package com.dsy.dsu;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class Class_Generations_RxJava2 {

    Activity contextДляКлассRxJava2;

    public Class_Generations_RxJava2(Activity activity) {

        contextДляКлассRxJava2=activity;
        ///

        Observable<Integer> observable = Observable.just(1);
        observable.subscribeOn(Schedulers.computation())
                .subscribe(
                        new Observer<Integer>() {
                            @Override
                            public void onSubscribe(Disposable d) {
                                // TODO: 02.09.2021
                                Log.d(MODEL_synchronized.class.getName(), " PUBLIC_CONTENT.БуферРезуоотатРаботыБазыВсестеССервером " );
                            }

                            @Override
                            public void onError(Throwable e) {
                                // TODO: 02.09.2021
                                Log.d(MODEL_synchronized.class.getName(), " PUBLIC_CONTENT.БуферРезуоотатРаботыБазыВсестеССервером " );
                            }

                            @Override
                            public void onComplete() {
                                // TODO: 02.09.2021
                                Log.d(MODEL_synchronized.class.getName(), " PUBLIC_CONTENT.БуферРезуоотатРаботыБазыВсестеССервером " );

                                observable.subscribeOn(AndroidSchedulers.mainThread())
                                        .subscribe ((ddd)->{
                                            Log.d(MODEL_synchronized.class.getName(), " PUBLIC_CONTENT.БуферРезуоотатРаботыБазыВсестеССервером " );

                                            // TODO: 24.09.2021

                                            Toast.makeText(contextДляКлассRxJava2, " Превый RXJAVA 2" , Toast.LENGTH_SHORT).show();


                                        }  );


                            }

                            @Override
                            public void onNext(Integer e) {
                                System.out.println(e);
                                //request web service
                                // TODO: 02.09.2021
                                Log.d(MODEL_synchronized.class.getName(), " PUBLIC_CONTENT.БуферРезуоотатРаботыБазыВсестеССервером " );

                                Socket socket = new Socket();

                                SocketAddress socketAddress = new InetSocketAddress("192.168.254.40", 8080); //"http://192.168.254.40:8080/dsu1.glassfish/DSU1JsonServlet"; //"216.58.212.131"//80.66.149.58///tabel.dsu1.ru   //8888

                                try {
                                    socket.connect(socketAddress, 1000);
                                    socket.setSoTimeout(10000);
                                } catch (IOException ioException) {
                                    ioException.printStackTrace();
                                }
                            }
                        });
    }



    //todo функция получающая время операции ДАННАЯ ФУНКЦИЯ ВРЕМЯ ПРИМЕНЯЕТЬСЯ ВО ВСЕЙ ПРОГРАММЕ

}
