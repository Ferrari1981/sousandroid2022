package com.dsy.dsu;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutionException;


public class Fragment_Messages_СообщенияЧата extends Fragment    {

    // TODO: Rename parameter arguments, choose names that match

    View viewДляСообщений=null;

    ListView ЛистВьюДляСообщенийЧата =null;

    Cursor КурсорДанныеДляСообщенийЧата=null;
    ///

    Cursor Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате=null;


    TextView ТекстВиюВьюДляСообщенийЧатаКогдаНетДанных =null;


    FloatingActionButton floatingActionButtonФрагментСообщение;

    private int ПолученыйIDДляЧата;

    private TextView textViewФрагментСообщенияНазваниеЧАты;


    private View viewФрагментСообщенияНазваниеЧАты;
    // TODO: 12.10.2021  Ссылка Менеджер Потоков

    PUBLIC_CONTENT class_async_backgroundГдеНаходитьсяМенеджерПотоков =null;///


    ///////TODO
    CREATE_DATABASE   Create_Database_СсылкаНАБазовыйКласс;



    Integer   ПубличноеIDПолученныйИзСервлетаДляUUID=0;









    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        try{
            // Inflate the layout for this fragment
            viewДляСообщений= inflater.inflate(R.layout.fragment1_layout, container, false);
            ////
            ЛистВьюДляСообщенийЧата = (ListView) viewДляСообщений.findViewById(R.id.list);




            ТекстВиюВьюДляСообщенийЧатаКогдаНетДанных= (TextView) viewДляСообщений.findViewById(R.id.TextviewКогдаНетДанных);


            ТекстВиюВьюДляСообщенийЧатаКогдаНетДанных.setVisibility(View.GONE);



            floatingActionButtonФрагментСообщение= (FloatingActionButton) viewДляСообщений.findViewById(R.id.floatingActionButtonФрагментСообщение);




            class_async_backgroundГдеНаходитьсяМенеджерПотоков =new     PUBLIC_CONTENT(getActivity());///







///////TODO
             Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(getContext());


            // TODO: 02.07.2021 своими силаи зодаем название ЧАТА И ЛИНИЮ СНИЗУ



            textViewФрагментСообщенияНазваниеЧАты=    (TextView) viewДляСообщений.findViewById(R.id.textViewФрагментСообщенияНазваниеЧАты);



            ////

            viewФрагментСообщенияНазваниеЧАты= (View) viewДляСообщений.findViewById(R.id.viewФрагментСообщенияНазваниеЧАты);

            // viewФрагментСообщенияНазваниеЧАты.getBackground().setColorFilter(Color.parseColor("#00ff00"), PorterDuff.Mode.DARKEN);


            //  viewФрагментСообщенияНазваниеЧАты.getBackground().setTint(Color.parseColor("#212121"));








         /*   Long  результатСинхронизацииЗапущеннойВМетодеPAuse = null;
            try {
                результатСинхронизацииЗапущеннойВМетодеPAuse = new Class_Async_Background(getActivity()).
                        МетодЗапускаСинхронизацииПередСозданеимНовгоСообщенияДляЧата(getActivity());

            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }*/

          ///  Log.d(this.getClass().getName(), "  результатСинхронизацииЗапущеннойВМетодеPAuse   " +результатСинхронизацииЗапущеннойВМетодеPAuse);














        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///


        }
        return  viewДляСообщений;
    }









    ////////////////////////////////МОДЕЛЬ MVC ////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public void onStart() {
        super.onStart();

        try{



            // TODO  ////////////////////////////МОДЕЛЬ MVC ////////////////////////////////////////////////////////////////////////////////////////////////


            new Fragment_Messages_СообщенияЧата. MODEL(getActivity());

            new Fragment_Messages_СообщенияЧата.VIEW(getActivity());


            new Fragment_Messages_СообщенияЧата. CONTROLLER(getActivity());


        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///


        }

    }





















    // TODO: 18.06.2021  класс вью
    private class VIEW {

        public VIEW(Activity  activity) {


            try{


                Log.d(this.getClass().getName(), "  VIEW   " );

                if (КурсорДанныеДляСообщенийЧата.getCount()>0) {
                    Log.d(this.getClass().getName(), "  КурсорДанныеДляСообщенийЧата   "  + КурсорДанныеДляСообщенийЧата.getCount());



                    // TODO: 28.06.2021 мето заполения даными ФРАГМЕНТА СООБЩЕНИЯ


                    МетодЗаполенияПервогоФрагментаДаннымиСообщения();



                }else{

                    ///

                    // TODO: 28.06.2021 данный код когда нет вообще данных в курсоре и нет сообдений
                    ЛистВьюДляСообщенийЧата.setVisibility(View.GONE);


                    ТекстВиюВьюДляСообщенийЧатаКогдаНетДанных.setGravity( Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);

                    // ТекстВиюВьюДляСообщенийЧатаКогдаНетДанных.setPadding(30,0,0,0);

                    // TODO: 29.06.2021 когда данныхе нет
                    StringBuffer БуферКогдаНетСообщенийВооюоще=new StringBuffer("* Нет сообщений в чате !!! *");
                    ТекстВиюВьюДляСообщенийЧатаКогдаНетДанных.setVisibility(View.VISIBLE);

                    ТекстВиюВьюДляСообщенийЧатаКогдаНетДанных.setText(БуферКогдаНетСообщенийВооюоще.toString());
                }




                ///


                ///



                ////


            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }

        private void МетодЗаполенияПервогоФрагментаДаннымиСообщения() throws ExecutionException, InterruptedException {
            // КурсорДанныеДляСообщенийЧата



            // ID


            // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ
            Class_GRUD_SQL_Operations class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ= new Class_GRUD_SQL_Operations(getContext());
            ///
            class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СамFreeSQLКОд",
                    " SELECT id  FROM successlogin  ORDER BY date_update DESC ;");


            // TODO: 12.10.2021  Ссылка Менеджер Потоков

            PUBLIC_CONTENT  class_async_backgroundГдеНаходитьсяМенеджерПотоков =new PUBLIC_CONTENT (getContext());


            ///////
            SQLiteCursor            Курсор_ПолучаемПубличныйID= (SQLiteCursor) class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ.
                    new GetаFreeData(getContext()).getfreedata(class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                    class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков
                    ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

            if(Курсор_ПолучаемПубличныйID.getCount()>0){
////
                Курсор_ПолучаемПубличныйID.moveToFirst();

                /////
                ПубличноеIDПолученныйИзСервлетаДляUUID=         Курсор_ПолучаемПубличныйID.getInt(0);
///


                Log.d(this.getClass().getName(), " ПубличноеIDПолученныйИзСервлетаДляUUID  " + ПубличноеIDПолученныйИзСервлетаДляUUID);


            }












            SimpleCursorAdapter АдаптерДляСообщенийЧата=null;
            try{

                        /////

                АдаптерДляСообщенийЧата = new SimpleCursorAdapter(getContext(), R.layout.simple_for_chats_messages,КурсорДанныеДляСообщенийЧата,
                                new String[]{"user_update", "status_write"}, ///
                                new int[]{android.R.id.text1, android.R.id.text2},0);

                
                //
                SimpleCursorAdapter.ViewBinder БиндингДляСообщенийЧата = new SimpleCursorAdapter.ViewBinder() {
                    @Override
                    public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
                        // TODO: 22.06.2021 выравниваем тексвид


                        // TODO: 29.06.2021  форматирования


                        ((TextView) view).setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);

                        // ((TextView) view).setPadding(20,0,0,0);

                        ////
                        if (cursor.getCount()>0) {
                            ///
                            switch (view.getId()) {

                                case android.R.id.text1:


                                    Log.d(this.getClass().getName()," ClassActitytyClassActityty  view.getId() "+view.getId());
                                    //return true;
                                    ((TextView) view).setPadding(0,50,0,50);

                                    // TODO: 28.06.2021  заполения данныит первый фрагмент

                                    int ИндексДляФИОпервогоФрагмента=cursor.getColumnIndex("id_user");// вывшый user_for
                                    ////
                                    int IDдляпервогоФрагмента=cursor.getInt(ИндексДляФИОпервогоФрагмента);

                                    Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоФрагмента);


                                    // TODO: 08.07.2021 если user_update я то меняем кто писал
                                    String ФИОдляпервогоФрагмента=new String();



                                    if (IDдляпервогоФрагмента==ПубличноеIDПолученныйИзСервлетаДляUUID) {

                                        ИндексДляФИОпервогоФрагмента=cursor.getColumnIndex("user_update");//user_update
                                        ////
                                        IDдляпервогоФрагмента=cursor.getInt(ИндексДляФИОпервогоФрагмента);
                                        //
                                        ФИОдляпервогоФрагмента=new MODEL(getActivity()).  МетодПолучениеФИОНАОснованииIDВыбранногоСотрудника(IDдляпервогоФрагмента);

                                        Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоФрагмента);


                                    }  else{
                                        ИндексДляФИОпервогоФрагмента=cursor.getColumnIndex("id_user");//бывший user_for
                                        ////
                                        IDдляпервогоФрагмента=cursor.getInt(ИндексДляФИОпервогоФрагмента);
                                        //
                                        ФИОдляпервогоФрагмента=new MODEL(getActivity()).  МетодПолучениеФИОНАОснованииIDВыбранногоСотрудника(IDдляпервогоФрагмента);

                                        Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоФрагмента);

                                        //
                                        Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоФрагмента);
                                    }











                                    Log.d(this.getClass().getName(), "  ФИОдляпервогоФрагмента  "+ФИОдляпервогоФрагмента);

                                    ///
                                    if (ФИОдляпервогоФрагмента!=null) {
                                        ///

                                        Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате=null;

                                        //////

                                        // TODO: 28.06.2021  заполняем id кому и скем чат
                                        int ИндексДляIDЧьиСообшение=cursor.getColumnIndex("id_user"); //бышвий user_for
                                        ////
                                        int IDдляпервогоЧтьиСообщение=cursor.getInt(ИндексДляIDЧьиСообшение);

                                        Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоЧтьиСообщение+ "  ПубличноеIDПолученныйИзСервлетаДляUUID " +ПубличноеIDПолученныйИзСервлетаДляUUID);


                                        // TODO: 08.07.2021 если user_update я то меняем кеог на друного
                                        int     IDдляпервогоЧтьиСообщениеДляПосика=0;
                                        /////
                                        if (IDдляпервогоЧтьиСообщение!=ПубличноеIDПолученныйИзСервлетаДляUUID){

                                            // TODO: 28.06.2021  заполняем id кому и скем чат
                                            ИндексДляIDЧьиСообшение=cursor.getColumnIndex("user_update");
                                            ////
                                            IDдляпервогоЧтьиСообщениеДляПосика=cursor.getInt(ИндексДляIDЧьиСообшение);

                                            Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоЧтьиСообщение);

                                            Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате=null;


                                            // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                                            ///
                                  Class_GRUD_SQL_Operations           class_grud_sql_operationsЗаполенияПервогоФрагментаДаннымиСообщенияЧастьПервая=new Class_GRUD_SQL_Operations(getActivity());

                                            ///
                                            class_grud_sql_operationsЗаполенияПервогоФрагментаДаннымиСообщенияЧастьПервая.
                                                    concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","viewchat");
                                            ///////
                                            class_grud_sql_operationsЗаполенияПервогоФрагментаДаннымиСообщенияЧастьПервая.
                                                    concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","*");
                                            //
                                            class_grud_sql_operationsЗаполенияПервогоФрагментаДаннымиСообщенияЧастьПервая.
                                                    concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика"," user_update =  ?  AND status_write=0  ");
                    ///"_id > ?   AND _id< ?"
                    //////
                                            class_grud_sql_operationsЗаполенияПервогоФрагментаДаннымиСообщенияЧастьПервая.
                                                    concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",IDдляпервогоЧтьиСообщение);
                    ///
                /*    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......
*/
                                            ////TODO другие поля

                                            ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
                                            ////
                                            //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
                                            ////
                                            class_grud_sql_operationsЗаполенияПервогоФрагментаДаннымиСообщенияЧастьПервая. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update DESC");
                                            ////
                                            /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                                            ////

                                            // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ
                                            Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате=null;

                                            //////
                                            try {
                                                ///////
                                                Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате= (SQLiteCursor)  class_grud_sql_operationsЗаполенияПервогоФрагментаДаннымиСообщенияЧастьПервая.
                                                        new GetData(getActivity()).getdata(class_grud_sql_operationsЗаполенияПервогоФрагментаДаннымиСообщенияЧастьПервая. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                                                        class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());


                                            } catch (ExecutionException e) {
                                                e.printStackTrace();
                                            } catch (InterruptedException e) {
                                                e.printStackTrace();
                                            }

                                            Log.d(this.getClass().getName(), "GetData "  +Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате);



                                  /*          // TODO: 08.09.2021 _OLD

                                                Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате=
                                                        new MODEL(getActivity()).МетодПолучениеДанныхДляФрагментаСообщенияЧата("SELECT * FROM viewchat WHERE user_update ="
                                                                +IDдляпервогоЧтьиСообщение+
                                                                "   AND status_write=0  ORDER BY  date_update DESC");

                                                //////
*/
                                             //   Log.d(this.getClass().getName(), "  Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате  "+Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате);




                                        }

                                        ///


                                        if(Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате!=null &&  Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате.getCount()>0) {

                                            /////
                                            if (IDдляпервогоЧтьиСообщение==ПубличноеIDПолученныйИзСервлетаДляUUID &&КурсорДанныеДляСообщенийЧата.getCount()>1) {

                                                ((TextView) view).setVisibility(View.GONE);

                                            }else {

                                                ((TextView) view).setText("    " + ФИОдляпервогоФрагмента + " (" + Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате.getCount() + ")");
                                                //
                                                ((TextView) view).setBackgroundResource(R.drawable.sltyle_messege_view_contact);

                                                ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);
                                                ((TextView) view).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 17);


                                                ЛистВьюДляСообщенийЧата.deferNotifyDataSetChanged();
                                                //
                                                ЛистВьюДляСообщенийЧата.invalidateViews();

                                            }
                                        }else{

                                            if (IDдляпервогоЧтьиСообщение==ПубличноеIDПолученныйИзСервлетаДляUUID &&КурсорДанныеДляСообщенийЧата.getCount()>1) {

                                                //

                                                ((TextView) view).setVisibility(View.GONE);
                                            }else{
                                                /////
                                                ((TextView) view).setText("    " + ФИОдляпервогоФрагмента);
                                                ///
                                                ((TextView) view).setBackgroundResource(R.drawable.sltyle_messege_view_contact);
                                            /*
                           ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);
                           ((TextView) view).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 17);*/
                                                ///////
                                                ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.NORMAL);

                                                ((TextView) view).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);

                                                /////
                                                //  ((TextView) view).setText("    " + ФИОдляпервогоФрагмента+ " (" + Курсор_ИщемСтатусХотьестьОДинНольНЕПрочттаноеСообщениевЧате.getCount() + ")");
                                            }

                                        }









                                    }

                                    // TODO: 28.06.2021  заполняем id кому и скем чат
                                    int ИндексДляIDпервогоФрагмента=cursor.getColumnIndex("id_user"); /////вывший user_for
                                    ////
                                    int IDдляпервогоФрагментаДляСообщенияTag=cursor.getInt(ИндексДляIDпервогоФрагмента);

                                    Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоФрагментаДляСообщенияTag + "  ПубличноеIDПолученныйИзСервлетаДляUUID " +ПубличноеIDПолученныйИзСервлетаДляUUID);


                                    if(IDдляпервогоФрагментаДляСообщенияTag ==ПубличноеIDПолученныйИзСервлетаДляUUID)   {

                                        ИндексДляIDпервогоФрагмента=cursor.getColumnIndex("user_update");
                                        ////
                                        IDдляпервогоФрагментаДляСообщенияTag=cursor.getInt(ИндексДляIDпервогоФрагмента);

                                        Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоФрагментаДляСообщенияTag);
                                    }
                                    //////
                                    Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоФрагментаДляСообщенияTag);


                                    ///
                                    if (IDдляпервогоФрагментаДляСообщенияTag>0) {
                                        ////
                                        ((TextView) view).setTag(IDдляпервогоФрагментаДляСообщенияTag);



                                        // TODO: 22.06.2021 добавляем значёк


                                        Drawable icon = null;
                                        icon = getResources().getDrawable(R.drawable.icon_dsu1_for_fragment1_chat2);
                                        icon.setBounds(0, 0, 80, 80);


                                        // ((TextView) view).   setPadding(50,100,100,100);
                                        ((TextView) view).setCompoundDrawables(icon, null, null, null);


                                        // TODO: 29.06.2021  делаем форматирования bord  или нет








                                        // TODO: 28.06.2021  заполняем id кому и скем чат














                                    }







                                    return true;

                                // TODO: 28.06.2021 заполения ВТОРОГОЕ ТЕКС ФИЮ АКТИВТИ ПЕРВОГО С СООБЕЩНИЯСИМ

                                case android.R.id.text2:

                                    Log.d(this.getClass().getName()," ClassActitytyClassActityty  view.getId() "+view.getId());
                                    //return true;


                                    ((TextView) view).setGravity(Gravity.CENTER_HORIZONTAL| Gravity.CENTER_VERTICAL);

                                    // ((TextView) view).setPadding(100,0,0,0);
                                    ((TextView) view).setTextColor(Color.parseColor("#696969"));//olor.parseColor("##008080")

                                    String ФиналСтатусдляпервогоФрагмента = new String();


                                    // TODO: 28.06.2021  заполения данныит первый фрагмент

                       /*         int ИндексДляСтатусапервогоФрагмента=cursor.getColumnIndex("status_write");
                                ////
                                int СтатусдляпервогоФрагмента=cursor.getInt(ИндексДляСтатусапервогоФрагмента);

                                Log.d(this.getClass().getName(), "  ФИОдляпервогоФрагмента  "+СтатусдляпервогоФрагмента);

                                if(СтатусдляпервогоФрагмента==0){
                                    //////
                                    ФиналСтатусдляпервогоФрагмента="не прочитано";
                                }else {
                                    //////
                                    ФиналСтатусдляпервогоФрагмента="прочитано";
                                }*/


                                    //
                                    int ИндексДляДатыпервогоФрагмента=cursor.getColumnIndex("date_update");
                                    ////
                                    String ДатадляпервогоФрагмента=cursor.getString(ИндексДляДатыпервогоФрагмента);

                                    Log.d(this.getClass().getName(), "  ДатадляпервогоФрагмента  "+ДатадляпервогоФрагмента);


                                    // TODO: 28.06.2021 даты обработка

                                    Date date = null;
                                    // TODO: 28.06.2021 даты обработка
                                    SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", new Locale("ru"));
                                    dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                                    try {
                                        date = dateFormat.parse(ДатадляпервогоФрагмента);
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                        // TODO: 02.08.2021
                                         dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));
                                        dateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                                        // TODO: 02.08.2021
                                        try {
                                            date = dateFormat.parse(ДатадляпервогоФрагмента);


                                        } catch (ParseException parseException) {
                                            parseException.printStackTrace();
                                        }

                                    }

                                    String ФиналДата= null;

                                    /////
                                    if (date!=null) {

                                        ///
                                        Log.d(this.getClass().getName(), "  date  "+date.toString());
                                        /////////

                                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd MMMM yyyy", new Locale("ru"));
                                        //
                                        simpleDateFormat.applyPattern("dd MMMM yyyy");//dd-MM-yyyy
                                        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));
                                        //////
                                        ФиналДата = simpleDateFormat.format(date);

                                        Log.d(this.getClass().getName(), "  ФиналДата  "+ФиналДата);
                                    }


                                    ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);

                                    // TODO: 09.07.2021  HIDE
                                    // TODO: 28.06.2021  заполняем id кому и скем чат
                                    int ИндексДляIDЧьиСообшение=cursor.getColumnIndex("id_user"); //бышвий user_for
                                    ////
                                    int IDдляпервогоЧтьиСообщение=cursor.getInt(ИндексДляIDЧьиСообшение);

                                    Log.d(this.getClass().getName(), "  IDдляпервогоФрагмента  "+IDдляпервогоЧтьиСообщение);




                                    /////
                                    if (IDдляпервогоЧтьиСообщение==ПубличноеIDПолученныйИзСервлетаДляUUID &&КурсорДанныеДляСообщенийЧата.getCount()>1) {

                                        ((TextView) view).setVisibility(View.GONE);

                                    }else {

                                        ///TODO дата
                                        if (ФиналДата!=null) {
                                            ///
                                            ((TextView) view).setText(ФиналДата);
                                        }
                                    }










                                    return true;




                                ////
                                default:
                                    //////////////////

                                    return false;
                            }
                        } else {



                            ((TextView) view).setGravity(Gravity.CENTER_HORIZONTAL |  Gravity.CENTER_VERTICAL);



                            StringBuffer БуферКогдаНетСообщенийВооюоще=new StringBuffer("* Нет сообщений в чате !!! *");

                            // TODO: 28.06.2021 данный код когда нет вообще данных в курсоре и нет сообдений
                            ((TextView) view).setText(БуферКогдаНетСообщенийВооюоще.toString());



                            return false;
                        }


                        //////////////////

                    }};


                ////
                АдаптерДляСообщенийЧата.setViewBinder( БиндингДляСообщенийЧата);
                ///
                ЛистВьюДляСообщенийЧата.setAdapter(АдаптерДляСообщенийЧата);

                ////

            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }
    }


















    private class CONTROLLER implements AdapterView.OnItemClickListener  {
        /////

        private  String ПолученыйФИОIDДляЧата;

        public CONTROLLER(Activity  activity) {
            try{

                Log.d(this.getClass().getName(), "  CONTROLLER  ");

                ЛистВьюДляСообщенийЧата.setOnItemClickListener(this);
                ///
                viewДляСообщений.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        Log.d(this.getClass().getName(), "  onClick  MyWork_Update_ОбновлениеПО СЛУЖБА  " + viewДляСообщений.getId());
                    }
                });
                //  Курсор_ДляЗагрузкиСотрудников.close();






// TODO: 30.06.2021 ФЛот
                МетодКруглаяКнопкаНаФрагментеЧитатьПисать();





            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            try{
                Log.d(this.getClass().getName(), " onItemClick MyWork_Update_ОбновлениеПО СЛУЖБА  " + view.getId());


                //  Snackbar.make(v, "Here",Snackbar.LENGTH_LONG).setAction("Action",null).show();
                Vibrator v2 = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v2.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    //deprecated in API 26
                    v2.vibrate(150);
                }



///
                Object ХэшДанныеВВидеОбьекта= parent.getItemAtPosition(position);

                ///
                TextView textViewВытаскиваемФрагментСообщения=  view.findViewById(android.R.id.text1);

                //////

                ПолученыйIDДляЧата=0;


                ///////////////////////////////TODO получения  ID
                ПолученыйIDДляЧата=Integer.parseInt(textViewВытаскиваемФрагментСообщения.getTag().toString());

                Log.d(this.getClass().getName(), "  textView.getTag() "+ textViewВытаскиваемФрагментСообщения.getTag()  + " ПолученыйIDДляЧата " +ПолученыйIDДляЧата);


                ///
                ПолученыйФИОIDДляЧата=new String();
                //
                ПолученыйФИОIDДляЧата=textViewВытаскиваемФрагментСообщения.getText().toString().trim();

                Log.d(this.getClass().getName(),  " ПолученыйФИОIDДляЧата " +ПолученыйФИОIDДляЧата);



                ///



                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

           /*             Toast.makeText(getActivity(),
                                "Фрагмент НОМер 1  " + textViewВытаскиваемФрагментСообщения.getText() + " textView.getTag() "+ textViewВытаскиваемФрагментСообщения.getTag()   , Toast.LENGTH_SHORT).show();*/
                    }
                });

                // TODO: 02.07.2021 полылаем значния с  сообщения



                Intent intentЗапускСообщенияИзФрагмента=new Intent();

                //////
                // intentЗапускЧата.setClass(getApplicationContext(), MainActivity_history_chat_test.class);

                intentЗапускСообщенияИзФрагмента.setClass(getActivity(), MainActivity_List_Chats.class);

                HashMap<String,Object> ХэщЗапусАктивтиИзФрагмента=new HashMap<>();
                //
                ХэщЗапусАктивтиИзФрагмента.put("ЗапускАктивтиЧатИзФрагмента","Повторный Запск Активти  Для Третьего Фрагмента");


                // TODO: 29.06.2021 второй парамент передают ID
                ХэщЗапусАктивтиИзФрагмента.put("ПолученыйIDДляЧата",ПолученыйIDДляЧата);

                ///

                // TODO: 30.06.2021 ПолучаемКто написла чеоез ЗАПРОС


                // TODO: 29.06.2021 второй парамент передают ID
                if (ПолученыйФИОIDДляЧата.length()>0) {
                    //////
                    ХэщЗапусАктивтиИзФрагмента.put("ПолученыйФИОIDДляЧата",ПолученыйФИОIDДляЧата);
                }


                //
                intentЗапускСообщенияИзФрагмента.putExtra("ОбменМеждуАктивти",ХэщЗапусАктивтиИзФрагмента);


                intentЗапускСообщенияИзФрагмента.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                startActivity(intentЗапускСообщенияИзФрагмента);





                ///



            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }




        private void МетодКруглаяКнопкаНаФрагментеЧитатьПисать() {


            //////////////////////////////
            floatingActionButtonФрагментСообщение.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.e(this.getClass().getName()," " );
                    //////конец второго лушателя спинера
                    //  floatingActionButtonВФагментеReadandWrite.setBackgroundResource(R.drawable.icon_dsu1_fragment_read_write_down);  ////@drawable/icon_dsu1_singlescroll_forfart

                    //TODO ТУТ КОД БУДЕТ ЗАПУСКАТЬСЯ СОЗДАЕНИЕ НОВОГО ИЛИ ДОБАВЛЕНИЕ ДЕЙСТВУЕЮЩЕГО СОТРУДНИКА В ТАБЕЛЬ
                    floatingActionButtonФрагментСообщение.setImageResource(R.drawable.icon_dsu1_message_add_kontact);

                    //  Snackbar.make(v, "Here",Snackbar.LENGTH_LONG).setAction("Action",null).show();
                    Vibrator v2 = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v2.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        //deprecated in API 26
                        v2.vibrate(100);
                    }

                    Handler handler=new Handler();
                    /////
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            floatingActionButtonФрагментСообщение.setImageResource(R.drawable.icon_dsu1_message_add_toback_fragment);


                            Intent intentЗапускЧатаИзФрагмента=new Intent();
                            ///




                            intentЗапускЧатаИзФрагмента.setClass(getActivity(), MainActivity_List_Chats.class);

                            HashMap<String,Object> ХэщЗапусАктивтиИзФрагмента=new HashMap<>();
                            //
                            ХэщЗапусАктивтиИзФрагмента.put("ЗапускАктивтиЧатИзФрагмента","Повторный Запск Фрагмента Контактов");


                            // TODO: 30.06.2021 ПолучаемКто написла чеоез ЗАПРОС


                            //
                            intentЗапускЧатаИзФрагмента.putExtra("ОбменМеждуАктивти",ХэщЗапусАктивтиИзФрагмента);


                            intentЗапускЧатаИзФрагмента.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                            startActivity(intentЗапускЧатаИзФрагмента);



                        }
                    },200);








                }


            });


        }




    }





    private class MODEL {
        /////
        public MODEL(Activity activity) {

            ///
            SQLiteCursor  Курсор_ВычисляемПУбличныйID=null;

          Class_GRUD_SQL_Operations   class_grud_sql_operationsВычисляемПУбличныйIDВтораяЧасть=new Class_GRUD_SQL_Operations(getActivity());

            try{


                // TODO: 05.07.2021  получаем публичный ID


                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ


                ///
                class_grud_sql_operationsВычисляемПУбличныйIDВтораяЧасть.
                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","SuccessLogin");
                ///////
                class_grud_sql_operationsВычисляемПУбличныйIDВтораяЧасть.
                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","id");
                //
            /*        class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","uuid=?    AND status_send !=? AND month_tabels=? AND  year_tabels =? AND fio IS NOT NULL ");
                    ///"_id > ?   AND _id< ?"
                    //////
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",finalПолученныйUUID);
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......
*/
                ////TODO другие поля

                ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
                ////
                //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
                ////
                class_grud_sql_operationsВычисляемПУбличныйIDВтораяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update DESC");
                ////
                class_grud_sql_operationsВычисляемПУбличныйIDВтораяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                ////

                // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ


                Курсор_ВычисляемПУбличныйID=null;
                //////////////

                Курсор_ВычисляемПУбличныйID= (SQLiteCursor) class_grud_sql_operationsВычисляемПУбличныйIDВтораяЧасть.
                        new GetData(getActivity()).getdata(class_grud_sql_operationsВычисляемПУбличныйIDВтораяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                        class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                Log.d(this.getClass().getName(), "GetData "  +Курсор_ВычисляемПУбличныйID);




       /*         // TODO: 08.09.2021  _old
                Курсор_ВычисляемПУбличныйID=new MODEL_synchronized(getContext()).КурсорУниверсальныйБазыДанных("SELECT id FROM SuccessLogin LIMIT 1 ");
                /////
*/
                // TODO: 08.09.2021 resultat 
                
                if(Курсор_ВычисляемПУбличныйID.getCount()>0){
                    //////////
                    Курсор_ВычисляемПУбличныйID.moveToFirst();
                    //////////////
                    ПубличноеIDПолученныйИзСервлетаДляUUID=Курсор_ВычисляемПУбличныйID.getInt(0);
                    //////




                }



                // TODO: 28.06.2021  обнуялем курсор перед получением данных




                //  TimeUnit.MILLISECONDS.sleep(100);

                Log.d(this.getClass().getName(), "  MODEL  ПубличноеIDПолученныйИзСервлетаДляUUID "+ПубличноеIDПолученныйИзСервлетаДляUUID);



                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

             Class_GRUD_SQL_Operations          class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть=new Class_GRUD_SQL_Operations(getActivity());
                ///
//                class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть.
//                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","viewchat");
//                ///////
//                class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть.
//                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","*");
//                //
//      /*          class_grud_sql_operations_ДанныеДляСообщенийЧата. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","uuid=?    " +
//                        "AND status_send !=? AND month_tabels=? AND  year_tabels =? AND fio IS NOT NULL ");
//                    ///"_id > ?   AND _id< ?"*/
//                    //////
//
//                class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть.
//                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФлагНепотораяемостиСтрок",true);
//                    ///
//            /*      class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
//                    ///
//                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);//ФлагНепотораяемостиСтрок
//                    //
//                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......
//*/
//                ////TODO другие поля*/
//
//                class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть.
//                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки","id_user");
//                ////
//                class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть.
//                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки"," COUNT(*) >= 1");
//                ////
//                class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть.
//                        concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update DESC");
//                ////
//               /// class_grud_sql_operationsMODEL. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                ////

                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                ///
                class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СамFreeSQLКОд",
                        " SELECT DISTINCT *  FROM viewchat   WHERE message  IS NOT NULL   group by id_user   HAVING COUNT(*) >= 1   ORDER BY date_update   ;");///date_update DESC





                // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ  вторая операиця
                //////
                КурсорДанныеДляСообщенийЧата=null;

                ////////
                КурсорДанныеДляСообщенийЧата= (SQLiteCursor)  class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть.
                        new GetаFreeData(getActivity()).getfreedata(class_grud_sql_operations_ДанныеДляСообщенийЧатаТретьяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                        class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                // TODO: 28.09.2021

                Log.d(this.getClass().getName(), "GetData "  +КурсорДанныеДляСообщенийЧата);





      /*          // TODO: 08.09.2021    _old

                КурсорДанныеДляСообщенийЧата= МетодПолучениеДанныхДляФрагментаСообщенияЧата("SELECT " +
                        " DISTINCT  * FROM viewchat   GROUP BY id_user HAVING COUNT(*) >= 1   ORDER BY date_update DESC");//бышвий user_for
                ////*/
                /*КурсорДанныеДляСообщенийЧата= МетодПолучениеДанныхДляФрагментаСообщенияЧата("SELECT * FROM ViewChat WHERE user_update ="+PUBLIC_CONTENT.ПУбличныйДанныеПришёлЛиIDДЛяГенерацииUUID+
                        " OR user_update="+PUBLIC_CONTENT.ПУбличныйДанныеПришёлЛиIDДЛяГенерацииUUID+"   GROUP BY user_update ORDER BY date_update DESC");*/

                //////

                Log.d(this.getClass().getName(), "  КурсорДанныеДляСообщенийЧата  "+КурсорДанныеДляСообщенийЧата);



                // TODO: 06.07.2021 вычислеме если хоть одно не прочитаное сообщение тогда статк ирный устанвливаем на переписку



            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///
            }
        }










        // TODO: 08.09.2021  Метод Получает ФИО на основании выбраного сотрудника

        String МетодПолучениеФИОНАОснованииIDВыбранногоСотрудника(int ПуличныйIdДляВычисленияКтоНаписал){


            Cursor       КурсорДанныеДляКонтактовФИОЧата=null;
            ////
            StringBuffer    ПолученыйФИОIDДляЧата = new StringBuffer();
            /////
           Class_GRUD_SQL_Operations    class_grud_sql_operationsПолучениеФИОНАОснованииIDВыбранногоСотрудникаЧетвертаяЧасть=new Class_GRUD_SQL_Operations(getActivity());

            try{


                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                ///
                class_grud_sql_operationsПолучениеФИОНАОснованииIDВыбранногоСотрудникаЧетвертаяЧасть=new Class_GRUD_SQL_Operations(getActivity());

                ///
                class_grud_sql_operationsПолучениеФИОНАОснованииIDВыбранногоСотрудникаЧетвертаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","Chat_Users");
                ///////
                class_grud_sql_operationsПолучениеФИОНАОснованииIDВыбранногоСотрудникаЧетвертаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","name");
                //
                class_grud_sql_operationsПолучениеФИОНАОснованииIDВыбранногоСотрудникаЧетвертаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","_id =? ");
                    ///"_id > ?   AND _id< ?"
                    //////
                class_grud_sql_operationsПолучениеФИОНАОснованииIDВыбранногоСотрудникаЧетвертаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",ПуличныйIdДляВычисленияКтоНаписал);
                    ///
             /*       class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......

                ////TODO другие поля

                ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
                ////
                //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
                ////
                class_grud_sql_operationsПолучениеИмяСистемы. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");*/
                ////
                /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                ////

                // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

                КурсорДанныеДляКонтактовФИОЧата=null;

                ////////

                КурсорДанныеДляКонтактовФИОЧата= (SQLiteCursor)  class_grud_sql_operationsПолучениеФИОНАОснованииIDВыбранногоСотрудникаЧетвертаяЧасть.
                        new GetData(getActivity()).getdata(class_grud_sql_operationsПолучениеФИОНАОснованииIDВыбранногоСотрудникаЧетвертаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                        class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                Log.d(this.getClass().getName(), "GetData "  +КурсорДанныеДляКонтактовФИОЧата);
                
                
                
                
                
                
                
                


           /*     // TODO: 08.09.2021  _old

                КурсорДанныеДляКонтактовФИОЧата= new MODEL(getActivity()).
                        МетодПолучениеДанныхДляФрагментаСообщенияЧата(" SELECT name  FROM  Chat_Users   WHERE _id =" + ПуличныйIdДляВычисленияКтоНаписал + ""); ///Chat_Users /fio


*/
                //////TODO resultat
                if(КурсорДанныеДляКонтактовФИОЧата.getCount()>0){
                    ///
                    КурсорДанныеДляКонтактовФИОЧата.moveToFirst();
                    ///
                    int ИндексФИо=КурсорДанныеДляКонтактовФИОЧата.getColumnIndex("name");
                    ////

                    // TODO: 08.09.2021  цикл
                    do{
                        ////

                        //
                        ПолученыйФИОIDДляЧата.append(КурсорДанныеДляКонтактовФИОЧата.getString(ИндексФИо).trim()).append(",").append("\n");;

                        Log.d(this.getClass().getName(), "ПолученыйФИОIDДляЧата "+ПолученыйФИОIDДляЧата);


                        // TODO: 30.06.2021 выход

                        if(ПолученыйФИОIDДляЧата.length()>0){
                            /////

                            Log.d(this.getClass().getName(), "ПолученыйФИОIDДляЧата "+ПолученыйФИОIDДляЧата);
                            ///
                            break;
                        }

                    }while (КурсорДанныеДляКонтактовФИОЧата.moveToNext());
                    // TODO: 22.07.2021  заполнили всеми фио

                    ПолученыйФИОIDДляЧата.setLength(ПолученыйФИОIDДляЧата.length()-2);
                    ////

///////////////
                }

                
                /////////

            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///
            }

            return ПолученыйФИОIDДляЧата.toString();
        }



    }
}