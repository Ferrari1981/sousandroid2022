package com.dsy.dsu;



import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.android.volley.toolbox.HttpResponse;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.CipherSuite;
import okhttp3.ConnectionSpec;
import okhttp3.OkHttpClient;


public class Fragment_Writer_Read_ЧитатьПисатьЧата extends Fragment    {

    // TODO: Rename parameter arguments, choose names that match

    View viewДляСообщений=null;

    ///////TODO
    CREATE_DATABASE   Create_Database_СсылкаНАБазовыйКласс;

    ListView ЛистВьюДляСообщенийЧата =null;


    SQLiteCursor КурсорДанныеДлязаписиичтнияЧата=null;

    int ПолученыйIDДляЧата=0;

    //
    String ПолученыйФИОIDДляЧата=new String();


    FloatingActionButton floatingActionButtonВФагментеReadandWrite;

    int ПубличныйIDДляФрагмента=0;


    TextView textViewФрагментЧитатьПисатьДляЧата;
    //

    EditText editTextТелоНаписаногоСообщенияДругимСотрудникам;


    // TODO: 11.10.2021

    PUBLIC_CONTENT public_contentМенеджерПотоковПоРасписанию=null;



    //
    SimpleAdapter АдаптерДляЗаписиЧтенияКогдаНетДанных =null;

    SimpleCursorAdapter АдаптерДляЗаписиЧтенияЧата=null;




    Long    СгенерированныйUUIDДляНовогоТабеля=0l;


    // TODO: 06.08.2021
    // TODO: 06.08.2021

    // TODO: 12.10.2021  Ссылка Менеджер Потоков

    PUBLIC_CONTENT  class_async_backgroundГдеНаходитьсяМенеджерПотоков =null;

    LinkedBlockingQueue<String> ЛистЗапускаемТолькоТаблицыЧатаВСинхронизации=new LinkedBlockingQueue();
    /////////

    Activity ActivityДляСинхронизацииОбмена=null;

    Fragment fragment=null;
/*
    Boolean  ФлагУказываетНАЗАпускСИнхронизацииИзЧата=true;





    // TODO: 07.07.2021  главный метод фрагмента читать и писать
    Boolean  ФлагУказываетСозданииНовгоСообщенияиИзЧата=true;*/
// TODO: 07.07.2021  главный метод фрагмента читать и писать
// TODO: 26.08.2021  конструктор

    // TODO: 26.08.2021  МЕНЕДЖЕР ПОТОКВ ДЛЯ GRUD ОПЕРАЦИЙ--по расписанию
    //////////


    //






    @Override
    public void onDestroy() {
        super.onDestroy();

        // TODO: 11.10.2021


            ////

        if (!public_contentМенеджерПотоковПоРасписанию. МенеджерПОтокПоРАсписанию.isShutdown()) {
            //////
            public_contentМенеджерПотоковПоРасписанию. МенеджерПОтокПоРАсписанию.shutdown();
        }


        Log.d(this.getClass().getName(), " ЧАТ  метод onDestroy()  выход из менедженра потоков ЧАТА на фраменте EXIT /:::::"
                    +   public_contentМенеджерПотоковПоРасписанию. МенеджерПОтокПоРАсписанию.isShutdown());




    }





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        try{

            // TODO: 09.09.2021  поток устанавлваем по рассанию





///////TODO
              Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(getContext());


            ActivityДляСинхронизацииОбмена=getActivity();

            ////

            fragment=this;


            class_async_backgroundГдеНаходитьсяМенеджерПотоков =new PUBLIC_CONTENT (getActivity());


            Log.d(getActivity().getClass().getName(), "ActivityДляСинхронизацииОбмена " + ActivityДляСинхронизацииОбмена.toString()+
                    "  fragment " +fragment.toString());


            // Inflate the layout for this fragment
            viewДляСообщений= inflater.inflate(R.layout.fragment3_layout, container, false);
            /////
            // Inflate the layout for this fragment



            ////
            ЛистВьюДляСообщенийЧата = (ListView) viewДляСообщений.findViewById(R.id.list);



            floatingActionButtonВФагментеReadandWrite= (FloatingActionButton) viewДляСообщений.findViewById(R.id.floatingActionButtonВФагментеReadandWrite);



            textViewФрагментЧитатьПисатьДляЧата= (TextView) viewДляСообщений.findViewById(R.id.textViewФрагментЧитатьПисатьДляЧата);




            // TODO: 30.06.2021 даннеы


            ПолученыйIDДляЧата=0;

            ////


            ПолученыйIDДляЧата = getArguments().getInt("ПолученыйIDДляЧата");

//

            ПолученыйФИОIDДляЧата=new String();



            ПолученыйФИОIDДляЧата = getArguments().getString("ПолученыйФИОIDДляЧата");






            Log.d(this.getClass().getName(), "   ЗАПУСК ФОНОВОЙ СИНХРОНИЗАЦИИИ С mYwORK_sYNCHRONIZACI  СЛУЖБА  WorkManager Synchronizasiy_Data ПолученыйIDДляЧата "+ПолученыйIDДляЧата+
                    "  ПолученыйФИОIDДляЧата " +ПолученыйФИОIDДляЧата);


            // TODO: 05.07.2021 значение написаного сообджгение в чате для другого пользолвателя

            editTextТелоНаписаногоСообщенияДругимСотрудникам= (EditText) viewДляСообщений.findViewById(R.id.editTextТелоНаписаногоСообщенияДругимСотрудникам);

//////////////////




            ////
            ЛистВьюДляСообщенийЧата = (ListView) viewДляСообщений.findViewById(R.id.list);



            floatingActionButtonВФагментеReadandWrite= (FloatingActionButton) viewДляСообщений.findViewById(R.id.floatingActionButtonВФагментеReadandWrite);



            textViewФрагментЧитатьПисатьДляЧата= (TextView) viewДляСообщений.findViewById(R.id.textViewФрагментЧитатьПисатьДляЧата);


            // TODO: 06.10.2021  опредяем какие таблиув для синхрониазцуии с этогй фрагмента для чата 
            ЛистЗапускаемТолькоТаблицыЧатаВСинхронизации.add("chats");
            ///
            ЛистЗапускаемТолькоТаблицыЧатаВСинхронизации.add("data_chat");


            Log.d(this.getClass().getName(), "ЛистЗапускаемТолькоТаблицыЧатаВСинхронизации " + ЛистЗапускаемТолькоТаблицыЧатаВСинхронизации);












            // TODO: 30.09.2021 МЕТОД ЗАПУСКА СИНХРОНИЗАЦИИ ЧАТА ПО РАСПИСАНИЮ , НЕ ВЗАВИСИМОСТИ ОТ СОЗДАВАЛ ЛИ СООБЩЕНИЕ ИЛИ НЕТ  
            
           МетодЗапускаСинхрониазцииПоРАсписаниювНезависимостиОтВставкиНовгоСообщения();





        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());

            // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///


        }
        return  viewДляСообщений;
    }

    private void МетодЗапускаСинхрониазцииПоРАсписаниювНезависимостиОтВставкиНовгоСообщения() {
        ///
        // TODO: 11.10.2021

        // TODO: 11.10.2021

      public_contentМенеджерПотоковПоРасписанию=new PUBLIC_CONTENT(getContext());


        // TODO: 08.09.2021 ВЫЗЫВАЕМ ПОТОК ПО РАСПИСАНИЮ
        public_contentМенеджерПотоковПоРасписанию. МенеджерПОтокПоРАсписанию.  scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {

                // TODO: 10.08.2021  временно запускаем сдесь фонофую синхронизацию для чата

                //////
                try {


                            Long РезультатЗапускаФоновойСинхронизации = 0l;

                            // TODO: 28.09.2021  nerwork ping

                            // TODO: 29.09.2021  перед началом СИНХРОНИЗАЦИИ ПРОВЕРЯЕМ УСТАНОВКИ СЕТИ ПОЛЬЗОВАТЕЛЯ НА АКТИВТИ НАСТРОЙКИ

                            boolean РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию=
                                    new  Class_Find_Setting_User_Network(getActivity()).МетодПроветяетКакуюУстановкуВыбралПользовательСети();

                            //TODO ФУТУРЕ ЗАВЕРШАЕМ
                            Log.d(this.getClass().getName(), "  РезультатПроВеркиУстановкиПользователяРежимРаботыСети "
                                    + РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию);


                            // TODO: 29.09.2021  финальный результат
                            boolean       РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции=false;


                            if (РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию==true) {
                                ////
                                try{
                                    /////////////////

                                    /////////////////
                                    РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции
                                            =new Class_Connections_Server(getContext()).МетодПингаСервераРаботаетИлиНет(getContext());
                                    ///

                                    Log.d(this.getClass().getName(), " РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции "
                                            + РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции);

                                } catch (Exception e) {
                                    e.printStackTrace();
                                    ///метод запись ошибок в таблицу
                                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                }
                            }


                            // TODO: 22.04.2021  srart JOBschedele
                            Log.d(this.getClass().getName(), " СЛУЖБА  РезультатЗапускаФоновойСинхронизации    "+РезультатЗапускаФоновойСинхронизации);


                            if (РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции==true) {

                                // TODO: 01.07.2021  после локальной обнолвения поробуем вотрунть синхронизацию локальную  в фоне и порстмортрим что будет
/*                 Integer РезультатФоновойСинхронизации =
                        new Class_Generation_Async_Inside_Tabel(getApplicationContext()).МетодЗапускаФоновойСинхронизацииАсинхронно(getApplicationContext());


                Log.d(this.getClass().getName(), " РезультатФоновойСинхронизации " + РезультатФоновойСинхронизации);

 */
                                ///////
                                    //
                                    Integer      РезультатЗапускаСинхронизацииЧатаОтправка =0;

                                    ////
                                    РезультатЗапускаСинхронизацииЧатаОтправка = МетодЗапускаСинхронизацииТОлькоДляЧатаПоРАсписанию("Запускаем Только Отправления Синхронизации");//Запускаем Только Отправления Синхронизации


                                    Log.d(this.getClass().getName(), "РезультатЗапускаСинхронизацииЧатаОтправка   "+РезультатЗапускаСинхронизацииЧатаОтправка);


                                    // TODO: 19.08.2021 получение дейстике второе


                                ///         new CONTROLLER(getActivity()).    МетодПослеВставкиНовгоСообщенияИлиПослеХолостогоХода(null, null,"Получено");

                                Log.d(this.getClass().getName(), " 2 . МетодПослеВставкиНовгоСообщенияИлиПослеХолостогоХода ЧАТ  ");
                                //////
                                // TODO: 22.04.2021  srart JOBschedele
                                Log.d(this.getClass().getName(), " СЛУЖБА  РезультатЗапускаФоновойСинхронизации    "+РезультатЗапускаФоновойСинхронизации);

                                Integer finalРезультатЗапускаСинхронизацииЧатаОтправка = РезультатЗапускаСинхронизацииЧатаОтправка;


                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        ////

                                        // TODO: 29.04.2021 вуключаем

                                        if (finalРезультатЗапускаСинхронизацииЧатаОтправка >0) {

                                            //
                                            editTextТелоНаписаногоСообщенияДругимСотрудникам.setHintTextColor(Color.GRAY);

                                            //
                                            editTextТелоНаписаногоСообщенияДругимСотрудникам.setHint("Отправка/Получение ►►►");


                                            // TODO: 11.08.2021 дейстиве заключительно после синхронизации перерисовываем внешний вид чатат
                                            Log.d(this.getClass().getName(), " finalРезультатЗапускаСинхронизацииЧатаОтправка " + finalРезультатЗапускаСинхронизацииЧатаОтправка);




                                                МетодПерегрузкиВнешнегоВидаЧата(finalРезультатЗапускаСинхронизацииЧатаОтправка);






                                            /////
                                            Vibrator v2 = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                                            // Vibrate for 500 milliseconds
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                v2.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE));
                                            } else {
                                                //deprecated in API 26
                                                v2.vibrate(200);
                                            }


                                        }else {

                              /*              //
                                            editTextТелоНаписаногоСообщенияДругимСотрудникам.setHintTextColor(Color.RED);
                                            //
                                            editTextТелоНаписаногоСообщенияДругимСотрудникам.setHint(" Нет Отправка/Получение ►►►");*/

                                        }

                                        editTextТелоНаписаногоСообщенияДругимСотрудникам.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {

                                                //
                                                editTextТелоНаписаногоСообщенияДругимСотрудникам.setHintTextColor(Color.parseColor("#00ACC1"));
                                                //
                                                editTextТелоНаписаногоСообщенияДругимСотрудникам.setHint("Напишите сообщение !!!");


                                                // TODO: 11.08.2021 дейстиве заключительно после синхронизации перерисовываем внешний вид чатат
                                                Log.w(this.getClass().getName(), " СЛУЖБА ЧАТА ПО РАСПИСАНИЮ ВНУТРИ КОНЕЦ ПОСЛЕ КАК ОДИН КРУГ ОТРАБОТАЛ " +
                                                        "" + finalРезультатЗапускаСинхронизацииЧатаОтправка);



                                            }
                                        },1500);


                                    }});
                                ///////

                                ///
                                // TODO: 22.04.2021  srart JOBschedele
                                Log.d(this.getClass().getName(), " СЛУЖБА  РезультатЗапускаФоновойСинхронизации    "+РезультатЗапускаФоновойСинхронизации);



                            }





                // TODO: 29.09.2021  конец синхрониазции по раписанию
            } catch (Exception e) {
                e.printStackTrace();
               ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }



            }
        }, 2, 7L , TimeUnit.SECONDS);
        ////
    }


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // TODO: 10.08.2021 запуск метода по расписанию для ЧАТА
    private Integer МетодЗапускаСинхронизацииТОлькоДляЧатаПоРАсписанию(String ФлагКакуюЧастьСинхронизацииЗапускаем) {
        ////
   Integer РезультатЗапускаВторойСинхронизации = 0;


        try{
            /////TODO ВТОРОЙ ШАГ СИНХРОНИЗАЦИИ ПОЛУЧАЕМ СПИСОК ТАБЛИЦ КОТОРЫЕ НУЖНО  СИНХРОНИЗИРОВАТЬ 100% процентов , И ПРОВЕРМЯЕМ ЕСЛИ СВЯЗЬ С ИНТЕНТОМ




                                // TODO: 28.09.2021  --САМ ЗАПУСК СИНХРОНИАЗЦИИИ ДЛЯ ЧАТА

                                РезультатЗапускаВторойСинхронизации =
                                        new Class_Async_Background(getActivity()).
                                        МетодЗАпускаФоновойСинхронизации(getActivity(),
                                                "СинхронизацияДляЧата",true,
                                                ActivityДляСинхронизацииОбмена,
                                                ЛистЗапускаемТолькоТаблицыЧатаВСинхронизации,"ПовторныйЗапускСинхронизации",0);  //МетодЗАпускаСинхронизациивФонеТолькоСинхронно   //МетодЗАпускаСинхронизациивФоне
                                ///
                                Log.d(this.getClass().getName(), " Холостой Синхронизации ТОлько Полчение Данных   РезультатЗапускаВторойСинхронизации"+ РезультатЗапускаВторойСинхронизации);




                            Log.d(this.getClass().getName(), "  СЛУЖБА ТОЛЬКО ДЛЯ ЧАТА  РезультатЗапускаВторойСинхронизации  "
                                    + РезультатЗапускаВторойСинхронизации+
                                    " ИндексКоличествоПопытокОтправкиЧата " );

                            // TODO: 29.04.2021 вуключаем


            if (РезультатЗапускаВторойСинхронизации>0) {

                Integer finalРезультатЗапускаВторойСинхронизации = РезультатЗапускаВторойСинхронизации;
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ////

                        МетодПерегрузкиВнешнегоВидаЧата(finalРезультатЗапускаВторойСинхронизации);

                    }});
            }


            ///         new CONTROLLER(getActivity()).    МетодПослеВставкиНовгоСообщенияИлиПослеХолостогоХода(null, null,"Получено");

                            Log.d(this.getClass().getName(), " 2 . МетодПослеВставкиНовгоСообщенияИлиПослеХолостогоХода ЧАТ  ");
                                //////
                                // TODO: 22.04.2021  srart JOBschedele


            // TODO: 29.09.2021  конец синхрониазции по раписанию




    } catch (Exception e) {

            e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        ///


    }
        return РезультатЗапускаВторойСинхронизации;
    }


    // TODO: 19.08.2021 Асинхронно  запуск синхронизации ЧАТА















    // TODO: 10.08.2021 запуск метода по расписанию для ЧАТА
    private Integer МетодЗапускаСинхронизацииАсинхронныйЗапскПослеСозданиесообщения(View v,String ФлагКакуюЧастьСинхронизацииЗапускаем) {
        /////

        final Integer[] РезультатЗапускаВторойСинхронизации = {0};
        //////
        final Integer[] ФиналРезультатЗапускаВторойСинхронизации = {0};
        //////
PUBLIC_CONTENT public_contentЗапускаСинхронизацииАсинхронныйЗапскПослеСозданиесообщенияnew = new PUBLIC_CONTENT(getActivity());
//////
     ///   editTextТелоНаписаногоСообщенияДругимСотрудникам.setTextColor(Color.parseColor("#00ACC1"));

        ;



        // TODO: 30.09.2021  ЗАПУСКАЕМ МЕНЕДЖЕР ПОТОКО ДЯЛ СИНХРОНИЗАЦИИ ЧАТА ПОСЛЕ СОЗДАНИЯ НОВОГО СООБЩЕНИЯ
        class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков.submit(()-> {



        try{



            /////TODO ВТОРОЙ ШАГ СИНХРОНИЗАЦИИ ПОЛУЧАЕМ СПИСОК ТАБЛИЦ КОТОРЫЕ НУЖНО  СИНХРОНИЗИРОВАТЬ 100% процентов , И ПРОВЕРМЯЕМ ЕСЛИ СВЯЗЬ С ИНТЕНТОМ



                        Long РезультатЗапускаФоновойСинхронизации = 0l;

                        // TODO: 28.09.2021  nerwork ping

                        // TODO: 29.09.2021  перед началом СИНХРОНИЗАЦИИ ПРОВЕРЯЕМ УСТАНОВКИ СЕТИ ПОЛЬЗОВАТЕЛЯ НА АКТИВТИ НАСТРОЙКИ

                        boolean РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию=
                                new  Class_Find_Setting_User_Network(getActivity()).МетодПроветяетКакуюУстановкуВыбралПользовательСети();

                        //TODO ФУТУРЕ ЗАВЕРШАЕМ
                        Log.d(this.getClass().getName(), "  РезультатПроВеркиУстановкиПользователяРежимРаботыСети " + РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию);


                        // TODO: 29.09.2021  финальный результат
                        boolean       РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции=false;


                        if (РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию==true) {
                            ////
                            try{
                                /////////////////


                                /////////////////
                                РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции
                                        =new Class_Connections_Server(getContext()).МетодПингаСервераРаботаетИлиНет(getContext());
                                ///

                                Log.d(this.getClass().getName(), " РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции " + РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции);






                            } catch (Exception e) {
                                e.printStackTrace();
                                ///метод запись ошибок в таблицу
                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                            }
                        }


                        // TODO: 22.04.2021  srart JOBschedele
                        Log.d(this.getClass().getName(), " СЛУЖБА  РезультатЗапускаФоновойСинхронизации    "+РезультатЗапускаФоновойСинхронизации);


                        if (РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции==true) {

                            // TODO: 01.07.2021  после локальной обнолвения поробуем вотрунть синхронизацию локальную  в фоне и порстмортрим что будет
   /*                 Integer РезультатФоновойСинхронизации =
                            new Class_Generation_Async_Inside_Tabel(getApplicationContext()).МетодЗапускаФоновойСинхронизацииАсинхронно(getApplicationContext());


                    Log.d(this.getClass().getName(), " РезультатФоновойСинхронизации " + РезультатФоновойСинхронизации);
*/


                            try{


                                /////TODO ВТОРОЙ ШАГ СИНХРОНИЗАЦИИ ПОЛУЧАЕМ СПИСОК ТАБЛИЦ КОТОРЫЕ НУЖНО  СИНХРОНИЗИРОВАТЬ 100% процентов , И ПРОВЕРМЯЕМ ЕСЛИ СВЯЗЬ С ИНТЕНТОМ  ЗАПУСКАЕТЬСЯ ПОСЛЕ СОЗДАНИЕ СООБЩЕНИЯ

                                // Boolean РезультатЕслиСвязьСерверомДСУ=false;
                                // TODO: 29.04.2021 вуключаем



                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        ////

                                        // TODO: 29.04.2021 вуключаем

                                        //
                                        editTextТелоНаписаногоСообщенияДругимСотрудникам.setHintTextColor(Color.GRAY);

                                        editTextТелоНаписаногоСообщенияДругимСотрудникам.setHint("Отправка/Получение  ►►►");

                                    }});
                                ///////




                                РезультатЗапускаВторойСинхронизации[0] =           new Class_Async_Background(getActivity()).
                                        МетодЗАпускаФоновойСинхронизации(getActivity(),"СинхронизацияДляЧата",true,ActivityДляСинхронизацииОбмена,ЛистЗапускаемТолькоТаблицыЧатаВСинхронизации,"ПовторныйЗапускСинхронизации",0);  //МетодЗАпускаСинхронизациивФонеТолькоСинхронно   //МетодЗАпускаСинхронизациивФоне
                                ///
                                Log.d(this.getClass().getName(), "РезультатЗапускаВторойСинхронизации"+ РезультатЗапускаВторойСинхронизации[0]);

                                // TODO: 29.09.2021

                                Log.d(this.getClass().getName(), "  СЛУЖБА ТОЛЬКО ДЛЯ ЧАТА  РезультатЗапускаВторойСинхронизации  "
                                        + РезультатЗапускаВторойСинхронизации[0] +
                                        " ИндексКоличествоПопытокОтправкиЧата " );






                                // TODO: 11.08.2021 дейстиве заключительно после синхронизации перерисовываем внешний вид чатат
                                Log.d(this.getClass().getName(), " 2 . МетодПослеВставкиНовгоСообщенияИлиПослеХолостогоХода ЧАТ  ");



                            } catch (Exception e) {
                                e.printStackTrace();
                                ///метод запись ошибок в таблицу
                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                // TODO: 01.09.2021 метод вызова
                                new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                                        this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                        Thread.currentThread().getStackTrace()[2].getLineNumber());
                                ///


                            }


                            Log.d(this.getClass().getName(), "  СЛУЖБА ТОЛЬКО ДЛЯ ЧАТА  РезультатЗапускаВторойСинхронизации  "
                                    + РезультатЗапускаВторойСинхронизации[0] +
                                    " ИндексКоличествоПопытокОтправкиЧата " );

                            // TODO: 29.04.2021 вуключаем



                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    ////

                                    // TODO: 29.04.2021 вуключаем

                                    МетодПерегрузкиВнешнегоВидаЧата(РезультатЗапускаВторойСинхронизации[0]);

                                }});




                            ФиналРезультатЗапускаВторойСинхронизации[0] = РезультатЗапускаВторойСинхронизации[0];

                            ///         new CONTROLLER(getActivity()).    МетодПослеВставкиНовгоСообщенияИлиПослеХолостогоХода(null, null,"Получено");

                            Log.d(this.getClass().getName(), " 2 . МетодПослеВставкиНовгоСообщенияИлиПослеХолостогоХода ЧАТ  "  + ФиналРезультатЗапускаВторойСинхронизации[0] );
                            //////
                            // TODO: 22.04.2021  srart JOBschedele
                            Log.d(this.getClass().getName(), " СЛУЖБА  РезультатЗапускаФоновойСинхронизации    "+РезультатЗапускаФоновойСинхронизации);



                            ///
                            // TODO: 22.04.2021  srart JOBschedele
                            Log.d(this.getClass().getName(), " СЛУЖБА  РезультатЗапускаФоновойСинхронизации    "+РезультатЗапускаФоновойСинхронизации);



                        }

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///


        }finally {
            ///TODO  exit in менеджера потоков


            class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков.poll();




    /*        getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //
                    editTextТелоНаписаногоСообщенияДругимСотрудникам.setBackgroundColor(Color.parseColor("#00ACC1"));
                }
            });*/


// TODO: 30.09.2021
            editTextТелоНаписаногоСообщенияДругимСотрудникам.postDelayed(new Runnable() {
                @Override
                public void run() {
                    //

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ////

                          ////  editTextТелоНаписаногоСообщенияДругимСотрудникам.setTextColor(Color.parseColor("#00ACC1"));
                        }
                    });


                    ;
                    if (  РезультатЗапускаВторойСинхронизации[0]>0) {
                        ///////

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                ////
                                editTextТелоНаписаногоСообщенияДругимСотрудникам.setHintTextColor(Color.GRAY);

                                editTextТелоНаписаногоСообщенияДругимСотрудникам.setHint("Успешно ►►►");



                                Log.d(this.getClass().getName(), "   Успешная Отправка ► "
                                        +РезультатЗапускаВторойСинхронизации[0]);

                            }});
                    } else {

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                ////

              /*                  editTextТелоНаписаногоСообщенияДругимСотрудникам.setHintTextColor(Color.RED);

                                editTextТелоНаписаногоСообщенияДругимСотрудникам.setHint("Нет  Отправка ‼");

                                // TODO: 30.09.2021


                                Log.d(this.getClass().getName(), "   Нет  Отправка ‼"
                                        +РезультатЗапускаВторойСинхронизации[0]);
*/




                            }});
                    }

                    ////

                    editTextТелоНаписаногоСообщенияДругимСотрудникам.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            //

                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    ////
                                    editTextТелоНаписаногоСообщенияДругимСотрудникам.setHintTextColor(Color.parseColor("#00ACC1"));
                                 ///editTextТелоНаписаногоСообщенияДругимСотрудникам.setTextColor(Color.BLACK);
                                    ////
                                    ;
                                   // editTextТелоНаписаногоСообщенияДругимСотрудникам.setText("");
                                    //
                                    editTextТелоНаписаногоСообщенияДругимСотрудникам.setHint("Напишите сообщение !!!");

                                }});


                        }
                    },2500);



                }
            },1000);











        }

                    // TODO: 30.09.2021

            return РезультатЗапускаВторойСинхронизации[0];

        });

        return  ФиналРезультатЗапускаВторойСинхронизации[0] ;
    }



































    // TODO: 11.08.2021 Метод после изменнения данных и меняем внешний вид чата
    private void МетодПерегрузкиВнешнегоВидаЧата(Integer ФлагПроизошлиЛиИзмененивБазе) {

        try{
            Log.d(this.getClass().getName(), "   ФлагПроизошлиЛиИзмененивБазе   " +ФлагПроизошлиЛиИзмененивБазе);

            if (ФлагПроизошлиЛиИзмененивБазе>0 ) {
                //////


                fragment.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //TODO

                        //TODO
                        // TODO: 06.08.2021 после синхронизациии обноддвяем куроср и внешний вид
                        try {
                            new MODEL(getActivity()).МетодПолучениеДанныхдляФрагментаЧитатьиПисатьЧат();
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        ///
                        new VIEW(getActivity());

                    }});





            }




            fragment.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //TODO

                        if (         ФлагПроизошлиЛиИзмененивБазе>0 ) {

                        if (АдаптерДляЗаписиЧтенияЧата != null) {
                            //////
                            АдаптерДляЗаписиЧтенияЧата.changeCursor(КурсорДанныеДлязаписиичтнияЧата);
                            ////


                            АдаптерДляЗаписиЧтенияЧата.notifyDataSetChanged();
                        }

                        ///



                        if (ЛистВьюДляСообщенийЧата != null) {
                            /////
                            ЛистВьюДляСообщенийЧата.deferNotifyDataSetChanged();

                            ЛистВьюДляСообщенийЧата.invalidateViews();

                            ЛистВьюДляСообщенийЧата.findFocus();
                            ///



                                ЛистВьюДляСообщенийЧата.setItemChecked(ЛистВьюДляСообщенийЧата.getCheckedItemPosition() + 1, true);
                                ///
                                ЛистВьюДляСообщенийЧата.setSelection(ЛистВьюДляСообщенийЧата.getCount() - 1);
                            }


                        }





                    }
                });
                ///todo


        } catch (Exception e) {
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        ///


    }
    }




















    @Override
    public void onPause() {
        super.onPause();

        // TODO: 01.07.2021  после локальной обнолвения поробуем вотрунть синхронизацию локальную  в фоне и порстмортрим что будет
/*
      Long  результатСинхронизацииЗапущеннойВМетодеPAuse = new CONTROLLER(getActivity()).
              МетодЗапускаСинхронизацииПередСозданеимНовгоСообщенияДляЧата();

        Log.d(this.getClass().getName(), "  результатСинхронизацииЗапущеннойВМетодеPAuse   " +результатСинхронизацииЗапущеннойВМетодеPAuse);*/
 /*       ///
        Long  результатСинхронизацииЗапущеннойВМетодеPAuse=  new CONTROLLER(getActivity()).МетодЗапускаСинхронизацииПередСозданеимНовгоСообщенияДляЧата();
        ///

        ////
        Log.d(this.getClass().getName(), " 1. результатСинхронизацииЗапущеннойВМетодеPAuse ЧАТ  "+ результатСинхронизацииЗапущеннойВМетодеPAuse);*/

    }








    @Override
    public void onStart() {
        super.onStart();
        try{
            /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
            //


            /////
            // Inflate the layout for this fragment





            /*       ((Activity)getActivity()).getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED);*/




















            // TODO: 15.07.2021    ////////////////////////////////МОДЕЛЬ MVC ////////////////////////////////////////////////////////////////////////////////////////////////


            new Fragment_Writer_Read_ЧитатьПисатьЧата. MODEL(getActivity()).МетодПолучениеДанныхдляФрагментаЧитатьиПисатьЧат();

            new Fragment_Writer_Read_ЧитатьПисатьЧата.VIEW(getActivity());


            new Fragment_Writer_Read_ЧитатьПисатьЧата. CONTROLLER(getActivity());
            //

        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
             // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            ///


        }
    }























    // TODO: 18.06.2021  класс вью
    private class VIEW {

        public VIEW(Activity  activity) {


            try{

                //   RequestFuture<JSONObject> requestFuture=RequestFuture.newFuture();
                HttpResponse httpResponse;
                // JsonObjectRequest myReq = new JsonObjectRequest(Request.Method.POST, "ss", jsonObj, requestFuture, requestFuture);





                /////

                Log.d(this.getClass().getName(), "  VIEW   " );

                if (КурсорДанныеДлязаписиичтнияЧата!=null) {
                    ///
                    if (КурсорДанныеДлязаписиичтнияЧата.getCount()>0) {
                        Log.d(this.getClass().getName(), "  КурсорДанныеДлязаписиичтнияЧата   "  + КурсорДанныеДлязаписиичтнияЧата.getCount());

                        // TODO: 01.07.2021  МЕТОД ЗАГРУЖЕТ ДАННЫЕ НА ФРАГМЕНТ ЧАТА ЧИТАТЬ И ПИСАТЬ ПРИ НАЛИЧИИ ИХ В КУРСОРЕ
                        МетодЗагрузкиданныхНаФрагментКогдаЕстьДанные();


                        // TODO: 05.07.2021 КОД КОТОРЫЙ ЗАПИСЫВАЕМ 1 И ПОКАЗЫВАЕТ ЧТО АТ ПРОЧИТАН И НЕ НАДО ЕГО ВЫДЕЛЯТЬ ЖИРНЫМ ЦВЕТОМ



                        ////////
                    }else{

                        // TODO: 01.07.2021  МЕТОД НЕ ЗАГРУЖАЕТ НА ФРАГМЕНТ ПОТОМУ ЧТО В КУРСОРРЕ НЕТ ДАННЫХ  ПОЛЬЗОТЕЛЮ МЫ ПРОСТОПОКАЗЫВЕМ СООБШЩЕНИЕ ЧТО НЕТ СООБЩЕНИЙ ПОКА
                        МетодЗагрузкиданныхНаФрагментКогдаНетДанных();

                        Log.d(this.getClass().getName(), "  нет данных для заргузки КурсорДанныеДлязаписиичтнияЧата   "  + КурсорДанныеДлязаписиичтнияЧата.getCount());


                    }
                }

                Log.d(this.getClass().getName(), "  МетодЗагрузкиданныхНаФрагментКогдаНетДанных   " );


                ///
                ////


            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }















































        // TODO: 01.07.2021  метод загружаем на фрагмент данные когда в курсоре есть данные

        private void МетодЗагрузкиданныхНаФрагментКогдаЕстьДанные() throws ExecutionException, InterruptedException {
            // КурсорДанныеДлязаписиичтнияЧата
            //
            SimpleCursorAdapter АдаптерДляЗаписиЧтенияЧата=null;

            ////
            try{

                        ///
                        АдаптерДляЗаписиЧтенияЧата = new SimpleCursorAdapter(getContext(), R.layout.simple_for_chats_read_write,КурсорДанныеДлязаписиичтнияЧата,
                                new String[]{"user_update", "date_update"},
                                new int[]{android.R.id.text1, android.R.id.text2},0);



                // TODO: 05.07.2021 set FIO


                if (ПолученыйФИОIDДляЧата !=null && ПолученыйФИОIDДляЧата.length()>0) {
                    ///
                    textViewФрагментЧитатьПисатьДляЧата.setText(ПолученыйФИОIDДляЧата);

                    //


                    // TODO: 06.07.2021 после как мы зашли в чат в строчку конткетную делаем его ка прочитанный не жирный




                    //   new CONTROLLER(getActivity()).     МетодЗаписиСтатусаНеЖиныйПослеПросмотраЗаписиВЧате(String.valueOf(ПолученыйIDДляЧата),"user_update");



                } else {
                    ///
                    textViewФрагментЧитатьПисатьДляЧата.setText("ЧАТ");
                }


                //
                SimpleCursorAdapter.ViewBinder БиндингДляСообщенийЧата = new SimpleCursorAdapter.ViewBinder() {
                    @Override
                    public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
                        // TODO: 22.06.2021 выравниваем тексвид




                        //  ((TextView) view).setPadding(200,0,0,0);


                        ////
                        if (cursor.getCount()>0) {
                            ///


                            ///
                            switch ( view.getId()){

                                case android.R.id.text1:
                                    ///////
                                    Log.d(this.getClass().getName(), " ClassActitytyClassActityty  view.getId() " + view.getId());
                                    //return true;
                                    ((TextView) view).setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);

                                    // TODO: 29.06.2021 сами сообщения для с выбранным сотрудником


                                    int ИндексТелоСообщенийВсехСВыбраннымСотрудником = cursor.getColumnIndex("message");


                                    // TODO: 29.04.2021


                                    /////////////////
                                    String ПолученноеТелоСообщения = cursor.getString(ИндексТелоСообщенийВсехСВыбраннымСотрудником);


                                    Log.d(this.getClass().getName(), " метод посика уже существующего сотрудника в базе андройжа ПолученныйФИО"
                                            + ПолученноеТелоСообщения);


                                    // view.setTag(String.valueOf(ПолученныйUUID));
                                    // TODO: 29.04.2021 Вписываем UUID для конкретного сотрудника




                                    // TODO: 06.07.2021 данные выгружем на читать писать сообщения

                                    ((TextView) view).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
                                    ///
                                    // ((TextView) view).setBackgroundResource(R.drawable.style_for_chat);
                                    //
                                    ((TextView) view).setPadding(0,40,30,40);


                                    // TODO: 29.04.2021 ПрисваемваемКАЖДОМУ СОТРУДНИКУ ID
                                    if (ПолученноеТелоСообщения != null ) {
                                        ////
                                        ((TextView) view).setText("    " + ПолученноеТелоСообщения);
                                    }else{

                                        ((TextView) view).setText("    " + "пустое сообщение");

                                    }




                                    ////////

                                    ((TextView) view).getLayoutParams().height= ViewGroup.LayoutParams.WRAP_CONTENT;
                                    /////

                                    ////////

                                    ((TextView) view).getLayoutParams().width= ViewGroup.LayoutParams.MATCH_PARENT;





                                    // TODO: 30.06.2021 форматирование кто написал
                                    int ИндексКтоНаписалСообщениеСотрудником = cursor.getColumnIndex("user_update");

                                    // TODO: 29.04.2021
                                    /////////////////
                                    int ПолученноеКтоНаписал = cursor.getInt(ИндексКтоНаписалСообщениеСотрудником);

/*

                                ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                                ((TextView) parent.getChildAt(0)).setPaintFlags( ((TextView) parent.getChildAt(0)).getPaintFlags() | Paint.FAKE_BOLD_TEXT_FLAG);
                                ((TextView) parent.getChildAt(0)).setBackgroundResource(R.drawable.textlines_tabel);
                                ((TextView) parent.getChildAt(0)).setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
                                ((TextView) parent.getChildAt(0)).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
*/

                                    // TODO: 30.06.2021  выделять жирным или нет в записимости прочитан или нет

                                    Cursor Курсор_ВычисляемПУбличныйID=null;

                                    // TODO: 05.07.2021  получаем публичный ID
                                    int ПубличныйID=0;





                                    // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                                    ///
                      Class_GRUD_SQL_Operations         class_grud_sql_operationsЗагрузкиданныхНаФрагментКогдаЕстьДанныеТретьеЧасть=new Class_GRUD_SQL_Operations(getActivity());

                                    ///
                                    class_grud_sql_operationsЗагрузкиданныхНаФрагментКогдаЕстьДанныеТретьеЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","SuccessLogin");
                                    ///////
                                    class_grud_sql_operationsЗагрузкиданныхНаФрагментКогдаЕстьДанныеТретьеЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","id");
                                    //
            /*        class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","uuid=?    AND status_send !=? AND month_tabels=? AND  year_tabels =? AND fio IS NOT NULL ");
                    ///"_id > ?   AND _id< ?"
                    //////
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",finalПолученныйUUID);
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......
*/
                                    ////TODO другие поля

                                    ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
                                    ////
                                    //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
                                    ////
                                  //  class_grud_sql_operationsПолучениеИмяСистемы. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
                                    ////
                                    class_grud_sql_operationsЗагрузкиданныхНаФрагментКогдаЕстьДанныеТретьеЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                                    ////

                                    // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

                                    Курсор_ВычисляемПУбличныйID=null;

                                    /////
                                    try {
                                        ///
                                        Курсор_ВычисляемПУбличныйID= (SQLiteCursor) class_grud_sql_operationsЗагрузкиданныхНаФрагментКогдаЕстьДанныеТретьеЧасть.
                                                new GetData(getActivity()).getdata(class_grud_sql_operationsЗагрузкиданныхНаФрагментКогдаЕстьДанныеТретьеЧасть.
                                                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                                                class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков
                                                ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());
                                   /////


                                        Log.d(this.getClass().getName(), "GetData "  +Курсор_ВычисляемПУбличныйID);

                                        ///поймать ошибку
                                    } catch (Exception e) {
                                        //  Block of code to handle errors
                                        e.printStackTrace();
                                        ///метод запись ошибок в таблицу
                                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                        new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                        ///////
                                    }


/*

                                    // TODO: 09.09.2021  __________old

                                        Курсор_ВычисляемПУбличныйID=new MODEL_synchronized(getContext()).КурсорУниверсальныйБазыДанных("SELECT id FROM SuccessLogin LIMIT 1 ");
*/



                                    /////TODO resultat
                                    if(Курсор_ВычисляемПУбличныйID.getCount()>0){
                                        //////////
                                        Курсор_ВычисляемПУбличныйID.moveToFirst();
                                        //////////////
                                        ПубличныйIDДляФрагмента=Курсор_ВычисляемПУбличныйID.getInt(0);
                                        //////

                                        //
                                        Log.d(this.getClass().getName(), " ПолученноеКтоНаписал "+ПолученноеКтоНаписал+ " ПубличныйIDДляФрагмента " +ПубличныйIDДляФрагмента);

                                    }




                                    //
                                    if(ПолученноеКтоНаписал==ПубличныйIDДляФрагмента){
                                        /////
                              /*   ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);
                                   ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.NORMAL);*/
                                        ///
                                        ((TextView) view).setBackgroundResource(R.drawable.style_for_chat);
                                        // TODO: 06.07.2021 определяем прочитано текущее собщенеи или нет пока




                                        ((TextView) view).setGravity(Gravity.CENTER_VERTICAL |  Gravity.RIGHT);

                                        Log.d(this.getClass().getName(), " метод посика уже существующего сотрудника в базе андройжа ПолученныйФИО"
                                                + ПолученноеТелоСообщения);

                                        Drawable icon = null;
                                        icon = getResources().getDrawable(R.drawable.icon_dsu1_for_read_write_chats);
                                        icon.setBounds(0, 0, 40, 40);
                                        //
                                        /*    ((TextView) view).setCompoundDrawables(null, null, icon, null);*/





                                    } else {

                                        //
                                        //  ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.NORMAL);

                                        ///////
                                        ((TextView) view).setGravity(Gravity.CENTER_VERTICAL |  Gravity.LEFT);
                                        ///
                                /*   Drawable icon = null;
                                   icon = getResources().getDrawable(R.drawable.icon_dsu1_for__wifi);
                                   icon.setBounds(0, 0, 50, 50);
                                   //
                                   ((TextView) view).setCompoundDrawables(null, null, null, null);*/


                                        // TODO: 30.06.2021 форматирование кто написал
                                        int ИндексUUIDЧата = cursor.getColumnIndex("chat_uuid");

                                        // TODO: 29.04.2021
                                        /////////////////
                                        Long UUIDЧатаКтоНАписал = cursor.getLong(ИндексUUIDЧата);


                                        ((TextView) view).setTag(UUIDЧатаКтоНАписал);


                                        ///
                                        ((TextView) view).setBackgroundResource(R.drawable.style_for_chat_alien);












                                        // TODO: 09.09.2021  получение данных

                                        SQLiteCursor  КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет=null;


                                        Log.d(this.getClass().getName(), "  MODEL  ");


                                        // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                                        ///
                                   Class_GRUD_SQL_Operations    class_grud_sql_operationsДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНетЧетвертаяЧасть=new Class_GRUD_SQL_Operations(getActivity());

                                        ///
                                        class_grud_sql_operationsДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНетЧетвертаяЧасть.
                                                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","viewchat");
                                        ///////
                                        class_grud_sql_operationsДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНетЧетвертаяЧасть.
                                                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","status_write");
                                        //
                                        class_grud_sql_operationsДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНетЧетвертаяЧасть.
                                                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","chat_uuid=? ");
                    ///"_id > ?   AND _id< ?"
                    //////
           /*         class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",UUIDЧатаКтоНАписал);
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......
*/
                                        ////TODO другие поля

                                        ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
                                        ////
                                        //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
                                        ////
                                       // class_grud_sql_operationsПолучениеИмяСистемы. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
                                        ////
                                        class_grud_sql_operationsДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНетЧетвертаяЧасть.
                                                concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                                        ////

                                        // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ
                                        КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет=null;



                                        try {
                                        //////


                                            КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет= (SQLiteCursor)  class_grud_sql_operationsДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНетЧетвертаяЧасть.
                                                    new GetData(getActivity()).getdata(class_grud_sql_operationsДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНетЧетвертаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                                                    class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков
                                                    ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());


                                        Log.d(this.getClass().getName(), "GetData "  +КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет);


                           /*             // TODO: 09.09.2021 _____old

                                            КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет=  new MODEL(getActivity()).
                                                    МетодПолучениеДанныхДляФрагментаСообщенияЧата("SELECT status_write FROM viewchat  WHERE chat_uuid  IN ("
                                                            + UUIDЧатаКтоНАписал + " ) LIMIT 1 ");//ORDER BY date_update DESC
                                            /////*/
                                        ///поймать ошибку
                                    } catch (Exception e) {
                                    //  Block of code to handle errors
                                    e.printStackTrace();
                                    ///метод запись ошибок в таблицу
                                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    ///////
                                }


                                        ///
                                        // TODO: 29.04.2021
                                        int ПолученноеСтатусЖирныйИлИНЕТПрочатаннйИЛИЕНТ =0;
                                        //////


                                        // TODO: 09.09.2021 получаемыйц результат
                                        if (КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет.getCount()>0){
                                            //
                                            КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет.moveToFirst();

                                            /////////////////
                                            // TODO: 30.06.2021 форматирование кто написал
                                            int ИндексСтатусАЖирные = КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет.getColumnIndex("status_write");
                                            ///////

                                            ПолученноеСтатусЖирныйИлИНЕТПрочатаннйИЛИЕНТ = КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет.getInt(ИндексСтатусАЖирные);

                                            Log.d(this.getClass().getName(), " ПолученноеСтатусЖирныйИлИНЕТПрочатаннйИЛИЕНТ " +ПолученноеСтатусЖирныйИлИНЕТПрочатаннйИЛИЕНТ
                                                    + " ИндексКтоПроситанныйИлНЕТ " +ИндексСтатусАЖирные);
                                        }
                                        КурсорДанныеДлязаписиичтнияЧатаИщеммСтатусЖирныйИлиНет.close();




                                        // TODO: 16.07.2021

                                        if (ПолученноеСтатусЖирныйИлИНЕТПрочатаннйИЛИЕНТ==0) {
                                            ////
                                            ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);





                                            // TODO: 13.07.2021  важный код отмечаем сообзения что они уже прочитаны и меняе СТАТУС ПРОЧЬТЕНИЯ НА 1


                                            Integer РезультатВставкиФлагаЖирным=
                                                    new CONTROLLER(getActivity()).     МетодЗаписиСтатусаНеЖиныйПослеПросмотраЗаписиВЧате(String.valueOf(UUIDЧатаКтоНАписал),"chat_uuid");

                                            //

                                            Log.d(this.getClass().getName(), " onItemClick MyWork_Update_ОбновлениеПО СЛУЖБА  " + РезультатВставкиФлагаЖирным);





                                        }else {
                                            //
                                            //
                                            ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.NORMAL);
                                        }

                                        Log.d(this.getClass().getName(), " метод посика уже существующего сотрудника в базе андройжа ПолученныйФИО"
                                                + ПолученноеТелоСообщения);
                                    }







/*

                                        // TODO: 13.07.2021  важный код отмечаем сообзения что они уже прочитаны и меняе СТАТУС ПРОЧЬТЕНИЯ НА 1




                                        new CONTROLLER(getActivity()).     МетодЗаписиСтатусаНеЖиныйПослеПросмотраЗаписиВЧате(String.valueOf(UUIDЧатаКтоНАписал),"chat_uuid");

*/






                                    return true;






                                // TODO: 29.06.2021


                                case android.R.id.text2:
                                    ///////
                                    Log.d(this.getClass().getName(), " ClassActitytyClassActityty  view.getId() " + view.getId());


                                    //
                                    // ((TextView) view).setPadding(100,0,0,0);
                                    //   ((TextView) view).setTextColor(Color.parseColor("#F0FFFF"));//olor.parseColor("#00BBC1")

                                    ///  ((TextView) view).setBackgroundColor(Color.parseColor("#F5FFFA"));

                                    // TODO: 30.06.2021  дата сообщения
                                    int ИндексДатаСообщенийВсехСВыбраннымСотрудником = cursor.getColumnIndex("date_update");


                                    // TODO: 29.04.2021


                                    /////////////////даты
                                    String ПолученноеДатыСообщенияСообщения = cursor.getString(ИндексДатаСообщенийВсехСВыбраннымСотрудником);


                                    // TODO: 28.06.2021 даты обработка
                                    // Date date= Calendar.getInstance().getTime();
                        /*tyle Locale.US Locale.France
                        SHORT 6/30/09 30/06/09
                        MEDIUM Jun 30, 2009 30 juin 2009
                        LONG June 30, 2009 30 juin 2009
                        FULL Tuesday, June 30, 2009 mardi 30 juin 2009*/

                                    SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", new Locale("ru"));
                                    Date date = null;
                                    try {
                                        date = dateFormat.parse(ПолученноеДатыСообщенияСообщения);
                                    } catch (ParseException e) {
                                        //  e.printStackTrace();

                                        dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new Locale("ru"));

                                        /////////
                                        try {
                                            date = dateFormat.parse(ПолученноеДатыСообщенияСообщения);
                                        } catch (ParseException parseException) {
                                            // parseException.printStackTrace();
                                        }


                                    }

                                    Log.d(this.getClass().getName(), "  date  "+date.toString());
                                    /////////



                                    SimpleDateFormat simpleDateFormat= new SimpleDateFormat("dd MMMM yyyy HH:mm", new Locale("ru"));
                                    //
                                    simpleDateFormat.applyPattern("dd MMMM yyyy HH:mm");//dd-MM-yyyy

                                    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Moscow"));


                                    String ФиналДата= null;
                                    try {
                                        ФиналДата = simpleDateFormat.format(date);
                                    } catch (Exception e) {
                                        // e.printStackTrace();
                                        // TODO: 05.08.2021


                                    }

                                    Log.d(this.getClass().getName(), "  ФиналДата  "+ФиналДата);


                                    // TODO: 18.08.2021 Определяем от кого было написано сообещгия

                                    int ИндексКемБылоНаписаноСообщение = cursor.getColumnIndex("user_update");


                                    // TODO: 29.04.2021
                                    String ФиоКтоНАписалСообщение=new String();

                                    /////////////////даты
                                    Integer ПолученноеФИОКемБылоНаписаноСообщение = cursor.getInt(ИндексКемБылоНаписаноСообщение);
                                    //


                                    // TODO: 09.09.2021  ПОЛУЧЕНИЕ ДАННЫХ
                                    // TODO: 09.09.2021  ПОЛУЧЕНИЕ ДАННЫХ
                                    // TODO: 09.09.2021  ПОЛУЧЕНИЕ ДАННЫХ

                                    // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                                    ///
                                    Class_GRUD_SQL_Operations          class_grud_sql_operationsКурсорсоЗначениемФИОПятаяЧасть=new Class_GRUD_SQL_Operations(getActivity());

                                    ///
                                    class_grud_sql_operationsКурсорсоЗначениемФИОПятаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("НазваниеОбрабоатываемойТаблицы","fio");
                                    ///////
                                    class_grud_sql_operationsКурсорсоЗначениемФИОПятаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СтолбцыОбработки","name");
                                    //
                                    class_grud_sql_operationsКурсорсоЗначениемФИОПятаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ФорматПосика","user_update = ? ");

                                    class_grud_sql_operationsКурсорсоЗначениемФИОПятаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",ПолученноеФИОКемБылоНаписаноСообщение);



                    ///"_id > ?   AND _id< ?"
                    //////
   /*                                 class_grud_sql_operationsКурсорсоЗначениемФИО. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска1",ПолученноеФИОКемБылоНаписаноСообщение);
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска2","Удаленная");
                    ///
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска3",МЕсяцДляКурсораТабелей);
                    //
                    class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеПоиска4",ГодДляКурсораТабелей);////УсловиеПоискаv4,........УсловиеПоискаv5 .......

                                    ////TODO другие поля

                                    ///classGrudSqlOperations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("ПоляГрупировки",null);
                                    ////
                                    //class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеГрупировки",null);
                                    ////
                                    class_grud_sql_operationsПолучениеИмяСистемы. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеСортировки","date_update");
                                    ////*/
                                    /// class_grud_sql_operations. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("УсловиеЛимита","1");
                                    ////
                                    SQLiteCursor Курсор_соЗначениемФИО=null;

                                    // TODO: 27.08.2021  ПОЛУЧЕНИЕ ДАННЫХ ОТ КЛАССА GRUD-ОПЕРАЦИИ

                                    try {
                                        Курсор_соЗначениемФИО= (SQLiteCursor)  class_grud_sql_operationsКурсорсоЗначениемФИОПятаяЧасть.
                                                new GetData(getActivity()).getdata(class_grud_sql_operationsКурсорсоЗначениемФИОПятаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                                                class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков
                                                ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());
                                        /////

                                        ///поймать ошибку
                                    } catch (Exception e) {
                                        //  Block of code to handle errors
                                        e.printStackTrace();
                                        ///метод запись ошибок в таблицу
                                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                        new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                        ///////
                                    }

                                    Log.d(this.getClass().getName(), "GetData "  +Курсор_соЗначениемФИО);





/*

                                    // TODO: 09.09.2021  _old

                                           КтоНаписалСообщениеФИО=new    ();
                                    ////
                                       КтоНаписалСообщениеФИО.setTables("fio");
                                    ///


                                           КтоНаписалСообщениеФИО.appendWhere("user_update = ?");

                                    //
                                    SQLiteCursor  Курсор_соЗначениемФИО=null;
                   */
/*  sqLiteCursorКурсорсоЗначениемФИО=
                                       КтоНаписалСообщениеФИО.query(ССылкаНаСозданнуюБазу,new String[]{"*"},"_id",new String[]{String.valueOf(ПолученноеФИОКемБылоНаписаноСообщение)},null,null,null,null);*//*


                                    Курсор_соЗначениемФИО=
                                            (SQLiteCursor)    КтоНаписалСообщениеФИО.query(ССылкаНаСозданнуюБазу,new String[]{"name" }
                                            ,"user_update",new String[]{String.valueOf(ПолученноеФИОКемБылоНаписаноСообщение)},null,null,null);
                                 */
/*  String sqLiteCursorКурсорсоЗначениемФИО=
                                                      КтоНаписалСообщениеФИО.buildQuery(new String[]{"name"},"_id",null,null,null,"1");

                                       КтоНаписалСообщениеФИО.appendWhere(String.valueOf(ПолученноеФИОКемБылоНаписаноСообщение));*//*




                                   //

*/



                                    // TODO: 09.09.2021  resultat

                                        if(Курсор_соЗначениемФИО.getCount()>0){
                                            //
                                            Курсор_соЗначениемФИО.moveToFirst();
                                            //
                                            if(!Курсор_соЗначениемФИО.isNull(0)) {

                                                /////
                                                ФиоКтоНАписалСообщение = Курсор_соЗначениемФИО.getString(0);
                                                //

                                                Log.d(this.getClass().getName(), "  ФиоКтоНАписалСообщение  " + ФиоКтоНАписалСообщение);
                                            }

                                        }





                                    ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);
                               /*     ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.NORMAL);

                                    ((TextView) view).setGravity(Gravity.CENTER_VERTICAL );*/

                                    ((TextView) view).setText( ФиналДата +"\n"+
                                            "  ( " +ФиоКтоНАписалСообщение.trim()+" )");///ПолученыйФИОIDДляЧата

                                    //    ((TextView) view).setPadding(250,0,0,0);


                                    // TODO: 30.06.2021 форматирование кто написал
                                    int ИндексКтоНаписалСообщениеСотрудникомДляtext2 = cursor.getColumnIndex("user_update");

                                    // TODO: 29.04.2021
                                    /////////////////
                                    int ПолученноеКтоНаписалДляtext2 = cursor.getInt(ИндексКтоНаписалСообщениеСотрудникомДляtext2);

/*

                                ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                                ((TextView) parent.getChildAt(0)).setPaintFlags( ((TextView) parent.getChildAt(0)).getPaintFlags() | Paint.FAKE_BOLD_TEXT_FLAG);
                                ((TextView) parent.getChildAt(0)).setBackgroundResource(R.drawable.textlines_tabel);
                                ((TextView) parent.getChildAt(0)).setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
                                ((TextView) parent.getChildAt(0)).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
*/

                                    // TODO: 30.06.2021  выделять жирным или нет в записимости прочитан или нет


                                    ////


                                    //
                                    if(ПолученноеКтоНаписалДляtext2==ПубличныйIDДляФрагмента) {
                                        /////
                                        ((TextView) view).setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);

                                        // ((TextView) view).setBackgroundResource(R.drawable.style_for_chat);
                                        ((TextView) view).setBackgroundColor(Color.parseColor("#F5FFFA"));
                                        ((TextView) view).setPadding(0,0,30,0);

                                        ((TextView) view).setTextColor(Color.GRAY);//olor.parseColor("#00BBC1")
                                    }else{
                                        /////
                                        ((TextView) view).setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
                                        ///
                                        ((TextView) view).setPadding(50,0,0,0);

                                        ((TextView) view).setBackgroundColor(Color.parseColor("#F0FFFF"));

                                        /// ((TextView) view).setBackgroundResource(R.drawable.style_for_chat_alien);
                                        ((TextView) view).setTextColor(Color.GRAY);//olor.parseColor("#00BBC1")

                                    }
                                    ///////

                                    return true;


                                // TODO: 29.06.2021 defalut


                                default:

                                    return false;


                            }





                        }else{

                            StringBuffer БуферКогдаНетСообщенийВооюоще=new StringBuffer("* Нет сообщений !!! *");

                            ((TextView) view).setGravity(Gravity.CENTER_VERTICAL |  Gravity.CENTER_HORIZONTAL);

                            ((TextView) view).setBackgroundColor(Color.parseColor("#F5FFFA"));

                            ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);

                            // TODO: 28.06.2021 данный код когда нет вообще данных в курсоре и нет сообдений
                            //     ((TextView) view).setText(БуферКогдаНетСообщенийВооюоще.toString());



                            return false;


                        }

                        /////TODO

                        //////////////////

                        //////////////////

                    }};


                ////
                АдаптерДляЗаписиЧтенияЧата.setViewBinder( БиндингДляСообщенийЧата);
                ///
                ЛистВьюДляСообщенийЧата.setAdapter(АдаптерДляЗаписиЧтенияЧата);

                ////
                ЛистВьюДляСообщенийЧата.deferNotifyDataSetChanged();
                ////
                ЛистВьюДляСообщенийЧата.setSelection(ЛистВьюДляСообщенийЧата.getCount() - 1);

            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }






        /////

        // TODO: 01.07.2021  метод не загружаем даннные потомц что нет данных в курсоре и даем пользователю сообщение

        private void МетодЗагрузкиданныхНаФрагментКогдаНетДанных() throws ExecutionException, InterruptedException {
            // КурсорДанныеДлязаписиичтнияЧата

            try{


                /////



                ///
                ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();
                LinkedHashMap<String, String> map;

// Досье на первого кота
                map = new LinkedHashMap<>();
                map.put("Name", "* Начните Чат  !!! *");
                arrayList.add(map);
                ///


                // TODO: 09.09.2021 АДАПТЕР НЕ БЕЗ КОНЕЧНЫЙ
                // TODO: 09.09.2021 АДАПТЕР НЕ БЕЗ КОНЕЧНЫЙ
                // TODO: 09.09.2021 АДАПТЕР НЕ БЕЗ КОНЕЧНЫЙ


/*                        АдаптерДляЗаписиЧтенияЧатаВнутри = new SimpleCursorAdapter(getContext(), R.layout.simple_for_chats_read_write,КурсорДанныеДлязаписиичтнияЧата,
                                new String[]{"user_update", "date_update"},
                                new int[]{android.R.id.text1, android.R.id.text2},0);*/

                        ////////
                        SimpleAdapter        АдаптерДляЗаписиЧтенияКогдаНетДанных=null;
///
                        АдаптерДляЗаписиЧтенияКогдаНетДанных= new SimpleAdapter(getActivity(), arrayList, R.layout.simple_for_chats_read_write,
                                new String[]{"Name","Name"},
                                new int[]{android.R.id.text1,android.R.id.text2});



                ///


                // TODO: 08.07.2021 Binf view
                //
                SimpleAdapter.ViewBinder БиндингДляСообщенийЧатаКогдаНетДанных = new SimpleAdapter.ViewBinder() {
                    @Override
                    public boolean setViewValue(View view, Object data, String textRepresentation) {
                        //here goes the code
                        Log.d(this.getClass().getName(), " ClassActitytyClassActityty  ");

                        ((TextView) view).setGravity( Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);

                        // TODO: 05.07.2021

                        textViewФрагментЧитатьПисатьДляЧата.setText(ПолученыйФИОIDДляЧата);

                        switch (view.getId()){
                            ////////////
                            case  android.R.id.text1:

                                ///
                                ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);
                                //
                                ((TextView) view).setPadding(0,0,0,500);
                                ////

                                ((TextView) view).setText(data.toString());
                                ////
                                ((TextView) view).setTextColor(Color.parseColor("#00BBC1"));
                                ((TextView) view).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
                                ((TextView) view).setBackgroundColor(Color.parseColor("#F5FFFA"));

                                ////////

                                ((TextView) view).getLayoutParams().height= ViewGroup.LayoutParams.WRAP_CONTENT;
                                /////

                                ////////

                                ((TextView) view).getLayoutParams().width= ViewGroup.LayoutParams.MATCH_PARENT;




                                return true;
                            ///
                            ////////////
                            case  android.R.id.text2:

                                ///
                                ((TextView) view).setTypeface(Typeface.SANS_SERIF,Typeface.BOLD);
                                //
                                ((TextView) view).setPadding(0,0,0,650);
                                ////

                                //   ((TextView) view).setText(data.toString());
                                ////
                                //((TextView) view).setTextColor(Color.parseColor("#00BBC1"));
                                ((TextView) view).setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
                                ((TextView) view).setBackgroundColor(Color.parseColor("#F5FFFA"));

                                ////////

                                ((TextView) view).getLayoutParams().height= 0;
                                /////

                                ////////

                                ((TextView) view).getLayoutParams().width= ViewGroup.LayoutParams.MATCH_PARENT;




                                return true;
                            ///









                            default:
                                //////
                                ////
                                return false;
                        }


                        /////TODO

                        //////////////////

                        //////////////////

                    }};


                ////
                АдаптерДляЗаписиЧтенияКогдаНетДанных.setViewBinder( БиндингДляСообщенийЧатаКогдаНетДанных);
                ///
                ЛистВьюДляСообщенийЧата.setAdapter(АдаптерДляЗаписиЧтенияКогдаНетДанных);

                ////
                ЛистВьюДляСообщенийЧата.setSelection(ЛистВьюДляСообщенийЧата.getCount() - 1);


                Log.d(this.getClass().getName(), "                   ЛистВьюДляСообщенийЧата.setSelection(ЛистВьюДляСообщенийЧата.getCount() - 1); "+ЛистВьюДляСообщенийЧата.getCount());

            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }
    }


// TODO: 01.07.2021 метод когда нет данных в курсоре и отображаем сообщени что сообщений нет в фрагменте















    private class CONTROLLER implements AdapterView.OnItemClickListener  {
        /////
        public CONTROLLER(Activity  activity) {
            try{

                Log.d(this.getClass().getName(), "  CONTROLLER  ");


                // TODO: 30.06.2021 клик
                МетодКликаПоЛистуЧитатьПисать();

// TODO: 30.06.2021  клик по круглой кнопки
                МетодКруглаяКнопкаНаФрагментеЧитатьПисать();

                // TODO: 07.07.2021

                ///ккод кторый работает при изменении в в лсию при скроле
                МетодЗапускаетьсяКогдаНаЛИстВиюПроищходитСкролл();




            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }

        private void МетодЗапускаетьсяКогдаНаЛИстВиюПроищходитСкролл() {

            try{




            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }







        }

        private void МетодКликаПоЛистуЧитатьПисать() {
            ЛистВьюДляСообщенийЧата.setOnItemClickListener(this);
            ///
   /*         viewДляСообщений.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    Log.d(this.getClass().getName(), "  onClick  MyWork_Update_ОбновлениеПО СЛУЖБА  " + viewДляСообщений.getId());
                }
            });*/
            //  Курсор_ДляЗагрузкиСотрудников.close();
        }

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            try{
                Log.d(this.getClass().getName(), " onItemClick MyWork_Update_ОбновлениеПО СЛУЖБА  " + view.getId());


                /////
                Vibrator v2 = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v2.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    //deprecated in API 26
                    v2.vibrate(150);
                }



///
                Object ХэшДанныеВВидеОбьекта= parent.getItemAtPosition(position);



                ///
                TextView textView=  view.findViewById(android.R.id.text1);

                ///
                ((TextView) textView).setTypeface(Typeface.SANS_SERIF,Typeface.NORMAL);

                Long ПолученныйUUIDЗаписи=Long.parseLong(textView.getTag().toString());




       Integer РезультатВставкиФлагаЖирным=
               new CONTROLLER(getActivity()).     МетодЗаписиСтатусаНеЖиныйПослеПросмотраЗаписиВЧате(String.valueOf(ПолученныйUUIDЗаписи),"chat_uuid");

                //

                Log.d(this.getClass().getName(), " onItemClick MyWork_Update_ОбновлениеПО СЛУЖБА  " + РезультатВставкиФлагаЖирным);



            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }


         void МетодКруглаяКнопкаНаФрагментеЧитатьПисать() {
            try{
                ////
                final Long[] futureрезультатФинальнойСинхрнизации = {0l};
                ////
                ////
                final Long[] futureрезультатФинальнойСинхрнизациихОЛОСТОЙхОД = {0l};


                // TODO: 23.07.2021 код при нажатии на БОЛЬШУЮ КРУГЛУЮ КНОПКУ
                //////////////////////////////
                floatingActionButtonВФагментеReadandWrite.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // TODO: 24.07.2021

                        ПубличныйIDДляФрагмента=0;
                        //



                        ////////////////////
                        Log.d(this.getClass().getName()," Нажатие на кнопку floatingActionButtonВФагментеReadandWrite" );
                        try{
                            Cursor Курсор_ВычисляемПУбличныйID=null;







                            //////конец второго лушателя спинера
                            floatingActionButtonВФагментеReadandWrite.setBackgroundResource(R.drawable.icon_dsu1_singlescroll_forfart);  ////@drawable/icon_dsu1_singlescroll_forfart//R.drawable.icon_dsu1_fragment_read_write_down   //    R.drawable.icon_dsu1_singlescroll_forfart


                  /*          Vibrator v2 = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                v2.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                            } else {
                                //deprecated in API 26
                                v2.vibrate(150);
                            }
                            ///*/

                            //  Snackbar.make(v, "Here",Snackbar.LENGTH_LONG).setAction("Action",null).show();


                            Log.d(this.getClass().getName(), "   запуск кнпоки синхрогизации в чате   editTextТелоНаписаногоСообщенияДругимСотрудникам.getText().toString() "
                                    +editTextТелоНаписаногоСообщенияДругимСотрудникам.getText().toString());

                            // TODO: 05.07.2021 ЗАПУСКАЕМ СОЗДАНЕИ НОВОЙ ЗАПИСИ ЕСЛИ ЕСЛИ  ХОТЬ ОДИТ СМВОЛ НАПИСАННЫМ ПОЛЬЗОВАТЕМ


                            /////
                            if (  editTextТелоНаписаногоСообщенияДругимСотрудникам.getText().toString()!=null &&
                                    //////
                                    editTextТелоНаписаногоСообщенияДругимСотрудникам.getText().toString().length()>0) {




                                //TODO ТУТ КОД БУДЕТ ЗАПУСКАТЬСЯ СОЗДАЕНИЕ НОВОГО ИЛИ ДОБАВЛЕНИЕ ДЕЙСТВУЕЮЩЕГО СОТРУДНИКА В ТАБЕЛЬ
                               /* floatingActionButtonВФагментеReadandWrite.setImageResource(R.drawable.icon_dsu1_chat_messgae_sync_up);
                                //
                                floatingActionButtonВФагментеReadandWrite.setImageResource(R.drawable.icon_dsu1_fragment_read_write_down);*/




                                floatingActionButtonВФагментеReadandWrite.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        //
                                        floatingActionButtonВФагментеReadandWrite.setImageResource(R.drawable.icon_dsu1_chat_messgae_sync_up);

                                        ;

                                        ////

                                        floatingActionButtonВФагментеReadandWrite.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                //


                                                floatingActionButtonВФагментеReadandWrite.setImageResource(R.drawable.icon_dsu1_singlescroll_forfart);

                                            }
                                        },1500);



                                    }
                                },500);





                                /////
                                Vibrator v2 = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                                // Vibrate for 500 milliseconds
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    v2.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                                } else {
                                    //deprecated in API 26
                                    v2.vibrate(150);
                                }




                                // TODO: 05.07.2021 клавиатура вниз


                                //
                                InputMethodManager imm = (InputMethodManager) viewДляСообщений.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                                ///
                                imm.hideSoftInputFromWindow(viewДляСообщений.getWindowToken(), 0);


// TODO: 14.07.2021  ЗАПУСКАЕМ ОБРВАБОТКУ СИНХРОНИЗАЦИИ-- СОЗДАНИЕ НОВГО СООБЩЕНИЯ -- ФИНАЛЬНОЙ СИНХРОНИЗАЦИИ ПРИМЕНЯЯ  ТРИ КЛАССА ЗАПЕЫХ В ОЧЕРЕДИ
                                //   floatingActionButtonВФагментеReadandWrite.setImageResource(R.drawable.icon_dsu1_singlescroll_forfart);



                                ///////////////TODO   UPDATE МЕТОД ФИНАЛЬНОЙ ФИКСАЦИИ ОБНОВЛЕНИЯ ПОСЛЕ ЦИКЛ FOR
               /*                 //
                                Long     РезультатЗапускаПервойСинхронизации  =new CONTROLLER(getActivity()).МетодЗапускаСинхронизацииПослеСозданеимНовгоСообщенияДляЧата();///ПослеСозданеимНовгоСообщенияДляЧата();

                                Log.d(this.getClass().getName(), "  РезультатЗапускаПервойСинхронизации  "
                                        +   РезультатЗапускаПервойСинхронизации+
                                        " ИндексКоличествоПопытокОтправкиЧата " );*/




                                ///////////////TODO   UPDATE МЕТОД ФИНАЛЬНОЙ ФИКСАЦИИ ОБНОВЛЕНИЯ ПОСЛЕ ЦИКЛ FOR
                                //




                                /////TODO ШАГ СОЗДАНИЕ НОВГО СООБЩЕНИЯ ЧЕРЕЗ ПРОВЕРКУ ЗАПУЩЕНА СЛУЖА ИЛИ НЕТ

                                ///////////////TODO   создание новго сообщенияk









///TODO


// TODO: 10.08.2021 создание новго сообщения



                                Integer      РезультатЗапускаСозданииНовгоСообщения = 0;




                                            try {


                                                РезультатЗапускаСозданииНовгоСообщения = МетодСозданииНовогоСообщениявЧате(v);


                                                Log.d(this.getClass().getName(), " 2 . РезультатЗапускаСозданииНовгоСообщения ЧАТ  " + РезультатЗапускаСозданииНовгоСообщения);

                                                //////
                                            } catch (InterruptedException e) {
                                                e.printStackTrace();
                                                ///метод запись ошибок в таблицу
                                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                                                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                                ///

                                            }



                                    // TODO: 23.08.2021 exit

                                if (РезультатЗапускаСозданииНовгоСообщения>0) {

                                    //
                                    Vibrator v3 = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                                    // Vibrate for 500 milliseconds
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        v3.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                                    } else {
                                        //deprecated in API 26
                                        v3.vibrate(150);
                                    }



                                }





                                // TODO: 11.08.2021 дейстиве заключительно после синхронизации перерисовываем внешний вид чатат
                                        Log.d(this.getClass().getName(), " 2 . МетодПослеВставкиНовгоСообщенияИлиПослеХолостогоХода ЧАТ РезультатЗапускаСозданииНовгоСообщения  " + РезультатЗапускаСозданииНовгоСообщения);


                                if (РезультатЗапускаСозданииНовгоСообщения>0) {

                                    МетодПерегрузкиВнешнегоВидаЧата(РезультатЗапускаСозданииНовгоСообщения);


                                }

                             /*           // TODO: 10.08.2021  временно запускаем сдесь фонофую синхронизацию для чата

                                        //////
                                        if (РезультатЗапускаСозданииНовгоСообщения>0) {
                                            ///
                                            Long                   РезультатЗапускаСинхронизацииЧата = МетодЗапускаСинхронизацииТОлькоДляЧатаПоРАсписанию();

                                            Log.d(this.getClass().getName(), "РезультатЗапускаСинхронизацииЧата   "+РезультатЗапускаСинхронизацииЧата);
                                        }

*/







                                // TODO: 10.08.2021  временно запускаем сдесь фонофую синхронизацию для чата
// TODO: 10.08.2021 создание новго сообщения

                     /*           if (РезультатЗапускаСозданииНовгоСообщения>0) {

                                    Log.d(this.getClass().getName(), "МетодЗапускаСинхронизацииТОлькоДляЧатаПоРАсписанию   "+
                                            "  class_grud_sql_operationsДляФрагмента.getМенеджерПотоков().isShutdown() "
                                            +     МенеджерПОтокПоРАсписанию.isShutdown()+ " РезультатЗапускаСозданииНовгоСообщения " +РезультатЗапускаСозданииНовгоСообщения);
                                    //////
                                    ////
                                    Long                   РезультатЗапускаСинхронизацииЧата =
                                            МетодЗапускаСинхронизацииАсинхронныйЗапскПослеСозданиесообщения(v,"Запускаем Только Отправления Синхронизации");//"Запускаем Только Отправления Синхронизации"

                                    Log.d(this.getClass().getName(), " СЛУЖБА ЗАПУСК С КНОПКИ ЧАТА  РезультатЗапускаСинхронизацииЧата   "+РезультатЗапускаСинхронизацииЧата);

                                    System.out.println("РезультатЗапускаСинхронизацииЧата   "  +РезультатЗапускаСинхронизацииЧата  + " ВРЕМЯ ОПЕРАЦИИ СИНХРОНИЗАЦИИ ЧТА ПО РАСПИСАНИЮ СЛУЖБА" + new Date());

// TODO: 10.08.2021 после создание сообдения метод визуализации
                                    // TODO: 14.07.2021  ХОЛОСТОЙ ХОД     // TODO: 14.07.2021  ХОЛОСТОЙ ХОД     // TODO: 14.07.2021  ХОЛОСТОЙ ХОД     // TODO: 14.07.2021  ХОЛОСТОЙ ХОД     // TODO: 14.07.2021  ХОЛОСТОЙ ХОД
                                }


                                Log.d(this.getClass().getName(), "   запуск кнпоки синхрогизации в чате");*/






















                                // TODO: 30.09.2021  когда нет новго сообщение и мы просто получаем данные      // TODO: 30.09.2021  когда нет новго сообщение и мы просто получаем данные



                                // TODO: 30.09.2021  когда нет новго сообщение и мы просто получаем данные      // TODO: 30.09.2021  когда нет новго сообщение и мы просто получаем данные


                                // TODO: 30.09.2021  когда нет новго сообщение и мы просто получаем данные      // TODO: 30.09.2021  когда нет новго сообщение и мы просто получаем данные









                                ///todo когда данных не для встаки тогда запускаем синхронизация для чата


                            }else{

                                ///todo когда данных не для встаки тогда запускаем синхронизация для чата

                                floatingActionButtonВФагментеReadandWrite.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        //
                                        floatingActionButtonВФагментеReadandWrite.setImageResource(R.drawable.icon_dsu1_chat_messgae_sync_up);

                                        ;

                                        ////

                                        floatingActionButtonВФагментеReadandWrite.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                //


                                                floatingActionButtonВФагментеReadandWrite.setImageResource(R.drawable.icon_dsu1_singlescroll_forfart);

                                            }
                                        },1500);



                                    }
                                },500);
// TODO: 26.07.2021  холостой ход





                                /////
                                Vibrator v2 = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                                // Vibrate for 500 milliseconds
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    v2.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                                } else {
                                    //deprecated in API 26
                                    v2.vibrate(150);
                                }





                                PUBLIC_CONTENT public_contentЗапускаемСинхронизациюБезПолученияДанныхСкругллойКнопкой = new PUBLIC_CONTENT(getActivity());
                                /////

                                // TODO: 30.09.2021  ЗАПУСКАЕМ МЕНЕДЖЕР ПОТОКО ДЯЛ СИНХРОНИЗАЦИИ ЧАТА ПОСЛЕ СОЗДАНИЯ НОВОГО СООБЩЕНИЯ

                                class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков.submit(()-> {



                                    Integer      РезультатЗапускаСинхронизацииЧатаОтправка =0;
                                    //
                                    ////
                                    Integer     РезультатЗапускаСинхронизацииЧатаПолучение =0;
                                   try{

                                       // TODO: 11.10.2021

                                Log.d(this.getClass().getName(), "МетодЗапускаСинхронизацииТОлькоДляЧатаПоРАсписанию   "
                                        + "  class_grud_sql_operationsДляФрагмента.getМенеджерПотоков().isShutdown() "
                                        +     public_contentМенеджерПотоковПоРасписанию. МенеджерПОтокПоРАсписанию.isShutdown());
                                


                                       // TODO: 06.10.2021  проверяем если подключение


                              boolean         РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции =
                                               new Class_Connections_Server(getContext()).МетодПингаСервераРаботаетИлиНет(getContext());





                                    //TODO ФУТУРЕ ЗАВЕРШАЕМ
                                    Log.d(this.getClass().getName(), "  РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции " + РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции);

                                       // TODO: 16.07.2021

                                       if (РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции == true) {

                                           ////


                                           РезультатЗапускаСинхронизацииЧатаОтправка = МетодЗапускаСинхронизацииТОлькоДляЧатаПоРАсписанию("Запускаем Только Отправления Синхронизации");//Запускаем Только Отправления Синхронизации


                                           Log.d(this.getClass().getName(), "РезультатЗапускаСинхронизацииЧатаОтправка   " + РезультатЗапускаСинхронизацииЧатаОтправка);

                                           // TODO: 19.08.2021 получение дейстике второе

                                           Integer finalРезультатЗапускаСинхронизацииЧатаОтправка = РезультатЗапускаСинхронизацииЧатаОтправка;
                                           //////////
                                           getActivity().runOnUiThread(new Runnable() {
                                               @Override
                                               public void run() {
// TODO: 11.10.2021


                                                   if (finalРезультатЗапускаСинхронизацииЧатаОтправка > 0) {


                                                       //
                                                       editTextТелоНаписаногоСообщенияДругимСотрудникам.setHintTextColor(Color.GRAY);
                                                       ///////
                                                       //
                                                       editTextТелоНаписаногоСообщенияДругимСотрудникам.setHint("Получение/Отправка  ►►►");
                                                       //

                                                   }


                                               }
                                           });

                                       }


                             /*           ////
                                        РезультатЗапускаСинхронизацииЧатаПолучение = МетодЗапускаСинхронизацииТОлькоДляЧатаПоРАсписанию("Запускаем Только Получения Синхронизации");


                                        Log.d(this.getClass().getName(), "РезультатЗапускаСинхронизацииЧатаПолучение   "+РезультатЗапускаСинхронизацииЧатаПолучение);*/

                                    // TODO: 30.09.2021 exit

                                ///////////////TODO   UPDATE МЕТОД ФИНАЛЬНОЙ ФИКСАЦИИ ОБНОВЛЕНИЯ ПОСЛЕ ЦИКЛ FOR
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    ///метод запись ошибок в таблицу
                                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    // TODO: 01.09.2021 метод вызова
                                    new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                                            this.getClass().getName(),
                                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    ///
                                }finally {

                                       /////

                                       class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков.poll();




                                       getActivity().runOnUiThread(new Runnable() {
                                           @Override
                                           public void run() {
                                               //
                                               editTextТелоНаписаногоСообщенияДругимСотрудникам.setHintTextColor(Color.parseColor("#00ACC1"));
                                               //

                                               editTextТелоНаписаногоСообщенияДругимСотрудникам.setHint("Напишите сообщение !!!");


                                               // TODO: 11.08.2021 дейстиве заключительно после синхронизации перерисовываем внешний вид чатат
                                               Log.w(this.getClass().getName(), "  СЛУЖБА ЧАТА ПО ПОСЛЕ НАЖАТИЯ НА КНОПКУ КРУГЛУЮ КОНЕЦ ПОСЛЕ КАК ОДИН КРУГ ОТРАБОТАЛ " +
                                                       "");



                                           }
                                       });



                                   }

                                    Log.d(this.getClass().getName(), "   РезультатЗапускаСинхронизацииЧатаПолучение+РезультатЗапускаСинхронизацииЧатаОтправка  "
                                            +РезультатЗапускаСинхронизацииЧатаПолучение+РезультатЗапускаСинхронизацииЧатаОтправка);


                                    return РезультатЗапускаСинхронизацииЧатаПолучение+РезультатЗапускаСинхронизацииЧатаОтправка;
                                });


                                // TODO: 30.09.2021  конец IF
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                             // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                            ///
                        }



                        // TODO: 24.07.2021 end click

                    }
                    
                    // TODO: 23.07.2021 синхронизация для холостого хода
                });

            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }


        
        
        
        
        
        


































        
        
        
        // TODO: 14.07.2021

        protected   void МетодПослеВставкиНовгоСообщенияИлиПослеХолостогоХода(View v,Long РезультатЗапускаХолостогоХода,String ФлагОтправитьПолучить) {
            try{

                /////


                new Fragment_Writer_Read_ЧитатьПисатьЧата. MODEL(getActivity()).МетодПолучениеДанныхдляФрагментаЧитатьиПисатьЧат();
                ////


                АдаптерДляЗаписиЧтенияЧата.changeCursor(КурсорДанныеДлязаписиичтнияЧата);

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        

                        if (АдаптерДляЗаписиЧтенияЧата!=null) {
                            ///////
                            АдаптерДляЗаписиЧтенияЧата.changeCursor(КурсорДанныеДлязаписиичтнияЧата);

                        }

                        //
                        if (АдаптерДляЗаписиЧтенияЧата!=null) {
                            //////////
                            АдаптерДляЗаписиЧтенияЧата.notifyDataSetChanged();
                            //
                            АдаптерДляЗаписиЧтенияЧата.notifyDataSetInvalidated();
                        }

                        ////
                        //   АдаптерДляЗаписиЧтенияЧата.changeCursor(КурсорДанныеДлязаписиичтнияЧата);

                        ///
                        ///
                        ЛистВьюДляСообщенийЧата.deferNotifyDataSetChanged();

                        ///

                        ЛистВьюДляСообщенийЧата.setItemChecked(ЛистВьюДляСообщенийЧата.getCheckedItemPosition() + 1, true);
                        ///
                        ЛистВьюДляСообщенийЧата.setSelection(ЛистВьюДляСообщенийЧата.getCount() - 1);

                        ЛистВьюДляСообщенийЧата.invalidateViews();


                        // TODO: 30.09.2021
                        if (РезультатЗапускаХолостогоХода>=1) {

                            Vibrator v2 = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                            // Vibrate for 500 milliseconds
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                v2.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
                            } else {
                                //deprecated in API 26
                                v2.vibrate(100);
                            }
                        }

                        ///todo когда данных не для встаки тогда запускаем синхронизация для чата
/*
                                }
                            },500);*/

                        floatingActionButtonВФагментеReadandWrite.setImageResource(R.drawable.icon_dsu1_chat_messgae_sync_up);


                        ///
                        ЛистВьюДляСообщенийЧата.setSelection(ЛистВьюДляСообщенийЧата.getCount() - 1);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////////
                //
                //  Snackbar.make(v, ""+ФлагОтправитьПолучить+" (" + РезультатЗапускаХолостогоХода +") сообщений!!!",Snackbar.LENGTH_LONG).setAction("Action",null).show();

            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
        }











        // TODO: 29.07.2021
        private boolean isMyServiceRunning(Class<?> serviceClass) {
            ActivityManager manager = (ActivityManager) getActivity().getSystemService(Context.ACTIVITY_SERVICE);
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
            return false;
        }










        // TODO: 05.07.2021 код запуска метода для данных

        protected Integer МетодЗапускСинхронизацииДляЧатаПоРАсписанию(View v,String ФлагКакуюЧастьСинхронизацииЗапускаем) {
            //
            Integer  РезультатСинхронизацииДОСозданиеЯСообщения=0;


            boolean РезультатЕслиСвязьСерверомДСУ=false;

            try{

                Log.d(this.getClass().getName(), "  МетодЗаписиНовгоСообщенияСамимКлиентом");

                Log.d(this.getClass().getName(), "  МетодЗаписиНовгоСообщенияСамимКлиентом");


                /////TODO ВТОРОЙ ШАГ СИНХРОНИЗАЦИИ ПОЛУЧАЕМ СПИСОК ТАБЛИЦ КОТОРЫЕ НУЖНО  СИНХРОНИЗИРОВАТЬ 100% процентов , И ПРОВЕРМЯЕМ ЕСЛИ СВЯЗЬ С ИНТЕНТОМ


                /////TODO ВТОРОЙ ШАГ СИНХРОНИЗАЦИИ ПОЛУЧАЕМ СПИСОК ТАБЛИЦ КОТОРЫЕ НУЖНО  СИНХРОНИЗИРОВАТЬ 100% процентов , И ПРОВЕРМЯЕМ ЕСЛИ СВЯЗЬ С ИНТЕНТОМ



               РезультатЕслиСвязьСерверомДСУ =      new Class_Connections_Server(getActivity()).МетодПингаСервераРаботаетИлиНет(getActivity());

                //TODO ФУТУРЕ ЗАВЕРШАЕМ
                Log.d(this.getClass().getName(), "  РезультатЕслиСвязьСерверомДСУ " +РезультатЕслиСвязьСерверомДСУ);

                ////TODO ТОЛЬКО ПРИ НАЛИЧИИ ИНТРЕНТА  !!!!!!!!!!!!!!!! ЗАПУСК СИНХРОНИЗАЦИИ

                if (РезультатЕслиСвязьСерверомДСУ == true) {


                    РезультатСинхронизацииДОСозданиеЯСообщения=           new Class_Async_Background(getActivity()).
                            МетодЗАпускаФоновойСинхронизации(getActivity(),"СинхронизацияДляЧата",
                                    true,ActivityДляСинхронизацииОбмена,
                                    ЛистЗапускаемТолькоТаблицыЧатаВСинхронизации,
                                    "ПовторныйЗапускСинхронизации",0);  //МетодЗАпускаСинхронизациивФонеТолькоСинхронно   //МетодЗАпускаСинхронизациивФоне
                    ///
                    Log.d(this.getClass().getName(), "МетодЗапускаЛокальнойСинхронизации() СЛУЖБА синхронизации запускаем через  getApplication()"+ РезультатСинхронизацииДОСозданиеЯСообщения);


/*
                                // TODO: 07.07.2021 sleep
                                TimeUnit.MILLISECONDS.sleep(1000);*/


                }

                Log.d(this.getClass().getName(), "  СЛУЖБА ТОЛЬКО ДЛЯ ЧАТА  РезультатСинхронизацииДОСозданиеЯСообщения  "
                        +   РезультатСинхронизацииДОСозданиеЯСообщения+
                        " ИндексКоличествоПопытокОтправкиЧата " );

                // TODO: 29.04.2021 вуключаем




                ///
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }
            return  РезультатСинхронизацииДОСозданиеЯСообщения;
        }



 //todo













        // TODO: 11.08.2021  метод ССОЗДАНИИ НОВГО СООБЩЕНИЯ В ЧАТЕ
        protected Integer МетодСозданииНовогоСообщениявЧате(View v) throws InterruptedException, ExecutionException {
            ///
            ////////
            // TODO: 25.07.2021

            try {
                // TODO: 05.07.2021  получаем публичный ID



/*
         Cursor cursor=      new MyContentProviderDatabase().query(Uri.parse("content://com.dsy.dsu/Database DSU-1.db/chats"),new String[]{"id"},null,null,null);

                if (cursor.getCount()>0) {

                }*/


                // TODO: 09.09.2021  ПОЛУЧНИЕ ДАННЫХ ДЛЯ ФРАГМЕНТА ЧИТАТЬИ ПИСАТЬ ЧАТ

                SQLiteCursor    Курсор_ВычисляемПУбличныйID=null;
                ///////
                int ПубличныйID=0;



                Log.d(this.getClass().getName(), " ПубличныйIDДляФрагмента  " + ПубличныйIDДляФрагмента);


                if ( ПубличныйIDДляФрагмента>0) {




                    // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                    // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ
                    Class_GRUD_SQL_Operations class_grud_sql_operationsРабоатемВФрагментечитатьПисатьШестаяЧасть= new Class_GRUD_SQL_Operations(getContext());
                    ///
                    class_grud_sql_operationsРабоатемВФрагментечитатьПисатьШестаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СамFreeSQLКОд",
                            " SELECT id FROM SuccessLogin ORDER BY date_update DESC LIMIT 1 ");

                    // TODO: 28.09.2021
                    Курсор_ВычисляемПУбличныйID=null;


                    ///////
                    Курсор_ВычисляемПУбличныйID= (SQLiteCursor) class_grud_sql_operationsРабоатемВФрагментечитатьПисатьШестаяЧасть.
                            new GetаFreeData(getContext()).getfreedata(class_grud_sql_operationsРабоатемВФрагментечитатьПисатьШестаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                            class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков
                            ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                    ///

                    Log.d(this.getClass().getName(), "GetData "  +Курсор_ВычисляемПУбличныйID);




/*
// TODO: 09.09.2021  ___old

              Курсор_ВычисляемПУбличныйID=new MODEL_synchronized(getContext()).КурсорУниверсальныйБазыДанных("SELECT id FROM SuccessLogin ORDER BY date_update DESC  LIMIT 1 ");
*/

                    Log.d(this.getClass().getName(), " ПубличныйIDДляФрагмента  " + ПубличныйIDДляФрагмента);
                    /////TODO RESULTAT
                if(Курсор_ВычисляемПУбличныйID.getCount()>0) {
                    //////////
                    Курсор_ВычисляемПУбличныйID.moveToFirst();
                    //////////////
                    ПубличныйID = Курсор_ВычисляемПУбличныйID.getInt(0);
                    //////
                }else{
                    ПубличныйID =ПубличныйIDДляФрагмента;

                }
                    //////

                    //////


                }



            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///
            }


            СгенерированныйUUIDДляНовогоТабеля=0l;

            //TODO флаг говорт от том что ненадо запускаитьси6хрониазцию

            ////
            Long РезультатВставкиПервогоСообщения=0l;
            ////
            Long РезультатВставкиВторогоСообщения=0l;
            ///
      Integer РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТ = 0;
            //


                    try{
                        /////


                        ////todo создаение UUID
                        Long СгенерированованныйUUIDДляФрагмента=   (Long)  new Class_Generation_UUID(getActivity()).МетодГенерацииUUID(getContext());
                        ///

                        СгенерированныйUUIDДляНовогоТабеля =СгенерированованныйUUIDДляФрагмента;

                        //
                        Log.d(this.getClass().getName(), "  СгенерированныйUUIDДляНовогоТабеля "+ СгенерированныйUUIDДляНовогоТабеля);


                        // TODO: 23.07.2021 борьба с гонками потоков


                        ///

                        ///TODO --первая вставка


                        ///TODO --первая вставка

                        /////

                        if (ПубличныйIDДляФрагмента==0) {
                            ///////
                            SQLiteCursor    Курсор_ВычисляемПУбличныйIDПриСозданииНовогоСообщения=null;


                            // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ

                            // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ
                            Class_GRUD_SQL_Operations class_grud_sql_operationsРабоатемВФрагментечитатьПисатьШестаяЧасть= new Class_GRUD_SQL_Operations(getContext());
                            ///
                            class_grud_sql_operationsРабоатемВФрагментечитатьПисатьШестаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СамFreeSQLКОд",
                                    " SELECT id FROM SuccessLogin ORDER BY date_update DESC LIMIT 1 ");


                            ////
                            Курсор_ВычисляемПУбличныйIDПриСозданииНовогоСообщения=null;
                            ///////
                            Курсор_ВычисляемПУбличныйIDПриСозданииНовогоСообщения= (SQLiteCursor) class_grud_sql_operationsРабоатемВФрагментечитатьПисатьШестаяЧасть.
                                    new GetаFreeData(getContext()).getfreedata(class_grud_sql_operationsРабоатемВФрагментечитатьПисатьШестаяЧасть. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                                    class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков
                                    ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());



                            Log.d(this.getClass().getName(), "GetData "  +Курсор_ВычисляемПУбличныйIDПриСозданииНовогоСообщения);





                            // TODO: 09.09.2021 resultat
                            /////
                            if(Курсор_ВычисляемПУбличныйIDПриСозданииНовогоСообщения.getCount()>0){
                                //////////
                                Курсор_ВычисляемПУбличныйIDПриСозданииНовогоСообщения.moveToFirst();
                                //////////////
                                ПубличныйIDДляФрагмента= Курсор_ВычисляемПУбличныйIDПриСозданииНовогоСообщения.getInt(0);
                                //////


                                //
                                Log.d(this.getClass().getName(), "  ФИНАЛ ФОНОВАЯ  СИНХРОНИЗАЦИИ СЛУЖБА КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ полученный публичный id ПЕРЕД ВСТАВКОЙ" + " ПубличныйIDДляФрагмента "+ПубличныйIDДляФрагмента ) ;

                            }
                            Курсор_ВычисляемПУбличныйIDПриСозданииНовогоСообщения.close();
                            ////
                        }
























                      //TODO  ПЕРВАЯ вставка   ТАБЛИЦА  CHATS





                        ///
                        String ДатаПриСоздаенииНовгоСообщениявЧате=new String();

                        //
                        ////TODO ДАТА
                        String СгенерированованныйДатаДляФрагмента=     new Class_Generation_Data(getActivity()).ГлавнаяДатаИВремяОперацийСБазойДанных();

                        ////////////////////
                        ДатаПриСоздаенииНовгоСообщениявЧате=null;
                        //////
                        ДатаПриСоздаенииНовгоСообщениявЧате=   СгенерированованныйДатаДляФрагмента;

                        /////


                        Log.d(this.getClass().getName(), "   СгенерированныйUUIDДляНовогоТабеля "+ СгенерированныйUUIDДляНовогоТабеля +
                                " ПриСоздаенииНовгоСообщениявЧате " +ДатаПриСоздаенииНовгоСообщениявЧате);




                        /////КОНТЕЙГНЕР
                        ContentValues contentValuesЗаписьНовогоСообщения_ТаблицаЧат=new ContentValues();



                        contentValuesЗаписьНовогоСообщения_ТаблицаЧат.put("date_update", ДатаПриСоздаенииНовгоСообщениявЧате);
                        ///////////////////////////////////////

                        contentValuesЗаписьНовогоСообщения_ТаблицаЧат.put("user_update", ПубличныйIDДляФрагмента);
                        //////

                        contentValuesЗаписьНовогоСообщения_ТаблицаЧат.put("id_user", ПолученыйIDДляЧата);////бышвий user_for



                        Log.d(this.getClass().getName(), "  ПолученыйIDДляЧата  "+ПолученыйIDДляЧата+ "  ПубличныйIDДляФрагмента " +ПубличныйIDДляФрагмента);
                 /*       Long НовыйUUIDДляТаблицыЧат=0L;
                        ///
                        ////TODO UUID
                       Long СгенерированованныйUUIDДляОбвновления=   (Long)  new Class_Generation_UUID(getActivity()).МетодГенерацииUUID(getActivity());
                        //////
                      НовыйUUIDДляТаблицыЧат =СгенерированованныйUUIDДляОбвновления;

*/
                        //

                        contentValuesЗаписьНовогоСообщения_ТаблицаЧат.put("uuid", СгенерированныйUUIDДляНовогоТабеля);


                        String ПерваяТаблицыОбработкиТаблицаЧат="chats";




                        //TODO курант чат

                        Class_GRUD_SQL_Operations        class_grud_sql_operationsПовышаемВерсиюДанныхВосьмаяЧасть=new Class_GRUD_SQL_Operations(getActivity());


                        Long РезультатУвеличинаяВерсияДАныхЧата=0L;

                        РезультатУвеличинаяВерсияДАныхЧата=         class_grud_sql_operationsПовышаемВерсиюДанныхВосьмаяЧасть. new ChangesVesionData(getContext()).
                                МетодПолученияУвеличинойВесрииДанныхДляТекущейВнутренейтаблицы(ПерваяТаблицыОбработкиТаблицаЧат,"localversionandroid_version",getContext()
                                        ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());


                        //TODO  конец курант ча
                        //////
                        contentValuesЗаписьНовогоСообщения_ТаблицаЧат.put("current_table", РезультатУвеличинаяВерсияДАныхЧата);


                        Log.d(this.getClass().getName(), "РезультатУвеличинаяВерсияДАныхЧата   " + РезультатУвеличинаяВерсияДАныхЧата);


                        // TODO: 05.07.2021 вставка новго сообщения в деве таблоицы Chats and DATA_Chat




                        // TODO: 15.08.2021  начало транзакции
                        ///PUBLIC_CONTENT.ССылкаНаСозданнуюБазу.execSQL(" BEGIN DEFERRED TRANSACTION ");



                        Long       РезультатВставки_НовойЗаписиВТаблицуЧАТ=0l;


                                     РезультатВставки_НовойЗаписиВТаблицуЧАТ= new MODEL_synchronized(getActivity()).ВставкаДанныхЧерезКонтейнерТолькоПриСозданииНСообщенияДЛЯЧата("chats",
                                        contentValuesЗаписьНовогоСообщения_ТаблицаЧат, ПерваяТаблицыОбработкиТаблицаЧат, "",
                                        true);

                        Log.d(this.getClass().getName(), " СЛУЖБА ЗАПИСЬ ПЕРВАЯ В ЧАТ ....   ФИНАЛ ФОНОВАЯ  СИНХРОНИЗАЦИИ СЛУЖБА КОЛИЧЕСТВО УСПЕШНЫХ ВСТАКОВ РезультатВставки_НовойЗаписиВТаблицуЧАТ "
                                +РезультатВставки_НовойЗаписиВТаблицуЧАТ+
                                " РезультатВставки_НовойЗаписиВТаблицуЧАТ " +РезультатВставки_НовойЗаписиВТаблицуЧАТ+  " ПерваяТаблицыОбработкиТаблицаЧат " +ПерваяТаблицыОбработкиТаблицаЧат);

                        // TODO: 28.09.2021

                        contentValuesЗаписьНовогоСообщения_ТаблицаЧат.clear();
                        ////////




                        // TODO: 23.07.2021 борьба с гонками потоков


                        Log.d(this.getClass().getName(), "  РезультатВставки_НовойЗаписиВТаблицуЧАТ  "+РезультатВставки_НовойЗаписиВТаблицуЧАТ);
                        ////
                          if (РезультатВставки_НовойЗаписиВТаблицуЧАТ>0){

       /*                       //TODO ДОПОЛНИТЕЛЬНОЕ СОХРАНИЕНИ  ДАННЫХ С ПИМИМИНЕНИЕМ ВЕРСИЙ ДАННЫХ (ВМЕСТО ДАТЫ)
                     int РезультатЗаписиВерсииДанныхвБазе=    new MODEL_synchronized(getContext()).
                             МетодЗаписьЧтоОрацияПрошлаЗаписьВБазуСПрименениемВерсииДанных("chats",
                                     new Date(),null,"localversionandroid_version",Integer.parseInt(String.valueOf(РезультатУвеличинаяВерсияДАныхЧата)));

*/




                              ////TODO ДАТА  ПОВЫШАЕМ ВЕРИСЮ ДАННЫХ

                              Integer Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы =
                                      new Class_Async_Background(getActivity()).МетодПослеGRUDОперацийПовышаемВерсиюДанных( РезультатВставки_НовойЗаписиВТаблицуЧАТ ,ПерваяТаблицыОбработкиТаблицаЧат,"Локальное",0l,
                                              class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков);


                              Log.i(this.getClass().getName(), "   PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице:"+
                                     " РезультатВставки_НовойЗаписиВТаблицуЧАТ " +РезультатВставки_НовойЗаписиВТаблицуЧАТ+
                                      "  Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы " +Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы+
                                        " РезультатВставки_НовойЗаписиВТаблицуЧАТ " +РезультатВставки_НовойЗаписиВТаблицуЧАТ +  "  ПерваяТаблицыОбработкиТаблицаЧат " +ПерваяТаблицыОбработкиТаблицаЧат
                              );


                          }
















                        //////////////////////////////////////////////
                        ///         ///TODO --вторая вставка   ТАБЛИЦА  DATA_TABELS   вторая вставка   ТАБЛИЦА  DATA_TABELS   вторая вставка   ТАБЛИЦА  DATA_TABELS  вторая вставка   ТАБЛИЦА  DATA_TABELS

                        ///TODO --вторая вставка

                        //TODO курант чат

                        Class_GRUD_SQL_Operations        class_grud_sql_operationsПовышаемВерсиюДанныхДевятаяЧасть=new Class_GRUD_SQL_Operations(getActivity());

                        // TODO: 20.07.2021
                        //////
                        /////
                        ContentValues contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT=new ContentValues();
                        ////////

                        ////////////////////
                        ДатаПриСоздаенииНовгоСообщениявЧате=null;
                        //////
                        ////TODO ДАТА
                        String СгенерированованныйДатаДляДаннойОперации=     new Class_Generation_Data(getActivity()).ГлавнаяДатаИВремяОперацийСБазойДанных();

                        //////
                        ДатаПриСоздаенииНовгоСообщениявЧате=   СгенерированованныйДатаДляДаннойОперации;
                        ///

                        Log.d(this.getClass().getName(), "   СгенерированныйUUIDДляНовогоТабеля "+ СгенерированныйUUIDДляНовогоТабеля +
                                " ПриСоздаенииНовгоСообщениявЧате " +ДатаПриСоздаенииНовгоСообщениявЧате);



                        contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT.put("chat_uuid", СгенерированныйUUIDДляНовогоТабеля);
                        /////////


                        contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT.put("date_update", ДатаПриСоздаенииНовгоСообщениявЧате);

                        //////

                        ///
                        contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT.put("user_update",ПубличныйIDДляФрагмента);
                        ///

                        contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT.put("id_user", ПолученыйIDДляЧата);////бышвий user_for

                        //
                        //////contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT.put("users_chats", PUBLIC_CONTENT.ПУбличныйДанныеПришёлЛиIDДЛяГенерацииUUID);

                        //
                        Log.d(this.getClass().getName(), " СгенерированныйUUIDДляНовогоТабеля второй  " +СгенерированныйUUIDДляНовогоТабеля);

                        Long НовыйUUIDДляТаблицыДатаЧат=0L;
                        //
                        ////TODO UUID
                       /// Long СгенерированованныйUUIDДляОбвновления=   (Long)  new Class_Generation_UUID(getActivity()).МетодГенерацииUUID(getActivity());
                        ////
                       НовыйUUIDДляТаблицыДатаЧат=(Long)  new Class_Generation_UUID(getActivity()).МетодГенерацииUUID(getActivity());
                        //
                        ////
                        contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT.put("uuid", НовыйUUIDДляТаблицыДатаЧат);


                        // TODO: 28.09.2021  запись в таблицу Data_tabels

                        String ТаблицаВторойОбработкиДляТаблицыДата_Табеля="data_chat";



                        // TODO: 11.08.2021 up current chat vesion

                        Long РезультатУвеличинаяВерсияДАныхДатЧата=0L;



                        РезультатУвеличинаяВерсияДАныхДатЧата=          class_grud_sql_operationsПовышаемВерсиюДанныхДевятаяЧасть.new ChangesVesionData(getContext()).
                                МетодПолученияУвеличинойВесрииДанныхДляТекущейВнутренейтаблицы(ТаблицаВторойОбработкиДляТаблицыДата_Табеля,"localversionandroid_version",getContext()
                                        ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());

                        //TODO  конец курант чат
                        ///




                        //////
                        contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT.put("current_table", РезультатУвеличинаяВерсияДАныхДатЧата);


                        Log.d(this.getClass().getName(), "РезультатУвеличинаяВерсияДАныхДатЧата   " + РезультатУвеличинаяВерсияДАныхДатЧата);






                        // TODO: 05.07.2021 само тело новго сообщения
                        String СамоСообщенияНовоеДляЧата=new String();
                        //////
                        СамоСообщенияНовоеДляЧата=editTextТелоНаписаногоСообщенияДругимСотрудникам.getText().toString().trim();

                        ////
                        if (СамоСообщенияНовоеДляЧата.length()>0   && РезультатВставки_НовойЗаписиВТаблицуЧАТ>0) {
                            ///////
                            contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT.put("message", СамоСообщенияНовоеДляЧата.trim());



                            //////////

                            /////////TODO запуск нновую нотификашенс устанолвка


                            // TODO: 06.07.2021 finial
                            РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТ=0;

                            ///
                     Long       РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТВременный = new MODEL_synchronized(getContext()).
                                    ВставкаДанныхЧерезКонтейнерТолькоПриСозданииНСообщенияДЛЯЧата(ТаблицаВторойОбработкиДляТаблицыДата_Табеля,
                                            contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT, ТаблицаВторойОбработкиДляТаблицыДата_Табеля, "",
                                            true);

                            //
                            РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТ=   Integer.parseInt(String.valueOf(РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТВременный)) ;

                            Log.d(this.getClass().getName(),
                                    " РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТ " + РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТ + " РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТВременный " +
                                            РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТВременный);


                            //////
                            contentValuesЗаписьНовогоСообщения_ТаблицыDATA_CHAT.clear();


                            Log.d(this.getClass().getName(), "  РезультатВставки_НовойЗаписиВТаблицуЧАТ  "+РезультатВставки_НовойЗаписиВТаблицуЧАТ);
                            ////
                            if (  РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТ>0){

                               /* //TODO ДОПОЛНИТЕЛЬНОЕ СОХРАНИЕНИ  ДАННЫХ С ПИМИМИНЕНИЕМ ВЕРСИЙ ДАННЫХ (ВМЕСТО ДАТЫ)
                                int РезультатЗаписиВерсииДанныхвБазе=    new MODEL_synchronized(getContext()).
                                        МетодЗаписьЧтоОрацияПрошлаЗаписьВБазуСПрименениемВерсииДанных("data_chat", new Date(),null,"localversionandroid_version",Integer.parseInt(String.valueOf(РезультатУвеличинаяВерсияДАныхДатЧата)));

*/
                                ////TODO ДАТА  ПОВЫШАЕМ ВЕРИСЮ ДАННЫХ

                                Integer Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы =
                                        new Class_Async_Background(getActivity()).МетодПослеGRUDОперацийПовышаемВерсиюДанных( РезультатВставки_НовойЗаписиВТаблицуЧАТ ,ТаблицаВторойОбработкиДляТаблицыДата_Табеля,"Локальное",0l,
                                                class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков);


                                Log.i(this.getClass().getName(), "   PUBLIC_CONTENT.СколькоСтрочекJSONПоКонкретнойТаблице:"+
                                        " РезультатВставки_НовойЗаписиВТаблицуЧАТ " +РезультатВставки_НовойЗаписиВТаблицуЧАТ+
                                        "  Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы " +Результат_ПриписиИзменнийВерсииДанныхВФонеПослеОбработкиТекущийТаблицы);


                                // TODO: 15.08.2021  начало транзакции
                               /// PUBLIC_CONTENT.ССылкаНаСозданнуюБазу.execSQL(" COMMIT");
                            }else{

                                // TODO: 15.08.2021  начало транзакции
                             ///   PUBLIC_CONTENT.ССылкаНаСозданнуюБазу.execSQL(" ROLLBACK ");

                            }


                        }



                        // TODO: 26.07.2021  обняем после синхрониазции
                        if (РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТ>0) {
                            ////
                            editTextТелоНаписаногоСообщенияДругимСотрудникам.setText("");


                            ///


                            // TODO: 14.07.2021 Запуск Синхронизации ХолостойХод

                        }



                        // TODO: 23.07.2021 прогняем потоки через цикл CALLBELLE

                        /////
                        ////


                        СгенерированныйUUIDДляНовогоТабеля=0l;

                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                         // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                                Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                        ///

                    }

            ///////////////TODO   UPDATE МЕТОД ФИНАЛЬНОЙ ФИКСАЦИИ ОБНОВЛЕНИЯ ПОСЛЕ ЦИКЛ FOR
            //


            return РезультатВставки_НовойЗаписиВТаблицуДАТА_ЧАТ;
            // TODO: 05.07.2021 после успешной вставки новой записи обновляем UI
        }


























        // TODO: 05.07.2021 код запуска метода ЗАПИСИВ БАУЗ СТАТУСА КАК ПРОЧИТАННЫЙ

        Integer МетодЗаписиСтатусаНеЖиныйПослеПросмотраЗаписиВЧате(String ЧерезЧегоОбновляем,String СамоЗначенияИндифкатора) {

            // TODO: 05.07.2021 вставка новго сообщения в деве таблоицы Chats and DATA_Chat
            Integer РезультатОбновленияСтатусЧатаКакПрочитанный = 0;

            try{


                Log.d(this.getClass().getName(), "  МетодЗаписиСтатусаНеЖиныйПослеПросмотраЗаписиВЧате");


                //     <Long>     ОбновленияСтатусаПрочитанный=new Executor    (Executors.newCachedThreadPool());
                //////

                        /////КОНТЕЙГНЕР
                        ContentValues contentValuesОбновленниВТАблицеКакПрочитанныйМеняемСтатусЗаписисВчатеПостлеПросмотра = new ContentValues();

                        ////////

                        contentValuesОбновленниВТАблицеКакПрочитанныйМеняемСтатусЗаписисВчатеПостлеПросмотра.put("status_write", 1);
                        //////

                        //////


                        // TODO: 05.07.2021 вставка новго сообщения в деве таблоицы Chats and DATA_Chat
                     РезультатОбновленияСтатусЧатаКакПрочитанный = 0;

                        ///TODO ВТОРАЯ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                        РезультатОбновленияСтатусЧатаКакПрочитанный = new MODEL_synchronized(getActivity()).
                                ЛокальногоОбновлениеДанныхЧерезКонтейнерУниверсальная("data_chat",
                                        contentValuesОбновленниВТАблицеКакПрочитанныйМеняемСтатусЗаписисВчатеПостлеПросмотра, Long.parseLong(ЧерезЧегоОбновляем), СамоЗначенияИндифкатора);


                   /*     Integer Результат_ПриписиИзменнийВерсииДанныхДляЧатаСообщений = null;
                        if (РезультатОбновленияСтатусЧатаКакПрочитанный > 0) {

                            ///TODO ПЕРОВЕ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                            Log.d(this.getClass().getName(), " Результат_ПриписиИзменнийВерсииДанных   " + РезультатОбновленияСтатусЧатаКакПрочитанный);


                            ///TODO ВТОРАЯ ТРАНЗАКЦИЯ ВСТАВКИ ДАННЫХ
                            Результат_ПриписиИзменнийВерсииДанныхДляЧатаСообщений = new MODEL_synchronized(getActivity()).МетодЗаписьЧтоОрацияПрошлаЗаписываемВТбалицуВерсийДанныхТолькоДляЛокальногоОбновленияДанных(
                                    "data_chat", new Date());

                        }*/
                        Log.d(this.getClass().getName(), " Результат_ПриписиИзменнийВерсииДанныхДляЧата   " + РезультатОбновленияСтатусЧатаКакПрочитанный);



                ///////
                Log.d(this.getClass().getName(), "   РезультатОбновленияСтатусЧатаКакПрочитанный "+РезультатОбновленияСтатусЧатаКакПрочитанный);


                if (РезультатОбновленияСтатусЧатаКакПрочитанный>0) {
                    //

                    Log.d(this.getClass().getName(), " УСПЕШНОЕ СОЗДАНИЕ НОВОГО СООБЩЕНИЯ   РезультатОбновленияСтатусЧатаКакПрочитанный "+РезультатОбновленияСтатусЧатаКакПрочитанный);
                    /////



                    // TODO: 05.07.2021 ПОСЛЕ УСПЕШНОЙ ВСТАВКИ ДАННЫХ ОБНОВЛЕНИЕ UI ЗАПУСКАЕМ СИНХРОНИЗАЦИЮ  С СЕРВЕРОМ


                }else{
                    Log.d(this.getClass().getName(), "  НЕТ УСПЕШНОГО СООБШЕИЯ  РезультатОбновленияСтатусЧатаКакПрочитанный "+РезультатОбновленияСтатусЧатаКакПрочитанный);

                }




                // TODO: 05.07.2021 после успешной вставки новой записи обновляем UI







            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }

            return РезультатОбновленияСтатусЧатаКакПрочитанный   ;   // TODO: 05.07.2021 вставка новго сообщения в деве таблоицы Chats and DATA_Chat

        }


    }
























    private class MODEL {
        /////
        public MODEL(Activity activity) {
            try{



            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///


            }


        }


        // TODO: 09.09.2021

        void МетодПолучениеДанныхдляФрагментаЧитатьиПисатьЧат() throws ExecutionException, InterruptedException {
            try{

                        // TODO: 05.07.2021  получаем публичный ID
                // TODO: 09.09.2021 первый  курсор





                // TODO: 28.09.2021  первая  часть


                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ
                Class_GRUD_SQL_Operations class_grud_sql_operationsРабоатемВФрагментечитатьПисать= new Class_GRUD_SQL_Operations(getContext());
                ///
                class_grud_sql_operationsРабоатемВФрагментечитатьПисать. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СамFreeSQLКОд",
                        " SELECT id FROM SuccessLogin ORDER BY date_update DESC  LIMIT 1  ;");


                ///////
                SQLiteCursor            Курсор_ВычисляемПУбличныйID= (SQLiteCursor) class_grud_sql_operationsРабоатемВФрагментечитатьПисать.
                        new GetаFreeData(getContext()).getfreedata(class_grud_sql_operationsРабоатемВФрагментечитатьПисать. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                        class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков
                        ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());



                Log.d(this.getClass().getName(), "GetData "  +Курсор_ВычисляемПУбличныйID);





/*


                // TODO: 09.09.202 _____old
                            Курсор_ВычисляемПУбличныйID=new MODEL_synchronized(getContext()).КурсорУниверсальныйБазыДанных("SELECT id FROM SuccessLogin ORDER BY date_update DESC  LIMIT 1 ");
*/
                Log.d(this.getClass().getName(), "  ПубличныйIDДляФрагмента  " + ПубличныйIDДляФрагмента);


                            /////TODO resultat
                            if(Курсор_ВычисляемПУбличныйID.getCount()>0) {
                                //////////
                                Курсор_ВычисляемПУбличныйID.moveToFirst();
                                //////////////
                                ПубличныйIDДляФрагмента = Курсор_ВычисляемПУбличныйID.getInt(0);
                                //////

                                //////
                                //////


                                // TODO: 28.06.2021  обнуляем для полученеи для чата


                                Log.d(this.getClass().getName(), "  ПубличныйIDДляФрагмента  " + ПубличныйIDДляФрагмента);


                                // TODO: 28.09.2021  вторая часть


                                Log.d(this.getClass().getName(), "  Вторая Часть  ");


                                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ
                                Class_GRUD_SQL_Operations class_grud_sql_operationsРабоатемВФрагментечитатьПисатьВтораяЧасть = new Class_GRUD_SQL_Operations(getContext());
                                ///
                                class_grud_sql_operationsРабоатемВФрагментечитатьПисатьВтораяЧасть.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СамFreeSQLКОд",

                                        " SELECT   * FROM viewchat  WHERE " +
                                                "  EXISTS ( SELECT   * FROM viewchat  WHERE   user_update =" + ПолученыйIDДляЧата + " ) " +
                                                "   AND EXISTS ( SELECT   * FROM viewchat  WHERE   id_user =" + ПолученыйIDДляЧата + " ) " +
                                                "   AND EXISTS ( SELECT   * FROM viewchat  WHERE   user_update =" + ПубличныйIDДляФрагмента + " ) " +
                                                "   AND EXISTS ( SELECT   * FROM viewchat  WHERE   id_user =" + ПубличныйIDДляФрагмента + " ) " +
                                                " AND   message IS NOT NULL    ORDER BY  current_table    ");


                                ///date_update
                               /* +" UNION " +




                                                " SELECT   * FROM viewchat  WHERE user_update  = "+  ПубличныйIDДляФрагмента  +   " AND  user_update =" + ПолученыйIDДляЧата  +
                                " AND EXISTS ( SELECT   * FROM viewchat  WHERE id_user  = "+
                                ПубличныйIDДляФрагмента  +   " AND  id_user =" + ПолученыйIDДляЧата  + ") " +
                                " AND   message IS NOT NULL    ORDER BY  current_table    "); ///date_update
                               /* +" UNION " +

                                " SELECT   * FROM viewchat  WHERE user_update = " + ПолученыйIDДляЧата  + " AND EXISTS ( SELECT   * FROM viewchat  WHERE id_user = "+ ПубличныйIDДляФрагмента  + " ) " +

                                " AND   message IS NOT NULL    ORDER BY date_update  ;");//date_updatecurrent_table*/




/*
                " SELECT   * FROM viewchat  WHERE user_update = "+  ПубличныйIDДляФрагмента  +" AND EXISTS ( SELECT   * FROM viewchat  WHERE id_user = " + ПолученыйIDДляЧата + " )  "
                        +" UNION " +

                        " SELECT   * FROM viewchat  WHERE user_update = " + ПолученыйIDДляЧата  + " AND EXISTS ( SELECT   * FROM viewchat  WHERE id_user = "+ ПубличныйIDДляФрагмента  + " ) " +

                        " AND   message IS NOT NULL    ORDER BY date_update  ;");//date_updatecurrent_table
*/

                                // TODO: 28.09.2021

                                КурсорДанныеДлязаписиичтнияЧата = null;

                                ///////
                                КурсорДанныеДлязаписиичтнияЧата = (SQLiteCursor) class_grud_sql_operationsРабоатемВФрагментечитатьПисатьВтораяЧасть.
                                        new GetаFreeData(getContext()).getfreedata(class_grud_sql_operationsРабоатемВФрагментечитатьПисатьВтораяЧасть.concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                                        class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков
                                        ,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());


                                // TODO: 11.10.2021

                                Log.d(this.getClass().getName(), "GetData " + КурсорДанныеДлязаписиичтнияЧата);


                                if (КурсорДанныеДлязаписиичтнияЧата.getCount() > 0) {
                                    ////////
                                    КурсорДанныеДлязаписиичтнияЧата.moveToFirst();
                                }


                                //////
//


         /*       //////*
                КурсорДанныеДлязаписиичтнияЧата= "   SELECT   * FROM viewchat  WHERE user_update = "
                        +  ПубличныйIDДляФрагмента  +
                        " AND EXISTS ( SELECT   * FROM viewchat  WHERE id_user = "+ ПолученыйIDДляЧата + " )  " +
                        " UNION " +
                        "   SELECT   * FROM viewchat  WHERE user_update = " + ПолученыйIDДляЧата  + " AND EXISTS ( SELECT   * FROM viewchat  WHERE id_user = " +
                        ПубличныйIDДляФрагмента  + " ) " +
                        " AND   message IS NOT NULL    ORDER BY date_update  ;");  ////быший user_for

*/

                            }

            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                 // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getActivity()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
          this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
                ///
            }

        }



    }























    // TODO: 01.07.2021  метод



    class тестдляОбмена{

        public тестдляОбмена() {

            SSLSocketFactory socketFactory = null;
            KeyManagerFactory keyManagerFactory = null;
            try {
                keyManagerFactory = KeyManagerFactory.getInstance("SunX509");

                KeyStore keyStore = null;

                keyStore = KeyStore.getInstance("PKCS12");

                keyManagerFactory.init(keyStore, "password".toCharArray());
                SSLContext    context = SSLContext.getInstance("TLS");
                context.init(keyManagerFactory.getKeyManagers(), null, new SecureRandom());


                socketFactory = context.getSocketFactory();

            } catch (NoSuchAlgorithmException | KeyStoreException e) {
                e.printStackTrace();
            } catch (UnrecoverableKeyException e) {
                e.printStackTrace();
            } catch (KeyManagementException e) {
                e.printStackTrace();
            }

            ConnectionSpec connectionSpec=new ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
                    .allEnabledCipherSuites()
                    .allEnabledTlsVersions()
                    .cipherSuites(
                            CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
                            CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
                            CipherSuite.TLS_DHE_RSA_WITH_AES_128_GCM_SHA256)
                    .build();

            OkHttpClient client = new OkHttpClient.Builder()
                    .connectionSpecs(Collections.singletonList(connectionSpec))
                    .readTimeout(10, TimeUnit.SECONDS)
                    .callTimeout(1,TimeUnit.MICROSECONDS)
                    .connectTimeout(10, TimeUnit.SECONDS)
                    .writeTimeout(10, TimeUnit.SECONDS)
                    .build();
/*


        //////
        // TODO: 30.07.2021   тест для полученеи и отправки данных   тест
        String postBody = "test post";

        Request request = new Request.Builder()
                .url(URL_SECURED_BY_BASIC_AUTHENTICATION)
                .addHeader("Authorization", Credentials.basic("username", "password"))
                .
                    .post(RequestBody.create(
                MediaType.parse("text/x-markdown), postBody))
                        .build();

        Call call = client.newCall(request);
        okhttp3.Response response = call.execute();

        assertThat(response.code(), equalTo(200));



        String json = "{\"id\":1,\"name\":\"John\"}";

        RequestBody body = RequestBody.create(
                MediaType.parse("application/json"), json);

        Request request = new Request.Builder()
                .url(BASE_URL + "/users/detail")
                .post(body)
                .build();

        Call call = client.newCall(request);
        Response response = call.execute();

        assertThat(response.code(), equalTo(200));
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("username", "test")
                .addFormDataPart("password", "test")
                .addFormDataPart("file", "file.txt",
                        RequestBody.create(MediaType.parse("application/octet-stream"),
                                new File("src/test/resources/test.txt")))
                .build();

        Request request = new Request.Builder()
                .url(BASE_URL + "/users/multipart")
                .post(requestBody)
                .build();

        Call call = client.newCall(request);
        okhttp3.Response response = call.execute();

        assertThat(response.code(), equalTo(200));

        OkHttpClient client = new OkHttpClient();


        final MediaType JSON = MediaType.get("application/json; charset=utf-8");
        OkHttpClient client2 = new OkHttpClient();
        RequestBody body2 = RequestBody.create(JSON, params);
        Request request2 = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        okhttp3.Response response1= null;
        response1 = client.newCall(request).execute();
*/
      /*  OkHttpClient client = new OkHttpClient.Builder()
                .sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0])
                .certificatePinner(certPinner)
                .readTimeout(10, TimeUnit.SECONDS)
                .connectTimeout(10, TimeUnit.SECONDS)
                .build();*/

            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @SuppressLint("TrustAllX509TrustManager")
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {}

                        @SuppressLint("TrustAllX509TrustManager")
                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {}

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }
                    }


            };


        /*PrivateKey priv = null;
        KeyFactory fact = null;
        try {
            fact = KeyFactory.getInstance("AES");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        byte[] clear = Base64.decode("ppppppppppppppp", 0).toString().getBytes();
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(clear);
        try {
            priv = fact.generatePrivate(keySpec);
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        SSLContext sslContext = null;
        try {
            sslContext = SSLContext.getInstance("SSL");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        try {
            sslContext.init(null, trustAllCerts, 787878787);
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }*/
            // Create an ssl socket factory with our all-trusting manager
    /*    final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
        ///
        final MediaType JSON3 = MediaType.get("application/json; charset=utf-8");
        OkHttpClient client2;
        client2 = new OkHttpClient.Builder()
                .sslSocketFactory()
                .certificatePinner(
                        new CertificatePinner.Builder()
                                .add("publicobject.com", "sha256/afwiKY3RxoMmLkuRW1l7QsPZTJPwDS2pdDROQjXw8ig=")
                                .build())
                .build();*/

     /*   JsonStreamParser jsonStreamParser;
        jsonStreamParser.*/



/*
        RequestBody body = RequestBody.create(JSON, params);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        Response response = null;
        response = client.newCall(request).execute();
        String responseBody = response.body().string();

        client.newCall(request).execute().;
        CipherSuite
        try {
            Cipher c = Cipher.getInstance("DES/CBC/PKCS5Padding");
            Charset charset = Charset.forName("ASCII");
            Charset charset = StandardCharsets.UTF_16;

            byte[] byteA hrrray = inputString.getBytes(charset);

            byte[] byteArrray = inputString.getBytes(charset);
            //
            String dd = "IBM01140";
            byte[] byteArrray2 = dd.getBytes();
            try {
                c.doFinal(byteArrray2);
            } catch (BadPaddingException e) {
                e.printStackTrace();
            } catch (IllegalBlockSizeException e) {
                e.printStackTrace();
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        }

        //

        SecretKeyFactory factory = null;
        try {
            factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        KeySpec spec = new PBEKeySpec("222".toCharArray(), "11".getBytes(), 65536, 256);
        try {
            SecretKey secret = new SecretKeySpec(factory.generateSecret(spec)
                    .getEncoded(), "AES");
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }

        String dd = "IBM01140";
        byte[] byteArrray3 = dd.getBytes();
        Cipher cipher = null;
        try {
            cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        }
        cipher.init(Cipher.ENCRYPT_MODE, spec, byteArrray3);
        byte[] cipherText = cipher.doFinal(input.getBytes());
        return Base64.getEncoder()
                .encodeToString(cipherText);




        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.DECRYPT_MODE, key, iv);
        byte[] plainText = cipher.doFinal(Base64.getDecoder()
                .decode(cipherText));
        return new String(plainText);

        String input = "baeldung";
        SecretKey key = factory.generateKey(128);
        IvParameterSpec ivParameterSpec = AESUtil.generateIv();
        String algorithm = "AES/CBC/PKCS5Padding";
        Cipher cipher = Cipher.getInstance(algorithm);
        IvParameterSpec ivParameterSpec = AESUtil.generateIv();
        cipher.init(Cipher.ENCRYPT_MODE, key, ivParameterSpec);
*/





            // TODO: 30.07.2021  конец получение и отпаврк данных на сервер и с сервера тест
        }
    }


}