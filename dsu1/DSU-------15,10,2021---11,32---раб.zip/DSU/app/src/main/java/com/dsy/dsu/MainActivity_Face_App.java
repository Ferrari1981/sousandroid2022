package com.dsy.dsu;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteCursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.annotation.UiThread;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;




/////////////////////////////////////////////////////////////////////////
public class MainActivity_Face_App extends AppCompatActivity {
    //////////
    protected Button     КнопкаТабельныйУчёт;


    ImageView  imageView_ЗначекApp;

    ///////TODO
    CREATE_DATABASE   Create_Database_СсылкаНАБазовыйКласс;
    protected Button ТекстПриложения;
    //protected  Class_Async_Background УниверсальныйОбмен;
    protected ScrollView ScrollFaceAppСкорол;
    private  static   AlarmManager alarmManager;




    protected LinearLayout LinearLayoutFaceApp;

    //////////////////////
    boolean РежимыПросмотраДанныхЭкрана;

    PUBLIC_CONTENT class_async_backgroundГдеНаходитьсяМенеджерПотоков =null;


    static Context КонтекстFaceAppВнешний;

    Context КонтекстFaceApp;
    ///
    Activity activity;

    Class_GRUD_SQL_Operations classGrudSqlOperations;

    /*    Context КонтекстДляСинхронизацииОбмена;*/

////////////////FACE APP

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            Log.w(getPackageName().getClass().getName(), "Сработал  protected void onCreate(Bundle savedInstanceState)  в MainActivity_Face_App");

            super.onCreate(savedInstanceState);

////////////////////


            ////todo ДАННОЕ АКТИВИТИ ПЕРЕДАЕМ НА ВСЮ СИНХРОНИЗАЦИЮ
            КонтекстFaceApp=this;
            ///
            activity=this;

            КонтекстFaceAppВнешний=this;


            ((Activity) КонтекстFaceApp) .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


/////////TODO локальная весрия данных для АНАЛИЗА ПО


            setContentView(R.layout.activity_main_face_app);


            ((Activity) КонтекстFaceApp) .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);

            //////todo настрока экрана

            //////todo  конец настрока экрана
            class_async_backgroundГдеНаходитьсяМенеджерПотоков =new PUBLIC_CONTENT(getApplicationContext());

            /////todo данная настрока запрещает при запуке активти подскаваать клавиатуре вверх на компонеты eedittext
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

            getSupportActionBar().hide(); ///скрывать тул бар


// TODO: 28.04.2021 Убиваем все службы




///////TODO
          Create_Database_СсылкаНАБазовыйКласс=new CREATE_DATABASE(getApplicationContext());

// TODO: 28.04.2021 разрешаем широковещатльнй приемник

         /*   ComponentName componentName = new ComponentName(getApplicationContext(), Broadcasts_Широковещательный_приемник.class);
            PackageManager packageManagerBroadcast_Notification = getApplicationContext().getPackageManager();
            packageManagerBroadcast_Notification.setComponentEnabledSetting(
                    componentName,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP);
*/



            //////////TODO  иниализивуем кнопки
            КнопкаТабельныйУчёт = (Button) findViewById(R.id.FaceApp_КнопкаТабельныйУчёт); /////КНОПКА ТАБЕЛЬНОГО УЧЕТА








            ////
            imageView_ЗначекApp= (ImageView) findViewById(R.id.imageView_ЗначекApp); /////КНОПКА ТАБЕЛЬНОГО УЧЕТА

            //   ScrollFaceAppСкорол = (ScrollView) findViewById(R.id.ScrollFaceApp); /////КНОПКА ТАБЕЛЬНОГО УЧЕТА

            LinearLayoutFaceApp = (LinearLayout) findViewById(R.id.LineLayFaceApp); /////КНОПКА ТАБЕЛЬНОГО УЧЕТА

            КнопкаТабельныйУчёт.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);






            Drawable icon = getResources().getDrawable(R.mipmap.icon_faceapp_tabels);
            icon.setBounds(0,1,150,150);
            // КнопкаТабельныйУчёт.   setPadding(100,100,10,100);
            КнопкаТабельныйУчёт . setCompoundDrawables(icon,null,null,null);





// TODO: 04.04.2021 test


            DisplayMetrics met = new DisplayMetrics();
            this.getWindowManager().getDefaultDisplay().getMetrics(met);// get display metrics object
            String strSize =
                    new DecimalFormat("##.##").format(Math.sqrt(((met.widthPixels / met.xdpi) *
                            (met.widthPixels / met.xdpi)) +
                            ((met.heightPixels / met.ydpi) * (met.heightPixels / met.ydpi))));

            ///
            Log.d(this.getClass().getName(), "strSize " + strSize);

            StringBuffer диагональ=new StringBuffer(strSize);

            диагональ.substring(0,1);
            Log.d(this.getClass().getName(), "  диагональ.substring(0,1) " +       диагональ.substring(0,1));

            Integer       ДиагональЭкранаФинал=Integer.parseInt( диагональ.substring(0,1));

            switch (ДиагональЭкранаФинал){
                case 5:

                    КнопкаТабельныйУчёт.setMinLines(24);
                    break;

                case 6:
                    КнопкаТабельныйУчёт.setMinLines(27);
                    break;
                case 4:
                    КнопкаТабельныйУчёт.setMinLines(21);
                    break;
                case 7:
                    КнопкаТабельныйУчёт.setMinLines(30);
                    break;

                case 8:
                    КнопкаТабельныйУчёт.setMinLines(32);
                    break;

            }



            // КнопкаТабельныйУчёт.setMinLines();


            МетодЗапускаАктивити();//// создание активти

            МетодНажатиеЗначекAPP();
            ///









            ////TODO АНАЛИЗИРУЕМ ПРИШЕДШИЙ ФАЙЛ И ПРИНИМАЕМ РЕШЕНИЕ НА СКАЧИВАНЕИ ФАЙЛА ИЛИ НЕТ


            ///TODO запускаем службу если несть права на   WRITE_EXTERNAL_STORAGE

            ///TODO запускаем дВУХсЛУЖБ



            //////////////////////TODO SERVICE

            String[] permissions = new String[]{
                    Manifest.permission.INTERNET,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.VIBRATE,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.REQUEST_INSTALL_PACKAGES,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS,
                    Manifest.permission.MANAGE_EXTERNAL_STORAGE,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.ACCESS_MEDIA_LOCATION,
                    Manifest.permission.INSTALL_PACKAGES,
                    Manifest.permission.WRITE_SETTINGS,
                    Manifest.permission.WRITE_SECURE_SETTINGS


            };

            //  startService(new Intent(КонтекстFaceApp, Service_UpdateSoft.class));
////TODO УСТАНВЛИВАЕМ РАЗРЕШЕНИЯ НА ВСЕ ПРИЛОЖЕНИЯ НАСТРОЙКИ
            try {
                ActivityCompat.requestPermissions(this, permissions, 1);
            } catch (Exception e) {
                e.printStackTrace();
            }



            ///TODO запуск службы
            if (Build.VERSION.SDK_INT >= 23) {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                }
                else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                }
            }


// TODO: 18.05.2021 запуск служб



            Log.d(getApplicationContext().getClass().getName(), " ЗАПУСК СЛУЖБА FACE_APP   МЕТОД ОБНОВЛЕНИЕ ПО  " + "--" + new Date());/////








// TODO: 06.06.2021 ЗАПУСК ТРЕХ СЛУЖБ   // TODO: 06.06.2021 ЗАПУСК ТРЕХ СЛУЖБ   // TODO: 06.06.2021 ЗАПУСК ТРЕХ СЛУЖБ   // TODO: 06.06.2021 ЗАПУСК ТРЕХ СЛУЖБ



/*


  //TODO #1

            МетодЗапускаСлужбВШировоВещятелеУведомления(); //5 СЕКУНД


            Log.d(getApplicationContext().getClass().getName(), " ЗАПУСК СЛУЖБА FACE_APP   МетодЗапускаСлужбВШировоВещятелеУведомления  " + "--" + new Date());/////



                   //TODO #3


            new MODEL_synchronized(this) .   МетодЗапускаСинхоронизацииИзШироковещательногоПриёмника(this); //30СЕКУНД



            Log.d(getApplicationContext().getClass().getName(), " ЗАПУСК СЛУЖБА FACE_APP   new MODEL_synchronized(this) .   МетодЗапускаСинхоронизацииИзШироковещательногоПриёмника(this) " + "--" + new Date());/////






*/


            //TODO #2

            МетодЗапускДляАнализаОбновленияПО();////5 СЕКУНД


            Log.d(getApplicationContext().getClass().getName(), " ЗАПУСК СЛУЖБА FACE_APP   МетодЗапускДляАнализаОбновленияПО " + "--" + new Date());/////


// TODO: 14.10.2021  тест код


/////////

        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

            // TODO: 11.05.2021 запись ошибок

                StringBuffer БуферОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе=new StringBuffer(   e.toString());

            Integer   ПубличноеIDПолученныйИзСервлетаДляUUID=0;
                // ID


                // TODO: 26.08.2021 НОВЫЙ ВЫЗОВ НОВОГО КЛАСС GRUD - ОПЕРАЦИИ
                Class_GRUD_SQL_Operations class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ= new Class_GRUD_SQL_Operations(getApplicationContext());
                ///
                class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций.put("СамFreeSQLКОд",
                        " SELECT id  FROM successlogin  ORDER BY date_update DESC ;");


                // TODO: 12.10.2021  Ссылка Менеджер Потоков

                PUBLIC_CONTENT  class_async_backgroundГдеНаходитьсяМенеджерПотоков =new PUBLIC_CONTENT (getApplicationContext());


                ///////
                SQLiteCursor Курсор_ПолучаемИмяСотрудникаИзТаблицыФИО= null;
                try {
                    Курсор_ПолучаемИмяСотрудникаИзТаблицыФИО = (SQLiteCursor) class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ.
                            new GetаFreeData(getApplicationContext()).getfreedata(class_grud_sql_operationsПолучаемНаБазуUUIDфиоПолучаемИзТаблицыФИОИМЯ. concurrentHashMapНаборПараментовSQLBuilder_Для_GRUD_Операций,
                            class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков,Create_Database_СсылкаНАБазовыйКласс.getССылкаНаСозданнуюБазу());
                } catch (ExecutionException executionException) {
                    executionException.printStackTrace();
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }

                if(Курсор_ПолучаемИмяСотрудникаИзТаблицыФИО.getCount()>0){
                    ////
                    Курсор_ПолучаемИмяСотрудникаИзТаблицыФИО.moveToFirst();

                    /////
                    ПубличноеIDПолученныйИзСервлетаДляUUID=         Курсор_ПолучаемИмяСотрудникаИзТаблицыФИО.getInt(0);
///


                    Log.d(this.getClass().getName(), " ПубличноеIDПолученныйИзСервлетаДляUUID  " + ПубличноеIDПолученныйИзСервлетаДляUUID);


                }




                БуферОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе.append("\n")
                        .append(" текущий пользователь : ")

                        .append(ПубличноеIDПолученныйИзСервлетаДляUUID).append(" время: ").append(new Date());

                // TODO: 01.09.2021 ПОСЫЛАЕМ ОШИБКИ СИСТМЕНУМО АДМИНИСТАТОРУ

                new Class_Sendiing_Errors(activity).МетодПослываемОшибкиАдминистаторуПо(БуферОшибкаПриПодключениекСерверуДляАунтификацииПользователяПриВходе,activity);




            }

        }









    // TODO: 22.04.2021
/*    private void МетодЗапускаJOBВШироковещательном_Применике() {
    try{
        // TODO: 22.04.2021  srart JOBschedele


        ComponentName componentName = new ComponentName(this,JobMyService.class);
        JobInfo info = new JobInfo.Builder(1,componentName)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED) // change this later to wifi
                .setPersisted(true)
                .setPeriodic(900000)
                .build();

        JobScheduler scheduler = (JobScheduler)getSystemService(JOB_SCHEDULER_SERVICE);
        int resultCode = scheduler.schedule(info);
        if (resultCode==JobScheduler.RESULT_SUCCESS) {
            Log.d(this.getClass().getName()," СЛУЖБА JOb JOb Scheduled");
        } else {
            Log.d(this.getClass().getName()," СЛУЖБА JOb Job Scheduling fail");
        }















*//*        AsyncTaskLoader asyncTaskLoader=new AsyncTaskLoader(getApplicationContext()) {



            @Override
            public void commitContentChanged() {
                super.commitContentChanged();
                Log.d(this.getClass().getName(), "Запущен.... метод  on public void onCreate(SQLiteDatabase ССылкаНаСозданнуюБазу)  ; ");
            }



            @Nullable
            @Override
            public Object loadInBackground() {
                Log.d(this.getClass().getName(), "Запущен.... метод  on public void onCreate(SQLiteDatabase ССылкаНаСозданнуюБазу)  ; ");

      for (int i=0;i<5;i++){
          Log.d(this.getClass().getName(), "Запущен.... метод  on public void onCreate(SQLiteDatabase ССылкаНаСозданнуюБазу)  ; ");
          try {
              TimeUnit.SECONDS.sleep(2);

              cancelLoadInBackground();
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
      }



                return null;
            }

            @Nullable
            @Override
            protected Object onLoadInBackground() {
                Log.d(this.getClass().getName(), "Запущен.... метод  on public void onCreate(SQLiteDatabase ССылкаНаСозданнуюБазу)  ; ");
                return super.onLoadInBackground();

            }

            @Override
            public void cancelLoadInBackground() {
                super.cancelLoadInBackground();
                Log.d(this.getClass().getName(), "Запущен.... метод  on public void onCreate(SQLiteDatabase ССылкаНаСозданнуюБазу)  ; ");
            }


        };
        asyncTaskLoader.forceLoad();*//*





        /////////
    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
               new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }
    }*/























    private void МетодЗапускаСлужбВШировоВещятелеУведомления() {


        try {


            Log.i(this.getClass().getName(), "ЗАПУСК из FAceapp СЛУЖБА СЛУЖБАService_Notifications doWork  MyWork_Notifocations_Уведомления время "
                    + new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation"));


            Constraints constraintsУведомления = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                    .setRequiresCharging(false)
                    .setRequiresBatteryNotLow(false)
                    .setRequiresStorageNotLow(false)
                    .build();
///
            ///
            ///
            String ИмяСлужбыУведомления="WorkManager NOtofocation";

            PeriodicWorkRequest periodicWorkRequestУведомления = new PeriodicWorkRequest.Builder(MyWork_Notifocations_Уведомления.class, 15, TimeUnit.MINUTES)//MIN_PERIODIC_FLEX_MILLIS
                    .setConstraints(constraintsУведомления)
                    .addTag(ИмяСлужбыУведомления)
                    //.setInputData(new Data.Builder().putString("КтоЗапустилWorkmanager","BroadCastRecieve").build())
                    .setInitialDelay(15, TimeUnit.SECONDS)
                    .build();


// Queue the work
            WorkManager.getInstance(getApplicationContext()).enqueueUniquePeriodicWork(ИмяСлужбыУведомления, ExistingPeriodicWorkPolicy.KEEP, periodicWorkRequestУведомления);





            Log.i(getClass().getName(), "После Запуска из  FaceAPP  СЛУЖБА СЛУЖБАService_Notifications ПОСЛЕ doWork  MyWork_Notifocations_Уведомления время "
                    + new Date() + " СТАТУС WORKMANAGER-----------" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation"));


            // TODO: 23.04.2021 jobs


            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.e(getClass().getName(), " Стоп из fACEAPP  СЛУЖБА Service_Notificatios_Уведомления в BroadCasrReciver onDestroy() Exception " + e.toString());


        }


    }









































    // TODO: 28.04.2021 принудительная синхронизация














    @Override
    protected void onDestroy() {
        super.onDestroy();



        ///TODO ЗАПУСК СЛУЖБЫ СПРАВОЧНИКА ФИО



    }




































    /////TODO метод синхронизхации данных обмен данными при запуске программы





    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(this.getClass().getName(), "onRestart()  FAce app " );


        try {
            TimeUnit.MILLISECONDS.sleep(30);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }






    @Override
    protected void onStop() {
        super.onStop();

        //
        try{

            ////TODO запуск службы справочкиа FIO

            //////TODO  данный код срабатывает когда произошда ошивка в базе


        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        //////TODO  данный код срабатывает когда произошда ошивка в базе

    /*    if(ССылкаНаСозданнуюБазу.isOpen()){
            if(ССылкаНаСозданнуюБазу.inTransaction()){

    ;
            }
            ССылкаНаСозданнуюБазу.close();
        }*/

    }




























    private void МетодНажатиеЗначекAPP() {

        //todo метод возврата к предыдущему активт

        imageView_ЗначекApp.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                Log.d(this.getClass().getName(), " кликнем для созданни новго сотрдника при нажатии  ");
                ///todo код которыц возврящет предыдущий актвитики кнопка back
                Log.d(this.getClass().getName(), "Во весь экран ");
                if (РежимыПросмотраДанныхЭкрана==false) {
                    try {
                        TimeUnit.MILLISECONDS.sleep(30);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    getSupportActionBar().show();
                    РежимыПросмотраДанныхЭкрана = true;
                    //  РежимыПросмотраДанныхЭкрана = false;
                }else{
                    try {
                        TimeUnit.MILLISECONDS.sleep(30);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    getSupportActionBar().hide();
                    РежимыПросмотраДанныхЭкрана = false;
                    ////
                    //////todo настрока экрана

                }

                return false;
            }
        });



    }





    //todo  ТАБЕЛЬНЫЙ УЧЁТ
    //// TODO  ЗАПУСКАЕМ ПО НОЖАТИЕ НА КНОППКУ ТАБЕЛЬНЫЙ УЧЁТ НА АКТИВИТИ FACE_APP МЕТОД СРАБОАТЫВАЕТ КОГДА НАЖИМАЕМ НА КНОППКУ ТАБЕЛЬНЫЙ УЧЕТ И ПЕРЕРХОДИМ НА СОЗДАНИЕ ТАБЕЛЯ
    void МетодЗапускаАктивити() {
        try{

            ////TODO

            КнопкаТабельныйУчёт.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{



                        /////
                        Vibrator v2 = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
                        // Vibrate for 500 milliseconds
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            v2.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                        } else {
                            //deprecated in API 26
                            v2.vibrate(150);
                        }




                        //todo запускаем если получент ПУБЛИЧНЫЙ ID ИЛИ ИЗ БАЗЫ ЛИБО С ИНТРЕНТА
                        Intent Интент_ЗапускТабельногоУчётаПервыйШаг=new Intent();
                        /////
                        // Интент_ЗапускТабельногоУчётаПервыйШаг.setClass(getApplication(),  MainActivity_List_Tabels.class); // ТУТ ЗАПВСКАЕТЬСЯ ВЫБОР ПРИЛОЖЕНИЯ КОТОРЫЕ ЕСТЬ FACE APP НА ДАННЫЙ МОМЕТНТ РАЗРАБОТНАО ТАБЕЛЬНЫЙ УЧЁТ

                        Интент_ЗапускТабельногоУчётаПервыйШаг.setClass(getApplication(),  MainActivity_List_Tabels.class); //  ТЕСТ КОД КОТОРЫЙ ЗАПУСКАЕТ ACTIVITY VIEWDATA  ПРОВЕРИТЬ ОБМЕН

                        Интент_ЗапускТабельногоУчётаПервыйШаг.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);


                        ////


                        //////
                        startActivity(Интент_ЗапускТабельногоУчётаПервыйШаг);
                        //////
                        ///finish();

                        КонтекстFaceAppВнешний=null;

                        //////
                    } catch (Exception e) {
                        //  Block of code to handle errors
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }
                }



            });


            /////TODO вторая кнопка настройки



//TODO кнопка настроки












            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }








    /// TODO МЕНЮ ГЛАВНОЕ НА АКТИВИТИ ПРОСМОТР ДАННЫХ/// МЕНЮ ГЛАВНОЕ НА АКТИВИТИ ПРОСМОТР ДАННЫХ/// МЕНЮ ГЛАВНОЕ НА АКТИВИТИ ПРОСМОТР ДАННЫХ/// МЕНЮ ГЛАВНОЕ НА АКТИВИТИ ПРОСМОТР ДАННЫХ/// МЕНЮ ГЛАВНОЕ НА АКТИВИТИ ПРОСМОТР ДАННЫХ
//#1
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        Log.d(this.getClass().getName(), "  Меню  запустилось на Активити FACE_APP");
        try{

            if (  Build.VERSION.SDK_INT >23) {

                MenuInflater inflater = getMenuInflater();
                inflater.inflate(R.menu.viewsdata_menu, menu);

            }else{
// добавляем пункты меню
                menu.add(0, 1, 0, "■ Отчёт Ошибок");
                menu.add(0, 2, 0, "■ Настройка");
                menu.add(0, 3, 3, "■ Пользователи");
                menu.add(1, 4, 1, "■ Обмен с данными");
                menu.add(1, 5, 2, "■ Шаблоны");
                menu.add(1, 6, 4, "■ Обновление ПО");
                menu.add(1, 7, 5, "■ Чат");

                return super.onCreateOptionsMenu(menu);
            }
            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return true;
    }

    //#2

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.d(this.getClass().getName(), "  Меню  запустилось на Активити FACE_APP");
        try{
            ///////
            switch (item.getItemId()) {
                ////

//////ПЕРВЫЙ ПРОСМОТР ОШИБОК//////ПЕРВЫЙ ПРОСМОТР ОШИБОК//////ПЕРВЫЙ ПРОСМОТР ОШИБОК//////ПЕРВЫЙ ПРОСМОТР ОШИБОК//////ПЕРВЫЙ ПРОСМОТР ОШИБОК
                case R.id.ПунктМенюПервый:
                case 1:
                    Log.e(this.getClass().getName(), "Хотите посмотреть ошибки ?");


                /*    if (PUBLIC_CONTENT.Отладка==true) {
                        МетодДиалогаДляМеню("Ошибки системы", "Посмотреть ошибки ?");*/



                        try{
                            ///TODO тестовый код
                            ////   МетодТестовыйЗапускВизуальноФайлаApK();

                            /////
                            Intent  Интент_Меню = new Intent(getApplication(), MainActivity_Errors.class);

                            Интент_Меню.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//////FLAG_ACTIVITY_SINGLE_TOP

                            startActivity(Интент_Меню);

                            ///TODO запуск службы
                            ///////
                        } catch (Exception e) {
                            //  Block of code to handle errors
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                    Thread.currentThread().getStackTrace()[2].getLineNumber());
                        }




                    return true;

//////ПЕРВЫЙ ОБНОВЛЕНИЕ ДАННЫХ//////ПЕРВЫЙ ОБНОВЛЕНИЕ ДАННЫХ//////ПЕРВЫЙ ОБНОВЛЕНИЕ ДАННЫХ//////ПЕРВЫЙ ОБНОВЛЕНИЕ ДАННЫХ//////ПЕРВЫЙ ОБНОВЛЕНИЕ ДАННЫХ

                case R.id.ПунктМенюВторой:
                    ///
                case 2:
                    Log.e(this.getClass().getName(), "Хотите посмотреть ошибки ?");

                /*    if (PUBLIC_CONTENT.Отладка==true) {
                        МетодДиалогаДляМеню("Настройка системы", "Перейти к настройкам системы ?");
                */


                        try{
                            ///TODO тестовый код
                            ////   МетодТестовыйЗапускВизуальноФайлаApK();

                            /////
                            Intent      Интент_Меню = new Intent(getApplication(), MainActivity_Settings.class);

                            Интент_Меню.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//////FLAG_ACTIVITY_SINGLE_TOP

                            startActivity(Интент_Меню);

                            ///TODO запуск службы
                            ///////
                        } catch (Exception e) {
                            //  Block of code to handle errors
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                    Thread.currentThread().getStackTrace()[2].getLineNumber());
                        }



                    return true;







////ТРЕТИЙ ПУНКТ ДОБАВЛЕНИЕ ДАННЫХ////ТРЕТИЙ ПУНКТ ДОБАВЛЕНИЕ ДАННЫХ////ТРЕТИЙ ПУНКТ ДОБАВЛЕНИЕ ДАННЫХ////ТРЕТИЙ ПУНКТ ДОБАВЛЕНИЕ ДАННЫХ////ТРЕТИЙ ПУНКТ ДОБАВЛЕНИЕ ДАННЫХ
                case R.id.ПунктМенюТретий:
                    ///
                case 3:
                    Log.d(this.getClass().getName(), "Сменить пользователя ?");


                    // TODO: 06.07.2021  пользователь СМЕНИТЬ

                    String ПолученыйТекущееИмяПользователя=new MODEL_synchronized(getApplicationContext()).МетодПолучениеИмяСистемыДляСменыПользователя(getApplicationContext());
                    //////
                    МетодДиалогаДляМеню("Пользователи Системы", "При смене пользователя,"
                            +"\n"+" поменяються и данные системы." +"\n"
                            + "Поменять пользователя ?" + "\n"
                            + " (текущий пользователь : ) " + ПолученыйТекущееИмяПользователя.toUpperCase());


                    ////////////////







                    return true;

// TODO СИНХРОНИЗАЦИЯ ДАННЫХ ПУКТО МЕНЮ
                case R.id. ПунктМенюЧетвертый:
                    ///
                case 4:
                    Log.d(this.getClass().getName(), "Синхронизация Данных с Web-сервера ДСУ-1 ?");


                    ///////TODO ТУТ ЗАПУСКАЕМ СИНХРОНИЗАЦИЮ В  ФОНЕ КОТОРАЯ НАХОДИТЬСЯ ЗАПУСКАЮЩИЙ МЕТОД В АКТИВИТИ  MainActivity_Tabel_Only_Single_Employee() СОТРУДНИКИ
        /*            if (PUBLIC_CONTENT.Отладка==true) {
                        МетодДиалогаДляМеню("Данных системы", "Запустить обмен данными?");
                  */
                        try{
                            // TODO: 09.04.2021 запуск синхронизации фоновой по расписанию
                            boolean РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию=
                                    new  Class_Find_Setting_User_Network(getApplicationContext()).МетодПроветяетКакуюУстановкуВыбралПользовательСети();

                            //TODO ФУТУРЕ ЗАВЕРШАЕМ
                            Log.d(this.getClass().getName(), "  РезультатПроВеркиУстановкиПользователяРежимРаботыСети " + РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию);
                            ///////////////

                            final boolean[] РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции = {false};


                            // TODO: 01.10.2021

                            PUBLIC_CONTENT public_contentЗапусСинхрониазцииИМеню=new PUBLIC_CONTENT(getApplicationContext());
                            //

                            final Integer[] ФинальныйРезультатФоновойСинхронизации = {0};
                            ///

                            // TODO: 12.10.2021  Ссылка Менеджер Потоков



                            class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков.submit(()->{

                                try{


                                    // TODO: 01.10.2021


                                    if (РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию==true) {


                                        ////////////
                                        РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции[0] =
                                                new Class_Connections_Server(getApplicationContext()).МетодПингаСервераРаботаетИлиНет(getApplicationContext());
                                    }

                                    // TODO: 16.07.2021
                                    Log.d(this.getClass().getName(), "РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции "+ РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции[0]);


                                    if (РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции[0] ==true) {
                                        ///////
                                        LinkedBlockingQueue ЗаполненыеСистемныеТаблицыДЛяСинхронизации = new Class__Generation_Genetal_Tables(getApplicationContext()).
                                                МетодЗаполеннияТаблицДЛяРаботыиСинхрониазции();
                                        //TODO ФУТУРЕ ЗАВЕРШАЕМ
                                        Log.d(this.getClass().getName(), "  ЗаполненыеСистемныеТаблицыДЛяСинхронизации " + ЗаполненыеСистемныеТаблицыДЛяСинхронизации.size());
                                        // TODO: 01.07.2021  ЗАПУСКАЕМ ВИЗУАЛЬНУЮ СИНХРОНИЗИЦИЮ С АКТИВТИ ЧДЕ КРУТИТЬСЯ ПРОГРЕСС БАР


                                        ФинальныйРезультатФоновойСинхронизации[0] =
                                                new Class_Async_Background(getApplicationContext()).
                                                        МетодЗАпускаФоновойСинхронизации(getApplicationContext(),
                                                                "СинхронизацияДляЧата", false, activity, ЗаполненыеСистемныеТаблицыДЛяСинхронизации,
                                                                "",0);  //TODO третить параментр false --указывает что обработка всех таблиц кроме чата


                                        //  МетодПринудительногоАЗпускаУведомлений();
                                        Log.d(this.getClass().getName(), "Синхронизация Данных с Web-сервера ДСУ-1 ?  ФинальныйРезультатФоновойСинхронизации "+ ФинальныйРезультатФоновойСинхронизации[0]);





                                    }else{

                                        activity.runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                ///

                                                Toast toast=       Toast.makeText(getApplicationContext(), "Нет связи с сервером !!!", Toast.LENGTH_LONG);

                                                toast.setGravity(Gravity.BOTTOM,0,40);
                                                toast.show();


                                            }
                                        });


                                    }

                                    //////////
                            } catch (Exception e) {
                                e.printStackTrace();
                                ///метод запись ошибок в таблицу
                                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                                Log.e(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА Service_Notificatios_Уведомления в MyWork_Notifocations_Уведомления Exception  ошибка в классе MyWork_Notifocations_Уведомления"+e.toString());


                            }finally {

                                    /////
                                    class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков.poll();

                                    ////
                                    activity.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            ///

                                            Toast toast=       Toast.makeText(getApplicationContext(), " Обмен Данными ↑  ↓   кол : "+ФинальныйРезультатФоновойСинхронизации[0], Toast.LENGTH_LONG);

                                            toast.setGravity(Gravity.BOTTOM,0,40);
                                            toast.show();


                                        }
                                    });
                                }

                            return ФинальныйРезультатФоновойСинхронизации[0];
                            });

                            //////////
                        } catch (Exception e) {
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                            Log.e(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА Service_Notificatios_Уведомления в MyWork_Notifocations_Уведомления Exception  ошибка в классе MyWork_Notifocations_Уведомления"+e.toString());


                        }


                    return true;

/*//СИНХРОНИЗАЦИЯ ДАННЫХ ПУКТО МЕНЮ
            case R.id.ПунктМенюПятый:
                Log.d(this.getClass().getName(), "Во весь экран ");
                if (РежимыПросмотраДанныхЭкрана==true) {
                    try {
                        TimeUnit.MILLISECONDS.sleep(30);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    getSupportActionBar().hide();
                    РежимыПросмотраДанныхЭкрана = false;

                    Log.d(this.getClass().getName(), "Синхронизация Данных с Web-сервера ДСУ-1 ?");
                  //  РежимыПросмотраДанныхЭкрана = false;
                }
                /// МетодДиалогаДляМеню(" Вид Просмотра Данных", "Просмотр во весь экран ?");
                return true;*/

                //шаблоны
                case R.id.ПунктМенюШестрой:
                    ///
                case 5:

                    if (РежимыПросмотраДанныхЭкрана==true) {


                        Log.d(this.getClass().getName(), "Шаблоны из меню?");

                        Intent Интент_BackВозвращаемАктивти = new Intent();
                        Интент_BackВозвращаемАктивти.setClass(getApplicationContext(), MainActivity_New_Templates_Tabels.class); // Т

                        ////todo запускаем активти
                        Интент_BackВозвращаемАктивти.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

                        Интент_BackВозвращаемАктивти.putExtra("ЗапускШаблоновFaceAppБлокировкаКнопкиДа",true);

                        ////

                        startActivity( Интент_BackВозвращаемАктивти);

                    }
                    /// МетодДиалогаДляМеню(" Вид Просмотра Данных", "Просмотр во весь экран ?");
                    return true;

                // TODO: 17.03.2021 обновление ПО
                case R.id.ПунктМенюСедьмой:
                    ///
                case 6:
                    Log.d(this.getClass().getName(), "Обновлени ПО ");
                    Toast.makeText(getApplicationContext(),
                            "запуск обновление ПО."    , Toast.LENGTH_SHORT).show();


                    // TODO: 17.03.2021 метд дополнительного удаления

                    ///  Intent IntentОбновлениеПО = new Intent(getApplicationContext(), Service_Update_ОбновлениеПО.class);

                    //////
                    //  IntentОбновлениеПО.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);


                    //// getApplicationContext().stopService(IntentОбновлениеПО);



                    МетодДополнительногоУдалениеФайлов();



                    ///   МетодЗапускДляАнализаОбновленияПО();



                    Log.d(getApplicationContext().getClass().getName(), " ЗАПУСК СЛУЖБА FACE_APP  МетодДополнительногоУдалениеФайлов " + "--" + new Date());/////
                    ////
                    МетодЗапускДляАнализаОбновленияПО();






                    /// МетодДиалогаДляМеню(" Вид Просмотра Данных", "Просмотр во весь экран ?");
                    return true;










                // TODO: 17.03.2021 ДАННЫЙ ПУЕКТ В МЕНЮ ЗАПУСКАЕТ ЧАТ
                case R.id.ПунктМенюВосьмой:
                    ///
                case 7:
                    Log.d(this.getClass().getName(), "Запускает Чат из меню   ");





          /*          Toast.makeText(getApplicationContext(),
                            "Запускаем Чат !!! "    , Toast.LENGTH_SHORT).show();*/


// TODO: 23.04.2021 запуск чата
                        Log.d(this.getClass().getName(), "Запускает Чат из меню   ");


                        Intent intentЗапускЧата=new Intent();


                            //////
                           // intentЗапускЧата.setClass(getApplicationContext(), MainActivity_history_chat_test.class);

                              intentЗапускЧата.setClass(getApplicationContext(), MainActivity_List_Chats.class);//рабочий






                        intentЗапускЧата.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                        startActivity(intentЗапускЧата);









                    // TODO: 17.03.2021 ДАННЫЙ ПУЕКТ В МЕНЮ ЗАПУСКАЕТ ЧАТ




                    return true;








////ПРОСТО ТАК НЕ ВЫБРАЛИ НИЧЕГО////ПРОСТО ТАК НЕ ВЫБРАЛИ НИЧЕГО////ПРОСТО ТАК НЕ ВЫБРАЛИ НИЧЕГО////ПРОСТО ТАК НЕ ВЫБРАЛИ НИЧЕГО////ПРОСТО ТАК НЕ ВЫБРАЛИ НИЧЕГО
                default:
                    Log.d(this.getClass().getName(), " МЕНЮ default:" + item.getItemId());

                    return super.onOptionsItemSelected(item);
                // break;

            } // конец switch (item.getItemId())





            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        return super.onOptionsItemSelected(item);

    }

























































    private void МетодДополнительногоУдалениеФайлов() {

        try{


/////TODO  УДАЛЕНИЕ .JSON ФАЙЛА
               /* File  ФайлыДляОбновлениеПОУдаление = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS + "/" + "*.json");*/

            File  ФайлыДляОбновлениеПОУдалениеПриАнализеJSONВерсии = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS );

            File[] Files = ФайлыДляОбновлениеПОУдалениеПриАнализеJSONВерсии.listFiles();

            if(Files != null) {
                int j;
                for(j = 0; j < Files.length; j++) {
                    String ИмяФайла=Files[j].getName();
                    boolean ПосикПоНазваниюФайла=ИмяФайла.matches("(.*)json(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");
                    boolean ПосикПоНазваниюФайлаРасширенная=ИмяФайла.matches("(.*)analysis_version(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");

                    if(ПосикПоНазваниюФайла==true || ПосикПоНазваниюФайлаРасширенная==true) {
                        Files[j].delete();
                        //
                        /////
                        if (!Files[j].isFile()) {
                            Log.d(this.getClass().getName(), " СЛУЖБА  ТАКОГО ФАЙЛА БОЛЬШЕ НЕТ  .JSON АНАЛИЗ " + Files[j].length()
                                    + "   путь файла " +  Files[j].getAbsolutePath() + "   --- "  +new Date() + " ИмяФайла "+ИмяФайла);
                        }
                    }
                    ////    ФайлыДляОбновлениеПОУдаление.delete();

                }//ещыыщ
            }





            /////TODO  УДАЛЕНИЕ .JSON ФАЙЛА
               /* File  ФайлыДляОбновлениеПОУдаление = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS + "/" + "*.json");*/

            if(Files != null) {
                int j;
                for(j = 0; j < Files.length; j++) {
                    String ИмяФайла=Files[j].getName();
                    boolean ПосикПоНазваниюФайла = ИмяФайла.matches("(.*)apk(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");
                    boolean ПосикПоНазваниюФайлаРасширенная = ИмяФайла.matches("(.*)update_dsu1(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");

                    if(ПосикПоНазваниюФайла==true || ПосикПоНазваниюФайлаРасширенная==true) {
                        Files[j].delete();
                        //
                        /////
                        if (!Files[j].isFile()) {
                            Log.d(this.getClass().getName(), " СЛУЖБА  ТАКОГО ФАЙЛА БОЛЬШЕ НЕТ  .JSON АНАЛИЗ " + Files[j].length()
                                    + "   путь файла " +  Files[j].getAbsolutePath() + "   --- "  +new Date() + " ИмяФайла "+ИмяФайла);
                        }
                    }
                    ////    ФайлыДляОбновлениеПОУдаление.delete();

                }//ещыыщ
            }










        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.d(this.getClass().getName(), " Стоп СЛУЖБА СЛУЖБАService_Notifications Обновление ПО onDestroy() Exception ");


        }
    }


    ///MESSGABOX ДЛЯ ГЛАВНОГО МЕНЮ    ///MESSGABOX ДЛЯ ГЛАВНОГО МЕНЮ    ///MESSGABOX ДЛЯ ГЛАВНОГО МЕНЮ    ///MESSGABOX ДЛЯ ГЛАВНОГО МЕНЮ    ///MESSGABOX ДЛЯ ГЛАВНОГО МЕНЮ    ///MESSGABOX ДЛЯ ГЛАВНОГО МЕНЮ    ///MESSGABOX ДЛЯ ГЛАВНОГО МЕНЮ
    @UiThread
    protected void МетодДиалогаДляМеню(String ШаблонСообщения, String Самообщение) {
        try {
//////сам вид
            final AlertDialog DialogBox = new MaterialAlertDialogBuilder(this)
                    .setTitle(ШаблонСообщения)
                    .setMessage(Самообщение)
                    .setPositiveButton("Да", null)
                    .setNegativeButton("Нет", null)
                    .setIcon(R.drawable.icon_dsu1_web_success)
                    .show();
            final Button MessageBox = DialogBox.getButton(AlertDialog.BUTTON_POSITIVE);
            MessageBox.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void onClick(View v) {
///запуск метода обновления через DIALOGBOX
                    try {
//удаляем с экрана Диалог
                        DialogBox.dismiss();
                        Intent Интент_Меню = new Intent();
                        //////
                        switch (ШаблонСообщения.trim()){
                            ///////todo по словам запускаем то что выбралив меню
                            case "Ошибки системы":

                                //todo ТЕКСТ КОД

                                try{
                                    ///TODO тестовый код
                                    ////   МетодТестовыйЗапускВизуальноФайлаApK();

                                    /////
                                    Интент_Меню = new Intent(getApplication(), MainActivity_Errors.class);

                                    Интент_Меню.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//////FLAG_ACTIVITY_SINGLE_TOP

                                    startActivity(Интент_Меню);

                                    ///TODO запуск службы
                                    ///////
                                } catch (Exception e) {
                                    //  Block of code to handle errors
                                    e.printStackTrace();
                                    ///метод запись ошибок в таблицу
                                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                                }




                                break;
                            ///////
                            case "Данных системы":

                        /*        Toast.makeText(getApplicationContext(),
                                        "запуск обмена данными."    , Toast.LENGTH_SHORT).show();*/
                 /*               ///TODO УСТАНАВЛИВАЕМ ФЛАГ ПРИ АУНТИФИКАЦИИ И МЯ И ПАРОЛЬ  СТАЫИМ ФЛАГ ОТКЛЮЧИТЬ ОБНОВЛЕНИЕ ПРИ СИНХРОНИЗАЦИИ false по умолчанию проверяем
                                new Class_Async_Background(getApplicationContext()).  МетодЗАпускаСинхронизациивФоне(КонтекстFaceApp);*/

                                try{


                                    /////////TODO запуск нновую нотификашенс устанолвка
                                    Intent intent = new Intent(getApplicationContext(), Service_Async_Синхронизация_Общая.class);
                                    intent.setAction(Intent.ACTION_BOOT_COMPLETED);
                                    intent.setAction(Intent.ACTION_REBOOT );
                                    //  intent.setAction(Intent.ACTION_LOCKED_BOOT_COMPLETED);






                                    getApplicationContext().startService( intent);///FLAG_UPDATE_CURRENT///


                                    Log.i(getApplicationContext().getClass().getName(),
                                            "Запуск СЛУЖБА СЛУЖБА Synchronizasiy_Data   startService   из BroadCasrReciver время "+new Date());


                                    Toast.makeText(getApplicationContext(),
                                            "конец обмена данными."    , Toast.LENGTH_SHORT).show();


                                    //////////
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    ///метод запись ошибок в таблицу
                                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                                            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                                            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

                                    Log.e(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА Service_Notificatios_Уведомления в MyWork_Notifocations_Уведомления Exception  ошибка в классе MyWork_Notifocations_Уведомления"+e.toString());


                                }



                                break;







                            ///////
                            case "Пользователи Системы":
                                /////todo меняем пользователя и меняем его данные под корень и ПЛЮЧ МЕНЯЕМ ВЕРСИЮ ДАННЫХ


                                boolean       РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции=false;

                                РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции=
                                        new Class_Connections_Server(getApplicationContext()).МетодПингаСервераРаботаетИлиНет(getApplicationContext());

                                // TODO: 16.07.2021

                                ///
                                Log.d(getApplicationContext().getClass().getName(), " РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции  " + "--"
                                        + РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции);/////



                                if (РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции) {

                        /*            if(PUBLIC_CONTENT.Отладка==true) {
                                        Toast aa = Toast.makeText(КонтекстFaceApp, "OPEN", Toast.LENGTH_SHORT);
                                        ImageView cc = new ImageView(КонтекстFaceApp);
                                        cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_success);//icon_dsu1_synchronisazia_dsu1_success
                                        aa.setView(cc);
                                        aa.show();
                                    }*/

                                    ///TODO УСТАНАВЛИВАЕМ ФЛАГ ПРИ АУНТИФИКАЦИИ И МЯ И ПАРОЛЬ  СТАЫИМ ФЛАГ ОТКЛЮЧИТЬ ОБНОВЛЕНИЕ ПРИ СИНХРОНИЗАЦИИ false по умолчанию проверяем

                                    // PUBLIC_CONTENT.ФлагПриПервомЗапускеОграничитьОперациюТолькоВставка=false;

                                    //////TODO  данный код срабатывает когда произошда ошивка в базе  ОЧИСТКА БАЗЫ И ПРИ СМЕНЕ ПОЛЬЗОВАТЕЛДЯ



                                    try{

                                        //////TODO  данный код срабатывает когда произошда ошивка в базе  ОЧИСТКА БАЗЫ И ПРИ СМЕНЕ ПОЛЬЗОВАТЕЛДЯ

                         Integer РезультатОчистикТАблицИДобалениеДаты=                       new Class_Clears_Tables(getApplicationContext()).ОчисткаТаблицДляПользователяЗапусксFaceApp(getApplicationContext(),
                                 class_async_backgroundГдеНаходитьсяМенеджерПотоков.МенеджерПотоков);
                                                //


                                        Log.d(this.getClass().getName(), "   ЗАПУСК ФОНРезультатОчистикТАблицИДобалениеДаты "+
                                                РезультатОчистикТАблицИДобалениеДаты);


// TODO: 09.09.2021 вызываем Интренит перерходим на активти ИМЯ И ПАРОЛЬ ПОВТОРНЫЙ ВХОД

                                        Intent finalИнтент_Меню = Интент_Меню;
                                        ////////
                                        ((Activity) КонтекстFaceApp).runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {

                                               /// КакойРежимСинхрониазции = ИнтентКакаяПоСчетуСинхронизация.getStringExtra("РежимЗапускаСинхронизации");


                                                finalИнтент_Меню.putExtra("РежимЗапускаСинхронизации","ПовторныйЗапускСинхронизации");

                                                /////TODO ЗАПУСКАМ ОБНОЛВЕНИЕ ДАННЫХ С СЕРВЕРА ПЕРЕРД ЗАПУСКОМ ПРИЛОЖЕНИЯ ВСЕ ПРИЛОЖЕНИЯ ДСУ-1
                                                finalИнтент_Меню.setClass(КонтекстFaceApp, MainActivity_Tabels_Users_And_Passwords.class); //MainActivity_Visible_Async //MainActivity_Face_App

                                                finalИнтент_Меню.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//////FLAG_ACTIVITY_SINGLE_TOP

                                                startActivity(finalИнтент_Меню);

                                                ////TODO ДАННАЯ КОМАНДА ПЕРЕКРЫВАЕТ НЕ ЗАПУСКАЕМОЕ АКТИВТИ А АКТИВТИ КОТОРЕ ЕГО ЗАПУСТИЛО
                                                finishAffinity();
                                            }
                                        });

                                    } catch (Exception e) {
                                        //  Block of code to handle errors
                                        e.printStackTrace();
                                        ///метод запись ошибок в таблицу
                                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                        new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                                    }




                                }else{

                                /*    Toast aa = Toast.makeText(КонтекстFaceApp, "OPEN",Toast.LENGTH_SHORT);
                                    ImageView cc = new ImageView(КонтекстFaceApp);
                                    cc.setImageResource(R.drawable.icon_dsu1_add_organisazio_error);//icon_dsu1_synchronisazia_dsu1_success
                                    aa.setView(cc);
                                    aa.show();*/

                                    ////
                                    //  Toast.makeText(context, "данных для Cинхронизации в фоне нет !!!!" , Toast.LENGTH_SHORT).show();





                                    Toast.makeText(getApplicationContext(), "Нет связи c Cервер ", Toast.LENGTH_SHORT).show();

                                    Snackbar.make(v, "Нет связи c Cервер/Интернетом ", Snackbar.LENGTH_LONG).show();
                                }
                                ////
                                break;
                            ///////
                            case "Настройка системы":
                                /////данные с потока
                                /////TODO ЗАПУСКАМ ОБНОЛВЕНИЕ ДАННЫХ С СЕРВЕРА ПЕРЕРД ЗАПУСКОМ ПРИЛОЖЕНИЯ ВСЕ ПРИЛОЖЕНИЯ ДСУ-1
                                Интент_Меню.setClass(getApplication(),  MainActivity_Settings.class); //MainActivity_Visible_Async //MainActivity_Face_App
                                Интент_Меню.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//////FLAG_ACTIVITY_SINGLE_TOP
                                startActivity( Интент_Меню);
                                ////TODO ДАННАЯ КОМАНДА ПЕРЕКРЫВАЕТ НЕ ЗАПУСКАЕМОЕ АКТИВТИ А АКТИВТИ КОТОРЕ ЕГО ЗАПУСТИЛО
                                finish();
                                break;
                        }

//ловим ошибки
                    } catch (Exception e) {
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                        new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                        // конец запись в файл
                    }

                }






            });

        } catch (Exception e) {
            e.printStackTrace();
///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
           new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        ///////////СЕРВЕР  ///////////СЕРВЕР  ///////////СЕРВЕР  ///////////СЕРВЕР  ///////////СЕРВЕР  ///////////СЕРВЕР  ///////////СЕРВЕР  ///////////СЕРВЕР  ///////////СЕРВЕР

    }







    /////////TODO ЗАУСК APK

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void МетодТестовыйЗапускВизуальноФайлаApK() throws IOException, JSONException {

        try{




   /*     String destination = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/";
        String fileName = "update_dsu1.apk";
        destination += fileName;
        Uri uri = Uri.parse("file://" + destination);*/

            File ФайлыДляОбновлениеПО = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS + "/" + "update_dsu1.apk");


            Log.d(this.getClass().getName(), "    ПУТИ В ФАЙЛУ   " + "\n"
                    + ФайлыДляОбновлениеПО);


            if (ФайлыДляОбновлениеПО.isFile()) {

                Log.d(this.getClass().getName(), "  storageDir.getAbsolutePath()  " + ФайлыДляОбновлениеПО.getAbsolutePath() + "\n" +
                        "  storageDir.getCanonicalPath()   " + ФайлыДляОбновлениеПО.getCanonicalPath() + "\n" +
                        " storageDir.getName() " + ФайлыДляОбновлениеПО.getName() + "\n" +
                        "  storageDir.exists() " + ФайлыДляОбновлениеПО.exists() + "\n" +
                        "+storageDir.length() " + ФайлыДляОбновлениеПО.length());





                ///TODO  ЗАПУСКА APK ФАЙЛОВ

           /* Uri uri = Uri.parse("file:///sdcard/xxx/log.txt");
            Intent viewTestLogFileIntent = new Intent(Intent.ACTION_EDIT);
            viewTestLogFileIntent.setData(uri);
            viewTestLogFileIntent.setType("text/plain");
            code3: который я пробовал и работал нормально

            Uri uri = Uri.parse("file:///sdcard/xxx/log.txt");
            Intent viewTestLogFileIntent = new Intent(Intent.ACTION_EDIT);
            viewTestLogFileIntent.setDataAndType(uri,"text/plain");*/



                File ФайлыДляОбновлен = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS + "/" + "analysis_version.txt");///analysis_version.json //analysis_version.txt  //update_dsu1.apk


                if (ФайлыДляОбновлен.isFile()) {
                    Uri uri = Uri.parse("file://" + "analysis_version.txt");

       /*         Uri videoUri = FileProvider.getUriForFile(this,
                        getApplicationContext().getPackageName() + ".provider",
                        new File(destination));

// устанавливаем флаг для того, чтобы дать внешнему приложению пользоваться нашим FileProvider
                String destination2 = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/";
                String fileName2 = "analysis_version.txt";
                destination2 += fileName2;
                Uri textUri = FileProvider.getUriForFile(this,
                        getApplicationContext().getPackageName() + ".provider",
                        new File(destination));*/

                }




                String destination = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/";
                String fileName = "update_dsu1.apk";
                destination += fileName;





                Uri textUri3 = FileProvider.getUriForFile(this,
                        getApplicationContext().getPackageName() + ".provider",
                        new File(destination));

                Intent intent = new Intent(Intent.ACTION_INSTALL_PACKAGE);
                intent.setDataAndType(textUri3, "application/vnd.android.package-archive");
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION| Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                        | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true);



// подтвердите, что устройство может открыть этот файл!
                PackageManager pm = getApplicationContext().getPackageManager();
                if (intent.resolveActivity(pm) != null) {
                    startActivity(intent);
                    finishAndRemoveTask();
                }







                Log.d(this.getClass().getName(), "  ФайлыДляОбновлениеПО " + ФайлыДляОбновлен.exists() + " ФайлыДляОбновлен.length() " +ФайлыДляОбновлен.length());







            } else {
                Log.d(this.getClass().getName(), "  ОШИБКА НЕТ КАКОГО ФАЙЛА  . APK" + ФайлыДляОбновлениеПО.length());
            }











        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }





    }

















































































///// TODO: 10.02.2021 МЕТОД ЗАПУСК СЛУЖБЫ



    private void МетодЗапускДляАнализаОбновленияПО() {


        try{
            //////////////////////TODO SERVICE

            //////////////////////TODO SERVICE

            String[] permissions = new String[]{
                    Manifest.permission.INTERNET,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.VIBRATE,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.REQUEST_INSTALL_PACKAGES,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS,
                    Manifest.permission.MANAGE_EXTERNAL_STORAGE,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.ACCESS_MEDIA_LOCATION,
                    Manifest.permission.INSTALL_PACKAGES,
                    Manifest.permission.WRITE_SETTINGS,
                    Manifest.permission.WRITE_SECURE_SETTINGS



            };

            //  startService(new Intent(КонтекстFaceApp, Service_UpdateSoft.class));
////TODO УСТАНВЛИВАЕМ РАЗРЕШЕНИЯ НА ВСЕ ПРИЛОЖЕНИЯ НАСТРОЙКИ
            try {
                ActivityCompat.requestPermissions(this, permissions, 1);
            } catch (Exception e) {
                e.printStackTrace();
            }

            ///TODO запуск службы
            if (Build.VERSION.SDK_INT >= 23) {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                }
                else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                }
            }


            ///TODO запускаем службу если несть права на   WRITE_EXTERNAL_STORAGE
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

                Log.d(this.getClass().getName(), " УСТАНОВКА ПРАВ ДЛЯ ЗАПУСК СЛУЖБА ОБНОВЛЕНИЯ ПО ... " + new Date());



                /////


// TODO: 11.05.2021 ЗПУСКАЕМ СЛУЖБУ ОБНОВЛЕНИЕ ПО


                Constraints constraintsОбновлениеПОЛокально= new Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .setRequiresCharging(false)
                        .setRequiresBatteryNotLow(false)
                        .setRequiresStorageNotLow(false)
                        .build();
                ///
String ИмяСлужбыОбнолвенияПО="WorkManager ОбновлениеПО Локально";


                OneTimeWorkRequest   OneTimeWorkRequestОбновлениеПОЛокально= new OneTimeWorkRequest.Builder(MyWork_Update_ОбновлениеПО.class)
                        .setConstraints(constraintsОбновлениеПОЛокально)
                        //    .setInputData(new Data.Builder().putString("КтоЗапустилWorkmanager","BroadCastRecieve").build())
                        .setInitialDelay(6,TimeUnit.SECONDS)
                        .addTag(ИмяСлужбыОбнолвенияПО)
                        .build();


// Queue the work
                WorkManager.getInstance(getApplicationContext()).enqueueUniqueWork(ИмяСлужбыОбнолвенияПО, ExistingWorkPolicy.REPLACE, OneTimeWorkRequestОбновлениеПОЛокально);
                // WorkManager.getInstance().enqueue(periodicWorkRequest);// workmanager.enqueueUniquePeriodicWork(TAG, ExistingPeriodicWorkPolicy.KEEP, photoCheckWork)




                Log.i(this.getClass().getName(), "После Запуска из  FaceApp  СЛУЖБА ОбновлениеПО  ПОСЛЕ doWork ОбновлениеПО  время "
                        +new Date() + " СТАТУС WORKMANAGER-----------" +WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager ОбновлениеПО"));

























/*
                Intent intentОбновлениеПО = new Intent(this, Service_Update_ОбновлениеПО.class);
                intentОбновлениеПО.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intentОбновлениеПО.setAction(Intent.ACTION_SCREEN_OFF);
                intentОбновлениеПО.setAction(Intent.ACTION_SCREEN_ON);
                intentОбновлениеПО.setAction(Intent.ACTION_BOOT_COMPLETED);
                intentОбновлениеПО.setAction(Intent.ACTION_REBOOT );
                intentОбновлениеПО.setAction(Intent.ACTION_LOCKED_BOOT_COMPLETED);
                intentОбновлениеПО.setAction(Intent.ACTION_SCREEN_OFF);
                intentОбновлениеПО.setAction(Intent.ACTION_SYNC);
                intentОбновлениеПО.setAction(Intent.ACTION_INSTALL_PACKAGE);
                intentОбновлениеПО.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION );
                intentОбновлениеПО.setFlags(Intent. FLAG_GRANT_WRITE_URI_PERMISSION );



*//*
Handler handler=new Handler();
handler.postDelayed(new Runnable() {
    @Override
    public void run() {*//*




                    startService(intentОбновлениеПО);
*//*

    }
},3000);
*/


            }else{
                Log.d(this.getClass().getName(), "НЕТ ПРАВ ДЛЯ ЗАПУСКА СЛУЖБА  ОБВНОВЛЕНИЕ ПО" );
            }














        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


    }











    //
















































    /////////TODO метод анализа версии

//   /* protected int МетодАнализаВерсииДанных() throws IOException, JSONException {
//        int  ПолученнаяВерсияПОДЛяОбновления = 0;
//        try {
//
//            Log.d(this.getClass().getName(), "Сработала... Загрузка Службы Файла ПО"
//                    + "   PUBLIC_CONTENT. downloadId " + PUBLIC_CONTENT.downloadId);
//
//
//   *//*     String destination = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/";
//        String fileName = "update_dsu1.apk";
//        destination += fileName;
//        Uri uri = Uri.parse("file://" + destination);*//*
//
//     *//*       File ФайлыДляОбновлениеПО = Environment.getExternalStoragePublicDirectory(
//                    Environment.DIRECTORY_DOWNLOADS + "/" + "update_dsu1.apk");
//
//
//            Log.d(this.getClass().getName(), "    ПУТИ В ФАЙЛУ   " + "\n"
//                    + ФайлыДляОбновлениеПО);
//
//
//            if (ФайлыДляОбновлениеПО.isFile()) {
//
//                Log.d(this.getClass().getName(), "  storageDir.getAbsolutePath()  " + ФайлыДляОбновлениеПО.getAbsolutePath() + "\n" +
//                        "  storageDir.getCanonicalPath()   " + ФайлыДляОбновлениеПО.getCanonicalPath() + "\n" +
//                        " storageDir.getName() " + ФайлыДляОбновлениеПО.getName() + "\n" +
//                        "  storageDir.exists() " + ФайлыДляОбновлениеПО.exists() + "\n" +
//                        "+storageDir.length() " + ФайлыДляОбновлениеПО.length());
//
//
//            } else {
//                Log.d(this.getClass().getName(), "  ОШИБКА НЕТ КАКОГО ФАЙЛА " + ФайлыДляОбновлениеПО.length());
//            }*//*
//
//
//////TODO АНАЛИЗ ВЕРСИ ДАННЫХ КОТОРЫЕ ПРИШЛИ С СЕРВЕРА
//
//
//            File  ФайлыДляОбновлениеПО = Environment.getExternalStoragePublicDirectory(
//                    Environment.DIRECTORY_DOWNLOADS + "/" + "analysis_version.json");
//
//
//            Log.d(this.getClass().getName(), "    ПУТИ В ФАЙЛУ   " + "\n"
//                    + ФайлыДляОбновлениеПО);
//
//
//            if (ФайлыДляОбновлениеПО.isFile()) {
//
//                Log.d(this.getClass().getName(), "  storageDir.getAbsolutePath()  " + ФайлыДляОбновлениеПО.getAbsolutePath() + "\n" +
//                        "  storageDir.getCanonicalPath()   " + ФайлыДляОбновлениеПО.getCanonicalPath() + "\n" +
//                        " storageDir.getName() " + ФайлыДляОбновлениеПО.getName() + "\n" +
//                        "  storageDir.exists() " + ФайлыДляОбновлениеПО.exists() + "\n" +
//                        "+storageDir.length() " + ФайлыДляОбновлениеПО.length());
//
//
//////TODO если json файл существует то начинаем из него плучать данные
//
//
//              *//*  File file = getBaseContext().getFileStreamPath( "analysis_version.json");
//
//
//                Log.d(this.getClass().getName(), "  storageDir.getAbsolutePath()  " + ФайлыДляОбновлениеПО.getAbsolutePath() + " file.length()" +file.length());*//*
//
//                *//*FileInputStream fin = openFileInput(Environment.DIRECTORY_DOWNLOADS + "/" + "analysis_version.json");
//
//           int y=     fin.available();*//*
//
//               // Log.d(this.getClass().getName(), "  storageDir.getAbsolutePath()  " + ФайлыДляОбновлениеПО.getAbsolutePath() + "  y" +y);
//                /////
//                StringBuffer БуферДляАнализаПО = new StringBuffer();
//                //////////
//                BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(ФайлыДляОбновлениеПО), StandardCharsets.UTF_8));
//                ///todo переираем версию файлов
//                for (String line; (line = r.readLine()) != null; ) {
//
//                    БуферДляАнализаПО.append(line).append('\n');
//
//                    System.out.println("File content:   line " + line);
//
//                }//TODO END FOR
//
//                r.close();
//
//                System.out.println("File content: " + БуферДляАнализаПО.toString() + "   БуферДляАнализаПО " + БуферДляАнализаПО.toString()
//                        + "    БуферДляАнализаПО.length() " + БуферДляАнализаПО.length());
//
//
//                ///TODO Читаем JSON
//
//
//                JSONObject JSONДляАналиазПО = new JSONObject(БуферДляАнализаПО.toString());
//
//                JSONArray МассивJSONТаблиц = JSONДляАналиазПО.names();
//                String НазваниеИзПришедшихТаблицДляКлиента;
//                String СодержимоеИзПришедшихТаблицДляКлиента;
//                String JSONСтрочка;
//                String JSONНазваниеСтолбика = null;
//                String JSONСодержимоеСтолика;
//                String JSONСодержимоеСтоликаДляХэша;
//                JSONArray МассивJSONТаблиц2;
//
//
//                for (int ИндексТаблицыДляДанногоКлиента = 0; ИндексТаблицыДляДанногоКлиента < JSONДляАналиазПО.names().length(); ИндексТаблицыДляДанногоКлиента++) {
//                    ////// распарсиваем  josn
//                    НазваниеИзПришедшихТаблицДляКлиента = МассивJSONТаблиц.getString(ИндексТаблицыДляДанногоКлиента);
//
//                    СодержимоеИзПришедшихТаблицДляКлиента = JSONДляАналиазПО.getString(НазваниеИзПришедшихТаблицДляКлиента); // Here's
//
//
//                    System.out.println(" НазваниеИзПришедшихТаблицДляКлиента" + НазваниеИзПришедшихТаблицДляКлиента +
//                            "  СодержимоеИзПришедшихТаблицДляКлиента " + СодержимоеИзПришедшихТаблицДляКлиента);
//                    String СодержимоеИзПришедшихТаблицДляКлиентаdd;
//
//                    int СодержимоеИзПришедшихТабл = СодержимоеИзПришедшихТаблицДляКлиента.lastIndexOf("versionCode");
//                    int СодержимоеИзПришедшихТабл2 = СодержимоеИзПришедшихТаблицДляКлиента.indexOf("versionName");
//
//                    if (СодержимоеИзПришедшихТабл >= 0 && СодержимоеИзПришедшихТабл2 >= 0) {
//
//                        СодержимоеИзПришедшихТаблицДляКлиентаdd = СодержимоеИзПришедшихТаблицДляКлиента.substring(СодержимоеИзПришедшихТабл, СодержимоеИзПришедшихТабл2);
//                        ///
//                        System.out.println("   СодержимоеИзПришедшихТаблицДляКлиентаdd  " + СодержимоеИзПришедшихТаблицДляКлиентаdd);
//
//                        String numberOnly = СодержимоеИзПришедшихТаблицДляКлиентаdd.replaceAll("[^0-9]", "");
//
//                        System.out.println("   numberOnly  " + numberOnly);
//
//
//                        ПолученнаяВерсияПОДЛяОбновления = Integer.parseInt(numberOnly);
//                        System.out.println("  ПолученнаяВерсияПОДЛяОбновления " + ПолученнаяВерсияПОДЛяОбновления);
//
//                        ///
//                        break;
//
//                    }
//
//
//                    /////ЦИКЛ КОТРЫЙ БЕЖИТ ПО СТОЛБЦАМ  ПРИГЕДШЕГО JSON ФАЙЛА И НАХОДИМ НАЩШИ ТАЮЛИЦЫ ДЛЯ УКАЗАННОГО ПОЛЬЗОВАТСЯ
//
//
//                *//*//*/TODO УДАЛЕНИЕ ФАЙЛОВ ПОЛЕ АНАЛИЗА
//            ФайлыДляОбновлениеПО.delete();
//            /////
//            if (!ФайлыДляОбновлениеПО.isFile()) {
//                Log.d(this.getClass().getName(), "  ТАКОГО ФАЙЛА БОЛЬШЕ НЕТ  JSON АНАЛИЗ " + ФайлыДляОбновлениеПО.length());
//            }*//*
//
//
//                } //TODO  END  if (ФайлыДляОбновлениеПО.isFile())
//            }
//
//        } catch(Exception e){
//            e.printStackTrace();
//            ///метод запись ошибок в таблицу
//            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
//                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
//            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
//                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
//        }
//
//
//        return ПолученнаяВерсияПОДЛяОбновления;
//
//    }*/












    }








