package com.dsy.dsu;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.WindowManager;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity_List_Chats extends AppCompatActivity {


    FragmentManager fragmentManager;
    ///
    FragmentTransaction fragmentTransaction;

String РежимЗапускаАктивтиЧата=new String();
////
int ПолученыйIDДляЧата=0;

String ПолученыйФИОIDДляЧата=new String();


HashMap<String, Object> ХэщЗапусАктивтиИзФрагмента=null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try{
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main_history_chat);



            ////
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);

            /////


            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);


            Intent ОбменДаннымиСДругимиАктивити = getIntent();
            /////
        ХэщЗапусАктивтиИзФрагмента = (HashMap<String, Object>)ОбменДаннымиСДругимиАктивити.getSerializableExtra("ОбменМеждуАктивти");

            if (ХэщЗапусАктивтиИзФрагмента!=null) {
                ////
                Log.d(this.getClass().getName(), "   ХэщЗапусАктивтиИзФрагмента "+ХэщЗапусАктивтиИзФрагмента.values());

                ///

                РежимЗапускаАктивтиЧата=   ХэщЗапусАктивтиИзФрагмента.get("ЗапускАктивтиЧатИзФрагмента").toString();


                Log.d(this.getClass().getName(), "   РежимЗапускаАктивтиЧата "+РежимЗапускаАктивтиЧата);

                ////////////////////////ID приповтроном входет

                if (!РежимЗапускаАктивтиЧата.equalsIgnoreCase("Повторный Запск Фрагмента Контактов")) {
                    //////
                    if (РежимЗапускаАктивтиЧата.length()>0) {
                        ///
                        ПолученыйIDДляЧата= (int) ХэщЗапусАктивтиИзФрагмента.get("ПолученыйIDДляЧата");


                        Log.d(this.getClass().getName(), "   ПолученыйIDДляЧата "+ПолученыйIDДляЧата);

                        ///
                        ПолученыйФИОIDДляЧата= (String) ХэщЗапусАктивтиИзФрагмента.get("ПолученыйФИОIDДляЧата");



                        Log.d(this.getClass().getName(), "   ПолученыйФИОIDДляЧата "+ПолученыйФИОIDДляЧата);

                    }
                }

                ///




            }


// TODO: 27.04.2021 формируем внешний вид Чата через фрагменты



            //////////


            fragmentManager=getSupportFragmentManager();
            ///
            fragmentTransaction=fragmentManager.beginTransaction();




            /////////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }






    //////////////////////////////////////////////////////////////МОДЕЛЬ MVC  ////////////////////////////////////////////////////////////////////////





    @Override
    protected void onStart() {
        super.onStart();
        //
        try{

            // TODO: 16.06.2021


        new MainActivity_List_Chats.MODEL(fragmentManager);

            // TODO: 16.06.2021 ЗАПУСКАЕМ НА АКТИВТИ ЧАТ КЛАСС VIEW КОТОРЫЙ ОТВЕЧАЕТ ЗА ОТОБРАЖЕНИЯ ИНФОРМАЦИИ И КЛИК

            new MainActivity_List_Chats.VIEW(fragmentManager);

            // TODO: 16.06.2021


            new MainActivity_List_Chats.CONTROLLER(fragmentManager);



            /////////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


    }



















// TODO: 16.06.2021


    private class CONTROLLER {


        public CONTROLLER( FragmentManager fragmentManager ) {

            //
            try{

                
             
                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }




















    }

    private class MainAdapter extends FragmentPagerAdapter {

        ArrayList<String> stringArrayList=new ArrayList<>();
        //
        List<Fragment> fragmentList=new ArrayList<>();


        /**
         *
         */
        public void addFragment(Fragment fragment,String title){
            ////add title

            stringArrayList.add(title);
            ///
            fragmentList.add(fragment);

        }


        public MainAdapter(@NonNull @NotNull FragmentManager fm) {
            super(fm);
        }

        @NonNull
        @NotNull
        @Override
        public Fragment getItem(int position) {
            /**
             * return fragment position
             */
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        @Nullable
        @org.jetbrains.annotations.Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            /**
             * Return array list position
             */
            return stringArrayList.get(position);
        }
    }















// TODO: 16.06.2021

    private class MODEL{


        public MODEL( FragmentManager fragmentManager) {

            //
            try{







                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }





    }

// TODO: 16.06.2021


    private class VIEW {


        public VIEW(FragmentManager fragmentManager) {

            //
            try{




                Log.d(this.getClass().getName(), "   МетодОдинОтображаетьсяФрагмента(fragmentManager); РежимЗапускаАктивтиЧата"+РежимЗапускаАктивтиЧата);


                switch (РежимЗапускаАктивтиЧата){

                    case "Повторный Запск Фрагмента Контактов":

                        МетодОдинОтображаетьсяФрагментаПовторноеЗапускКонтактом(fragmentManager); ///ПОСЛЕ ВЫБОРА




                        Log.d(this.getClass().getName(), "   МетодОдинОтображаетьсяФрагмента(fragmentManager)  Повторный Запск Фрагмента Контактов ;");
                        //////////

                        break;
                    // TODO: 25.06.2021  запускаем код работает сразу два фрагмента









                    case "Повторный Запск Активти  Для Третьего Фрагмента":

                        МетодОдинОтображаетьсяФрагмента(fragmentManager); ///ПОСЛЕ ВЫБОРА




                        Log.d(this.getClass().getName(), "   МетодОдинОтображаетьсяФрагмента(fragmentManager);");
                        //////////

                        break;
                    // TODO: 25.06.2021  запускаем код работает сразу два фрагмента






                    default:

                        // TODO: 25.06.2021 ПЕРВЫЙ ЗАПУСК ФОРАГМЕНТОВ С СООБЩЕНИЯМИ


                        МетодОтображаетьсяДваФрагмента(fragmentManager);

                        Log.d(this.getClass().getName(), "     МетодОтображаетьсяДваФрагмента(fragmentManager);");

                        ///////
                        break;

                }

                // TODO: 05.07.2021






                /////////////
            } catch (Exception e) {
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                        " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                        Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
            }
        }

        // TODO: 25.06.2021  два фрагмента

        private void МетодОтображаетьсяДваФрагмента(FragmentManager fragmentManager) {

try{

            Fragment_Messages_СообщенияЧата fragment_Messages_сообщенияЧата =new Fragment_Messages_СообщенияЧата();
            ///
            fragmentTransaction.add(R.id.Layoutmain_for_chats, fragment_Messages_сообщенияЧата);



            fragmentTransaction.commit();



            Bundle bundleДляЧаста=new Bundle();
            ///
            //Put string

            ////
            //
            bundleДляЧаста.putString("ДаннеыДляФрагментаЧат","Создания Чата");


            //////
            // TODO: 22.06.2021  фрагменты

            ///todo публикум название таблицы или цифру его
    /////////////
} catch (Exception e) {
    e.printStackTrace();
    ///метод запись ошибок в таблицу
    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
            " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
    new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
            Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
}

        }

        // TODO: 25.06.2021 один фрагмент















        private void МетодОдинОтображаетьсяФрагмента(FragmentManager fragmentManager) {

  try{
            ///
            Bundle bundleДляФрагментаЧитатьПисатьПосылаемIDиФИО=new Bundle();
            ///

            // TODO: 29.06.2021 Получениый ID выбраного сотрудника передаем в фрагмент
            bundleДляФрагментаЧитатьПисатьПосылаемIDиФИО.putInt("ПолученыйIDДляЧата", ПолученыйIDДляЧата);

            bundleДляФрагментаЧитатьПисатьПосылаемIDиФИО.putString("ПолученыйФИОIDДляЧата", ПолученыйФИОIDДляЧата);

            Log.d(this.getClass().getName(), " ПолученыйIDДляЧата  "+ПолученыйIDДляЧата + "ПолученыйФИОIDДляЧата " +ПолученыйФИОIDДляЧата);

            //


            Fragment_Writer_Read_ЧитатьПисатьЧата fragment_WriterRead_читатьПисатьЧата =new Fragment_Writer_Read_ЧитатьПисатьЧата();

            /////
            fragment_WriterRead_читатьПисатьЧата.setArguments(bundleДляФрагментаЧитатьПисатьПосылаемIDиФИО);

            ///
            fragmentTransaction.replace(R.id.Layoutmain_for_chats, fragment_WriterRead_читатьПисатьЧата);

            ///
            fragmentTransaction.commit();




            // TabLayoutИзЧата.getTabAt(1).setIcon(R.mipmap.icon_dsu1_emloeys_sonrudnik);     TabLayoutИзЧата.getTabAt(2).setTabLabelVisibility(TabLayout.TAB_LABEL_VISIBILITY_UNLABELED);


/*
                TabLayoutИзЧата.addTab(TabLayoutИзЧата.newTab().setText("Tab 1"));



                ///
                TabLayoutИзЧата.addTab(TabLayoutИзЧата.newTab().setText("Tab 2"));*/

/*
            TabLayoutИзЧата.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {



                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация   " + new Date()+" tab " +tab.getText());


                    //


                    String КакойTab=tab.getText().toString();

                    switch (КакойTab)
                    {
                        case "Чат":
                            // your logic goes here!



                            Fragment_Messages_СообщенияЧата ФрагментRead_СообщенияЧата=new Fragment_Messages_СообщенияЧата();
                            ////
                            //  TabLayoutИзЧата.getTabAt(1).setText("ffffffff").setIcon();


                            ////
                            FragmentTransaction fTransФрагментRСообщенияЧата;
                            fTransФрагментRСообщенияЧата = fragmentManager.beginTransaction();
                            fTransФрагментRСообщенияЧата.replace(R.id.Relativemain_for_chats, ФрагментRead_СообщенияЧата); // fTrans.add(R.id.frgmCont, frag1);
                            fTransФрагментRСообщенияЧата.addToBackStack(null).commit();
                            ///
                            break;
*//*

                        // ...
                        case "Контакты":
                            // your logic goes here!

                            Fragment_Contacts_КонтактыЧата ФрагментКонтакты=new Fragment_Contacts_КонтактыЧата();
                            ////
                            //  TabLayoutИзЧата.getTabAt(1).setText("ffffffff").setIcon();


                            ////
                            FragmentTransaction fTransФрагментКонтакты;
                            fTransФрагментКонтакты = fragmentManager.beginTransaction();
                            fTransФрагментКонтакты.add(R.id.Relativemain_for_chats, ФрагментКонтакты); // fTrans.add(R.id.frgmCont, frag1);
                            fTransФрагментКонтакты.addToBackStack(null).commit();
                            ////
                            break;
*//*

                        // ...


                        //



                        // ...

                    }

                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {
                    Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация   " + new Date());





                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {
                    Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация   " + new Date());
                }

            });*/


            /////////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

        }


        // TODO: 02.07.2021 метод повтоного запуска фрагмента контактов


























        // TODO: 25.06.2021 один фрагмент



        private void МетодОдинОтображаетьсяФрагментаПовторноеЗапускКонтактом(FragmentManager fragmentManager) {

            try{



            Bundle bundleДляЧаста=new Bundle();
            ///
            // TODO: 29.06.2021 Получениый ID выбраного сотрудника передаем в фрагмент
            bundleДляЧаста.putInt("ПолученыйIDДляЧата", ПолученыйIDДляЧата);






            Fragment_Contacts_КонтактыЧата fragment_Contacts_контактыЧата =new Fragment_Contacts_КонтактыЧата();
            ///
            fragmentTransaction.replace(R.id.Layoutmain_for_chats, fragment_Contacts_контактыЧата);
            ////
            fragmentTransaction.commit();




            // TabLayoutИзЧата.getTabAt(1).setIcon(R.mipmap.icon_dsu1_emloeys_sonrudnik);     TabLayoutИзЧата.getTabAt(2).setTabLabelVisibility(TabLayout.TAB_LABEL_VISIBILITY_UNLABELED);


/*
                TabLayoutИзЧата.addTab(TabLayoutИзЧата.newTab().setText("Tab 1"));



                ///
                TabLayoutИзЧата.addTab(TabLayoutИзЧата.newTab().setText("Tab 2"));*/

/*
            TabLayoutИзЧата.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {



                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация   " + new Date()+" tab " +tab.getText());


                    //


                    String КакойTab=tab.getText().toString();

                    switch (КакойTab)
                    {
                        case "Чат":
                            // your logic goes here!



                            Fragment_Messages_СообщенияЧата ФрагментRead_СообщенияЧата=new Fragment_Messages_СообщенияЧата();
                            ////
                            //  TabLayoutИзЧата.getTabAt(1).setText("ffffffff").setIcon();


                            ////
                            FragmentTransaction fTransФрагментRСообщенияЧата;
                            fTransФрагментRСообщенияЧата = fragmentManager.beginTransaction();
                            fTransФрагментRСообщенияЧата.replace(R.id.Relativemain_for_chats, ФрагментRead_СообщенияЧата); // fTrans.add(R.id.frgmCont, frag1);
                            fTransФрагментRСообщенияЧата.addToBackStack(null).commit();
                            ///
                            break;
*//*

                        // ...
                        case "Контакты":
                            // your logic goes here!

                            Fragment_Contacts_КонтактыЧата ФрагментКонтакты=new Fragment_Contacts_КонтактыЧата();
                            ////
                            //  TabLayoutИзЧата.getTabAt(1).setText("ffffffff").setIcon();


                            ////
                            FragmentTransaction fTransФрагментКонтакты;
                            fTransФрагментКонтакты = fragmentManager.beginTransaction();
                            fTransФрагментКонтакты.add(R.id.Relativemain_for_chats, ФрагментКонтакты); // fTrans.add(R.id.frgmCont, frag1);
                            fTransФрагментКонтакты.addToBackStack(null).commit();
                            ////
                            break;
*//*

                        // ...


                        //



                        // ...

                    }

                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {
                    Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация   " + new Date());





                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {
                    Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация   " + new Date());
                }

            });*/

            /////////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


        }



    }

}