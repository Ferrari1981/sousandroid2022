package com.dsy.dsu;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.Date;
import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;


public class MyWork_Async_Синхронизация_Общая extends Worker {
    Context Контекст;

    public MyWork_Async_Синхронизация_Общая(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        Контекст = context;
    }

    @Override
    public void onStopped() {
        super.onStopped();
    }


    @NonNull
    @Override
    public Result doWork() {

// Do processing
        try {


            Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWork_Notifocations_Уведомления СЛУЖБА MyWork_SynchronizasiyDatas ВНУТРИ КЛАССА doWork  время "
                    + new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data"));


            Log.d(this.getClass().getName(), "   ЗАПУСК ФОНОВОЙ СИНХРОНИЗАЦИИИ С mYwORK_sYNCHRONIZACI  СЛУЖБА  WorkManager Synchronizasiy_Data ");


            /////////TODO запуск нновую нотификашенс устанолвка
            Intent intentСинхронизацияЛокальная_ВнутриТабеля = new Intent(Контекст, Service_Async_Синхронизация_Общая.class);
            ////////////

         //   intentСинхронизацияЛокальная.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            /////

            intentСинхронизацияЛокальная_ВнутриТабеля.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
            //
            intentСинхронизацияЛокальная_ВнутриТабеля.addFlags(Intent.FLAG_FROM_BACKGROUND);

            intentСинхронизацияЛокальная_ВнутриТабеля.putExtra("СинхронизацияЛокальная", "СинхронизацияФоноваяВнутриТабеля");


            // TODO: 01.05.2021 запускаем если все активти невидны спущены вниз

            // TODO: 01.05.2021 запускаем если все активти невидны спущены вниз
            // TODO: 01.05.2021 запускаем если все активти невидны спущены вниз


            boolean ФлагЛюбогоЗапущеногоАктивти = false;

            /////

            //////
            ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(ACTIVITY_SERVICE);

            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);

            Log.d("topActivity", "CURRENT Activity ::" + taskInfo.get(0).topActivity.getClassName());

            ComponentName componentInfo = taskInfo.get(0).topActivity;

            componentInfo.getPackageName();

            componentInfo.getClassName();


            Log.d(this.getClass().getName(), "   componentInfo.getPackageName() " + componentInfo.getPackageName() +
                    "  componentInfo.getClassName() " + componentInfo.getClassName());


            //

            // TODO: 08.04.2021
            // TODO: 08.04.2021
            boolean ФлагЗапущенолиКакоеннибутьАктивтиИлинет = false;
            ////////
            ФлагЗапущенолиКакоеннибутьАктивтиИлинет = componentInfo.getClassName().contains("com.dsy.dsu.MainActivity");

            /////


            // TODO: 08.04.2021
            if (ФлагЗапущенолиКакоеннибутьАктивтиИлинет == true) {


                ФлагЛюбогоЗапущеногоАктивти = true;

                Log.d(this.getClass().getName(), "НЕ Запуск MyWorkСинхронизации Активти какае то есть СЛУЖБА   componentInfo.getClassName().startsWith(\"Activity\",33)"
                        + componentInfo.getClassName().startsWith("Activity", 33) + " componentInfo.getClassName() " + componentInfo.getClassName() +
                        " getClass().getName()" + getClass().getName() + " ФлагЗапущенолиКакоеннибутьАктивтиИлинет " + ФлагЗапущенолиКакоеннибутьАктивтиИлинет);

                // TODO: 29.04.2021 end
            } else {

                Log.d(this.getClass().getName(), "ЗАПУСК MyWorkСинхронизации СЛУЖБА  Уведомления (внутри потока) НЕТ НЕ ОДНОГО АКТИВНОГО АКТИВТИ" + new Date()
                        + " +componentInfo.getClassName().startsWith(\"Activity\",33) " + componentInfo.getClassName().startsWith("Activity", 33) +
                        " componentInfo.getClassName()" + componentInfo.getClassName() + " getClass().getName()" + getClass().getName()
                        + " ФлагЗапущенолиКакоеннибутьАктивтиИлинет " + ФлагЗапущенолиКакоеннибутьАктивтиИлинет);

                ФлагЛюбогоЗапущеногоАктивти = false;

            }




            // TODO: 03.07.2021 вычисляем произошлили изименения в базе








                // TODO: 07.06.2021 САМ ЗАПУСК


              PendingIntent pendIntentСинхронизацияЛокальная= PendingIntent.getService(Контекст, 0, intentСинхронизацияЛокальная_ВнутриТабеля, 0);

              //

/*     boolean ПроверкаБылиИзмененияВБазе=       new Class_Search_Changes_Data(getApplicationContext()).МетодВычислемБылиИзменениВДанныхВДанныхПоДатам("data_tabels");


            Log.d(this.getClass().getName(), "ПроверкаБылиИзмененияВБазе "  +ПроверкаБылиИзмененияВБазе);


            if (ПроверкаБылиИзмененияВБазе==true) {
                ////////

                Log.d(this.getClass().getName(), "ПроверкаБылиИзмененияВБазе "  +ПроверкаБылиИзмененияВБазе);

            }*/

                if (ФлагЛюбогоЗапущеногоАктивти==false) {
                    ////
                    ContextCompat.startForegroundService(Контекст, intentСинхронизацияЛокальная_ВнутриТабеля);
                    ////

                    Log.i(Контекст.getClass().getName(),
                            "Запуск  СЛУЖБА СЛУЖБА Synchronizasiy_Data                        ContextCompat.startForegroundService(Контекст, intentСинхронизация);" +
                                    " из      FaceApp  время "+new Date()+
                                    " componentInfo.getClassName().startsWith(\"Activity\",33)" + componentInfo.getClassName().startsWith("Activity",33)+
                                    " ФлагЗапущенолиКакоеннибутьАктивтиИлинет " +ФлагЗапущенолиКакоеннибутьАктивтиИлинет);
                } else {


                    /////////////


                    Контекст.startService(intentСинхронизацияЛокальная_ВнутриТабеля);
                    //

                    Log.i(Контекст.getClass().getName(),
                            "Запуск  СЛУЖБА СЛУЖБА Synchronizasiy_Data        Контекст.startService(intentСинхронизация) из      FaceApp  время "+new Date()+
                                    " componentInfo.getClassName().startsWith(\"Activity\",33)" + componentInfo.getClassName().startsWith("Activity",33)+
                                    " ФлагЗапущенолиКакоеннибутьАктивтиИлинет " +ФлагЗапущенолиКакоеннибутьАктивтиИлинет);


                }



            Log.i(Контекст.getClass().getName(), "ПОСЛЕ MyWork_Async_Синхронизация_Общая   СЛУЖБА СЛУЖБА Synchronizasiy_Data ВНУТРИ КЛАССА doWork  MyWork_Async_Синхронизация_Общая "
                    + new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager Synchronizasiy_Data"));





            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
         /////////
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.e(Контекст.getClass().getName(), " Стоп СЛУЖБА MyWork_Async_Синхронизация_Общая из FaceApp в MyWork_Async_Синхронизация_Общая Exception  ошибка в классе MyWork_Async_Синхронизация_Общая" + e.toString());


        }

        return Result.success();
    }


}





























