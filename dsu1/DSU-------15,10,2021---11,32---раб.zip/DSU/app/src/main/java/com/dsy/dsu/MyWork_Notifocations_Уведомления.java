package com.dsy.dsu;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor    ;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static android.content.Context.ACTIVITY_SERVICE;


public class MyWork_Notifocations_Уведомления extends Worker {
    Context Контекст;

    Boolean ФлагЛюбогоЗапущеногоАктивтиВнутри=false;








    public MyWork_Notifocations_Уведомления(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        Контекст=context;
    }

    @Override
    public void onStopped() {
        super.onStopped();
    }












    @NonNull
    @Override
    public Result doWork() {

// Do processing
        Boolean ФинальныйФлагЛюбогоЗапущеногоАктивти = false;
        try {

            String РезультатКтоЗагрузил = getInputData().getString("КтоЗапустилWorkmanager");
            /////
            РезультатКтоЗагрузил = getInputData().getString("FaceApp");

            Log.d(Контекст.getClass().getName(), "MyWork_Notifocations_Уведомления СЛУЖБА  " + getInputData().getKeyValueMap());

            Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWork_Notifocations_Уведомления СЛУЖБА СЛУЖБАService_Notifications ВНУТРИ КЛАССА doWork  MyWork_Notifocations_Уведомления время "
                    + new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation") + "\n" +
                    "РезультатКтоЗагрузил " + РезультатКтоЗагрузил);






/*
            /////////TODO запуск нновую нотификашенс устанолвка
            Intent intentСлужбаУведомлений = new Intent(Контекст, Service_Notificatios_Уведомления.class);


            intentСлужбаУведомлений.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            /////////////
            intentСлужбаУведомлений.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);


            // intent.addCategory(Intent.CATEGORY_LAUNCHER);


            intentСлужбаУведомлений.putExtra("СлужбуЗапустил", "BroadcastReceiver");*/

            // TODO: This method is called when the BroadcastReceiver is receiving*/



            ///////////////////////////////////////////////////////////////////////////////////////
                    ActivityManager am = (ActivityManager) Контекст.getSystemService(ACTIVITY_SERVICE);

                    List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);

                    Log.d("topActivity", "CURRENT Activity ::" + taskInfo.get(0).topActivity.getClassName());

                    ComponentName componentInfo = taskInfo.get(0).topActivity;

                    componentInfo.getPackageName();

                    componentInfo.getClassName();


                    Log.d(this.getClass().getName(), "   componentInfo.getPackageName() " + componentInfo.getPackageName() +
                            "  componentInfo.getClassName() " + componentInfo.getClassName());

                    // TODO: 08.04.2021
                    if (componentInfo.getClassName().matches("com.dsy.dsu.MainActivity(.*)")) {
                        ///////
                        ФлагЛюбогоЗапущеногоАктивтиВнутри = true;


                        /////todo no
                    } else {


                        Log.d(this.getClass().getName(), "ЗАПУСК MyWork_Notifocations_Уведомления СЛУЖБА  Уведомления (внутри потока) НЕТ НЕ ОДНОГО АКТИВНОГО АКТИВТИ" + new Date()
                                + " ФлагЛюбогоЗапущеногоАктивти " + ФлагЛюбогоЗапущеногоАктивтиВнутри);
                        ///////
                        ФлагЛюбогоЗапущеногоАктивтиВнутри = false;
                    }


                    Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА ВНУТРИ startService   Вещятеля BroadcastReceiver  Service_Notificatios_Уведомления " + new Date() +
                            "\n" + " Build.BRAND " + Build.BRAND.toString() + "\n"+
                             "  ФинальныйФлагЛюбогоЗапущеногоАктивти " +ФинальныйФлагЛюбогоЗапущеногоАктивти);
                    ///////


                // TODO: 29.04.2021 вуключаем


                if (ФинальныйФлагЛюбогоЗапущеногоАктивти == false) {


                    /////
                    // TODO: 07.06.2021 САМ ЗАПУСК 

  /*               try {
                     /////s
                     PendingIntent pendIntentСинхронизация = PendingIntent.getService(Контекст, 0, intentСлужбаУведомлений, 0);

                     ///////
                     ContextCompat.startForegroundService(Контекст, intentСлужбаУведомлений);

                     Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWorkУведоммления СЛУЖБА            Контекст.startService(intentОбновлениеПО);;");


                 } catch (IllegalStateException exception) {


                     //

                     Контекст.startService(intentСлужбаУведомлений);
                     Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWorkУведоммления СЛУЖБА            Контекст.startService(intentОбновлениеПО);;");




                    }*/



                    

                    ///

/*
                    // TODO: 07.06.2021 САМ ЗАПУСК
                    switch ( Build.VERSION.SDK_INT){

                        case 29:
                        case 28:
                        case 27:
                        case 26:
                        case 25:
                        case 24:
                        case 23:

                            ContextCompat.startForegroundService(Контекст, intentСлужбаУведомлений);
                            ////
                            Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWorkУведоммления СЛУЖБА            Контекст.startService(intentОбновлениеПО);;");

                            break;

                        case 30:

                            Контекст.startService(intentСлужбаУведомлений);
                            //

                            Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWorkУведоммления СЛУЖБА            Контекст.startService(intentОбновлениеПО);;");

                            break;


                    }*/




                    Log.i(Контекст.getClass().getName(), "ПОСЛЕ MyWork_Notifocations_Уведомления СЛУЖБА СЛУЖБАService_Notifications ВНУТРИ КЛАССА doWork  ContextCompat.startForegroundService  MyWork_Notifocations_Уведомления время "
                            + new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager NOtofocation") +
                            " ФинальныйФлагЛюбогоЗапущеногоАктивти " + ФинальныйФлагЛюбогоЗапущеногоАктивти);

                }




            // TODO: 28.04.2021 сам запуск



            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.e(Контекст.getClass().getName(), " Стоп СЛУЖБА Service_Notificatios_Уведомления в MyWork_Notifocations_Уведомления Exception  ошибка в классе MyWork_Notifocations_Уведомления" + e.toString() + "\n" +
                    " ФинальныйФлагЛюбогоЗапущеногоАктивти " + ФинальныйФлагЛюбогоЗапущеногоАктивти);


        }

        return Result.success();
    }


    }






























