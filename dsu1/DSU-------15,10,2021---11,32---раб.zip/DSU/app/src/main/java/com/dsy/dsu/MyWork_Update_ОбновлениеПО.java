package com.dsy.dsu;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.Date;
import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;


public class MyWork_Update_ОбновлениеПО extends Worker {
    Context Контекст;












    public MyWork_Update_ОбновлениеПО(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        Контекст=context;
    }

    @Override
    public void onStopped() {
        super.onStopped();


    }

    @NonNull
    @Override
    public Result doWork() {

// Do processing
        try{

            String РезультатКтоЗагрузил = getInputData().getString("КтоЗапустилWorkmanager");
            РезультатКтоЗагрузил = getInputData().getString("FaceApp");

            Log.d(Контекст.getClass().getName(), "MyWork_Update_ОбновлениеПО СЛУЖБА  " + getInputData().getKeyValueMap());

            Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWork_Update_ОбновлениеПО СЛУЖБА  ВНУТРИ КЛАССА doWork  MyWork_Update_ОбновлениеПО время "
                    +new Date() + " СТАТУС WORKMANAGER" + WorkManager.getInstance(getApplicationContext()).getWorkInfosByTag("WorkManager MyWork_Update_ОбновлениеПО")+"\n"+
                    "РезультатКтоЗагрузил " +РезультатКтоЗагрузил);



            //////
            ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(ACTIVITY_SERVICE);

            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);

            Log.d("topActivity", "CURRENT Activity ::" + taskInfo.get(0).topActivity.getClassName());

            ComponentName componentInfo = taskInfo.get(0).topActivity;

            componentInfo.getPackageName();

            componentInfo.getClassName();


            Log.d(this.getClass().getName(), "   componentInfo.getPackageName() " + componentInfo.getPackageName() +
                    "  componentInfo.getClassName() " + componentInfo.getClassName());



            //

            // TODO: 08.04.2021
            // TODO: 08.04.2021
            boolean ФлагЗапущенолиКакоеннибутьАктивтиИлинет=false;
            ////////
            ФлагЗапущенолиКакоеннибутьАктивтиИлинет=componentInfo.getClassName().contains("com.dsy.dsu.MainActivity");

            /////














            Intent intentОбновлениеПО = new Intent(Контекст, Service_Update_ОбновлениеПО.class);
            ///
          //  intentОбновлениеПО.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK );

            intentОбновлениеПО.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);

            intentОбновлениеПО.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION );

            intentОбновлениеПО.setFlags(Intent. FLAG_GRANT_WRITE_URI_PERMISSION );


            // TODO: 06.07.2021 запуск службы



            // TODO: 08.04.2021
            if  ( ФлагЗапущенолиКакоеннибутьАктивтиИлинет==true){

                Контекст.startService(intentОбновлениеПО);
                //

                Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWork_Update_ОбновлениеПО СЛУЖБА             Контекст.startService(intentОбновлениеПО);");
            }else{
                //
                ContextCompat.startForegroundService(Контекст, intentОбновлениеПО);

                Log.i(Контекст.getClass().getName(), "ЗАПУСК MyWork_Update_ОбновлениеПО СЛУЖБА        ContextCompat.startForegroundService(Контекст, intentОбновлениеПО);");




            }






            //////////
        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.e(Контекст.getClass().getName(), " Стоп СЛУЖБА Service_ОбновлениПО в MyWork_Update_ОбновлениеПО Exception  ошибка в классе MyWork_Notifocations_Уведомления"+e.toString());


        }

        return Result.success();
    }


    }






























