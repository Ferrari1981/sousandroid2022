package com.dsy.dsu;



import android.app.Activity;
import android.app.ActivityManager;
import android.app.IntentService;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.LinkedBlockingQueue;


public class Service_Async_Синхронизация_Общая extends IntentService {






    public Service_Async_Синхронизация_Общая() {
        super("Async_Public_ALL");
    }


    // TODO: 12.10.2021  Ссылка Менеджер Потоков



/*    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ///TODO запускаем дВУХсЛУЖБ




        return START_REDELIVER_INTENT ;//  return super.onStartCommand(intent, flags, startId);
    }*/



    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();



        Log.d(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБА  СИнхронизации ");



    }





    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        try{

            ///
            Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация   " + new Date());
            ////





            boolean ФлагЛюбогоЗапущеногоАктивти = false;

            ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(ACTIVITY_SERVICE);

            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);

            Log.d("topActivity", "CURRENT Activity ::" + taskInfo.get(0).topActivity.getClassName());

            ComponentName componentInfo = taskInfo.get(0).topActivity;

            componentInfo.getPackageName();

            componentInfo.getClassName();


            Log.d(this.getClass().getName(), "   componentInfo.getPackageName() " + componentInfo.getPackageName() +
                    "  componentInfo.getClassName() " + componentInfo.getClassName());



            String КтоЗарустилСинхронизацию=             intent.getStringExtra("СинхронизацияЛокальная");



            Log.d(this.getClass().getName(), "   КтоЗарустилСинхронизацию " + КтоЗарустилСинхронизацию);


            boolean ФлагЗапущенолиКакоеннибутьАктивтиИлинет = false;
            ////////
            ФлагЗапущенолиКакоеннибутьАктивтиИлинет = componentInfo.getClassName().contains("com.dsy.dsu.MainActivity");

            // TODO: 26.04.2021 начинаем синхронизацию по условия но сейчас отключена на время


            ///
            Log.d(this.getClass().getName(), "ЗАПУСК СЛУЖБА  Синхронизация фоновой (внутри потока) " + new Date()+ "  ФлагЗапущенолиКакоеннибутьАктивтиИлинет "+ФлагЗапущенолиКакоеннибутьАктивтиИлинет);

// TODO: 02.07.2021 три вариант а запуска службы синхронизации

            if (!componentInfo.getClassName().contains("com.dsy.dsu.MainActivity_Face_Start") &&
                    ! componentInfo.getClassName().contains("com.dsy.dsu.MainActivity_Visible_Async")  ) {/// пример огинигальный com.dsy.dsu.MainActivity_Face_App

                // TODO: 08.09.2021  запус фоновой синхрониазции





                // TODO: 29.09.2021  перед началом СИНХРОНИЗАЦИИ ПРОВЕРЯЕМ УСТАНОВКИ СЕТИ ПОЛЬЗОВАТЕЛЯ НА АКТИВТИ НАСТРОЙКИ

                boolean РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию=
                        new  Class_Find_Setting_User_Network(getApplicationContext()).МетодПроветяетКакуюУстановкуВыбралПользовательСети();

                //TODO ФУТУРЕ ЗАВЕРШАЕМ
                Log.d(this.getClass().getName(), "  РезультатПроВеркиУстановкиПользователяРежимРаботыСети " + РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию);

                Integer РезультатЗапускаФоновойСинхронизации=0;

                try {

                    //TODO ФУТУРЕ ЗАВЕРШАЕМ
                    Log.d(this.getClass().getName(), "  РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию "
                            + РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию);



                    if (РезультатПроВеркиУстановкиПользователяРежимРаботыСетиСтоитЛиЗапускатьСсинхронизацию==true) {

                        boolean     РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции =
                                new Class_Connections_Server(getApplicationContext()).МетодПингаСервераРаботаетИлиНет(getApplicationContext());





                        LinkedBlockingQueue ЗаполненыеСистемныеТаблицыДЛяСинхронизации = new Class__Generation_Genetal_Tables(getApplicationContext()).
                                МетодЗаполеннияТаблицДЛяРаботыиСинхрониазции();



                        //TODO ФУТУРЕ ЗАВЕРШАЕМ
                        Log.d(this.getClass().getName(), "  ЗаполненыеСистемныеТаблицыДЛяСинхронизации " + ЗаполненыеСистемныеТаблицыДЛяСинхронизации.size());

                        Log.d(this.getClass().getName(), "  РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции "
                                + РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции);

                        if (РезультатЕслиСвязьСерверомПередНачаломВизуальнойСинхронизции==true) {


                            ///////
                            РезультатЗапускаФоновойСинхронизации= new Class_Async_Background(getApplicationContext()).
                                    МетодЗАпускаФоновойСинхронизации(getApplicationContext(),
                                            "СинхронизацияДляЧата", false, null, ЗаполненыеСистемныеТаблицыДЛяСинхронизации,
                                            "ПовторныйЗапускСинхронизации",0);  //TODO третить параментр false --указывает что обработка всех таблиц кроме чата

                            //
                            // TODO: 22.04.2021  srart JOBschedele
                            Log.d(this.getClass().getName(), " СЛУЖБА  РезультатЗапускаФоновойСинхронизации    "+РезультатЗапускаФоновойСинхронизации);
                        }
                    }


                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                    new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                            Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());

                }






            } else {
                // TODO: 22.04.2021  srart JOBschedele
                Log.d(this.getClass().getName(), "ВЫХОД ПОСЛЕ ОТРАБОТКИ СЛУЖБА ВНУТРИ startService   Вещятеля BroadcastReceiver" +
                        "  Synchronizasiy_Data pendingIntent    ");

            }



/////


            ////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }


}