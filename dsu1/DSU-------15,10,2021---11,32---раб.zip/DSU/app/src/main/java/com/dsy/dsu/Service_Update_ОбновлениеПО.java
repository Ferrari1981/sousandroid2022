package com.dsy.dsu;

import android.app.Activity;
import android.app.IntentService;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;

import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.ExecutionException;


public class Service_Update_ОбновлениеПО extends IntentService {


    String ТипПодключенияИнтернтаДляСлужбы;

   Integer СервернаяВерсияПОВнутри=0;
   ////
  Integer ЛокальнаяВерсияПО=0;


    public Service_Update_ОбновлениеПО() {
        super("UpdatePO");
    }
    ////




    @Override
    public void onCreate() {
        super.onCreate();
    }
/*    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        /////////TODO локальная весрия данных для АНАЛИЗА ПО
        /////
        try {



                                                        ///
                                                        Log.d(getApplicationContext().getClass().getName(), " ЗАПУСК СЛУЖБА Внутри службы   МЕТОД ОБНОВЛЕНИЕ ПО  " + "--" + new Date());/////




                                                            МетодНачалаЗапускаОбновленияПО();
                                                            /////








        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        ////
        return  START_REDELIVER_INTENT   ;//super.onStartCommand(intent, flags, startId)
    }*/






    // TODO: 02.04.2021 update service po

    void МетодНачалаЗапускаОбновленияПО() throws ExecutionException, InterruptedException {
        ////////


                try {


                        ////todo сам код
                        МетодОценкииСетиПередЗагрузкойAPKсСервера();

                        // TODO: 12.05.2021 вторая часть


                        if (ТипПодключенияИнтернтаДляСлужбы != null) {

                            Log.i(this.getClass().getName(), "ТипПодключенияИнтернтаДляСлужбы " +ТипПодключенияИнтернтаДляСлужбы);

                            if (ТипПодключенияИнтернтаДляСлужбы.equals("WIFI") || ТипПодключенияИнтернтаДляСлужбы.equals("Mobile")) {

                                ///  МетодДополнительногоУдалениеФайлов();

                                ////

                                //TODO СНАЧАЛА АНАЛИЗИРУЕМ ПРИШЕДНИЙ ФАЙЛ JSON c ВЕРСИЕЙ ДАННЫХ ЕСЛИ ВЕРСИЯ ДАННЫХ НА СЕРВЕР ВЫШЕ ТОГДА ЗАПУСКАЕМ ОБНОВЛЕНЕИ ПРОГРАММНОГО О ВТОРОЙ ЭТАП


                                МетодАнализаВерсииПОJSON();


                                /// boolean РешениеЗагрузильсяФайлИлиНет=МетодОпределямРаботаетИлиНетЗагрузчикФайлов();
///TODO РАБОТА НЕПОСТРДСТВЕННО УЖЕ С .apk
                            ///   МетодОпределнияВерсийПОСервераКлиентаИПринятиеРешенияНаСкачиваниеОбновлениеПО();


                                ////todo end apk


                            }
                        }







                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                           new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }





                ///TODO загруузка приложения  с сервера производиться только когда WIFI



            if (ТипПодключенияИнтернтаДляСлужбы != null) {

                Log.i(this.getClass().getName(), "ТипПодключенияИнтернтаДляСлужбы " + ТипПодключенияИнтернтаДляСлужбы);

                if (ТипПодключенияИнтернтаДляСлужбы.equals("WIFI")  || ТипПодключенияИнтернтаДляСлужбы.equals("Mobile")  ) {

                  ///  МетодДополнительногоУдалениеФайлов();

                    ////

                    //TODO СНАЧАЛА АНАЛИЗИРУЕМ ПРИШЕДНИЙ ФАЙЛ JSON c ВЕРСИЕЙ ДАННЫХ ЕСЛИ ВЕРСИЯ ДАННЫХ НА СЕРВЕР ВЫШЕ ТОГДА ЗАПУСКАЕМ ОБНОВЛЕНЕИ ПРОГРАММНОГО О ВТОРОЙ ЭТАП



                          //  МетодАнализаВерсииПОJSON();

                    // TODO: 12.05.2021 третья часть


                    /// boolean РешениеЗагрузильсяФайлИлиНет=МетодОпределямРаботаетИлиНетЗагрузчикФайлов();
///TODO РАБОТА НЕПОСТРДСТВЕННО УЖЕ С .apk
                    МетодОпределнияВерсийПОСервераКлиентаИПринятиеРешенияНаСкачиваниеОбновлениеПО();



                    ////todo end apk


                }
                //////
                /////


            }







    }


    private void МетодДополнительногоУдалениеФайлов() {

        try{


/////TODO  УДАЛЕНИЕ .JSON ФАЙЛА
               /* File  ФайлыДляОбновлениеПОУдаление = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS + "/" + "*.json");*/

            File  ФайлыДляОбновлениеПОУдалениеПриАнализеJSONВерсии = null;


            if (  Build.VERSION.SDK_INT >= 30)   {
                ФайлыДляОбновлениеПОУдалениеПриАнализеJSONВерсии = getApplicationContext().getExternalFilesDir(null);
            }else{

                ФайлыДляОбновлениеПОУдалениеПриАнализеJSONВерсии = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS);

            }






            File[] Files = ФайлыДляОбновлениеПОУдалениеПриАнализеJSONВерсии.listFiles();

            if(Files != null) {
                int j;
                for(j = 0; j < Files.length; j++) {
                    String ИмяФайла=Files[j].getName();
                    boolean ПосикПоНазваниюФайла=ИмяФайла.matches("(.*)json(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");
                    boolean ПосикПоНазваниюФайлаРасширенная=ИмяФайла.matches("(.*)analysis_version(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");

                    if(ПосикПоНазваниюФайла==true || ПосикПоНазваниюФайлаРасширенная==true) {
                        Files[j].delete();
                        //
                        /////
                        if (!Files[j].isFile()) {
                            Log.d(this.getClass().getName(), " СЛУЖБА  ТАКОГО ФАЙЛА БОЛЬШЕ НЕТ  .JSON АНАЛИЗ " + Files[j].length()
                                    + "   путь файла " +  Files[j].getAbsolutePath() + "   --- "  +new Date() + " ИмяФайла "+ИмяФайла);
                        }
                    }
                    ////    ФайлыДляОбновлениеПОУдаление.delete();

                }//ещыыщ
            }





            /////TODO  УДАЛЕНИЕ .JSON ФАЙЛА
               /* File  ФайлыДляОбновлениеПОУдаление = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS + "/" + "*.json");*/

            if(Files != null) {
                int j;
                for(j = 0; j < Files.length; j++) {
                    String ИмяФайла=Files[j].getName();
                    boolean ПосикПоНазваниюФайла = ИмяФайла.matches("(.*)apk(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");
                    boolean ПосикПоНазваниюФайлаРасширенная = ИмяФайла.matches("(.*)update_dsu1(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");

                    if(ПосикПоНазваниюФайла==true || ПосикПоНазваниюФайлаРасширенная==true) {
                        Files[j].delete();
                        //
                        /////
                        if (!Files[j].isFile()) {
                            Log.d(this.getClass().getName(), " СЛУЖБА  ТАКОГО ФАЙЛА БОЛЬШЕ НЕТ  .APK АНАЛИЗ " + Files[j].length()
                                    + "   путь файла " +  Files[j].getAbsolutePath() + "   --- "  +new Date() + " ИмяФайла "+ИмяФайла);
                        }
                    }
                    ////    ФайлыДляОбновлениеПОУдаление.delete();

                }//ещыыщ
            }










        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() +
                    " Линия  :" + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(),
                    Thread.currentThread().getStackTrace()[2].getMethodName(), Thread.currentThread().getStackTrace()[2].getLineNumber());

            Log.d(this.getClass().getName(), " Стоп СЛУЖБА СЛУЖБАService_Notifications Обновление ПО onDestroy() Exception ");


        }
    }




















    /////TODO ЗАПУСК ОБНОВЛЕНИЕ ПОТСЛЕ УСПЕШНОЕ СКАЧИВАННИЕ 10 СКЕКУНД
    private void МетодКоторыйЗапускаетОбновлениеПООтложенныйЗапускна10Секунд() {

        try{
        /*    handler = new Handler();

            handler.postDelayed(new Runnable() {
                public void run() {
                    *//*code*/

                    try {


                        /////




   /*     String destination = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/";
        String fileName = "update_dsu1.apk";
        destination += fileName;
        Uri uri = Uri.parse("file://" + destination);*///File ФайлыДляОбновлениеПО = Environment.getExternalStoragePublicDirectory(
                        //   Environment.DIRECTORY_DOWNLOADS + "/" + "update_dsu1.apk");

                        File ФайлыДляОбновлениеПО=null;// = Environment.getExternalStoragePublicDirectory(
                        ///Environment.DIRECTORY_DOWNLOADS + "/" + "update_dsu1.apk");



                        if (Build.VERSION.SDK_INT >= 30)  {


                            ФайлыДляОбновлениеПО = new File( getApplicationContext().getExternalFilesDir(null) + "/" + "update_dsu1.apk");///      ФайлыДляОбновлениеПО = getApplicationContext().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);

                        }else{

                            ФайлыДляОбновлениеПО = Environment.getExternalStoragePublicDirectory( ///Environment.getExternalStorageDirectory().getAbsolutePath()
                                    Environment.DIRECTORY_DOWNLOADS+ "/" + "update_dsu1.apk");
                        }















                        Log.d(this.getClass().getName(), "    ПУТИ В ФАЙЛУ   " + "\n"
                                + ФайлыДляОбновлениеПО);


                        if (ФайлыДляОбновлениеПО.isFile()) {

                            Log.d(this.getClass().getName(), "  storageDir.getAbsolutePath()  " + ФайлыДляОбновлениеПО.getAbsolutePath() + "\n" +
                                    "  storageDir.getCanonicalPath()   " + ФайлыДляОбновлениеПО.getCanonicalPath() + "\n" +
                                    " storageDir.getName() " + ФайлыДляОбновлениеПО.getName() + "\n" +
                                    "  storageDir.exists() " + ФайлыДляОбновлениеПО.exists() + "\n" +
                                    "+storageDir.length() " + ФайлыДляОбновлениеПО.length());


/*
                            handler.sendEmptyMessage((int) ФайлыДляОбновлениеПО.length());
                            handler.removeCallbacks(null);
                            handler.removeCallbacksAndMessages(null);
                            System.out.println(handler);*/
                            Log.d(this.getClass().getName(), "СКАЧЕННЫЙ ФАЙЛ ОБНОВЛЕНИЕ ПО УСТАНВЛИВАЕМ ПО ТАБЕЛЬНЫЙ УЧЁТ СЛУЖБА....... (файл уже на телефоне)"
                                    + "  ФайлыДляОбновлениеПО.length() " + ФайлыДляОбновлениеПО.length());



                            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
// Vibrate for 500 milliseconds
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                v.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE));
                            } else {
                                //deprecated in API 26
                                v.vibrate(500);
                            }


                            ///TODO  ЗАПУСКА APK ФАЙЛОВ ЧЕРЕЗ СООБЩЕНИЕ

                            СообщениеКотороеСообщаетПользователюЧТоНАлдоУстановитьНовуюВерисюПО();






                            Log.d(this.getClass().getName(), "  ФайлыДляОбновлениеПО " + ФайлыДляОбновлениеПО.exists() + " ФайлыДляОбновлен.length() " +ФайлыДляОбновлениеПО.length());



                        } else {
                            Log.d(this.getClass().getName(), " СЛУЖБА  ОШИБКА НЕТ КАКОГО ФАЙЛА  . APK" + ФайлыДляОбновлениеПО.length());
                        }









////////////

                    } catch (Exception e) {
                        //  Block of code to handle errors
                        e.printStackTrace();
                        ///метод запись ошибок в таблицу
                        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                + Thread.currentThread().getStackTrace()[2].getLineNumber());
                               new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                Thread.currentThread().getStackTrace()[2].getLineNumber());
                    }


            /*    }
            }, 0); //specify the number of milliseconds 30000  30 секунд
*/

            //////hedler end





/////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }
        ////
    }


    ////TODO АНАЛИЗИРУЕМ ПРИШЕДШИЙ ФАЙЛ И ПРИНИМАЕМ РЕШЕНИЕ НА СКАЧИВАНЕИ ФАЙЛА ИЛИ НЕТ



    private void МетодОпределнияВерсийПОСервераКлиентаИПринятиеРешенияНаСкачиваниеОбновлениеПО() {

        ///////TODO ЗАПУСК ПРОИЗВОДИМ ОТЛОЖЕННЫЙ НА 3 СЕКУЕНДЫ



                /*code*/

                try {


                        ////TODO получаем и записываем локальную верисю ПО



                        final Object versio = BuildConfig.VERSION_CODE;
     /////


                    ЛокальнаяВерсияПО = Integer.parseInt(versio.toString());

                    ///

                    Log.d(this.getClass().getName(), "  ЛокальнаяВерсияПО" + ЛокальнаяВерсияПО+   "  СервернаяВерсияПОВнутри " +СервернаяВерсияПОВнутри);




///////////TODO ПРИСТУПАЕМ К ЗАПУСКУ ОБНОВЛЕНИЕ ФАЙЛА . APK ТОЛЬКО КОГДА ВЕРСИЯ ДАННЫХ НА СЕРВЕРЕ БОЛЬШЕ ЧЕМ НА КЛИЕНТЕ (Android)
                        ///
                        if (СервернаяВерсияПОВнутри >ЛокальнаяВерсияПО ) {


                            МетодЗагрузкиФайлаAPK();
///////


                            Log.d(this.getClass().getName(), "  СЛУЖБА ЗАПУСКАЕМ...  Обновление  ПО .APK " +
                                    " ЛокальнаяВерсияПО " + ЛокальнаяВерсияПО + "СервернаяВерсияПОВнутри " + СервернаяВерсияПОВнутри);




                        } else {

                            Log.d(this.getClass().getName(), "  СЛУЖБА  ОБНОВЛЕНИЕ НЕ НУЖНО КАК ТАК ВЕРСИИ ПО НА СЕРВЕРЕ И КЛИЕНТЕ ОДИНАКОВЫ или НА КЛИЕТЕ ВЕРСИЯ ВЫШЕ...  (Обновление  ПО .APK) " +
                                    " ЛокальнаяВерсияПО " + ЛокальнаяВерсияПО + " СервернаяВерсияПО " + СервернаяВерсияПОВнутри);
                            /////todo stop service

                       /*     Toast.makeText(getApplicationContext(), "Обновление не нужно"+"\n"
                                    + ("версии программы одиноковы)") , Toast.LENGTH_LONG).show();*/


                            //  stopSelf();
                        }




////////////

                } catch (Exception e) {
                    //  Block of code to handle errors
                    e.printStackTrace();
                    ///метод запись ошибок в таблицу
                    Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                            + Thread.currentThread().getStackTrace()[2].getLineNumber());
                           new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                            Thread.currentThread().getStackTrace()[2].getLineNumber());
                }



        //////hedler end
    }


    private void МетодОценкииСетиПередЗагрузкойAPKсСервера() {



        try {

            /////todo тут МЫ ПОЛУЧАЕМ В КАКОЙ МОМЕНТ ТИП ПОДКЛЮЧЕНИЯ НА ТЕЛЕФОНЕ МОБИЛЯ ИЛИ  WIFI  И В ЗАВИСИМОСТИ ЧТОБЫ ПОНЯТЬ ЧЕ ЗА ДЕЛА



/*
       boolean  РезультатЕслиСвязьСерверомДСУ1 =        new Class_Connections_Server(getApplicationContext()).МетодПингаСервераРаботаетИлиНет(getApplicationContext());

            //TODO ФУТУРЕ ЗАВЕРШАЕМ
            Log.d(this.getClass().getName(), "  РезультатЕслиСвязьСерверомДСУ1" + РезультатЕслиСвязьСерверомДСУ1);


            // TODO: 09.09.2021 rsultat


            if (РезультатЕслиСвязьСерверомДСУ1 == true) {*/


                ТипПодключенияИнтернтаДляСлужбы = null;

                ///
                ТипПодключенияИнтернтаДляСлужбы = МетодОпределяемКакойТипПодключениеWIFIилиMobileДляСлужбы(getApplicationContext());

                Log.d(this.getClass().getName(), " ТипПодключенияИнтернтаДляСлужбы  " + ТипПодключенияИнтернтаДляСлужбы);


 /*           }*/


            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


    }









    private void МетодАнализаВерсииПОJSON() {
        ///

        try {

            Log.d(this.getClass().getName(), " СЛУЖБА ... МЕТОД АНАЛИЗА ДАННЫХ РАБОТАЕТ......" + new Date());

            //TODO УДАЛЕНИЕ ФАЙЛОВ ПОЛЕ АНАЛИЗА


            try {





           /*    File УниверсальныйБуферJSONАнализПОсСервера =        Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS);*/

//////////
                        try {
                     /*       УниверсальныйБуферJSONАнализПОсСервера =     new MODEL_synchronized(getApplicationContext()).
                                      УниверсальныйБуферAPKФайлаПОсСервера("dsu1.glassfish/update_android_dsu1/output-metadata.json","analysis_version.json",getApplicationContext());*/

                            СервернаяВерсияПОВнутри =     new MODEL_synchronized(getApplicationContext()).
                                    УниверсальныйБуферJSONВерсииПОсСервера("dsu1.glassfish/update_android_dsu1/output-metadata.json",getApplicationContext(),"tabel.dsu1.ru", 8888);




                            if (СервернаяВерсияПОВнутри>0) {
                                ////
                                Log.i(this.getClass().getName(), "СервернаяВерсияПОВнутри  " + СервернаяВерсияПОВнутри);

                            }


                            ///////
                        } catch (Exception e) {
                            //  Block of code to handle errors
                            e.printStackTrace();
                            ///метод запись ошибок в таблицу
                            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                                   new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                                    Thread.currentThread().getStackTrace()[2].getLineNumber());
                        }












                ///////
            } catch (Exception e) {
                //  Block of code to handle errors
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                       new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
            }

            ////TODO сервер уже отроботал ОДИН РАЗ И ВСЕ

            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }


    ////TODO


    protected void МетодЗагрузкиФайлаAPK() {
        ///

        try {
            Log.d(this.getClass().getName(), " СЛУЖБА ... МЕТОД ОБНОВЛЕНИЯ ПО РАБОТАЕТ......"+new Date());
            //////TODO вторая часть ЕСЛИ ВЕРСИЯ ПРОГРАМЫ НА СЕРВЕРЕ ВЫШЕ ЧЕМ НА АЕДРОЙДЕ ТО ЗАПУСКАЕМ  ЗАГРУЗКИ ПРИЛОЖЕНИЯ (НАПРИМЕР НА АНДРОЙДЕ 102 , А НА СЕРВЕРЕ 103, 104,итд.)
            String Adress_String = null;
            ////



            try {


                //TODO УДАЛЕНИЕ ФАЙЛОВ ПОЛЕ АНАЛИЗА


/*
                File  ФайлыДляОбновлениеПО = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS + "/" + "update_dsu1.apk");*/
                File  ФайлыДляОбновлениеПО=null;

                if (  Build.VERSION.SDK_INT >= 30)   {
                    ФайлыДляОбновлениеПО = new File(getApplicationContext().getExternalFilesDir(null) + "/" + "update_dsu1.apk");
                }else{

                    ФайлыДляОбновлениеПО = Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_DOWNLOADS+ "/" + "update_dsu1.apk");

                }










                Log.d(this.getClass().getName(), "    ПУТИ В ФАЙЛУ   " + "\n"
                        + ФайлыДляОбновлениеПО);



////TODOПолучаем весмиюСкачаеного ФАйла
                final PackageManager pm = getPackageManager();


                File fullPath = ФайлыДляОбновлениеПО;





                PackageInfo ИнформацияОФайле = pm.getPackageArchiveInfo(String.valueOf(fullPath), 0);






////////
                if (ИнформацияОФайле==null) {
                    ///TODO загрузка apk ФАЙЛА

                    МетодНепостредственннойЗагрузкиAPKФайлов(ФайлыДляОбновлениеПО, ИнформацияОФайле);


                    ////TODO после успешного  СКАЧЧИВАНИЯ ФАЙЛА МЫ С ОТЛОЖЕНИЕ В 10 СЕКУНД УСТАНВЛИВАЕМ ФАЙЛ
                    ////TODO после успешного  СКАЧЧИВАНИЯ ФАЙЛА МЫ С ОТЛОЖЕНИЕ В 10 СЕКУНД УСТАНВЛИВАЕМ ФАЙЛ
                    ////TODO после успешного  СКАЧЧИВАНИЯ ФАЙЛА МЫ С ОТЛОЖЕНИЕ В 10 СЕКУНД УСТАНВЛИВАЕМ ФАЙЛ

                    МетодКоторыйЗапускаетОбновлениеПООтложенныйЗапускна10Секунд();


                }else{

                    Log.d(this.getClass().getName(), " Скачитавать не НАдо версии Равны VersionCode : " + ИнформацияОФайле.versionCode + ", СервернаяВерсия ПО : " +  СервернаяВерсияПОВнутри);


                    if (ИнформацияОФайле.versionCode < СервернаяВерсияПОВнутри) {

                        ///TODO загрузка apk ФАЙЛА

                        МетодНепостредственннойЗагрузкиAPKФайлов(ФайлыДляОбновлениеПО, ИнформацияОФайле);


////TODO после успешного  СКАЧЧИВАНИЯ ФАЙЛА МЫ С ОТЛОЖЕНИЕ В 10 СЕКУНД УСТАНВЛИВАЕМ ФАЙЛ




                        МетодКоторыйЗапускаетОбновлениеПООтложенныйЗапускна10Секунд();





                    } else {

                        Log.d(this.getClass().getName(), " Скачитавать не НАдо версии Равны VersionCode : " + ИнформацияОФайле.versionCode + ", СервернаяВерсия ПО : " + СервернаяВерсияПОВнутри);



                        ////TODO после успешного  СКАЧЧИВАНИЯ ФАЙЛА МЫ С ОТЛОЖЕНИЕ В 10 СЕКУНД УСТАНВЛИВАЕМ ФАЙЛ

                        МетодКоторыйЗапускаетОбновлениеПООтложенныйЗапускна10Секунд();



                    }
                }


                ///////
            } catch (Exception e) {
                //  Block of code to handle errors
                e.printStackTrace();
                ///метод запись ошибок в таблицу
                Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                        + Thread.currentThread().getStackTrace()[2].getLineNumber());
                       new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                        Thread.currentThread().getStackTrace()[2].getLineNumber());
            }


            ////TODO сервер уже отроботал ОДИН РАЗ И ВСЕ

            ///////
        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }

    private void МетодНепостредственннойЗагрузкиAPKФайлов(File файлыДляОбновлениеПО, PackageInfo info) throws IOException {

        try {
            String Adress_String;


/////TODO  УДАЛЕНИЕ  ПРЕДЫДЦЩИЙ ФАЙЛ.APK ФАЙЛА


                File ФайлыДляОбновлениеПОУдалениеПО = null;

            if (  Build.VERSION.SDK_INT >= 30)   {
                ФайлыДляОбновлениеПОУдалениеПО = getApplicationContext().getExternalFilesDir(null);
            }else{

                ФайлыДляОбновлениеПОУдалениеПО = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS);

            }




                File[] Files = ФайлыДляОбновлениеПОУдалениеПО.listFiles();
                if (Files != null) {
                    int j;
                    for (j = 0; j < Files.length; j++) {
                        String ИмяФайла = Files[j].getName();
                        boolean ПосикПоНазваниюФайла = ИмяФайла.matches("(.*)apk(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");
                        boolean ПосикПоНазваниюФайлаРасширенная = ИмяФайла.matches("(.*)update_dsu1(.*)");//    boolean ПосикПоНазваниюФайла=Files[j].getName().matches("(.*).json(.*)");
                        if (ПосикПоНазваниюФайла==true || ПосикПоНазваниюФайлаРасширенная==true) {
                            Files[j].delete();
                            //
                            /////
                            if (!Files[j].isFile()) {
                                Log.d(this.getClass().getName(), " СЛУЖБА  ТАКОГО ФАЙЛА БОЛЬШЕ НЕТ  .APK ПО" + Files[j].length()
                                        + "   путь файла " + Files[j].getAbsolutePath() + "   --- " + new Date() + " ИмяФайла " + ИмяФайла);
                            }
                        }
                        ////    ФайлыДляОбновлениеПОУдаление.delete();

                    }//ещыыщ
                }





            ////TODO НАЧИНАЕМ ЗАГРУЗКИ С ИНТРЕНТА ФАЙЛ А ЕСЛИ ТОЛЬКО ЕГО НЕТ УЖЕ НА КЛИЕНТЕ



             // Adress_String = PUBLIC_CONTENT.ПубличныйАдресGlassFish + "dsu1.glassfish/update_android_dsu1/app-release.apk";


             //   Log.d(this.getClass().getName(), " Старт ..... Adress_String " + Adress_String);

            File УниверсальныйБуферAPKФайлаПОсСервера =null;



             File    УниверсальныйБуферAPKФайлаПОсСервераВнутри=     new MODEL_synchronized(getApplicationContext()).
                           УниверсальныйБуферAPKФайлаПОсСервера("dsu1.glassfish/update_android_dsu1/app-release.apk","update_dsu1.apk",getApplicationContext(),"tabel.dsu1.ru", 8888);


            if (УниверсальныйБуферAPKФайлаПОсСервераВнутри!=null) {
                ///
                if (УниверсальныйБуферAPKФайлаПОсСервераВнутри.length()>1000) {
                    Log.i(this.getClass().getName(), "УниверсальныйБуферAPKФайлаПОсСервераВнутри файл записалься на диск Телефона  " +УниверсальныйБуферAPKФайлаПОсСервераВнутри.length());
                }else{

                    Log.e(this.getClass().getName(), " рАЗМЕР ФАЙЛА МАЛЕНИКИЙ ниверсальныйБуферAPKФайлаПОсСервераВнутри файл  НЕ записалься на диск Телефона  Ошибка  " +УниверсальныйБуферAPKФайлаПОсСервераВнутри);
                }
            }else {

                Log.e(this.getClass().getName(), " NULL файл ниверсальныйБуферAPKФайлаПОсСервераВнутри файл  НЕ записалься на диск Телефона  Ошибка  " +УниверсальныйБуферAPKФайлаПОсСервераВнутри);
            }


            //////////todo такой файл УЖЕ ЕСТЬ .APK И ПЫТАЕТЬСЯ ЕЩЁ РАЗ ЗАГРУЗИТЬСЯ


        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
                   new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }



































    ////TODO метод который отпредеяеть КАКОЙ ТИП ПОДКЛЮЧЕНИ К ИНТРЕНТУ ЧЕРЕЗ WIFI ИЛИ MOBILE
    private String МетодОпределяемКакойТипПодключениеWIFIилиMobileДляСлужбы(Context КонтекстКоторыйДляСинхронизации) {

        try{

        ConnectivityManager cm = (ConnectivityManager) КонтекстКоторыйДляСинхронизации.getSystemService(Context.CONNECTIVITY_SERVICE);
        ////////
        NetworkInfo wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);


        if ( wifiInfo.isConnected()) {

            Log.d(MODEL_synchronized.class.getName(), " подключние к интренту через wifi");

            return "WIFI";
        }else{

            //

            ////////
            NetworkInfo wifiInfoMObile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            if (wifiInfoMObile.isConnected()) {

                Log.d(MODEL_synchronized.class.getName(), " подключние к интренту через mobile");

                return "Mobile";
            }
        }



    } catch (Exception e) {
        //  Block of code to handle errors
        e.printStackTrace();
        ///метод запись ошибок в таблицу
        Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                + Thread.currentThread().getStackTrace()[2].getLineNumber());
        new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                Thread.currentThread().getStackTrace()[2].getLineNumber());
    }

        return null;
    }

    ///TODO  конец  методы перерд перед  СИНХРОНИЗАЦИЯ ///TODO СИНХРОНИЗАЦИЯ при запуске прилиложения













    @Override
    public void onDestroy() {

        Log.d(this.getClass().getName(), " Остановилась .....Служба ООО Союз Автодор");

        super.onDestroy();


        Log.d(getApplicationContext().getClass().getName(), " Стоп СЛУЖБА СЛУЖБА  Обновление ПО  ");


        /*        Intent notificationIntentПовторныйЗапускСлужбы = new Intent(getApplicationContext(), Service_Update_ОбновлениеПО.class);
        notificationIntentПовторныйЗапускСлужбы.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK );
       // notificationIntentПовторныйЗапускСлужбы.addCategory(Intent.CATEGORY_LAUNCHER);
        notificationIntentПовторныйЗапускСлужбы.setAction("ru.startandroid.notifications.action_delete");
        notificationIntentПовторныйЗапускСлужбы.putExtra("СлужбуЗапустил", "BroadcastReceiver");
        ///////
        PendingIntent ПовторныйЗапуск = null;

        ПовторныйЗапуск = PendingIntent.getService(getApplicationContext(),
                4, notificationIntentПовторныйЗапускСлужбы,
                PendingIntent.FLAG_ONE_SHOT); //PendingIntent.FLAG_UPDATE_CURRENT


        Log.d(getApplicationContext().getClass().getName(), " PendingIntent Запуск Службы после СТОП  СЛУЖБА СЛУЖБА Обновление ПО  ");
*/










    }/**/










    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        ///
        Log.d(getApplicationContext().getClass().getName(), " ЗАПУСК СЛУЖБА Внутри службы   МЕТОД ОБНОВЛЕНИЕ ПО onBind  ОбновлениеБиндинг : "+ "--" + new Date());/////
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        try {



            ///
            Log.d(getApplicationContext().getClass().getName(), " ЗАПУСК СЛУЖБА Внутри службы   МЕТОД ОБНОВЛЕНИЕ ПО  " + "--" + new Date());/////




            МетодНачалаЗапускаОбновленияПО();
            /////








        } catch (Exception e) {
            //  Block of code to handle errors
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(), this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }


    }





























    @UiThread
    protected void СообщениеКотороеСообщаетПользователюЧТоНАлдоУстановитьНовуюВерисюПО() {
        ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ///////СОЗДАЕМ ДИАЛОГ ДА ИЛИ НЕТ


    // TODO: 23.03.2021 ПЫТАЕМСЯ ЗАПУСТИТЬ СООБЩЕНИЕ ИЗ ТРЕЗХ АКТИВТИ
              Activity КонтексСлужбыОбновления = null;




                if(MainActivity_Face_App.КонтекстFaceAppВнешний!=null){
                    КонтексСлужбыОбновления= (Activity) MainActivity_Face_App.КонтекстFaceAppВнешний;


                }else if(MainActivity_List_Tabels.КонтекстИсторииВсехТабелейВыбранныхВнешний!=null){
                    КонтексСлужбыОбновления= (Activity) MainActivity_List_Tabels.КонтекстИсторииВсехТабелейВыбранныхВнешний;

                }else if(MainActivity_List_Employees_Current_Tabel.КонтекстСотрудникиДляТабеляВнешний!=null){

                    КонтексСлужбыОбновления= (Activity) MainActivity_List_Employees_Current_Tabel.КонтекстСотрудникиДляТабеляВнешний;

                    }else if(MainActivity_Tabel_Only_Single_Employee.КонтекстОдногоСотрудикаВТабелеВнешний!=null){

                    КонтексСлужбыОбновления= (Activity) MainActivity_Tabel_Only_Single_Employee.КонтекстОдногоСотрудикаВТабелеВнешний;

                  }else if(MainActivity_Settings.КонтекстWIFIВнешний!=null) {
                    КонтексСлужбыОбновления= (Activity) MainActivity_Settings.КонтекстWIFIВнешний;
                }else{
                    КонтексСлужбыОбновления= (Activity) getApplicationContext();

                }


    //////





    if (КонтексСлужбыОбновления!=null) {

        Log.d(this.getClass().getName(), "КонтексСлужбыОбновления " + КонтексСлужбыОбновления.toString());


        Activity finalКонтексСлужбыОбновления = КонтексСлужбыОбновления;
        КонтексСлужбыОбновления.runOnUiThread(new Runnable() {
            @Override
            public void run() {


                // TODO: 03.10.2021  САМА НЕПОСТРЕДСТВЕННА ПОЯЛВЕНИЯ ФОРМА С ПРОГРАММОЙ ДЛЯ ПОЛЗОВАТЕЛЯ



                МетодВизуалиацииПОлученогоОбновлениеПО(finalКонтексСлужбыОбновления);
                
            }
        });


        
        
        
        
        
    }


}

    private void МетодВизуалиацииПОлученогоОбновлениеПО(Activity контексСлужбыОбновления) {
        try {
//////сам вид
            final AlertDialog alertDialog =new MaterialAlertDialogBuilder(контексСлужбыОбновления)///       final AlertDialog alertDialog =new AlertDialog.Builder( MainActivity_Face_App.КонтекстFaceApp)
                    .setTitle("Установщик")
                    .setMessage("Пришло Обновление,"
                            +"\n"+"ПО Табельный учёт ,"
                            +"\n" +"новая версия. "+ СервернаяВерсияПОВнутри+","
                            +"\n"+"реализовано: Новая версия"+"\n")
                    .setPositiveButton("Установить", null)
                    .setNegativeButton("Позже", null)
                    .setIcon(R.drawable.icon_dsu1_updates_po_success)
                    .show();
/////////кнопка
            final Button MessageBoxUpdateОбновитьПО = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            Activity finalКонтексСлужбыОбновления = контексСлужбыОбновления;
            MessageBoxUpdateОбновитьПО.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог


                    Log.d(this.getClass().getName(), "Установка Обновления .APK СЛУЖБА");


                    //////
                    String ФинальныйПутьДляЗагрузкиФайлаОбновения = null;
                    ////
                    if (  Build.VERSION.SDK_INT >= 30)   {
                        ФинальныйПутьДляЗагрузкиФайлаОбновения = getApplicationContext().getExternalFilesDir(null) + "/";
                    }else{

                        ФинальныйПутьДляЗагрузкиФайлаОбновения = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/";

                    }


                    String НазваниеФайлаОбновления = "update_dsu1.apk";

                    ////
                    ФинальныйПутьДляЗагрузкиФайлаОбновения += НазваниеФайлаОбновления;










                    Uri URIПутиДляЗагрузкиФайловЧерезПровайдер = FileProvider.getUriForFile(getApplicationContext(),
                            getApplicationContext().getPackageName() + ".provider",
                            new File(ФинальныйПутьДляЗагрузкиФайлаОбновения));







                    Intent intentОбновлениеПО = new Intent(Intent.ACTION_INSTALL_PACKAGE);
                    ////////
                    intentОбновлениеПО.setDataAndType(URIПутиДляЗагрузкиФайловЧерезПровайдер, "application/vnd.android.package-archive");
                    intentОбновлениеПО.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION| Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                            | Intent.FLAG_ACTIVITY_NEW_TASK  );
                    intentОбновлениеПО.putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true);
                    intentОбновлениеПО.putExtra( Intent.EXTRA_STREAM, URIПутиДляЗагрузкиФайловЧерезПровайдер);
                    // intent.addCategory("android.intent.category.APP_MARKET");

                    // TODO: 18.05.2021 PackegeManger проверка может ли с указаными выше условиями загрузиться файл

// подтвердите, что устройство может открыть этот файл!
                    PackageManager МеханизмПроверкиЗапуститьсяНашИнтентИлиНЕт = getApplicationContext().getPackageManager();

                    ///
                    if (intentОбновлениеПО.resolveActivity(МеханизмПроверкиЗапуститьсяНашИнтентИлиНЕт) != null) {
                        //////todo запуск установкика .apk
                ///     getApplicationContext(). startActivity(intent); ////   ((Activity) MainActivity_Face_App.КонтекстFaceApp). startActivity(intent);//  MainActivity_Face_App.КонтекстFaceApp. startActivity(intent);

                        Log.d(this.getClass().getName(), " СЛУЖБА УСТАНОВКА... ОБНОВЛЕНИЯ НА ТЕЛЕФОН (.APK файл)  МеханизмПроверкиЗапуститьсяНашИнтентИлиНЕт "  + МеханизмПроверкиЗапуститьсяНашИнтентИлиНЕт);





                        ////TODO непосрдствено сам запуск новго .apk файла



                        //////todo Удаляем все зайдгний план установкика .apk




                            finalКонтексСлужбыОбновления. startActivity(intentОбновлениеПО);

                            ((Activity) finalКонтексСлужбыОбновления).finishAndRemoveTask(); //// ((Activity) MainActivity_Face_App.КонтекстFaceApp).finish();







                 ///  МетодДополнительногоУдалениеФайлов();

                        /////

                        // stopService(new Intent(КонтекстFaceApp, Service_Update_ОбновлениеПО.class));
                        // stopSelf();



                        ///TODO УСТАНАВЛИВАЕМ ФЛАГ ЧТО МУ УЖЕ СКАЧИВАЛИ ЭТО ПРИЛОЖЕНИЕ



                    }else{
                        ///////TODO ОСТАНАВЛИВАЕМ СЛУЖБУ ЧЕРЕЗ 20 СЕКУНД
                        Log.d(this.getClass().getName(), "Ошибка файл .APK не устнаовлен ОШИБКА СЛУЖБА ОБНОВЛЕНИЯ ...  " + new Date() + " МеханизмПроверкиЗапуститьсяНашИнтентИлиНЕт " +МеханизмПроверкиЗапуститьсяНашИнтентИлиНЕт );
                    }


                    ///////////

                }
            });

            final Button MessageBoxUpdateНеуСтанавливатьПО= alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            MessageBoxUpdateНеуСтанавливатьПО.setOnClickListener(new View.OnClickListener() {
                ///MessageBoxUpdate метод CLICK для DIALOBOX
                @Override
                public void onClick(View v) {
                    //удаляем с экрана Диалог
                    alertDialog.dismiss();
                    Log.d(this.getClass().getName(), " создание нового сотрудника ");



                    ///////////

                }
            });





        } catch (Exception e) {
            e.printStackTrace();
            ///метод запись ошибок в таблицу
            Log.e(this.getClass().getName(), "Ошибка " + e + " Метод :" + Thread.currentThread().getStackTrace()[2].getMethodName() + " Линия  :"
                    + Thread.currentThread().getStackTrace()[2].getLineNumber());
            // TODO: 01.09.2021 метод вызова
            new   Class_Generation_Errors(getApplicationContext()).МетодЗаписиВЖурналНовойОшибки(e.toString(),
                    this.getClass().getName(), Thread.currentThread().getStackTrace()[2].getMethodName(),
                    Thread.currentThread().getStackTrace()[2].getLineNumber());
        }

    }


}











